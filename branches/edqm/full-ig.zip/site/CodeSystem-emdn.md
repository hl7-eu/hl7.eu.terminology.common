# EMDN CodeSystem - EU Common Terminologies v0.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EMDN CodeSystem**

## CodeSystem: EMDN CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:http://hl7europe.org/fhir/terminology/ehdsi/ValueSet/eHDSIMedicalDevice | *Version*:0.4.0 |
| Active as of 2026-10-24 | *Computable Name*:emdn |
| *Other Identifiers:*OID:1.3.6.1.4.1.12559.11.10.1.3.1.44.6 | |

 
European Medical Device Nomenclature 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "emdn",
  "url" : "http://hl7europe.org/fhir/terminology/ehdsi/ValueSet/eHDSIMedicalDevice",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.3.6.1.4.1.12559.11.10.1.3.1.44.6"
  }],
  "version" : "0.4.0",
  "name" : "emdn",
  "title" : "EMDN CodeSystem",
  "status" : "active",
  "date" : "2026-10-24T21:00:57+00:00",
  "publisher" : "HL7 Europe",
  "contact" : [{
    "name" : "HL7 Europe",
    "telecom" : [{
      "system" : "url",
      "value" : "http://hl7europe.org"
    }]
  }],
  "description" : "European Medical Device Nomenclature",
  "content" : "complete",
  "count" : 8453,
  "concept" : [{
    "code" : "A",
    "display" : "DEVICES FOR ADMINISTRATION, WITHDRAWAL AND COLLECTION"
  },
  {
    "code" : "A01",
    "display" : "NEEDLES",
    "concept" : [{
      "code" : "A0101",
      "display" : "NEEDLES FOR INFUSION AND SAMPLING",
      "concept" : [{
        "code" : "A010101",
        "display" : "HYPODERMIC NEEDLES",
        "concept" : [{
          "code" : "A01010101",
          "display" : "HYPODERMIC SYRINGE NEEDLES",
          "concept" : [{
            "code" : "A0101010101",
            "display" : "HYPODERMIC SYRINGE NEEDLES, WITH SAFETY SYSTEMS"
          },
          {
            "code" : "A0101010102",
            "display" : "HYPODERMIC SYRINGE NEEDLES, W/O SAFETY SYSTEMS"
          }]
        },
        {
          "code" : "A01010102",
          "display" : "HYPODERMIC PEN NEEDLES",
          "concept" : [{
            "code" : "A0101010201",
            "display" : "HYPODERMIC PEN NEEDLES, WITH SAFETY SYSTEMS"
          },
          {
            "code" : "A0101010202",
            "display" : "HYPODERMIC PEN NEEDLES, W/O SAFETY SYSTEMS"
          }]
        },
        {
          "code" : "A01010199",
          "display" : "HYPODERMIC NEEDLES - OTHER"
        }]
      },
      {
        "code" : "A010102",
        "display" : "BUTTERFLY NEEDLES",
        "concept" : [{
          "code" : "A01010201",
          "display" : "BUTTERFLY NEEDLES, WITH SAFETY SYSTEMS"
        },
        {
          "code" : "A01010202",
          "display" : "BUTTERFLY NEEDLES, W/O SAFETY SYSTEMS"
        }]
      },
      {
        "code" : "A010103",
        "display" : "NEEDLES AND KITS FOR IMPLANTABLE SYSTEMS (PORT)",
        "concept" : [{
          "code" : "A01010301",
          "display" : "NEEDLES AND KITS FOR IMPLANTABLE SYSTEMS (PORT), WITH SAFETY SYSTEMS"
        },
        {
          "code" : "A01010302",
          "display" : "NEEDLES AND KITS FOR IMPLANTABLE SYSTEMS (PORT), W/O SAFETY SYSTEMS"
        }]
      },
      {
        "code" : "A010104",
        "display" : "NEEDLES FOR VIAL COLLECTION"
      },
      {
        "code" : "A010105",
        "display" : "NEEDLES FOR COLLECTION UNDER VACUUM",
        "concept" : [{
          "code" : "A01010501",
          "display" : "NEEDLES FOR COLLECTION UNDER VACUUM, WITH SAFETY SYSTEMS"
        },
        {
          "code" : "A01010502",
          "display" : "NEEDLES FOR COLLECTION UNDER VACCUM, W/O SAFETY SYSTEMS"
        }]
      },
      {
        "code" : "A010106",
        "display" : "NEEDLES AND KITS FOR RECONSTRUCTIVE FILLING"
      },
      {
        "code" : "A010180",
        "display" : "NEEDLES FOR INFUSION AND COLLECTION - ACCESSORIES",
        "concept" : [{
          "code" : "A01018001",
          "display" : "HOLDERS FOR COLLECTION NEEDLES"
        },
        {
          "code" : "A01018099",
          "display" : "NEEDLES FOR INFUSION AND COLLECTION - OTHER ACCESSORIES"
        }]
      },
      {
        "code" : "A010199",
        "display" : "NEEDLES FOR INFUSION AND COLLECTION - OTHER"
      }]
    },
    {
      "code" : "A0102",
      "display" : "BIOPSY NEEDLES AND KITS",
      "concept" : [{
        "code" : "A010201",
        "display" : "NEEDLES AND KITS - HISTOLOGICAL AND CYTOLOGICAL BIOPSY OF SOFT TISSUES",
        "concept" : [{
          "code" : "A01020101",
          "display" : "SHEARING BIOPSY NEEDLES AND KITS",
          "concept" : [{
            "code" : "A0102010101",
            "display" : "SHEARING BIOPSY NEEDLES"
          },
          {
            "code" : "A0102010102",
            "display" : "SHEARING BIOPSY GUNS"
          }]
        },
        {
          "code" : "A01020102",
          "display" : "ASPIRATION FINE NEEDLES AND KITS"
        },
        {
          "code" : "A01020199",
          "display" : "NEEDLES AND KITS FOR HISTOLOGICAL AND CYTOLOGICAL BIOPSY OF SOFT TISSUES - OTHER"
        }]
      },
      {
        "code" : "A010202",
        "display" : "BONE MARROW BIOPSY NEEDLES AND KITS",
        "concept" : [{
          "code" : "A01020201",
          "display" : "ILIAC-STERNAL BIOPSY NEEDLES AND KITS"
        },
        {
          "code" : "A01020202",
          "display" : "BONE MARROW EXPLANT NEEDLES AND KITS"
        },
        {
          "code" : "A01020203",
          "display" : "VERTEBRAL AND PARAVERTEBRAL BIOPSY NEEDLES AND KITS"
        },
        {
          "code" : "A01020204",
          "display" : "MOTORISED BONE BIOPSY KITS"
        },
        {
          "code" : "A01020299",
          "display" : "NEEDLES AND KITS - BONE MARROW BIOPSY - OTHER"
        }]
      },
      {
        "code" : "A010203",
        "display" : "CUTANEOUS BIOPSY NEEDLES AND KITS",
        "concept" : [{
          "code" : "A01020301",
          "display" : "CUTANEOUS BIOPSY NEEDLES"
        },
        {
          "code" : "A01020302",
          "display" : "CUTANEOUS BIOPSY PUNCHES, SINGLE-USE"
        },
        {
          "code" : "A01020303",
          "display" : "CUTANEOUS BIOPSY CURETTES, SINGLE-USE"
        },
        {
          "code" : "A01020399",
          "display" : "CUTANEOUS BIOPSY NEEDLES AND KITS - OTHER"
        }]
      },
      {
        "code" : "A010204",
        "display" : "AMNIOCENTESIS AND VILLOCENTESIS NEEDLES AND KITS",
        "concept" : [{
          "code" : "A01020401",
          "display" : "AMNIOCENTESIS NEEDLES AND KITS"
        },
        {
          "code" : "A01020402",
          "display" : "VILLOCENTESIS NEEDLES AND KITS"
        }]
      },
      {
        "code" : "A010205",
        "display" : "PERENDOSCOPIC BIOPSY NEEDLES AND KITS (NON-GASTROINTESTINAL APPARATUS)",
        "concept" : [{
          "code" : "A01020501",
          "display" : "PERENDOSCOPIC BRONCHIAL BIOPSY NEEDLES AND KITS"
        },
        {
          "code" : "A01020502",
          "display" : "LAPAROSCOPIC AND THORACOSCOPIC BIOPSY NEEDLES AND KITS"
        },
        {
          "code" : "A01020599",
          "display" : "PERENDOSCOPIC BIOPSY NEEDLES AND KITS (NON-GASTROINTESTINAL APPARATUS) - OTHER"
        }]
      },
      {
        "code" : "A010206",
        "display" : "CEREBRAL BIOPSY NEEDLES AND KITS"
      },
      {
        "code" : "A010207",
        "display" : "PULMONARY BIOPSY NEEDLES AND KITS"
      },
      {
        "code" : "A010299",
        "display" : "BIOPSY NEEDLES AND KITS - OTHER"
      }]
    },
    {
      "code" : "A0103",
      "display" : "ANAESTHESIA NEEDLES AND KITS",
      "concept" : [{
        "code" : "A010301",
        "display" : "SPINAL AND EPIDURAL ANAESTHESIA NEEDLES AND KITS",
        "concept" : [{
          "code" : "A01030101",
          "display" : "SPINAL ANAESTHESIA NEEDLES AND KITS"
        },
        {
          "code" : "A01030102",
          "display" : "EPIDURAL ANAESTHESIA NEEDLES AND KITS"
        },
        {
          "code" : "A01030103",
          "display" : "COMBINED EPIDURAL AND SPINAL ANAESTHESIA NEEDLES AND KITS"
        }]
      },
      {
        "code" : "A010302",
        "display" : "PLEXUS BLOCK NEEDLES AND KITS"
      },
      {
        "code" : "A010399",
        "display" : "ANAESTHESIA NEEDLES AND KIT - OTHER"
      }]
    },
    {
      "code" : "A0104",
      "display" : "DIALYSIS NEEDLES",
      "concept" : [{
        "code" : "A010401",
        "display" : "ARTERIOVENOUS FISTULA NEEDLES"
      },
      {
        "code" : "A010480",
        "display" : "DIALYSIS NEEDLES - ACCESSORIES"
      },
      {
        "code" : "A010499",
        "display" : "DIALYSIS NEEDLES - OTHER"
      }]
    },
    {
      "code" : "A0105",
      "display" : "OPHTHALMOLOGY INJECTION NEEDLES AND KITS",
      "concept" : [{
        "code" : "A010501",
        "display" : "ANTERIOR EYE CHAMBER NEEDLES"
      },
      {
        "code" : "A010502",
        "display" : "EYE IRRIGATION NEEDLES"
      },
      {
        "code" : "A010503",
        "display" : "PERIBULBAR NEEDLES"
      },
      {
        "code" : "A010504",
        "display" : "RETROBULBAR NEEDLES"
      },
      {
        "code" : "A010505",
        "display" : "ENDOCULAR INJECTION NEEDLES"
      },
      {
        "code" : "A010506",
        "display" : "ENDOCULAR ASPIRATION CANNULA NEEDLES"
      },
      {
        "code" : "A010599",
        "display" : "OPHTHALMOLOGY INJECTION NEEDLES AND KITS - OTHER"
      }]
    },
    {
      "code" : "A0106",
      "display" : "DENTISTRY NEEDLES AND KITS",
      "concept" : [{
        "code" : "A010601",
        "display" : "CARPULE NEEDLES"
      },
      {
        "code" : "A010602",
        "display" : "DENTAL IRRIGATION NEEDLES"
      },
      {
        "code" : "A010699",
        "display" : "DENTISTRY NEEDLES AND KITS - OTHER"
      }]
    },
    {
      "code" : "A0180",
      "display" : "NEEDLES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES",
      "concept" : [{
        "code" : "A018001",
        "display" : "NEEDLE CAPS"
      },
      {
        "code" : "A018002",
        "display" : "NEEDLE GUIDES"
      },
      {
        "code" : "A018003",
        "display" : "NEEDLE INTRODUCERS"
      },
      {
        "code" : "A018004",
        "display" : "NEEDLE CONNECTORS AND ADAPTERS"
      },
      {
        "code" : "A018005",
        "display" : "NEEDLE COUNTING CONTAINERS"
      },
      {
        "code" : "A018006",
        "display" : "HYPODERMIC NEEDLES PEN INJECTORS"
      },
      {
        "code" : "A018099",
        "display" : "NEEDLES - OTHER ACCESSORIES"
      }]
    },
    {
      "code" : "A0190",
      "display" : "NEEDLES FOR OTHER PROCEDURES",
      "concept" : [{
        "code" : "A019001",
        "display" : "BLUNT NEEDLES"
      },
      {
        "code" : "A019002",
        "display" : "ACUPUNCTURE NEEDLES"
      },
      {
        "code" : "A019003",
        "display" : "ALCOHOLISATION NEEDLES"
      },
      {
        "code" : "A019004",
        "display" : "OPEN SURGERY CHOLANGIOGRAPHY NEEDLES AND KITS"
      },
      {
        "code" : "A019005",
        "display" : "GALACTOGRAPHY NEEDLES AND KITS"
      },
      {
        "code" : "A019006",
        "display" : "MESOTHERAPY NEEDLES"
      },
      {
        "code" : "A019007",
        "display" : "SCLEROTHERAPY NEEDLES AND KITS"
      },
      {
        "code" : "A019008",
        "display" : "MEDICAL PROCEDURES TATTOOING NEEDLES (NOT ENDOSCOPIC)"
      },
      {
        "code" : "A019009",
        "display" : "DRAINAGE NEEDLES"
      },
      {
        "code" : "A019010",
        "display" : "ANGIOGRAPHY NEEDLES"
      },
      {
        "code" : "A019011",
        "display" : "INTRAOSSEOUS INFUSION AND VERTEBROPLASTY INFUSION NEEDLES AND KITS"
      },
      {
        "code" : "A019012",
        "display" : "BREAST NODULES AND OTHER STRUCTURES LOCALISATION NEEDLES AND SYSTEMS"
      },
      {
        "code" : "A019013",
        "display" : "PERCUTANEOUS NEEDLES"
      },
      {
        "code" : "A019014",
        "display" : "LUMBAR PUNCTURE NEEDLES AND KITS"
      },
      {
        "code" : "A019015",
        "display" : "PERI- AND NEO-NATAL EPICRANIAL NEEDLES"
      },
      {
        "code" : "A019016",
        "display" : "BRACHYTHERAPY NEEDLES"
      },
      {
        "code" : "A019099",
        "display" : "NEEDLES FOR OTHER PROCEDURES - OTHER"
      }]
    },
    {
      "code" : "A0199",
      "display" : "NEEDLES - OTHER"
    }]
  },
  {
    "code" : "A02",
    "display" : "SYRINGES",
    "concept" : [{
      "code" : "A0201",
      "display" : "SINGLE-USE SYRINGES",
      "concept" : [{
        "code" : "A020101",
        "display" : "LOSS-OF-RESISTANCE SYRINGES"
      },
      {
        "code" : "A020102",
        "display" : "INFUSION AND IRRIGATION SYRINGES, SINGLE-USE",
        "concept" : [{
          "code" : "A02010201",
          "display" : "INFUSION AND IRRIGATION SYRINGES, LUER CONE, SINGLE-USE",
          "concept" : [{
            "code" : "A0201020101",
            "display" : "INFUSION AND IRRIGATION SYRINGES, 2-PIECE LUER CONE, SINGLE-USE",
            "concept" : [{
              "code" : "A020102010101",
              "display" : "INFUSION AND IRRIGATION SYRINGES, 2-PIECE LUER CONE, 2-PIECE WITH NEEDLE, SINGLE-USE"
            },
            {
              "code" : "A020102010102",
              "display" : "INFUSION AND IRRIGATION SYRINGES, 2-PIECE LUER CONE, 2-PIECE WITHOUT NEEDLE, SINGLE-USE"
            }]
          },
          {
            "code" : "A0201020102",
            "display" : "INFUSION AND IRRIGATION SYRINGES, LUER CONE, 3-PIECE",
            "concept" : [{
              "code" : "A020102010201",
              "display" : "INFUSION AND IRRIGATION SYRINGES, LUER CONE, 3-PIECE WITH NEEDLE, SINGLE-USE"
            },
            {
              "code" : "A020102010202",
              "display" : "INFUSION AND IRRIGATION SYRINGES, LUER CONE, 3-PIECE WITHOUT NEEDLE, SINGLE-USE"
            }]
          }]
        },
        {
          "code" : "A02010202",
          "display" : "INFUSION AND IRRIGATION SYRINGES, LUER LOCK CONE, SINGLE-USE",
          "concept" : [{
            "code" : "A0201020201",
            "display" : "INFUSION AND IRRIGATION SYRINGES, LUER LOCK CONE, 3-PIECE, SINGLE-USE",
            "concept" : [{
              "code" : "A020102020101",
              "display" : "INFUSION AND IRRIGATION SYRINGES, LUER LOCK CONE, 3-PIECE WITH NEEDLE, SINGLE-USE"
            },
            {
              "code" : "A020102020102",
              "display" : "INFUSION AND IRRIGATION SYRINGES, LUER LOCK CONE, 3-PIECE WITHOUT NEEDLE, SINGLE-USE"
            }]
          }]
        },
        {
          "code" : "A02010203",
          "display" : "INFUSION AND IRRIGATION SYRINGES, CATHETER CONE, SINGLE-USE"
        },
        {
          "code" : "A02010204",
          "display" : "INFUSION AND IRRIGATION SYRINGES, WITHOUT CONE, WITH FIXED NEEDLE, SINGLE-USE"
        },
        {
          "code" : "A02010205",
          "display" : "INFUSION AND IRRIGATION SYRINGES WITH SAFETY SYSTEM, SINGLE-USE"
        },
        {
          "code" : "A02010299",
          "display" : "INFUSION AND IRRIGATION SYRINGES - OTHER"
        }]
      },
      {
        "code" : "A020104",
        "display" : "SYRINGES FOR INJECTORS, SINGLE-USE",
        "concept" : [{
          "code" : "A02010401",
          "display" : "SYRINGES FOR CONTRAST MEDIA INJECTOR, SINGLE-USE"
        },
        {
          "code" : "A02010499",
          "display" : "SYRINGES FOR INJECTOR, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "A020105",
        "display" : "BLOOD GAS ANALYSIS, SYRINGES WITH NEEDLES AND KITS",
        "concept" : [{
          "code" : "A02010501",
          "display" : "BLOOD GAS ANALYSIS, SYRINGES WITH NEEDLE W/O SAFETY SYSTEM AND KITS"
        },
        {
          "code" : "A02010502",
          "display" : "BLOOD GAS ANALYSIS, SYRINGES WITH SAFETY NEEDLE AND KITS"
        }]
      },
      {
        "code" : "A020106",
        "display" : "INSULIN SYRINGES, SINGLE-USE",
        "concept" : [{
          "code" : "A02010601",
          "display" : "INSULIN SYRINGES WITH FIXED NEEDLE, SINGLE-USE"
        },
        {
          "code" : "A02010602",
          "display" : "INSULIN SYRINGES W/O FIXED NEEDLES, SINGLE-USE"
        },
        {
          "code" : "A02010603",
          "display" : "INSULIN SYRINGES WITH SAFETY SYSTEM, SINGLE-USE",
          "concept" : [{
            "code" : "A0201060301",
            "display" : "INSULIN SYRINGES WITH SAFETY SYSTEMS AND FIXED NEEDLES, SINGLE-USE"
          },
          {
            "code" : "A0201060302",
            "display" : "INSULIN SYRINGES WITH SAFETY SYSTEMS W/O FIXED NEEDLE, SINGLE-USE"
          }]
        },
        {
          "code" : "A02010699",
          "display" : "INSULIN SYRINGES, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "A020107",
        "display" : "PREFILLED SYRINGES",
        "concept" : [{
          "code" : "A02010701",
          "display" : "PREFILLED SYRINGES WITH STERILE PHYSIOLOGICAL SOLUTION"
        },
        {
          "code" : "A02010702",
          "display" : "PREFILLED SYRINGES WITH STERILE WATER"
        },
        {
          "code" : "A02010799",
          "display" : "PREFILLED SYRINGES - OTHER"
        }]
      },
      {
        "code" : "A020108",
        "display" : "ENTERAL FEEDING SYRINGES"
      },
      {
        "code" : "A020109",
        "display" : "TUBERCULIN SYRINGES, SINGLE-USE"
      },
      {
        "code" : "A020199",
        "display" : "SYRINGES, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "A0202",
      "display" : "REUSABLE SYRINGES",
      "concept" : [{
        "code" : "A020201",
        "display" : "REUSABLE INFUSION SYRINGES"
      },
      {
        "code" : "A020202",
        "display" : "REUSABLE IRRIGATION SYRINGES"
      },
      {
        "code" : "A020203",
        "display" : "CARTRIDGE SYRINGES"
      },
      {
        "code" : "A020299",
        "display" : "REUSABLE SYRINGES - OTHER"
      }]
    },
    {
      "code" : "A0280",
      "display" : "SYRINGES - ACCESSORIES"
    },
    {
      "code" : "A0299",
      "display" : "SYRINGES - OTHER"
    }]
  },
  {
    "code" : "A03",
    "display" : "TUBULAR DEVICES",
    "concept" : [{
      "code" : "A0301",
      "display" : "FLOW CONTROLLERS",
      "concept" : [{
        "code" : "A030101",
        "display" : "INFUSION CONTROLLERS",
        "concept" : [{
          "code" : "A03010101",
          "display" : "INFUSION CONTROLLERS WITH OR W/O AIR INLET"
        },
        {
          "code" : "A03010102",
          "display" : "INFUSION CONTROLLERS WITH FILTER (ALSO TRANSFUSION CONTROLLERS)"
        },
        {
          "code" : "A03010103",
          "display" : "INFUSION CONTROLLERS WITH FLOW REGULATOR"
        },
        {
          "code" : "A03010104",
          "display" : "INFUSION MICRO-CONTROLLERS"
        },
        {
          "code" : "A03010105",
          "display" : "INFUSION PUMP CONTROLLERS"
        },
        {
          "code" : "A03010199",
          "display" : "INFUSION CONTROLLERS - OTHER"
        }]
      },
      {
        "code" : "A030102",
        "display" : "IRRIGATION CONTROLLERS",
        "concept" : [{
          "code" : "A03010201",
          "display" : "ARTHROSCOPIC IRRIGATION CONTROLLERS"
        },
        {
          "code" : "A03010202",
          "display" : "UROLOGICAL IRRIGATION CONTROLLERS"
        },
        {
          "code" : "A03010299",
          "display" : "IRRIGATION CONTROLLERS - OTHER"
        }]
      },
      {
        "code" : "A030103",
        "display" : "ENTERAL FEEDING CONTROLLERS",
        "concept" : [{
          "code" : "A03010301",
          "display" : "ENTERAL FEEDING GRAVITY CONTROLLERS"
        },
        {
          "code" : "A03010302",
          "display" : "ENTERAL FEEDING PUMP CONTROLLERS"
        },
        {
          "code" : "A03010399",
          "display" : "ENTERAL FEEDING CONTROLLERS - OTHER"
        }]
      },
      {
        "code" : "A030104",
        "display" : "FLOW REGULATORS"
      },
      {
        "code" : "A030105",
        "display" : "FLUIDS HEATING SYSTEMS"
      },
      {
        "code" : "A030199",
        "display" : "CONTROLLERS - OTHER"
      }]
    },
    {
      "code" : "A0302",
      "display" : "EXTENSION LINES",
      "concept" : [{
        "code" : "A030201",
        "display" : "EXTENSIONS",
        "concept" : [{
          "code" : "A03020101",
          "display" : "LOW PRESSURE EXTENSION LINES"
        },
        {
          "code" : "A03020102",
          "display" : "HIGH PRESSURE EXTENSION LINES"
        },
        {
          "code" : "A03020199",
          "display" : "EXTENSIONS - OTHER"
        }]
      }]
    },
    {
      "code" : "A0303",
      "display" : "RAPID INFUSION SYSTEMS (HIGH FLOW)"
    },
    {
      "code" : "A0304",
      "display" : "ADMINISTRATION KITS",
      "concept" : [{
        "code" : "A030401",
        "display" : "INFUSION KITS (INCLUDING THOSE VIA PUMP), SINGLE-USE",
        "concept" : [{
          "code" : "A03040101",
          "display" : "KITS FOR CONTINUOUS SUBCUTANEOUS INSULIN INFUSION"
        },
        {
          "code" : "A03040102",
          "display" : "INTRAOSSEOUS INFUSION KITS, SINGLE-USE"
        },
        {
          "code" : "A03040199",
          "display" : "INFUSION KITS (WITH OR W/O PUMP), SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "A030402",
        "display" : "IRRIGATION KITS, SINGLE-USE",
        "concept" : [{
          "code" : "A03040201",
          "display" : "BLADDER IRRIGATION KITS, SINGLE-USE"
        },
        {
          "code" : "A03040202",
          "display" : "OCULAR IRRIGATION KITS, SINGLE-USE"
        },
        {
          "code" : "A03040203",
          "display" : "PERINEAL IRRIGATION KITS, SINGLE-USE"
        },
        {
          "code" : "A03040204",
          "display" : "EAR IRRIGATION KITS, SINGLE-USE"
        },
        {
          "code" : "A03040299",
          "display" : "IRRIGATION KITS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "A030403",
        "display" : "ENTERAL NUTRITION KITS (INCLUDING THOSE VIA PUMP), SINGLE-USE"
      },
      {
        "code" : "A030499",
        "display" : "ADMINISTRATION KITS - OTHER"
      }]
    },
    {
      "code" : "A0380",
      "display" : "TUBULAR DEVICES - ACCESSORIES"
    },
    {
      "code" : "A0399",
      "display" : "TUBULAR DEVICES - OTHER"
    }]
  },
  {
    "code" : "A04",
    "display" : "SOLUTION FILTERS",
    "concept" : [{
      "code" : "A0401",
      "display" : "INFUSION AND WITHDRAWL FILTERS",
      "concept" : [{
        "code" : "A040101",
        "display" : "ADMINISTRATION AND ASPIRATION FILTERS",
        "concept" : [{
          "code" : "A04010101",
          "display" : "WITHDRAWL AND ADMINISTRATION FILTERS (0.2-1.2 MICRONS)"
        },
        {
          "code" : "A04010102",
          "display" : "ASPIRATION AND TRANSFER FILTERS (>= 5 MICRONS)"
        },
        {
          "code" : "A04010199",
          "display" : "ADMINISTRATION AND ASPIRATION FILTERS - OTHER"
        }]
      },
      {
        "code" : "A040180",
        "display" : "INFUSION AND WITHDRAWL FILTERS - ACCESSORIES"
      },
      {
        "code" : "A040199",
        "display" : "INFUSION AND WITHDRAWL FILTERS - OTHER"
      }]
    },
    {
      "code" : "A0499",
      "display" : "SOLUTION FILTERS - OTHER"
    }]
  },
  {
    "code" : "A05",
    "display" : "MECHANICAL INFUSION SYSTEMS, SINGLE-USE",
    "concept" : [{
      "code" : "A0501",
      "display" : "ELASTOMERIC SYSTEMS",
      "concept" : [{
        "code" : "A050101",
        "display" : "ELASTOMERIC SYSTEMS - FIXED FLOW",
        "concept" : [{
          "code" : "A05010101",
          "display" : "ELASTOMERIC SYSTEMS - FIXED FLOW W/O ADDITIONAL BOLUS"
        },
        {
          "code" : "A05010102",
          "display" : "ELASTOMERIC SYSTEMS - FIXED FLOW WITH ADDITIONAL BOLUS"
        }]
      },
      {
        "code" : "A050102",
        "display" : "ELASTOMERIC SYSTEMS - VARIABLE FLOW",
        "concept" : [{
          "code" : "A05010201",
          "display" : "ELASTOMERIC SYSTEMS - VARIABLE FLOW W/O ADDITIONAL BOLUS"
        },
        {
          "code" : "A05010202",
          "display" : "ELASTOMERIC SYSTEMS - VARIABLE FLOW WITH ADDITIONAL BOLUS"
        }]
      }]
    },
    {
      "code" : "A0502",
      "display" : "NON-ELASTOMERIC SYSTEMS"
    },
    {
      "code" : "A0580",
      "display" : "MECHANICAL INFUSION SYSTEMS, SINGLE-USE - ACCESSORIES"
    },
    {
      "code" : "A0599",
      "display" : "MECHANICAL INFUSION SYSTEMS, SINGLE-USE - OTHER"
    }]
  },
  {
    "code" : "A06",
    "display" : "DRAINAGE AND FLUIDS COLLECTION DEVICES",
    "concept" : [{
      "code" : "A0601",
      "display" : "SURGICAL DRAINAGE SYSTEMS",
      "concept" : [{
        "code" : "A060101",
        "display" : "VACUUM AND GRAVITY DRAINAGE SYSTEMS",
        "concept" : [{
          "code" : "A06010101",
          "display" : "DRAINAGE SYSTEMS WITH PREDEFINED SUCTION",
          "concept" : [{
            "code" : "A0601010101",
            "display" : "DRAINAGE SYSTEMS WITH REDON TYPE RIGID CONTAINER"
          },
          {
            "code" : "A0601010102",
            "display" : "DRAINAGE SYSTEMS WITH RESERVOIR"
          },
          {
            "code" : "A0601010103",
            "display" : "BELLOWS DRAINAGE SYSTEMS"
          },
          {
            "code" : "A0601010199",
            "display" : "DRAINAGE SYSTEMS WITH PREDEFINED SUCTION - OTHER"
          }]
        },
        {
          "code" : "A06010102",
          "display" : "DRAINAGE SYSTEMS WITH ADJUSTABLE SUCTION",
          "concept" : [{
            "code" : "A0601010201",
            "display" : "DRAINAGE SYSTEMS WITH ADJUSTABLE SUCTION AND COLLECTION CHAMBER"
          },
          {
            "code" : "A0601010299",
            "display" : "DRAINAGE SYSTEMS WITH ADJUSTABLE SUCTION - OTHER"
          }]
        },
        {
          "code" : "A06010103",
          "display" : "CANNULAS AND TIPS FOR ASPIRATION AND IRRIGATION, SINGLE-USE"
        },
        {
          "code" : "A06010104",
          "display" : "DRAINAGE PROBES",
          "concept" : [{
            "code" : "A0601010401",
            "display" : "THORACIC DRAINAGES (STRAIGHT AND ANGLED)"
          },
          {
            "code" : "A0601010402",
            "display" : "CYLINDRICAL OR CIRCULAR DRAINAGES (STRAIGHT AND T-SHAPED)"
          },
          {
            "code" : "A0601010403",
            "display" : "FLAT AND LAMELLAR DRAINAGES"
          },
          {
            "code" : "A0601010499",
            "display" : "DRAINAGE PROBES - OTHER"
          }]
        },
        {
          "code" : "A06010199",
          "display" : "VACUUM AND GRAVITY DRAINAGE SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "A060102",
        "display" : "SURGICAL DRAINAGE CONNECTION MEDICAL TUBES"
      },
      {
        "code" : "A060199",
        "display" : "SURGICAL DRAINAGE SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "A0602",
      "display" : "PERCUTANEOUS DRAINAGE SYSTEMS",
      "concept" : [{
        "code" : "A060201",
        "display" : "EXTERNAL DRAINAGE CATHETERS AND KITS (ABSCESSES, GALLSTONES, CYSTS)"
      },
      {
        "code" : "A060202",
        "display" : "TROCAR DRAINAGES 3/4"
      },
      {
        "code" : "A060203",
        "display" : "PLEURAL DRAINAGES WITH VALVE AND KITS"
      },
      {
        "code" : "A060204",
        "display" : "THORACENTESIS AND PARACENTESIS DRAINAGES AND KITS"
      },
      {
        "code" : "A060205",
        "display" : "PERICARDIUM DRAINAGES AND KITS"
      },
      {
        "code" : "A060206",
        "display" : "PERITONAEAL DRAINAGES AND KITS"
      },
      {
        "code" : "A060299",
        "display" : "PERCUTANEOUS DRAINAGE SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "A0603",
      "display" : "FLUIDS COLLECTION BAGS AND SYSTEMS",
      "concept" : [{
        "code" : "A060301",
        "display" : "COLLECTION BAGS AND OTHER CONTAINERS FOR DRAINAGES AND FISTULAS, SINGLE USE"
      },
      {
        "code" : "A060302",
        "display" : "COLLECTION BAGS FOR UROLOGICAL AND ARTHROSCOPIC WASHINGS, SINGLE-USE"
      },
      {
        "code" : "A060303",
        "display" : "URINE COLLECTION SYSTEMS AND BAGS, SINGLE-USE",
        "concept" : [{
          "code" : "A06030301",
          "display" : "URINE COLLECTION BAGS"
        },
        {
          "code" : "A06030302",
          "display" : "HOURLY DIURESIS MEASUREMENT SETS"
        },
        {
          "code" : "A06030399",
          "display" : "URINE COLLECTION SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "A060304",
        "display" : "INTRA-OPERATION FLUID COLLECTION DEVICES",
        "concept" : [{
          "code" : "A06030401",
          "display" : "INTRAOPERATIVE SUCTION CONTAINERS"
        },
        {
          "code" : "A06030499",
          "display" : "INTRA-OPERATION FLUID COLLECTION DEVICES - OTHER"
        }]
      },
      {
        "code" : "A060399",
        "display" : "FLUID COLLECTION BAGS AND SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "A0680",
      "display" : "DRAINAGE AND FLUID COLLECTION DEVICES - ACCESSORIES"
    },
    {
      "code" : "A0699",
      "display" : "DRAINAGE AND FLUID COLLECTION DEVICES - OTHER"
    }]
  },
  {
    "code" : "A07",
    "display" : "ADAPTERS, CONNECTORS, RAMPS, STOPCOCKS, CAPS",
    "concept" : [{
      "code" : "A0701",
      "display" : "ADAPTERS AND CONNECTORS",
      "concept" : [{
        "code" : "A070101",
        "display" : "ASPIRATION LINES ADAPTERS AND CONNECTORS"
      },
      {
        "code" : "A070102",
        "display" : "IRRIGATION LINES ADAPTERS AND CONNECTORS"
      },
      {
        "code" : "A070103",
        "display" : "INFUSION LINES ADAPTERS AND CONNECTORS"
      },
      {
        "code" : "A070199",
        "display" : "ADAPTERS AND CONNECTORS - OTHER"
      }]
    },
    {
      "code" : "A0702",
      "display" : "RAMPS"
    },
    {
      "code" : "A0703",
      "display" : "STOPCOCKS"
    },
    {
      "code" : "A0704",
      "display" : "SYSTEMS FOR RECONSTITUTION AND ADMINISTRATION OF PHARMACEUTICALS"
    },
    {
      "code" : "A0705",
      "display" : "CAPS OR OBTURATORS",
      "concept" : [{
        "code" : "A070501",
        "display" : "CAPS OR OBTURATORS, NON-PERFORABLE"
      },
      {
        "code" : "A070502",
        "display" : "CAPS OR OBTURATORS, PERFORABLE",
        "concept" : [{
          "code" : "A07050201",
          "display" : "CAPS OR OBTURATORS, PERFORABLE WITH NEEDLE"
        },
        {
          "code" : "A07050202",
          "display" : "CAPS OR OBTURATORS, PERFORABLE WITHOUT NEEDLE"
        }]
      },
      {
        "code" : "A070599",
        "display" : "CAPS OR OBTURATORS - OTHER"
      }]
    },
    {
      "code" : "A0706",
      "display" : "ANTISEPTIC CONNECTOR PROTECTORS"
    },
    {
      "code" : "A0799",
      "display" : "ADAPTERS, CONNECTORS, RAMPS, STOPCOCKS, CAPS - OTHER"
    }]
  },
  {
    "code" : "A08",
    "display" : "NUTRITION AND INFUSION BAGS AND CONTAINERS, SINGLE-USE",
    "concept" : [{
      "code" : "A0801",
      "display" : "NUTRITION BAGS AND CONTAINERS, SINGLE-USE",
      "concept" : [{
        "code" : "A080101",
        "display" : "ENTERAL FEEDING BAGS AND CONTAINERS (INCLUDING THOSE VIA PUMP), SINGLE-USE"
      },
      {
        "code" : "A080102",
        "display" : "PARENTERAL FEEDING BAGS AND CONTAINERS (INCLUDING THOSE VIA PUMP), SINGLE-USE"
      },
      {
        "code" : "A080199",
        "display" : "NUTRITION BAGS AND CONTAINERS, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "A0802",
      "display" : "INFUSION BAGS AND CONTAINERS, SINGLE-USE",
      "concept" : [{
        "code" : "A080201",
        "display" : "INFUSION PUMP BAGS AND CONTAINERS, SINGLE-USE"
      },
      {
        "code" : "A080299",
        "display" : "INFUSION BAGS AND CONTAINERS, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "A0880",
      "display" : "NUTRITION AND INFUSION BAGS AND CONTAINERS, SINGLE-USE - ACCESSORIES",
      "concept" : [{
        "code" : "A088001",
        "display" : "PRESSURE INFUSION CUFFS, SINGLE-USE"
      },
      {
        "code" : "A088099",
        "display" : "NUTRITION AND INFUSION BAGS AND CONTAINERS, SINGLE-USE - OTHER ACCESSORIES"
      }]
    },
    {
      "code" : "A0899",
      "display" : "NUTRITION AND INFUSION BAGS AND CONTAINERS, SINGLE-USE - OTHER"
    }]
  },
  {
    "code" : "A09",
    "display" : "ORGAN CONTAINERS",
    "concept" : [{
      "code" : "A0901",
      "display" : "ORGAN COLLECTION CONTAINERS",
      "concept" : [{
        "code" : "A090101",
        "display" : "ORGAN COLLECTION BAGS"
      },
      {
        "code" : "A090199",
        "display" : "ORGAN COLLECTION CONTAINERS - OTHER"
      }]
    },
    {
      "code" : "A0980",
      "display" : "ORGAN CONTAINERS - ACCESSORIES"
    },
    {
      "code" : "A0999",
      "display" : "ORGAN CONTAINERS - OTHER"
    }]
  },
  {
    "code" : "A10",
    "display" : "ABDOMINAL OSTOMY DEVICES",
    "concept" : [{
      "code" : "A1001",
      "display" : "ONE PIECE ABDOMINAL OSTOMY DEVICES",
      "concept" : [{
        "code" : "A100101",
        "display" : "ONE PIECE COLOSTOMY BAGS",
        "concept" : [{
          "code" : "A10010101",
          "display" : "ONE-PIECE COLOSTOMY BAGS FOR NON-RETRACTED STOMA, FLAT",
          "concept" : [{
            "code" : "A1001010101",
            "display" : "ONE-PIECE COLOSTOMY BAGS FOR NON-RETRACTED STOMA, FLAT, W/O TISSUE COVER"
          },
          {
            "code" : "A1001010102",
            "display" : "ONE-PIECE COLOSTOMY BAGS FOR NON-RETRACTED STOMA, FLAT, WITH TISSUE COVER"
          }]
        },
        {
          "code" : "A10010102",
          "display" : "ONE-PIECE COLOSTOMY BAGS FOR RETRACTED STOMA, CONVEX",
          "concept" : [{
            "code" : "A1001010201",
            "display" : "ONE-PIECE COLOSTOMY BAGS FOR RETRACTED STOMA, CONVEX, W/O TISSUE COVER"
          },
          {
            "code" : "A1001010202",
            "display" : "ONE-PIECE COLOSTOMY BAGS FOR RETRACTED STOMA, CONVEX, WITH TISSUE COVER"
          }]
        }]
      },
      {
        "code" : "A100102",
        "display" : "ONE PIECE ILEOSTOMY BAGS",
        "concept" : [{
          "code" : "A10010201",
          "display" : "ONE-PIECE ILEOSTOMY BAGS FOR NON-RETRACTED STOMA, FLAT",
          "concept" : [{
            "code" : "A1001020101",
            "display" : "ONE-PIECE ILEOSTOMY BAGS FOR NON-RETRACTED STOMA, FLAT, W/O TISSUE COVER"
          },
          {
            "code" : "A1001020102",
            "display" : "ONE-PIECE ILEOSTOMY BAGS FOR NON-RETRACTED STOMA, FLAT, WITH TISSUE COVER"
          }]
        },
        {
          "code" : "A10010202",
          "display" : "ONE-PIECE ILEOSTOMY BAGS FOR RETRACTED STOMA, CONVEX",
          "concept" : [{
            "code" : "A1001020201",
            "display" : "ONE-PIECE ILEOSTOMY BAGS FOR RETRACTED STOMA, CONVEX, W/O TISSUE COVER"
          },
          {
            "code" : "A1001020202",
            "display" : "ONE-PIECE ILEOSTOMY BAGS FOR RETRACTED STOMA, CONVEX, WITH TISSUE COVER"
          }]
        }]
      },
      {
        "code" : "A100103",
        "display" : "ONE PIECE UROSTOMY BAGS",
        "concept" : [{
          "code" : "A10010301",
          "display" : "ONE-PIECE UROSTOMY BAGS FOR NON-RETRACTED STOMA, FLAT",
          "concept" : [{
            "code" : "A1001030101",
            "display" : "ONE-PIECE UROSTOMY BAGS FOR NON-RETRACTED STOMA, FLAT, W/O TISSUE COVER"
          },
          {
            "code" : "A1001030102",
            "display" : "ONE-PIECE UROSTOMY BAGS FOR NON-RETRACTED STOMA, FLAT, WITH TISSUE COVER"
          }]
        },
        {
          "code" : "A10010302",
          "display" : "ONE-PIECE UROSTOMY BAGS FOR RETRACTED STOMA, CONVEX",
          "concept" : [{
            "code" : "A1001030201",
            "display" : "ONE-PIECE UROSTOMY BAGS FOR RETRACTED STOMA, CONVEX, W/O TISSUE COVER"
          },
          {
            "code" : "A1001030202",
            "display" : "ONE-PIECE UROSTOMY BAGS FOR RETRACTED STOMA, CONVEX, WITH TISSUE COVER"
          }]
        }]
      },
      {
        "code" : "A100104",
        "display" : "EXPANSION CAPS FOR ABDOMINAL OSTOMY SYSTEMS - ONE PIECE"
      },
      {
        "code" : "A100199",
        "display" : "DEVICES FOR ABDOMINAL OSTOMY - ONE PIECE - OTHER"
      }]
    },
    {
      "code" : "A1002",
      "display" : "ABDOMINAL OOSTOMY DEVICES, TWO PIECE",
      "concept" : [{
        "code" : "A100201",
        "display" : "ABDOMINAL OSTOMY PLATES",
        "concept" : [{
          "code" : "A10020101",
          "display" : "COLOSTOMY PLATES",
          "concept" : [{
            "code" : "A1002010101",
            "display" : "COLOSTOMY PLATES, WITH NON-RETRACTED STOMA"
          },
          {
            "code" : "A1002010102",
            "display" : "COLOSTOMY PLATES, WITH RETRACTED STOMA"
          }]
        },
        {
          "code" : "A10020102",
          "display" : "ILEOSTOMY PLATES",
          "concept" : [{
            "code" : "A1002010201",
            "display" : "ILEOSTOMY PLATES, WITH NON-RETRACTED STOMA"
          },
          {
            "code" : "A1002010202",
            "display" : "ILEOSTOMY PLATES, WITH RETRACTED STOMA"
          }]
        },
        {
          "code" : "A10020103",
          "display" : "UROSTOMY PLATES",
          "concept" : [{
            "code" : "A1002010301",
            "display" : "UROSTOMY PLATES, WITH NON-RETRACTED STOMA"
          },
          {
            "code" : "A1002010302",
            "display" : "UROSTOMY PLATES WITH RETRACTED STOMA"
          }]
        },
        {
          "code" : "A10020104",
          "display" : "UNIVERSAL PLATES FOR ABDOMINAL STOMA (COLO-, ILEO-, UROSTOMY)",
          "concept" : [{
            "code" : "A1002010401",
            "display" : "UNIVERSAL PLATES FOR ABDOMINAL STOMA (COLO-, ILEO-, UROSTOMY) WITH NON-INTROFLEX STOMA"
          },
          {
            "code" : "A1002010402",
            "display" : "UNIVERSAL PLATES FOR ABDOMINAL STOMA (COLO-, ILEO-, UROSTOMY) WITH INTROFLEX STOMA"
          }]
        }]
      },
      {
        "code" : "A100202",
        "display" : "COLOSTOMY BAGS FOR TWO-PART SYSTEMS",
        "concept" : [{
          "code" : "A10020201",
          "display" : "OLOSTOMY BAGS FOR TWO-PART SYSTEMS, W/O TISSUE COVER"
        },
        {
          "code" : "A10020202",
          "display" : "COLOSTOMY BAGS FOR TWO-PART SYSTEMS, WITH TISSUE COVER"
        }]
      },
      {
        "code" : "A100203",
        "display" : "ILEOSTOMY BAGS FOR TWO-PART SYSTEMS",
        "concept" : [{
          "code" : "A10020301",
          "display" : "ILEOSTOMY BAGS FOR TWO-PART SYSTEMS, W/O TISSUE COVER"
        },
        {
          "code" : "A10020302",
          "display" : "ILEOSTOMY BAGS FOR TWO-PART SYSTEMS, WITH TISSUE COVER"
        }]
      },
      {
        "code" : "A100204",
        "display" : "UROSTOMY BAGS FOR TWO-PART SYSTEMS",
        "concept" : [{
          "code" : "A10020401",
          "display" : "UROSTOMY BAGS FOR TWO-PART SYSTEMS, W/O TISSUE COVER"
        },
        {
          "code" : "A10020402",
          "display" : "UROSTOMY BAGS FOR TWO-PART SYSTEMS, WITH TISSUE COVER"
        }]
      },
      {
        "code" : "A100205",
        "display" : "EXPANSION CAPS FOR TWO-PIECE ABDOMINAL OSTOMY SYSTEMS"
      },
      {
        "code" : "A100299",
        "display" : "TWO-PIECE ABDOMINAL OSTOMY DEVICES - OTHER"
      }]
    },
    {
      "code" : "A1003",
      "display" : "ABDOMINAL OSTOMY IRRIGATION DEVICES",
      "concept" : [{
        "code" : "A100301",
        "display" : "ABDOMINAL OSTOMY IRRIGATION KITS"
      },
      {
        "code" : "A100302",
        "display" : "ABDOMINAL OSTOMY DRAINAGE / IRRIGATION BAGS"
      },
      {
        "code" : "A100399",
        "display" : "ABDOMINAL OSTOMY IRRIGATION DEVICES - OTHER"
      }]
    },
    {
      "code" : "A1080",
      "display" : "ABDOMINAL OSTOMY DEVICES - ACCESSORIES",
      "concept" : [{
        "code" : "A108001",
        "display" : "RINGS / BEZELS / PLATES FOR PERISTOMAL SKIN"
      },
      {
        "code" : "A108002",
        "display" : "PROTECTIVE CREAMS / GELS FOR PERISTOMAL SKIN"
      },
      {
        "code" : "A108003",
        "display" : "PROTECTIVE POWDERS FOR PERISTOMAL SKIN"
      },
      {
        "code" : "A108004",
        "display" : "PROTECTIVE FILMS / SPRAYS FOR PERISTOMAL SKIN"
      },
      {
        "code" : "A108005",
        "display" : "DEVICES FOR THE REMOVAL OF ADHESIVES FROM THE PERISTOMAL SKIN"
      },
      {
        "code" : "A108006",
        "display" : "ABDOMINAL OSTOMY SUPPORT BELTS"
      },
      {
        "code" : "A108007",
        "display" : "ABDOMINAL OSTOMY IRRIGATION CONES"
      },
      {
        "code" : "A108008",
        "display" : "ADHESIVES FOR ABDOMINAL OSTOMY DEVICES"
      },
      {
        "code" : "A108009",
        "display" : "ABDOMINAL OSTOMY DILATORS"
      },
      {
        "code" : "A108099",
        "display" : "ACCESSORY DEVICES FOR ABDOMINAL OSTOMY - OTHER"
      }]
    },
    {
      "code" : "A1099",
      "display" : "ABDOMINAL OSTOMY DEVICES - OTHER"
    }]
  },
  {
    "code" : "A11",
    "display" : "SAMPLE COLLECTION SWABS",
    "concept" : [{
      "code" : "A1101",
      "display" : "SAMPLE COLLECTION NEUTRAL SWABS"
    },
    {
      "code" : "A1102",
      "display" : "SAMPLE COLLECTION SWABS WITH TRANSPORT MEDIUM"
    }]
  },
  {
    "code" : "A12",
    "display" : "SAMPLE COLLECTION SPATULAS"
  },
  {
    "code" : "A13",
    "display" : "APPLICATORS FOR DRUGS AND MEDICAL DEVICES NOT PRESENT IN OTHER CLASSES"
  },
  {
    "code" : "A99",
    "display" : "DEVICES FOR ADMINISTRATION, WITHDRAWAL AND COLLECTION - OTHER"
  },
  {
    "code" : "B",
    "display" : "HAEMATOLOGY AND HAEMOTRANSFUSION DEVICES"
  },
  {
    "code" : "B01",
    "display" : "BLOOD BAGS AND KITS",
    "concept" : [{
      "code" : "B0101",
      "display" : "BLOOD COLLECTION BAGS AND KITS",
      "concept" : [{
        "code" : "B010101",
        "display" : "AUTOLOGOUS BLOOD COLLECTION BAGS",
        "concept" : [{
          "code" : "B01010101",
          "display" : "AUTOTRANSFUSION BAGS, WITH FILTERS AND KITS",
          "concept" : [{
            "code" : "B0101010101",
            "display" : "AUTOTRANSFUSION DOUBLE BAGS, WITH FILTERS AND KITS"
          },
          {
            "code" : "B0101010199",
            "display" : "AUTOTRANSFUSION BAGS, WITH FILTERS AND KITS - OTHER"
          }]
        },
        {
          "code" : "B01010102",
          "display" : "AUTOTRANSFUSION BAGS, W/O FILTERS AND KITS",
          "concept" : [{
            "code" : "B0101010201",
            "display" : "AUTOTRANSFUSION SINGULAR BAGS, W/O FILTERS AND KITS"
          },
          {
            "code" : "B0101010202",
            "display" : "AUTOTRANSFUSION DOUBLE BAGS, W/O FILTERS AND KITS"
          },
          {
            "code" : "B0101010203",
            "display" : "AUTOTRANSFUSION TRIPLE BAGS, W/O FILTERS AND KITS"
          },
          {
            "code" : "B0101010299",
            "display" : "AUTOTRANSFUSION BAGS, W/O FILTERS AND KITS - OTHER"
          }]
        }]
      },
      {
        "code" : "B010102",
        "display" : "HOMOLOGOUS DONOR BLOOD COLLECTION BAGS AND KITS",
        "concept" : [{
          "code" : "B01010201",
          "display" : "DONOR BLOOD COLLECTION BAGS, WITH FILTERS AND KITS",
          "concept" : [{
            "code" : "B0101020101",
            "display" : "DONOR BLOOD COLLECTION QUADRUPLE BAGS, WITH FILTERS AND KITS"
          },
          {
            "code" : "B0101020102",
            "display" : "DONOR BLOOD COLLECTION QUINTUPLE BAGS, WITH FILTERS AND KITS"
          },
          {
            "code" : "B0101020199",
            "display" : "DONOR BLOOD COLLECTION BAGS AND KITS, WITH FILTERS - OTHER"
          }]
        },
        {
          "code" : "B01010202",
          "display" : "DONOR BLOOD COLLECTION BAGS, W/O FILTERS AND KITS - OTHER",
          "concept" : [{
            "code" : "B0101020201",
            "display" : "DONOR BLOOD COLLECTION TRIPLE BAGS, W/O FILTERS AND KIT"
          },
          {
            "code" : "B0101020202",
            "display" : "DONOR BLOOD COLLECTION QUADRUPLE BAGS, W/O FILTERS AND KITS"
          },
          {
            "code" : "B0101020299",
            "display" : "DONOR BLOOD COLLECTION BAGS W/O FILTERS AND KITS - OTHER"
          }]
        }]
      },
      {
        "code" : "B010199",
        "display" : "BLOOD COLLECTION BAGS AND KITS - OTHER"
      }]
    },
    {
      "code" : "B0102",
      "display" : "BLOOD TRANSFER BAGS AND KITS",
      "concept" : [{
        "code" : "B010201",
        "display" : "WHOLE BLOOD, RED BLOOD CELLS OR PLASMA TRANSFER BAGS AND KITS"
      },
      {
        "code" : "B010202",
        "display" : "PLATELETS CONCENTRATE TRANSFER BAGS AND KITS"
      },
      {
        "code" : "B010299",
        "display" : "BLOOD TRANSFER BAGS AND KITS - OTHER"
      }]
    },
    {
      "code" : "B0103",
      "display" : "MEDULLARY BLOOD COLLECTION, PURIFICATION, CRYOPRESERVATION BAGS AND KITS"
    },
    {
      "code" : "B0104",
      "display" : "PLACENTAL BLOOD BAGS AND KITS",
      "concept" : [{
        "code" : "B010401",
        "display" : "PLACENTAL BLOOD COLLECTION BAGS AND KITS"
      },
      {
        "code" : "B010402",
        "display" : "PLACENTAL BLOOD PURIFICATION BAGS AND KITS"
      },
      {
        "code" : "B010403",
        "display" : "PLACENTAL BLOOD CROYPRESERVATION BAGS AND KITS"
      },
      {
        "code" : "B010499",
        "display" : "PLACENTAL BLOOD BAGS AND KITS - OTHER"
      }]
    },
    {
      "code" : "B0105",
      "display" : "UMBILICAL CORD BLOOD COLLECTION, PURIFICATION, CRYOPRESERVATION BAGS AND KITS"
    },
    {
      "code" : "B0180",
      "display" : "BLOOD BAGS AND KITS - ACCESSORIES"
    },
    {
      "code" : "B0190",
      "display" : "BLOOD BAGS AND KITS - VARIOUS",
      "concept" : [{
        "code" : "B019001",
        "display" : "PLATELET GEL AND FIBRIN GLUE PRODUCTION BAGS AND KITS"
      },
      {
        "code" : "B019002",
        "display" : "COLLECTION AND FILTRATION OF WHOLE BLOOD WITH ALIQUOTATION OF CONCENTRATED RED BLOOD CELLS BAGS AND KITS"
      },
      {
        "code" : "B019003",
        "display" : "BLOOD COMPONENTS ALIQUOTATION KITS"
      },
      {
        "code" : "B019004",
        "display" : "BLOOD COMPONENTS SAMPLING BAGS AND KITS"
      }]
    },
    {
      "code" : "B0199",
      "display" : "BLOOD BAGS AND KITS - OTHER"
    }]
  },
  {
    "code" : "B02",
    "display" : "BLOOD FILTERS",
    "concept" : [{
      "code" : "B0201",
      "display" : "LEUKOREDUCTION FILTERS",
      "concept" : [{
        "code" : "B020101",
        "display" : "BED-SIDE LEUKOREDUCTION FILTERS",
        "concept" : [{
          "code" : "B02010101",
          "display" : "BED-SIDE ERYTHROCYTES (RBC) LEUKOREDUCTION FILTERS (WITH OR WITHOUT INFUSION CONTROLLER)"
        },
        {
          "code" : "B02010102",
          "display" : "BED-SIDE PLATELETS LEUKOREDUCTION FILTERS (WITH OR WITHOUT INFUSION CONTROLLER)"
        },
        {
          "code" : "B02010199",
          "display" : "BED-SIDE LEUKOREDUCTION FILTERS - OTHER"
        }]
      },
      {
        "code" : "B020102",
        "display" : "LABORATORY LEUKOREDUCTION FILTERS",
        "concept" : [{
          "code" : "B02010201",
          "display" : "LABORATORY ERYTHROCYTES (RBC) LEUKOREDUCTION FILTERS"
        },
        {
          "code" : "B02010202",
          "display" : "LABORATORY PLATELETS LEUKOREDUCTION FILTERS"
        },
        {
          "code" : "B02010299",
          "display" : "LABORATORY LEUKOREDUCTION FILTERS - OTHER"
        }]
      }]
    },
    {
      "code" : "B0202",
      "display" : "MASSIVE TRANSFUSION THERAPY FILTERS (FOR 40 MICRON MICROAGGREGATES)",
      "concept" : [{
        "code" : "B020201",
        "display" : "MASSIVE TRANSFUSION THERAPY FILTERS, WITH TRANSFUSION CONTROLLER"
      },
      {
        "code" : "B020202",
        "display" : "MASSIVE TRANSFUSION THERAPY FILTERS, W/O TRANSFUSION CONTROLLER"
      }]
    },
    {
      "code" : "B0280",
      "display" : "BLOOD FILTERS - ACCESSORIES"
    },
    {
      "code" : "B0299",
      "display" : "BLOOD FILTERS - OTHER"
    }]
  },
  {
    "code" : "B03",
    "display" : "APHERESIS DEVICES",
    "concept" : [{
      "code" : "B0301",
      "display" : "APHERESIS COLLECTION DEVICES",
      "concept" : [{
        "code" : "B030101",
        "display" : "APHERESIS PLASMA COLLECTION DEVICES"
      },
      {
        "code" : "B030102",
        "display" : "APHERESIS PLATELET COLLECTION DEVICES"
      },
      {
        "code" : "B030103",
        "display" : "APHERESIS LEUKOCYTE COLLECTION DEVICES"
      },
      {
        "code" : "B030104",
        "display" : "APHERESIS MULTIPLE BLOOD COMPONENT COLLECTION DEVICES"
      },
      {
        "code" : "B030199",
        "display" : "APHERESIS COLLECTION DEVICES - OTHER"
      }]
    },
    {
      "code" : "B0302",
      "display" : "APHERESIS THERAPY DEVICES",
      "concept" : [{
        "code" : "B030201",
        "display" : "PLASMAPHERESIS DEVICES AND KITS,"
      },
      {
        "code" : "B030202",
        "display" : "CYTAPHERESIS DEVICES AND KITS"
      },
      {
        "code" : "B030203",
        "display" : "SINGLE PLASMA COMPONENTS REMOVAL DEVICES AND KITS"
      },
      {
        "code" : "B030204",
        "display" : "EXTRACORPOREAL PHOTOCHAEMOTHERAPY OR PHOTOPHERESIS DEVICES AND KITS"
      },
      {
        "code" : "B030299",
        "display" : "APHERESIS THERAPY DEVICES - OTHER"
      }]
    },
    {
      "code" : "B0380",
      "display" : "APHERESIS DEVICES - ACCESSORIES"
    },
    {
      "code" : "B0399",
      "display" : "APHERESIS DEVICES - OTHER"
    }]
  },
  {
    "code" : "B04",
    "display" : "AUTOTRANSFUSION DEVICES",
    "concept" : [{
      "code" : "B0401",
      "display" : "INTRA- AND POSTOPERATIVE BLOOD COLLECTION, WASHING AND REINFUSION DEVICES AND KITS"
    },
    {
      "code" : "B0402",
      "display" : "INTRA- AND POSTOPERATIVE BLOOD COLLECTION AND REINFUSION ONLY DEVICES AND KITS"
    },
    {
      "code" : "B0480",
      "display" : "AUTOTRANSFUSION DEVICES - ACCESSORIES"
    },
    {
      "code" : "B0499",
      "display" : "AUTOTRANSFUSION DEVICES - OTHER"
    }]
  },
  {
    "code" : "B05",
    "display" : "TOPICAL USE BLOOD COMPONENTS PREPARATION DEVICES",
    "concept" : [{
      "code" : "B0501",
      "display" : "PLATELET GEL AUTOMATIC PREPARATION DEVICES (EXCLUDING BAGS)"
    },
    {
      "code" : "B0502",
      "display" : "FIBRIN GLUE AUTOMATIC PREPARATION DEVICES (EXCLUDING BAGS)"
    },
    {
      "code" : "B0599",
      "display" : "TOPICAL USE BLOOD COMPONENTS PREPARATION DEVICES - OTHER"
    }]
  },
  {
    "code" : "B06",
    "display" : "CELLULAR OR BIOLOGICAL MANIPULATION DEVICES"
  },
  {
    "code" : "B07",
    "display" : "BLOOD AND BLOOD COMPONENTS PRESERVATION SOLUTIONS"
  },
  {
    "code" : "B99",
    "display" : "HAEMATOLOGY AND HAEMOTRANSFUSION DEVICES - OTHER"
  },
  {
    "code" : "C",
    "display" : "CARDIOCIRCULATORY SYSTEM DEVICES"
  },
  {
    "code" : "C01",
    "display" : "ARTERIO-VENOUS SYSTEM DEVICES",
    "concept" : [{
      "code" : "C0101",
      "display" : "PERIPHERAL  I.V. CATHETERS AND CANNULAS",
      "concept" : [{
        "code" : "C010101",
        "display" : "PERIPHERAL I.V. CATHETERS",
        "concept" : [{
          "code" : "C01010101",
          "display" : "PERIPHERAL I.V. CATHETERS, W/O SAFETY SYSTEMS",
          "concept" : [{
            "code" : "C0101010101",
            "display" : "PERIPHERAL I.V. CATHETERS, W/O SAFETY SYSTEMS, WITH INJECTION VALVES"
          },
          {
            "code" : "C0101010102",
            "display" : "PERIPHERAL I.V. CATHETERS, W/O SAFETY SYSTEMS, W/O INJECTION VALVES"
          }]
        },
        {
          "code" : "C01010102",
          "display" : "PERIPHERAL I.V. CATHETERS, WITH SAFETY SYSTEMS",
          "concept" : [{
            "code" : "C0101010201",
            "display" : "PERIPHERAL I.V. CATHETERS, WITH SAFETY SYSTEMS, WITH INJECTION VALVES"
          },
          {
            "code" : "C0101010202",
            "display" : "PERIPHERAL I.V. CATHETERS, WITH SAFETY SYSTEMS, W/O INJECTION VALVES"
          }]
        },
        {
          "code" : "C01010103",
          "display" : "PERIPHERAL I.V. CATHETERS, WITH INTEGRATED EXTENSIONS"
        },
        {
          "code" : "C01010180",
          "display" : "PERIPHERAL I.V. CATHETERS - ACCESSORIES"
        },
        {
          "code" : "C01010199",
          "display" : "PERIPHERAL I.V. CATHETERS - OTHER"
        }]
      },
      {
        "code" : "C010102",
        "display" : "PERIPHERAL I.V. CATHETER SYSTEMS"
      },
      {
        "code" : "C010103",
        "display" : "INTEGRATED PERIPHERAL I.V. DEVICES"
      },
      {
        "code" : "C010104",
        "display" : "UMBILICAL I.V. CANNULAS"
      },
      {
        "code" : "C010180",
        "display" : "PERIPHERAL I.V. CATHETERS AND CANNULAS - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "C010199",
        "display" : "PERIPHERAL I.V. CATHETERS AND CANNULAS - OTHER"
      }]
    },
    {
      "code" : "C0102",
      "display" : "CENTRAL I.V. CATHETERS",
      "concept" : [{
        "code" : "C010201",
        "display" : "CENTRAL I.V. CATHETERS, PERIPHERAL ACCESS",
        "concept" : [{
          "code" : "C01020101",
          "display" : "CENTRAL I.V. SINGLE-LUMEN CATHETERS, PERIPHERAL ACCESS"
        },
        {
          "code" : "C01020102",
          "display" : "CENTRAL I.V. MULTI-LUMEN CATHETERS, PERIPHERAL ACCESS"
        }]
      },
      {
        "code" : "C010202",
        "display" : "CENTRAL I.V. CATHETERS, NON-TUNNELED",
        "concept" : [{
          "code" : "C01020201",
          "display" : "CENTRAL I.V. SINGLE-LUMEN CATHETERS, NON-TUNNELED"
        },
        {
          "code" : "C01020202",
          "display" : "CENTRAL VENOUS DOUBLE-LUMEN CATHETERS, NON-TUNNELED"
        },
        {
          "code" : "C01020203",
          "display" : "CENTRAL VENOUS MULTI-LUMEN (>2) CATHETERS, NON-TUNNELED"
        }]
      },
      {
        "code" : "C010203",
        "display" : "CENTRAL VENOUS CATHETERS, PARTIALLY TUNNELED",
        "concept" : [{
          "code" : "C01020301",
          "display" : "CENTRAL VENOUS SINGLE-LUMEN CATHETERS, PARTIALLY TUNNELED"
        },
        {
          "code" : "C01020302",
          "display" : "CENTRAL VENOUS DOUBLE-LUMEN CATHETERS, PARTIALLY TUNNELED"
        },
        {
          "code" : "C01020303",
          "display" : "CENTRAL VENOUS MULTI-LUMEN (>2) CATHETERS, PARTIALLY TUNNELED"
        }]
      },
      {
        "code" : "C010204",
        "display" : "SUBCUTANEOUS IMPLANTABLE VENOUS ACCESS PORT SYSTEMS",
        "concept" : [{
          "code" : "C01020401",
          "display" : "SUBCUTANEOUS IMPLANTABLE VENOUS ACCESS PORT SYSTEMS, SINGLE-CHAMBER"
        },
        {
          "code" : "C01020402",
          "display" : "SUBCUTANEOUS IMPLANTABLE VENOUS ACCESS PORT SYSTEMS, DUAL-CHAMBER OR DOUBLE-LUMEN"
        },
        {
          "code" : "C01020499",
          "display" : "SUBCUTANEOUS IMPLANTABLE VENOUS ACCESS PORT SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "C010280",
        "display" : "CENTRAL VENOUS CATHETERS - ACCESSORIES"
      },
      {
        "code" : "C010299",
        "display" : "CENTRAL VENOUS CATHETERS - OTHER"
      }]
    },
    {
      "code" : "C0103",
      "display" : "ARTERIAL CANNULAS",
      "concept" : [{
        "code" : "C010301",
        "display" : "RADIAL CANNULAS"
      },
      {
        "code" : "C010302",
        "display" : "UMBILICAL CANNULAS"
      },
      {
        "code" : "C010303",
        "display" : "FEMORAL CANNULAS"
      },
      {
        "code" : "C010380",
        "display" : "ARTERIAL CANNULAS - ACCESSORIES"
      },
      {
        "code" : "C010399",
        "display" : "ARTERIAL CANNULAS - OTHER"
      }]
    },
    {
      "code" : "C0104",
      "display" : "ANGIOGRAPHY AND HAEMODYNAMIC DEVICES",
      "concept" : [{
        "code" : "C010401",
        "display" : "CARDIAC ANGIOGRAPHY DEVICES",
        "concept" : [{
          "code" : "C01040101",
          "display" : "CARDIAC ANGIOGRAPHY DIAGNOSTIC DEVICES,",
          "concept" : [{
            "code" : "C0104010101",
            "display" : "CARDIAC ANGIOGRAPHY DIAGNOSTIC CATHETERS"
          },
          {
            "code" : "C0104010102",
            "display" : "CARDIAC AND INTRACORONARY ULTRASOUND CATHETERS"
          },
          {
            "code" : "C0104010199",
            "display" : "CARDIAC ANGIOGRAPHY DIAGNOSTIC DEVICES - OTHER"
          }]
        },
        {
          "code" : "C01040102",
          "display" : "CORONARY ANGIOGRAPHY THERAPEUTIC DEVICES",
          "concept" : [{
            "code" : "C0104010201",
            "display" : "PERCUTANEOUS TRANSLUMINAL CORONARY ANGIOPLASTY (PTCA) DILATATION CATHETERS",
            "concept" : [{
              "code" : "C010401020101",
              "display" : "PTCA BALLOON DILATION CATHETERS"
            },
            {
              "code" : "C010401020102",
              "display" : "CORONARY STENT IMPLANTATION DILATION CATHETERS"
            },
            {
              "code" : "C010401020180",
              "display" : "PTCA BALLOON DILATATION CATHETERS - ACCESSORIES"
            },
            {
              "code" : "C010401020199",
              "display" : "PTCA DIALATION CATHETERS - OTHER"
            }]
          },
          {
            "code" : "C0104010202",
            "display" : "CARDIAC ANGIOGRAPHY GUIDE CATHETERS"
          },
          {
            "code" : "C0104010203",
            "display" : "PHARMACEUTICAL INFUSION AND ADMINISTRATION INTRACORONARY AND INTRACARDIAC CATHETERS"
          },
          {
            "code" : "C0104010204",
            "display" : "CORONARY ARTERY ATHERECTOMY SYSTEMS",
            "concept" : [{
              "code" : "C010401020401",
              "display" : "CORONARY ARTERY ATHERECTOMY SYSTEMS, DIRECTIONAL"
            },
            {
              "code" : "C010401020402",
              "display" : "CORONARY ARTERY ATHERECTOMY SYSTEMS, ROTATIONAL"
            },
            {
              "code" : "C010401020480",
              "display" : "CORONARY ATHERECTOMY SYSTEMS - ACCESSORIES"
            },
            {
              "code" : "C010401020499",
              "display" : "CORONARY ARTERY ATHERECTOMY SYSTEMS - OTHER"
            }]
          },
          {
            "code" : "C0104010205",
            "display" : "CARDIAC THROMBECTOMY AND THROMBOASPIRATION SYSTEMS",
            "concept" : [{
              "code" : "C010401020501",
              "display" : "MANUAL CARDIAC THROMBECTOMY AND THROMBOASPIRATION SYSTEMS"
            },
            {
              "code" : "C010401020502",
              "display" : "MOTERED CARDIAC THROMBECTOMY AND THROMBOASPIRATION SYSTEMS"
            },
            {
              "code" : "C010401020580",
              "display" : "THROMBECTOMY AND CARDIAC THROMBOASPIRATION SYSTEMS - ACCESSORIES"
            }]
          },
          {
            "code" : "C0104010280",
            "display" : "INTERVENTIONAL CORONARY ANGIOGRAPHY DEVICES - ACCESSORIES"
          },
          {
            "code" : "C0104010299",
            "display" : "CARDIAC THROMBECTOMY AND THROMBOASPIRATION SYSTEMS - OTHER"
          }]
        },
        {
          "code" : "C01040180",
          "display" : "CORONARY ANGIOGRAPHY DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
        },
        {
          "code" : "C01040199",
          "display" : "CARDIAC ANGIOGRAPHY DEVICES - OTHER"
        }]
      },
      {
        "code" : "C010402",
        "display" : "PERIPHERAL ANGIOGRAPHY DEVICES",
        "concept" : [{
          "code" : "C01040201",
          "display" : "PERIPHERAL ANGIOGRAPHY DIAGNOSTIC DEVICES",
          "concept" : [{
            "code" : "C0104020101",
            "display" : "PANORAMIC AND SELECTIVE PERIPHERAL DIAGNOSTIC ANGIOGRAPHY CATHETERS AND MICROCATHETERS"
          },
          {
            "code" : "C0104020102",
            "display" : "INTRAVASCULAR ULTRASOUND CATHETERS"
          },
          {
            "code" : "C0104020103",
            "display" : "VASCULAR OCCLUSION CATHETERS"
          },
          {
            "code" : "C0104020180",
            "display" : "DIAGNOSTIC PERIPHERAL ANGIOGRAPHY DEVICES - ACCESSORIES"
          },
          {
            "code" : "C0104020199",
            "display" : "PERIPHERAL ANGIOGRAPHY DIAGNOSTIC DEVICES - OTHER"
          }]
        },
        {
          "code" : "C01040202",
          "display" : "PERIPHERAL ANGIOGRAPHY THERAPEUTIC DEVICES",
          "concept" : [{
            "code" : "C0104020201",
            "display" : "PERCUTANEOUS TRANSLUMINAL ANGIOPLASTY (PTA) DILATATION CATHETERS",
            "concept" : [{
              "code" : "C010402020101",
              "display" : "PTA BALLOON DILATATION CATHETERS"
            },
            {
              "code" : "C010402020102",
              "display" : "STENT POSITIONING VASCULAR BALLOON DILATATION CATHETERS"
            },
            {
              "code" : "C010402020180",
              "display" : "PTA BALLOON DILATATION CATHETERS - ACCESSORIES"
            },
            {
              "code" : "C010402020199",
              "display" : "PTA DILATATION CATHETERS - OTHER"
            }]
          },
          {
            "code" : "C0104020202",
            "display" : "PERIPHERAL EMBOLISATION CATHETERS AND MICROCATHETERS"
          },
          {
            "code" : "C0104020203",
            "display" : "EMBOLISATION DEVICES",
            "concept" : [{
              "code" : "C010402020301",
              "display" : "EMBOLISATION COILS"
            },
            {
              "code" : "C010402020302",
              "display" : "EMBOLISATION FLUIDS"
            },
            {
              "code" : "C010402020303",
              "display" : "EMBOLISATION PARTICLES AND MICROSPHERES"
            },
            {
              "code" : "C010402020380",
              "display" : "EMBOLISATION DEVICES - ACCESSORIES"
            },
            {
              "code" : "C010402020399",
              "display" : "EMBOLISATION DEVICES - OTHER"
            }]
          },
          {
            "code" : "C0104020204",
            "display" : "PERIPHERAL ANGIOGRAPHY GUIDE CATHETERS"
          },
          {
            "code" : "C0104020205",
            "display" : "PHARMACEUTICAL INFUSION AND ADMINISTRATION INTRAVASCULAR CATHETERS AND MICROCATHETERS"
          },
          {
            "code" : "C0104020206",
            "display" : "PERIPHERAL ATHERECTOMY SYSTEMS",
            "concept" : [{
              "code" : "C010402020601",
              "display" : "PERIPHERAL ATHERECTOMY SYSTEMS, DIRECTIONAL"
            },
            {
              "code" : "C010402020602",
              "display" : "PERIPHERAL ATHERECTOMY SYSTEMS, ROTATIONAL"
            },
            {
              "code" : "C010402020680",
              "display" : "PERIPHERAL ATHERECTOMY DEVICES - ACCESSORIES"
            },
            {
              "code" : "C010402020699",
              "display" : "PERIPHERAL ATHERECTOMY SYSTEMS - OTHER"
            }]
          },
          {
            "code" : "C0104020207",
            "display" : "PERIPHERAL THROMBECTOMY AND THROMBOASPIRATION SYSTEMS",
            "concept" : [{
              "code" : "C010402020701",
              "display" : "MANUAL PERIPHERAL THROMBECTOMY AND THROMBOASPIRATION SYSTEMS"
            },
            {
              "code" : "C010402020702",
              "display" : "MECHANICAL PERIPHERAL THROMBECTOMY AND THROMBOASPIRATION SYSTEMS"
            },
            {
              "code" : "C010402020780",
              "display" : "THROMBECTOMY AND PERIPHERAL THROMBOASPIRATION SYSTEMS - ACCESSORIES"
            }]
          },
          {
            "code" : "C0104020208",
            "display" : "TRANSJUGULAR INTRAHEPATIC PORTOSYSTEMIC SHUNT (TIPS) PERCUTANEOUS SYSTEMS"
          },
          {
            "code" : "C0104020209",
            "display" : "PERIPHERAL VASCULAR SYSTEM TOTAL CHRONIC OCCLUSION DEVICES"
          },
          {
            "code" : "C0104020280",
            "display" : "INTERVENTIONAL PERIPHERAL ANGIOGRAPHY DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
          },
          {
            "code" : "C0104020299",
            "display" : "PERIPHERAL ANGIOGRAPHY THERAPEUTIC DEVICES - OTHER"
          }]
        },
        {
          "code" : "C01040280",
          "display" : "PERIPHERAL ANGIOGRAPHY DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
        },
        {
          "code" : "C01040299",
          "display" : "PERIPHERAL ANGIOGRAPHY DEVICES - OTHER"
        }]
      },
      {
        "code" : "C010403",
        "display" : "FRACTIONAL FLOW RESERVE (FFR) MEASUREMENT DEVICES"
      },
      {
        "code" : "C010480",
        "display" : "ANGIOGRAPHY AND HEMODYNAMICS DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "C010499",
        "display" : "ANGIOGRAPHY AND HEMODYNAMICS DEVICES - OTHER"
      }]
    },
    {
      "code" : "C0105",
      "display" : "INTRAVASCULAR PROTECTION DEVICES",
      "concept" : [{
        "code" : "C010501",
        "display" : "VENA CAVA FILTERS",
        "concept" : [{
          "code" : "C01050101",
          "display" : "VENA CAVA FILTERS, RETRIEVABLE"
        },
        {
          "code" : "C01050102",
          "display" : "VENA CAVA FILTERS, PERMANENT"
        }]
      },
      {
        "code" : "C010502",
        "display" : "INTRAVASCULAR EMOBILIC PROTECTION CATHETERS AND SYSTEMS",
        "concept" : [{
          "code" : "C01050201",
          "display" : "PTCA EMBOLIC PROTECTION CATHETERS AND SYSTEMS"
        },
        {
          "code" : "C01050202",
          "display" : "PTA EMBOLIC PROTECTION CATHETERS AND SYSTEMS"
        },
        {
          "code" : "C01050203",
          "display" : "ARTERIO-SURGERY EMBOLIC PROTECTION CATHETERS AND SYSTEMS"
        },
        {
          "code" : "C01050299",
          "display" : "INTRAVASCULAR EMBOLIC PROTECTION CATHETERS AND SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "C010580",
        "display" : "INTRAVASCULAR PROTECTION DEVICES - ACCESSORIES"
      },
      {
        "code" : "C010599",
        "display" : "INTRAVASCULAR PROTECTION DEVICES - OTHER"
      }]
    },
    {
      "code" : "C0180",
      "display" : "ARTERO-VENOUS SYSTEM DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
    },
    {
      "code" : "C0190",
      "display" : "DEVICES FOR VASCULAR PROCEDURES - VARIOUS",
      "concept" : [{
        "code" : "C019001",
        "display" : "AORTIC COUNTERPULSATION CATHETERS"
      },
      {
        "code" : "C019002",
        "display" : "EMBOLECTOMY CATHETERS"
      },
      {
        "code" : "C019003",
        "display" : "THERMODILUTION CATHETERS"
      },
      {
        "code" : "C019004",
        "display" : "CARDIOVASCULAR MONITORING SYSTEMS"
      },
      {
        "code" : "C019005",
        "display" : "RETRIEVING SYSTEMS FOR VASCULAR FOREIGN BODIES"
      },
      {
        "code" : "C019006",
        "display" : "CAROTID ARTERY SHUNTS"
      },
      {
        "code" : "C019007",
        "display" : "CARDIOVASCULAR SYSTEM BRACHYTHERAPY RADIOFREQUENCY SYSTEMS"
      },
      {
        "code" : "C019008",
        "display" : "IMPLANTABLE SUBCUTANEOUS ARTERIAL ACCESS SYSTEMS"
      },
      {
        "code" : "C019009",
        "display" : "AORTIC OCCLUSION SYSTEMS"
      },
      {
        "code" : "C019010",
        "display" : "INTRAVASCULAR RECANALISATION SYSTEMS"
      },
      {
        "code" : "C019011",
        "display" : "INTRAVASCULAR AND CARDIAC BIOPSY SYSTEMS",
        "concept" : [{
          "code" : "C01901101",
          "display" : "INTRAVASCULAR BIOPSY SYSTEMS"
        },
        {
          "code" : "C01901102",
          "display" : "MYOCARDIAL BIOPSY KITS"
        }]
      },
      {
        "code" : "C019012",
        "display" : "AORTIC PUNCHES AND AORTOTOMY SYSTEMS",
        "concept" : [{
          "code" : "C01901201",
          "display" : "AORTIC PUNCHES"
        },
        {
          "code" : "C01901202",
          "display" : "AORTOTOMY SYSTEMS"
        }]
      },
      {
        "code" : "C019013",
        "display" : "ISOLATED TISSUE PERFUSION SYSTEMS (LOCOREGIONAL TUMOR THERAPY)"
      },
      {
        "code" : "C019014",
        "display" : "CARDIAC VALVULOPLASTY CATHETERS"
      },
      {
        "code" : "C019015",
        "display" : "CARDIAC TRANSSEPTAL PUNCTURE KITS"
      },
      {
        "code" : "C019016",
        "display" : "PERITONEOVENOUS SHUNTS"
      },
      {
        "code" : "C019017",
        "display" : "VALVULOTOMES, SINGLE-USE"
      },
      {
        "code" : "C019018",
        "display" : "SURGICAL VENTRICULAR REMODELLING SYSTEMS"
      },
      {
        "code" : "C019019",
        "display" : "VESSEL STRIPPER SYSTEMS",
        "concept" : [{
          "code" : "C01901901",
          "display" : "VEIN STRIPPER DEVICES"
        },
        {
          "code" : "C01901902",
          "display" : "RADIOFREQUENCY VENOUS ABLATION CATHETERS"
        },
        {
          "code" : "C01901903",
          "display" : "VASCULAR EXTRACTION SYSTEMS"
        },
        {
          "code" : "C01901999",
          "display" : "VEIN STRIPPER SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "C019020",
        "display" : "SELECTIVE LOCAL HYPERTHERMIA KITS"
      }]
    },
    {
      "code" : "C0199",
      "display" : "ARTERIO-VENOUS DEVICES - OTHER"
    }]
  },
  {
    "code" : "C02",
    "display" : "ARRHYTHMOLOGY DEVICES",
    "concept" : [{
      "code" : "C0201",
      "display" : "CARDIAC ELECTROPHYSIOLOGY AND MAPPING DEVICES",
      "concept" : [{
        "code" : "C020101",
        "display" : "ARRHYTHMOLOGY BIPOLAR DIAGNOSTIC CATHETERS"
      },
      {
        "code" : "C020102",
        "display" : "ARRHYTHMOLOGY TRIPOLAR DIAGNOSTIC CATHETERS"
      },
      {
        "code" : "C020103",
        "display" : "ARRHYTHMOLOGY TETRAPOLAR DIAGNOSTIC CATHETERS"
      },
      {
        "code" : "C020104",
        "display" : "ARRHYTHMOLOGY MULTIPOLAR DIAGNOSTIC CATHETERS",
        "concept" : [{
          "code" : "C02010401",
          "display" : "ARRHYTHMOLOGY MULTIPOLAR DIAGNOSTIC CATHETERS, CONVENTIONAL"
        },
        {
          "code" : "C02010402",
          "display" : "ARRHYTHMOLOGY MULTIPOLAR DIAGNOSTIC CATHETERS, BASKET TYPE"
        },
        {
          "code" : "C02010403",
          "display" : "ARRHYTHMOLOGY MULTIPOLAR DIAGNOSTIC CATHETERS, ADJUSTABLE"
        },
        {
          "code" : "C02010499",
          "display" : "ARRHYTHMOLOGY MULTIPOLAR DIAGNOSTIC CATHETERS – OTHER"
        }]
      },
      {
        "code" : "C020105",
        "display" : "NON-CONVENTIONAL MAPPING (CONTACT AND NON-CONTACT) THREE-DIMENSIONAL DIAGNOSTIC CATHETERS"
      },
      {
        "code" : "C020180",
        "display" : "CARDIAC ELECTROPHYSIOLOGY AND MAPPING DEVICES - ACCESSORIES"
      },
      {
        "code" : "C020199",
        "display" : "CARDIAC ELECTROPHYSIOLOGY AND MAPPING DEVICES - OTHER"
      }]
    },
    {
      "code" : "C0202",
      "display" : "CARDIAC TEMPORARY STIMULATION DEVICES (WITH OR WITHOUT ACTIVE SUBSTANCES)",
      "concept" : [{
        "code" : "C020201",
        "display" : "TEMPORARY ENDOCARDIAL LEADS"
      },
      {
        "code" : "C020202",
        "display" : "EPICARDIAL LEADS (MONOPOLAR AND BIPOLAR)"
      },
      {
        "code" : "C020203",
        "display" : "TRANSOESOPHAGEAL RECORDING AND STIMULATION LEADS"
      },
      {
        "code" : "C020280",
        "display" : "TEMPORARY CARDIAC ELECTRICAL STIMULATION DEVICES - ACCESSORIES"
      },
      {
        "code" : "C020299",
        "display" : "CARDIAC TEMPORARY STIMULATION DEVICES (WITH OR WITHOUT ACTIVE SUBSTANCES) - OTHER"
      }]
    },
    {
      "code" : "C0203",
      "display" : "CARDIAC TISSUE ABLATION DEVICES",
      "concept" : [{
        "code" : "C020301",
        "display" : "ARRHYTHMOGENIC FOCI RADIOFREQUENCY ABLATION CATHETERS"
      },
      {
        "code" : "C020302",
        "display" : "ARRHYTHMOGENIC FOCI CRYOENERGY ABLATION CATHETERS"
      },
      {
        "code" : "C020304",
        "display" : "ARRHYTHMOGENIC FOCI PULSED FIELD ABLATION CATHETERS"
      },
      {
        "code" : "C020305",
        "display" : "ARRHYTHMOGENIC FOCI LASER ABLATION CATHETERS"
      },
      {
        "code" : "C020380",
        "display" : "ABLATION OF ARRHYTHMOGENIC FOCUS DEVICES - ACCESSORIES"
      },
      {
        "code" : "C020399",
        "display" : "CARDIAC TISSUE ABLATION DEVICES - OTHER"
      }]
    },
    {
      "code" : "C0204",
      "display" : "EXTERNAL CARDIOVERSION AND DEFIBRILLATION DEVICES",
      "concept" : [{
        "code" : "C020401",
        "display" : "EXTERNAL CARDIOVERSION DEFIBRILLATOR ELECTRODE PADS"
      },
      {
        "code" : "C020402",
        "display" : "TEMPORARY CARDIOVERSION LEADS",
        "concept" : [{
          "code" : "C02040201",
          "display" : "TEMPORARY ENDOCAVITARY CARDIOVERSION LEADS"
        },
        {
          "code" : "C02040202",
          "display" : "TEMPORARY TRANSOESOPHAGEAL CARDIOVERSION LEADS"
        },
        {
          "code" : "C02040299",
          "display" : "TEMPORARY CARDIOVERSION LEADS - OTHER"
        }]
      },
      {
        "code" : "C020480",
        "display" : "CARDIOVERSION AND EXTERNAL DEFIBRILLATION DEVICES - ACCESSORIES"
      },
      {
        "code" : "C020499",
        "display" : "EXTERNAL CARDIOVERSION AND DEFIBRILLATION DEVICES - OTHER"
      }]
    },
    {
      "code" : "C0205",
      "display" : "CARDIAC DIAGNOSTIC DEVICES",
      "concept" : [{
        "code" : "C020501",
        "display" : "ECG ELECTRODES"
      },
      {
        "code" : "C020599",
        "display" : "CARDIAC DIAGNOSTIC DEVICES - OTHER"
      }]
    },
    {
      "code" : "C0280",
      "display" : "ARRYTHMOLOGY DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
    },
    {
      "code" : "C0299",
      "display" : "ARRHYTHMOLOGY DEVICES - OTHER"
    }]
  },
  {
    "code" : "C03",
    "display" : "CARDIAC SURGERY AND HEART TRANSPLANT DEVICES",
    "concept" : [{
      "code" : "C0301",
      "display" : "EXTRACORPOREAL ASSISTED CIRCULATION DEVICES",
      "concept" : [{
        "code" : "C030101",
        "display" : "EXTRACORPOREAL CIRCULATION KITS",
        "concept" : [{
          "code" : "C03010101",
          "display" : "EXTRACORPOREAL CIRCULATION CIRCUITS"
        },
        {
          "code" : "C03010102",
          "display" : "OXYGENATOR KITS"
        },
        {
          "code" : "C03010104",
          "display" : "EXTRACORPOREAL CIRCULATION FILTERS"
        },
        {
          "code" : "C03010199",
          "display" : "EXTRACORPOREAL CIRCULATION KITS - OTHER"
        }]
      },
      {
        "code" : "C030102",
        "display" : "CARDIOPLEGIA SOLUTION ADMINISTRATION KITS"
      },
      {
        "code" : "C030103",
        "display" : "CIRCULATORY SUPPORT KITS",
        "concept" : [{
          "code" : "C03010301",
          "display" : "CARDIOPULMONARY SUPPORT KITS (C.P.S. AND ECMO)"
        },
        {
          "code" : "C03010399",
          "display" : "CIRCULATORY SUPPORT KITS - OTHER"
        }]
      },
      {
        "code" : "C030104",
        "display" : "EXTRACORPOREAL CIRCULATION CANNULAS",
        "concept" : [{
          "code" : "C03010401",
          "display" : "EXTRACORPOREAL CIRCULATION ARTERIAL CANNULAS",
          "concept" : [{
            "code" : "C0301040101",
            "display" : "EXTRACORPOREAL CIRCULATION ARTERIAL CANNULAS, W/O FILTER"
          },
          {
            "code" : "C0301040102",
            "display" : "EXTRACORPOREAL CIRCULATION ARTERIAL CANNULAS, WITH FILTER"
          }]
        },
        {
          "code" : "C03010402",
          "display" : "EXTRACORPOREAL CIRCULATION VENOUS CANNULAS",
          "concept" : [{
            "code" : "C0301040201",
            "display" : "ATRIOCAVAL CANNULAS"
          },
          {
            "code" : "C0301040202",
            "display" : "BICAVAL CANNULAS"
          }]
        },
        {
          "code" : "C03010403",
          "display" : "INTRACAVITARY SUCTION CANNULAS"
        },
        {
          "code" : "C03010404",
          "display" : "CARDIOPLEGIA CANNULAS",
          "concept" : [{
            "code" : "C0301040401",
            "display" : "EXTRACORPOREAL CIRCULATION NON-SELECTIVE PERFUSION CANNULAS (WITH AORTIC VENTING LUMEN)"
          },
          {
            "code" : "C0301040402",
            "display" : "SELECTIVE CORONARY ARTERIES PERFUSION CANNULAS"
          },
          {
            "code" : "C0301040499",
            "display" : "CARDIOPLEGIA CANNULAS - OTHER"
          }]
        },
        {
          "code" : "C03010405",
          "display" : "SELECTIVE CAROTID ARTERY AND CORONARY SINUS PERFUSION CANNULAS"
        },
        {
          "code" : "C03010406",
          "display" : "PERCUTANEOUS ARTERIOVENOUS CANNULAS (WITH ENDOCLAMP AND CARDIPLEGIA VENTING LUMEN)"
        },
        {
          "code" : "C03010499",
          "display" : "EXTRACORPOREAL CIRCULATION CANNULAS - OTHER"
        }]
      },
      {
        "code" : "C030180",
        "display" : "EXTRACORPOREAL AND ASSISTED CIRCULATION DEVICES - ACCESSORIES"
      },
      {
        "code" : "C030199",
        "display" : "EXTRACORPOREAL AND ASSISTED CIRCULATION DEVICES - OTHER"
      }]
    },
    {
      "code" : "C0380",
      "display" : "HEART SURGERY AND ORGAN TRANSPLANTATION DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
    },
    {
      "code" : "C0390",
      "display" : "CARDIAC SURGERY AND HEART TRANSPLANT DEVICES - VARIOUS",
      "concept" : [{
        "code" : "C039001",
        "display" : "MINIMALLY INVASIVE ACCESS CARDIAC SURGERY SYSTEMS",
        "concept" : [{
          "code" : "C03900101",
          "display" : "DIRECT VISION MINIMALLY INVASIVE CARDIAC ACCESS KITS"
        },
        {
          "code" : "C03900102",
          "display" : "MINI-INVASIVE VIDEO-ASSISTED CARDIO-SURGICAL ACCESS KITS (WITH EXTERNAL MONITOR)"
        }]
      },
      {
        "code" : "C039002",
        "display" : "BEATING HEART CARDIOSURGERY DEVICES",
        "concept" : [{
          "code" : "C03900201",
          "display" : "EPI-MYOCARDIAL STABILISATION KITS"
        },
        {
          "code" : "C03900202",
          "display" : "INTRACORONARY SHUNTS"
        },
        {
          "code" : "C03900203",
          "display" : "GAS-JET CARDIAC SURGERY FIELD CLEANSING KITS (BLOWER)"
        },
        {
          "code" : "C03900299",
          "display" : "BEATING HEART CARDIOSURGERY DEVICES - OTHER"
        }]
      }]
    },
    {
      "code" : "C0399",
      "display" : "CARDIOSURGERY AND ORGAN TRANSPLANTATION DEVICES - OTHER"
    }]
  },
  {
    "code" : "C04",
    "display" : "CARDIOVASCULAR GUIDEWIRES",
    "concept" : [{
      "code" : "C0401",
      "display" : "CORONARY ARTERY GUIDEWIRES",
      "concept" : [{
        "code" : "C040101",
        "display" : "CORONARY ARTERY DIAGNOSTIC GUIDEWIRES",
        "concept" : [{
          "code" : "C04010101",
          "display" : "CORONARY ARTERY DIAGNOSTIC GUIDEWIRES, HYDROPHILIC"
        },
        {
          "code" : "C04010102",
          "display" : "CORONARY ARTERY DIAGNOSTIC GUIDEWIRES, NON-HYDROPHILIC"
        },
        {
          "code" : "C04010199",
          "display" : "CORONARY ARTERY DIAGNOSTIC GUIDEWIRES - OTHER"
        }]
      },
      {
        "code" : "C040102",
        "display" : "CORONARY ARTERY THERAPEUTIC GUIDEWIRES",
        "concept" : [{
          "code" : "C04010201",
          "display" : "CORONARY ARTERY THERAPEUTIC GUIDEWIRES, HYDROPHILIC"
        },
        {
          "code" : "C04010202",
          "display" : "CORONARY ARTERY THERAPEUTIC GUIDEWIRES, NON-HYDROPHILIC"
        },
        {
          "code" : "C04010299",
          "display" : "CORONARY ARTERY THERAPEUTIC GUIDEWIRES - OTHER"
        }]
      }]
    },
    {
      "code" : "C0402",
      "display" : "PERIPHERAL VASCULAR GUIDEWIRES",
      "concept" : [{
        "code" : "C040201",
        "display" : "PERIPHERAL VASCULAR DIAGNOSTIC GUIDEWIRES",
        "concept" : [{
          "code" : "C04020101",
          "display" : "PERIPHERAL VASCULAR DIAGNOSTIC GUIDEWIRES, HYDROPHILIC"
        },
        {
          "code" : "C04020102",
          "display" : "PERIPHERAL VASCULAR DIAGNOSTIC GUIDEWIRES, NON-HYDROPHILIC"
        },
        {
          "code" : "C04020199",
          "display" : "PERIPHERAL VASCULAR DIAGNOSTIC GUIDEWIRES- OTHER"
        }]
      },
      {
        "code" : "C040202",
        "display" : "PERIPHERAL VASCULAR THERAPEUTIC GUIDEWIRES",
        "concept" : [{
          "code" : "C04020201",
          "display" : "PERIPHERAL VASCULAR THERAPEUTIC GUIDEWIRES, HYDROPHILIC"
        },
        {
          "code" : "C04020202",
          "display" : "PERIPHERAL VASCULAR THERAPEUTIC GUIDEWIRES, NON-HYDROPHILIC"
        },
        {
          "code" : "C04020299",
          "display" : "PERIPHERAL VASCULAR GUIDEWIRES, THERAPEUTICAL - OTHER"
        }]
      }]
    },
    {
      "code" : "C0403",
      "display" : "CORONARY AND PERIPHERAL VASCULAR GUIDE WIRES",
      "concept" : [{
        "code" : "C040301",
        "display" : "DIAGNOSTIC CORONARY AND PERIPHERAL VASCULAR GUIDE WIRES",
        "concept" : [{
          "code" : "C04030101",
          "display" : "DIAGNOSTIC CORONARY AND PERIPHERAL VASCULAR GUIDE WIRES, HYDROPHILIC"
        },
        {
          "code" : "C04030102",
          "display" : "DIAGNOSTIC CORONARY AND PERIPHERAL VASCULAR GUIDE WIRES, NON-HYDROPHILIC"
        },
        {
          "code" : "C04030199",
          "display" : "DIAGNOSTIC CORONARY AND PERIPHERAL VASCULAR GUIDE WIRES - OTHER"
        }]
      },
      {
        "code" : "C040302",
        "display" : "INTERVENTIONAL CORONARY AND PERIPHERAL VASCULAR GUIDE WIRES",
        "concept" : [{
          "code" : "C04030201",
          "display" : "INTERVENTIONAL CORONARY AND PERIPHERAL VASCULAR GUIDE WIRES, HYDROPHILIC"
        },
        {
          "code" : "C04030202",
          "display" : "INTERVENTIONAL CORONARY AND PERIPHERAL VASCULAR GUIDE WIRES, NON-HYDROPHILIC"
        },
        {
          "code" : "C04030299",
          "display" : "INTERVENTIONAL CORONARY AND PERIPHERAL VASCULAR GUIDE WIRES - OTHER"
        }]
      }]
    },
    {
      "code" : "C0480",
      "display" : "CARDIOVASCULAR GUIDEWIRES - ACCESSORIES"
    },
    {
      "code" : "C0499",
      "display" : "CARDIOVASCULAR GUIDEWIRES - OTHER"
    }]
  },
  {
    "code" : "C05",
    "display" : "CARDIOVASCULAR INTRODUCER SHEATHS",
    "concept" : [{
      "code" : "C0501",
      "display" : "CARDIOVASCULAR INTRODUCER SHEATHS, NON-VALVED"
    },
    {
      "code" : "C0502",
      "display" : "CARDIOVASCULAR INTRODUCER SHEATHS, VALVED"
    },
    {
      "code" : "C0503",
      "display" : "CARDIOVASCULAR INTRODUCER SHEATHS, PEEL-AWAY"
    },
    {
      "code" : "C0504",
      "display" : "ARTERIAL INTRODUCTION SETS"
    },
    {
      "code" : "C0580",
      "display" : "CARDIOVASCULAR INTRODUCER SHEATHS - ACCESSORIES",
      "concept" : [{
        "code" : "C058001",
        "display" : "ADAPTERS AND CONNECTORS FOR CARDIOVASCULAR INTRODUCERS"
      },
      {
        "code" : "C058099",
        "display" : "CARDIOCIRCULATORY SYSTEM INTRODUCERS - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
      }]
    },
    {
      "code" : "C0599",
      "display" : "CARDIOVASCULAR INTRODUCER SHEATHS - OTHER"
    }]
  },
  {
    "code" : "C06",
    "display" : "CARDIOVASCULAR SURGERY INSTRUMENTS, SINGLE-USE",
    "concept" : [{
      "code" : "C0601",
      "display" : "CARDIOVASCULAR SURGERY INSTRUMENT KITS NOT INCLUDED IN OTHER CLASSES, SINGLE-USE"
    },
    {
      "code" : "C0602",
      "display" : "CARDIOVASCULAR SURGERY DILATORS, SINGLE-USE"
    },
    {
      "code" : "C0603",
      "display" : "CARDIOVASCULAR SURGERY FORCEPS, SINGLE-USE"
    },
    {
      "code" : "C0699",
      "display" : "CARDIOVASCULAR SURGERY INSTRUMENTS, SINGLE-USE - OTHER"
    }]
  },
  {
    "code" : "C90",
    "display" : "CARDIOCIRCULATORY DEVICES - VARIOUS",
    "concept" : [{
      "code" : "C9001",
      "display" : "HAEMOSTASIS VALVES AND SYSTEMS",
      "concept" : [{
        "code" : "C900101",
        "display" : "HAEMOSTASIS VALVES"
      },
      {
        "code" : "C900102",
        "display" : "HAEMOSTASIS ADAPTORS"
      },
      {
        "code" : "C900103",
        "display" : "PERCUTANEOUS ARTERIAL ACCESS HAEMOSTASIS SYSTEMS",
        "concept" : [{
          "code" : "C90010301",
          "display" : "HAEMOSTASIS MECHANICAL SYSTEMS (INCLUDING SINGLE-USE TOURNIQUETS)"
        },
        {
          "code" : "C90010302",
          "display" : "COLLAGEN-BASED HAEMOSTASIS SYSTEMS"
        },
        {
          "code" : "C90010303",
          "display" : "HAEMOSTASIS SYSTEMS WITH SUTURE OR CLIP SYSTEMS"
        },
        {
          "code" : "C90010399",
          "display" : "PERCUTANEOUS ARTERIAL ACCESS HAEMOSTASIS SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "C900180",
        "display" : "HAEMOSTASIS SYSTEMS - ACCESSORIES"
      },
      {
        "code" : "C900199",
        "display" : "HAEMOSTASIS SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "C9002",
      "display" : "VASCULAR AND FASCIAL DILATORS"
    },
    {
      "code" : "C9003",
      "display" : "CARDIOVASCULAR SENSORS",
      "concept" : [{
        "code" : "C900301",
        "display" : "PULSE OXIMETER SENSORS"
      },
      {
        "code" : "C900399",
        "display" : "CARDIOVASCULAR SENSORS - OTHER"
      }]
    },
    {
      "code" : "C9005",
      "display" : "PHONENDOSCOPES AND STETHOSCOPES"
    },
    {
      "code" : "C9006",
      "display" : "ANEROID SPHYGMOMANOMETERS"
    },
    {
      "code" : "C9080",
      "display" : "CARDIOCIRCULATORY SYSTEM DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
    }]
  },
  {
    "code" : "C99",
    "display" : "CARDIOCIRCULATORY DEVICES - OTHER"
  },
  {
    "code" : "D",
    "display" : "DISINFECTANTS, ANTISEPTICS, STERILISING AGENTS AND DETERGENTS FOR MEDICAL DEVICES"
  },
  {
    "code" : "D01",
    "display" : "ALDEHYDES FOR THE DISINFECTION OF MEDICAL DEVICES",
    "concept" : [{
      "code" : "D0101",
      "display" : "GLUTARALDEHYDE AND ASSOCIATES FOR THE DISINFECTION OF MEDICAL DEVICES",
      "concept" : [{
        "code" : "D010101",
        "display" : "GLUTARALDEHYDE FOR THE DISINFECTION OF MEDICAL DEVICES",
        "concept" : [{
          "code" : "D01010101",
          "display" : "GLUTARALDEHYDE, BASIC SOLUTION FOR THE DISINFECTION OF MEDICAL DEVICES"
        },
        {
          "code" : "D01010102",
          "display" : "GLUTARALDEHYDE, ACIDIC SOLUTION FOR THE DISINFECTION OF MEDICAL DEVICES"
        },
        {
          "code" : "D01010103",
          "display" : "GLUTARALDEHYDE, NEUTRAL SOLUTION FOR THE DISINFECTION OF MEDICAL DEVICES"
        }]
      },
      {
        "code" : "D010102",
        "display" : "GLUTARALDEHYDE AND POLYPHENOLS FOR THE DISINFECTION OF MEDICAL DEVICES",
        "concept" : [{
          "code" : "D01010201",
          "display" : "GLUTARALDEHYDE AND POLYPHENOLS, SOLUTION FOR THE DISINFECTION OF MEDICAL DEVICES"
        }]
      },
      {
        "code" : "D010103",
        "display" : "ORTHOPHTALALDEHYDE FOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D010199",
        "display" : "ASSOCIATED GLUTARALDEHYDE FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "D0199",
      "display" : "ALDEHYDES FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
    }]
  },
  {
    "code" : "D02",
    "display" : "BIGUANIDES FOR THE DISINFECTION OF MEDICAL DEVICES",
    "concept" : [{
      "code" : "D0201",
      "display" : "CHLORHEXIDINE AND ASSOCIATES FOR THE DISINFECTION OF MEDICAL DEVICES",
      "concept" : [{
        "code" : "D020101",
        "display" : "CHLORHEXIDINE FOR THE DISINFECTION OF MEDICAL DEVICES",
        "concept" : [{
          "code" : "D02010101",
          "display" : "CHLORHEXIDINE, AQUEOUS SOLUTION FOR THE DISINFECTION OF MEDICAL DEVICES"
        },
        {
          "code" : "D02010102",
          "display" : "CHLORHEXIDINE, HYDROALCOHOLIC SOLUTION FOR THE DISINFECTION OF MEDICAL DEVICES"
        },
        {
          "code" : "D02010199",
          "display" : "CHLORHEXIDINE FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
        }]
      },
      {
        "code" : "D020102",
        "display" : "CHLORHEXIDINE WITH DETERGENT FOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D020199",
        "display" : "CHLORHEXIDINE IN ASSCOCIATION FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "D0299",
      "display" : "BIGUANIDES FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
    }]
  },
  {
    "code" : "D03",
    "display" : "CHLORINE DERIVATIVES FOR THE DISINFECTION OF MEDICAL DEVICES",
    "concept" : [{
      "code" : "D0301",
      "display" : "HYPOCHLORITES AND ASSOCIATES FOR THE DISINFECTION OF MEDICAL DEVICES",
      "concept" : [{
        "code" : "D030101",
        "display" : "HYPOCHLORITE FOR THE DISINFECTION OF MEDICAL DEVICES",
        "concept" : [{
          "code" : "D03010101",
          "display" : "HYPOCHLORITE, AQUEOUS SOLUTION FOR THE DISINFECTION OF MEDICAL DEVICES"
        },
        {
          "code" : "D03010102",
          "display" : "HYPOCHLORITE, HYDROALCOHOLIC SOLUTION FOR THE DISINFECTION OF MEDICAL DEVICES"
        },
        {
          "code" : "D03010199",
          "display" : "HYPOCHLORITE FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
        }]
      },
      {
        "code" : "D030102",
        "display" : "HYPOCHLORITE WITH DETERGENT FOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D030103",
        "display" : "HYPOCHLORITE WITH DISINCRUSTANTS FOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D030199",
        "display" : "ASSOCIATED HYPOCHLORITES FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "D0302",
      "display" : "DICHLOROISOCYANURATES FOR THE DISINFECTION OF MEDICAL DEVICES"
    },
    {
      "code" : "D0303",
      "display" : "SODIUM CHLORITES AND ASSOCIATES FOR THE DISINFECTION OF MEDICAL DEVICES",
      "concept" : [{
        "code" : "D030301",
        "display" : "SODIUM CHLORITE AND LACTIC ACID FOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D030302",
        "display" : "SODIUM CHLORITE FOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D030399",
        "display" : "ASSOCIATED SODIUM CHLORITES FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "D0399",
      "display" : "CHLORINE DERIVATIVES FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
    }]
  },
  {
    "code" : "D05",
    "display" : "OXYGEN PRODUCERS FOR DISINFECTION OF MEDICAL DEVICES",
    "concept" : [{
      "code" : "D0501",
      "display" : "PERACETIC ACID AND ASSOCIATES FOR THE DISINFECTION OF MEDICAL DEVICES",
      "concept" : [{
        "code" : "D050101",
        "display" : "PERACETIC AND ACETIC ACID WITH HYDROGEN PEROXIDE FOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D050102",
        "display" : "PERACETIC ACID AND ADAMANTAN DERIVATIVES FOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D050103",
        "display" : "PERACETIC ACID FOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D050199",
        "display" : "ASSOCIATED PERACETIC ACID FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "D0502",
      "display" : "HYDROGEN PEROXIDE FOR DISINFECTION OF MEDICAL DEVICES"
    },
    {
      "code" : "D0599",
      "display" : "OXYGEN PRODUCERS FOR DISINFECTION OF MEDICAL DEVICES - OTHER"
    }]
  },
  {
    "code" : "D06",
    "display" : "PHENOLS FOR DISINFECTION OF MEDICAL DEVICES",
    "concept" : [{
      "code" : "D0601",
      "display" : "POLYPHENOLS AND ASSOCIATES FOR THE DISINFECTION OF MEDICAL DEVICES",
      "concept" : [{
        "code" : "D060101",
        "display" : "POLYPHENOLS",
        "concept" : [{
          "code" : "D06010101",
          "display" : "POLYPHENOLS, AQUEOUS SOLUTION FOR THE DISINFECTION OF MEDICAL DEVICES"
        },
        {
          "code" : "D06010199",
          "display" : "POLYPHENOLS FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
        }]
      },
      {
        "code" : "D060102",
        "display" : "POLYPHENOLS WITH DETERGENTSFOR THE DISINFECTION OF MEDICAL DEVICES"
      },
      {
        "code" : "D060199",
        "display" : "ASSOCIATED POLYPHENOLS FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "D0699",
      "display" : "PHENOLS FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
    }]
  },
  {
    "code" : "D07",
    "display" : "ALCOHOLS FOR THE DISINFECTION OF MEDICAL DEVICES",
    "concept" : [{
      "code" : "D0701",
      "display" : "ETHANOL FOR THE DISINFECTION OF MEDICAL DEVICES"
    },
    {
      "code" : "D0702",
      "display" : "ISOPROPYL ALCOHOL FOR THE DISINFECTION OF MEDICAL DEVICES"
    },
    {
      "code" : "D0799",
      "display" : "ALCOHOLS FOR THE DISINFECTION OF MEDICAL DEVICES - OTHER"
    }]
  },
  {
    "code" : "D08",
    "display" : "DETERGENTS FOR MEDICAL DEVICES",
    "concept" : [{
      "code" : "D0801",
      "display" : "ENZYMATIC DETERGENTS FOR MEDICAL DEVICES"
    },
    {
      "code" : "D0899",
      "display" : "DETERGENTS FOR MEDICAL DEVICES - OTHER"
    }]
  },
  {
    "code" : "D09",
    "display" : "AMMONIUM SALTS AND ASSOCIATES FOR THE DISINFECTION OF MEDICAL DEVICES",
    "concept" : [{
      "code" : "D0901",
      "display" : "AMMONIUM SALTS FOR THE DISINFECTION OF MEDICAL DEVICES"
    },
    {
      "code" : "D0902",
      "display" : "ASSOCIATED AMMONIUM SALTS FOR THE DISINFECTION OF MEDICAL DEVICES"
    }]
  },
  {
    "code" : "D99",
    "display" : "DISINFECTANTS, ANTISEPTICS, STERILISING AGENTS AND DETERGENTS FOR MEDICAL DEVICES - OTHER"
  },
  {
    "code" : "F",
    "display" : "DIALYSIS DEVICES"
  },
  {
    "code" : "F01",
    "display" : "DIALYSIS FILTERS",
    "concept" : [{
      "code" : "F0106",
      "display" : "HAEMODIALYSIS, HAEMOFILTRATION, HAEMODIAFILTRATION FILTERS",
      "concept" : [{
        "code" : "F010601",
        "display" : "DIALYSERS - UFC < 18 ml/h/mmHg",
        "concept" : [{
          "code" : "F01060101",
          "display" : "DIALYSERS - UFC < 18 ml/h/mmHg, CELLULOSE MEMBRANES"
        },
        {
          "code" : "F01060102",
          "display" : "DIALYSERS - UFC < 18 ml/h/mmHg, SUBSTITUTED CELLULOSE MEMBRANES"
        },
        {
          "code" : "F01060103",
          "display" : "DIALYSERS - UFC < 18 ml/h/mmHg, SYNTHETIC MEMBRANES"
        },
        {
          "code" : "F01060199",
          "display" : "DIALYSERS - UFC < 18 ml/h/mmHg - OTHER"
        }]
      },
      {
        "code" : "F010602",
        "display" : "DIALYSERS - UFC = 18 - 35 ml/h/mmHg",
        "concept" : [{
          "code" : "F01060201",
          "display" : "DIALYSERS - UFC = 18 - 35 ml/h/mmHg, CELLULOSE MEMBRANES"
        },
        {
          "code" : "F01060202",
          "display" : "DIALYSERS - UFC = 18 - 35 ml/h/mmHg, SUBSTITUTED CELLULOSE MEMBRANES"
        },
        {
          "code" : "F01060203",
          "display" : "DIALYSERS - UFC = 18 - 35 ml/h/mmHg, SYNTHETIC MEMBRANES"
        },
        {
          "code" : "F01060299",
          "display" : "DIALYSERS - UFC = 18 - 35 ml/h/mmHg - OTHER"
        }]
      },
      {
        "code" : "F010603",
        "display" : "DIALYSERS - UFC > 35 ml/h/mmHg",
        "concept" : [{
          "code" : "F01060301",
          "display" : "DIALYSERS - UFC > 35 ml/h/mmHg, CELLULOSE MEMBRANES"
        },
        {
          "code" : "F01060302",
          "display" : "DIALYSERS - UFC > 35 ml/h/mmHg, SUBSTITUTED CELLULOSE MEMBRANES"
        },
        {
          "code" : "F01060303",
          "display" : "DIALYSERS - UFC > 35 ml/h/mmHg, SYNTHETIC MEMBRANES"
        },
        {
          "code" : "F01060399",
          "display" : "DIALYSERS - UFC > 35 ml/h/mmHg - OTHER"
        }]
      },
      {
        "code" : "F010604",
        "display" : "DIALYSERS FOR SPECIAL HAEMODIAFILTRATION AND OTHER THERAPIES"
      }]
    },
    {
      "code" : "F0107",
      "display" : "HAEMOPERFUSION FILTERS",
      "concept" : [{
        "code" : "F010701",
        "display" : "HAEMOPERFUSION CARBON FILTERS"
      },
      {
        "code" : "F010702",
        "display" : "HAEMOPERFUSION RESIN FILTERS"
      },
      {
        "code" : "F010799",
        "display" : "HAEMOPERFUSION FILTERS - OTHER"
      }]
    },
    {
      "code" : "F0108",
      "display" : "ADSORPTION FILTERS AND COLUMNS",
      "concept" : [{
        "code" : "F010801",
        "display" : "IMMUNOADSORPTION FILTERS AND COLUMNS",
        "concept" : [{
          "code" : "F01080101",
          "display" : "IMMUNOADSORPTION FILTERS"
        },
        {
          "code" : "F01080102",
          "display" : "IMMUNOADSORPTION COLUMNS"
        }]
      },
      {
        "code" : "F010802",
        "display" : "ENDOTOXIN REMOVAL FILTERS AND COLUMNS",
        "concept" : [{
          "code" : "F01080201",
          "display" : "ENDOTOXIN REMOVAL FILTERS"
        },
        {
          "code" : "F01080202",
          "display" : "ENDOTOXIN REMOVAL COLUMNS"
        }]
      }]
    },
    {
      "code" : "F0109",
      "display" : "PERITONEAL DIALYSIS FILTERS"
    },
    {
      "code" : "F0199",
      "display" : "HAEMODIALYSIS FILTERS - OTHER"
    }]
  },
  {
    "code" : "F02",
    "display" : "DIALYSIS LINES",
    "concept" : [{
      "code" : "F0201",
      "display" : "ARTERIOVENOUS DIALYSIS LINES FOR HAEMODIALYSIS - HAEMOFILTRATION -HAEMODIAFILTRATION",
      "concept" : [{
        "code" : "F020101",
        "display" : "ARTERIOVENOUS DIALYSIS LINES, ONE NEEDLE"
      },
      {
        "code" : "F020102",
        "display" : "ARTERIOVENOUS DIALYSIS LINES, TWO NEEDLES"
      },
      {
        "code" : "F020104",
        "display" : "REINFUSION DIALYSIS LINES"
      },
      {
        "code" : "F020180",
        "display" : "ARTERIOVENOUS DIALYSIS LINES FOR HAEMODIALYSIS - HAEMOFILTRATION -HAEMODIAFILTRATION - ACCESSORIES"
      },
      {
        "code" : "F020199",
        "display" : "ARTERIOVENOUS DIALYSIS LINES FOR HAEMODIALYSIS - HAEMOFILTRATION -HAEMODIAFILTRATION - OTHER"
      }]
    },
    {
      "code" : "F0202",
      "display" : "PERITONAEAL DIALYSIS LINES",
      "concept" : [{
        "code" : "F020201",
        "display" : "PERMANENT PERITONAEAL DIALYSIS LINES",
        "concept" : [{
          "code" : "F02020101",
          "display" : "PERMANENT PERITONAEAL DIALYSIS LINES, ONE BAG (CAPD)"
        },
        {
          "code" : "F02020102",
          "display" : "PERMANENT PERITONAEAL DIALYSIS LINES, TWO BAGS (CAPD)"
        },
        {
          "code" : "F02020199",
          "display" : "PERMANENT PERITONAEAL DIALYSIS LINES - OTHER"
        }]
      },
      {
        "code" : "F020202",
        "display" : "TEMPORARY PERITONAEAL DIALYSIS LINES",
        "concept" : [{
          "code" : "F02020201",
          "display" : "TEMPORARY PERITONAEAL DIALYSIS LINES, GRAVITY (APD)"
        },
        {
          "code" : "F02020202",
          "display" : "TEMPORARY PERITONAEAL DIALYSIS LINES, WITH PUMP (APD)"
        },
        {
          "code" : "F02020299",
          "display" : "TEMPORARY PERITONAEAL DIALYSIS LINES - OTHER"
        }]
      },
      {
        "code" : "F020280",
        "display" : "PERITONAEAL DIALYSIS LINES - ACCESSORIES"
      },
      {
        "code" : "F020299",
        "display" : "PERITONAEAL DIALYSIS LINES - OTHER"
      }]
    },
    {
      "code" : "F0299",
      "display" : "DIALYSIS LINES - OTHER"
    }]
  },
  {
    "code" : "F03",
    "display" : "DIALYSIS KITS",
    "concept" : [{
      "code" : "F0301",
      "display" : "HAEMOFILTRATION-HAEMODIAFILTRATION KITS"
    },
    {
      "code" : "F0302",
      "display" : "BIOFILTRATION KITS"
    },
    {
      "code" : "F0303",
      "display" : "HAEMODIALYSIS KITS"
    },
    {
      "code" : "F0304",
      "display" : "DIALYSIS WASHING/FILLING KITS"
    },
    {
      "code" : "F0305",
      "display" : "HAEMOPERFUSION KITS"
    },
    {
      "code" : "F0306",
      "display" : "CONTINUOUS DIALYSIS KITS"
    },
    {
      "code" : "F0307",
      "display" : "ULTRAFILTRATION KITS"
    },
    {
      "code" : "F0399",
      "display" : "DIALYSIS KITS - OTHER"
    }]
  },
  {
    "code" : "F04",
    "display" : "DIALYSIS CONCENTRATES",
    "concept" : [{
      "code" : "F0401",
      "display" : "DIALYSIS CONCENTRATES, ACID SOLUTIONS",
      "concept" : [{
        "code" : "F040101",
        "display" : "DIALYSIS CONCENTRATES, ACID SOLUTIONS, NON-STERILE"
      },
      {
        "code" : "F040102",
        "display" : "DIALYSIS CONCENTRATES, ACID SOLUTIONS, STERILE"
      }]
    },
    {
      "code" : "F0402",
      "display" : "DIALYSIS CONCENTRATES, BASIC SOLUTIONS",
      "concept" : [{
        "code" : "F040201",
        "display" : "DIALYSIS CONCENTRATES, BASIC SOLUTIONS, POWDER"
      },
      {
        "code" : "F040202",
        "display" : "DIALYSIS CONCENTRATES, BASIC SOLUTIONS, LIQUID"
      }]
    },
    {
      "code" : "F0403",
      "display" : "DIALYSIS CONCENTRATES, WITHOUT ACETATE BUFFER",
      "concept" : [{
        "code" : "F040302",
        "display" : "DIALYSIS CONCENTRATES, WITHOUT ACETATE BUFFER - AFB"
      },
      {
        "code" : "F040399",
        "display" : "DIALYSIS CONCENTRATES, WITHOUT ACETATE BUFFER FOR OTHER TREATMENTS"
      }]
    },
    {
      "code" : "F0404",
      "display" : "DIALYSIS PROCEDURES, SALTS"
    },
    {
      "code" : "F0499",
      "display" : "DIALYSIS CONCENTRATES - OTHER"
    }]
  },
  {
    "code" : "F05",
    "display" : "DEVICES FOR MICRODIALYSIS OF SPECIFIC ORGANS"
  },
  {
    "code" : "F90",
    "display" : "DIALYSIS DEVICES - VARIOUS",
    "concept" : [{
      "code" : "F9001",
      "display" : "PERITONAEAL DIALYSIS DEVICES (NOT INCLUDED IN OTHER GROUPS)",
      "concept" : [{
        "code" : "F900101",
        "display" : "PERITONEAL DIALYSIS CATHETERS AND KITS"
      },
      {
        "code" : "F900199",
        "display" : "PERITONAEAL DIALYSIS - OTHER"
      }]
    },
    {
      "code" : "F9002",
      "display" : "VASCULAR ACCESS DEVICES (ONLY FOR HAEMODIALYSIS)",
      "concept" : [{
        "code" : "F900201",
        "display" : "TEMPORARY HEMODIALYSIS CATHETERS AND KITS"
      },
      {
        "code" : "F900202",
        "display" : "PERMANENT HEMODIALYSIS CATHETERS AND KITS"
      },
      {
        "code" : "F900299",
        "display" : "VASCULAR ACCESS DEVICES (ONLY FOR HAEMODIALYSIS) - OTHER"
      }]
    },
    {
      "code" : "F9003",
      "display" : "DIALYSIS ADAPTORS",
      "concept" : [{
        "code" : "F900301",
        "display" : "HAEMODIALYSIS ADAPTORS"
      },
      {
        "code" : "F900302",
        "display" : "PERITONAEAL DIALYSIS ADAPTORS"
      }]
    },
    {
      "code" : "F9004",
      "display" : "DIALYSATE COLLECTION AND REINFUSION BAGS",
      "concept" : [{
        "code" : "F900401",
        "display" : "DIALYSATE COLLECTION BAGS",
        "concept" : [{
          "code" : "F90040101",
          "display" : "HAEMODIALYSATE COLLECTION BAGS"
        },
        {
          "code" : "F90040102",
          "display" : "PERITONAEAL DIALYSATE COLLECTION BAGS"
        }]
      },
      {
        "code" : "F900402",
        "display" : "DIALYSATE REINFUSION BAGS"
      }]
    },
    {
      "code" : "F9006",
      "display" : "DIALYTIC TREATMENT INSTRUMENTS, SINGLE-USE"
    },
    {
      "code" : "F9080",
      "display" : "DIALYSIS DEVICES - OTHER ACCESSORIES"
    },
    {
      "code" : "F9099",
      "display" : "DIALYSIS DEVICES - OTHER"
    }]
  },
  {
    "code" : "G",
    "display" : "GASTROINTESTINAL DEVICES"
  },
  {
    "code" : "G01",
    "display" : "ORO-OESOPHAGEAL TUBES",
    "concept" : [{
      "code" : "G0101",
      "display" : "OESOPHAGEAL DILATION TUBES",
      "concept" : [{
        "code" : "G010101",
        "display" : "OESOPHAGEAL BOUGIES"
      },
      {
        "code" : "G010102",
        "display" : "CARDIAS DILATATION TUBES"
      },
      {
        "code" : "G010199",
        "display" : "OESOPHAGEAL DILATION TUBES - OTHER"
      }]
    },
    {
      "code" : "G0102",
      "display" : "OESOPHAGEAL HAEMOSTASIS TUBES",
      "concept" : [{
        "code" : "G010201",
        "display" : "SENGSTAKEN TUBES"
      },
      {
        "code" : "G010202",
        "display" : "LINTON-NACHLAS TUBES"
      },
      {
        "code" : "G010299",
        "display" : "OESOPHAGEAL HAEMOSTASIS TUBES - OTHER"
      }]
    },
    {
      "code" : "G0103",
      "display" : "ORO-ESOPAGHEAL DIAGNOSTIC TUBES",
      "concept" : [{
        "code" : "G010301",
        "display" : "OESOPHAGEAL PH-METRY, TUBES"
      },
      {
        "code" : "G010302",
        "display" : "OESOPHAGEAL MANOMETRY, CATHETERS"
      },
      {
        "code" : "G010303",
        "display" : "SIALOGRAPHY, CATHETERS"
      },
      {
        "code" : "G010304",
        "display" : "TUBES FOR pH METRY AND OESOPHAGEAL IMPEDANCE ANALYSIS"
      },
      {
        "code" : "G010305",
        "display" : "TUBES FOR OESOPHAGEA pH METRY AND BILIARY REFLUX ASSESSMENT"
      },
      {
        "code" : "G010399",
        "display" : "ORO-OESOPAGHEAL DIAGNOSTIC TUBES - OTHER"
      }]
    },
    {
      "code" : "G0180",
      "display" : "ORO-OESOPHAGEAL TUBES - ACCESSORIES"
    },
    {
      "code" : "G0199",
      "display" : "ORO-OESOPHAGEAL TUBES - OTHER"
    }]
  },
  {
    "code" : "G02",
    "display" : "GASTROINTESTINAL TUBES AND SETS",
    "concept" : [{
      "code" : "G0201",
      "display" : "GASTRO-INTESTINAL LAVAGE TUBES AND SETS",
      "concept" : [{
        "code" : "G020101",
        "display" : "GASTRIC LAVAGE TUBES AND SETS"
      },
      {
        "code" : "G020102",
        "display" : "INTESTINAL LAVAGE TUBES AND SETS"
      },
      {
        "code" : "G020199",
        "display" : "GASTROINTESTINAL LAVAGE, TUBES AND SETS - OTHER"
      }]
    },
    {
      "code" : "G0202",
      "display" : "GASTROINTESTINAL FEEDING/ASPIRATION TUBES",
      "concept" : [{
        "code" : "G020201",
        "display" : "NASOGASTRIC INTESTINAL TUBES",
        "concept" : [{
          "code" : "G02020101",
          "display" : "NASOGASTRIC TUBES"
        },
        {
          "code" : "G02020102",
          "display" : "NASOJEJUNAL/NASODUODENAL TUBES"
        },
        {
          "code" : "G02020199",
          "display" : "NASOGASTRIC INTESTINAL TUBES - OTHER"
        }]
      },
      {
        "code" : "G020202",
        "display" : "GASTRO-JEJUNOSTOMY, TUBES AND SETS",
        "concept" : [{
          "code" : "G02020201",
          "display" : "GASTROSTOMY, TUBES AND SETS"
        },
        {
          "code" : "G02020202",
          "display" : "JEJUNOSTOMY, TUBES AND SETS"
        },
        {
          "code" : "G02020203",
          "display" : "ILEOSTOMY, TUBES AND SETS"
        }]
      },
      {
        "code" : "G020299",
        "display" : "GASTROINTESTINAL FEEDING/ASPIRATION TUBES - OTHER"
      }]
    },
    {
      "code" : "G0203",
      "display" : "EVACUATION TUBES",
      "concept" : [{
        "code" : "G020301",
        "display" : "RECTAL TUBES"
      },
      {
        "code" : "G020399",
        "display" : "EVACUATION TUBES - OTHER"
      }]
    },
    {
      "code" : "G0204",
      "display" : "GASTROINTESTINAL HAEMOSTASIS DEVICES",
      "concept" : [{
        "code" : "G020401",
        "display" : "HAEMORRHOID LIGATURE SETS"
      },
      {
        "code" : "G020402",
        "display" : "HAEMORRHOID SCLEROTHERAPY DEVICES"
      },
      {
        "code" : "G020499",
        "display" : "GASTROINTESTINAL HAEMOSTASIS DEVICES - OTHER"
      }]
    },
    {
      "code" : "G0205",
      "display" : "DEVICES FOR THE SURGICAL OBESITY THERAPY",
      "concept" : [{
        "code" : "G020501",
        "display" : "GASTRIC BANDS"
      },
      {
        "code" : "G020502",
        "display" : "GASTRIC CALIBRATION TUBES"
      },
      {
        "code" : "G020503",
        "display" : "GASTRIC BAND SYSTEM ADJUSTMENT SETS"
      },
      {
        "code" : "G020599",
        "display" : "DEVICES FOR THE SURGICAL THERAPY OF OBESITY - OTHER"
      }]
    },
    {
      "code" : "G0206",
      "display" : "DEVICES FOR GASTROINTESTINAL DIAGNOSTIC PROCEDURES",
      "concept" : [{
        "code" : "G020601",
        "display" : "GASTROINTESTINAL DIAGNOSTIC PROCEDURE CATHETERS",
        "concept" : [{
          "code" : "G02060101",
          "display" : "DUODENOGRAPHY CATHETERS"
        },
        {
          "code" : "G02060102",
          "display" : "CATHETERS FOR GASTRO-JEJUNAL MANOMETRY"
        },
        {
          "code" : "G02060199",
          "display" : "CATHETERS FOR GASTRO-DUODENAL-DIGIUNAL DIAGNOSTICS - OTHER"
        }]
      },
      {
        "code" : "G020602",
        "display" : "CATHETERS FOR BILIARY AND PANCREATIC DIAGNOSTIC PROCEDURES",
        "concept" : [{
          "code" : "G02060201",
          "display" : "OPEN SURGERY CHOLANGIOGRAPHY CATHETERS"
        },
        {
          "code" : "G02060202",
          "display" : "BILIARY MANOMETRY CATHETERS"
        },
        {
          "code" : "G02060299",
          "display" : "BILIARY AND PANCREATIC DIAGNOSTIC PROCEDURE CATHETERS - OTHER"
        }]
      },
      {
        "code" : "G020603",
        "display" : "DEVICES FOR COLORECTAL DIAGNOSTIC PROCEDURES",
        "concept" : [{
          "code" : "G02060301",
          "display" : "ANOSCOPES"
        },
        {
          "code" : "G02060302",
          "display" : "RIGID PROCTOSCOPES"
        },
        {
          "code" : "G02060303",
          "display" : "BALLOON CATHETERS, BARIUM ENEMA"
        },
        {
          "code" : "G02060304",
          "display" : "COLORECTAL INSUFFLATION TUBES"
        },
        {
          "code" : "G02060305",
          "display" : "COLORECTAL MANOMETRY CATHETERS"
        },
        {
          "code" : "G02060399",
          "display" : "DEVICES FOR COLORECTAL DIAGNOSTIC PROCEDURES - OTHER"
        }]
      }]
    },
    {
      "code" : "G0280",
      "display" : "GASTROINTESTINAL TUBES - ACCESSORIES"
    },
    {
      "code" : "G0299",
      "display" : "GASTROINTESTINAL TUBES - OTHER"
    }]
  },
  {
    "code" : "G03",
    "display" : "GASTROINTESTINAL ENDOSCOPY DEVICES",
    "concept" : [{
      "code" : "G0301",
      "display" : "DEVICES FOR DILATION IN DIGESTIVE ENDOSCOPY",
      "concept" : [{
        "code" : "G030101",
        "display" : "GASTROINTESTINAL ENDOSCOPY, BALLOON CATHETERS",
        "concept" : [{
          "code" : "G03010101",
          "display" : "OESOPHAGEAL BALLOON CATHETERS",
          "concept" : [{
            "code" : "G0301010101",
            "display" : "OESOPHAGEAL BALLOON CATHETERS, LOW PRESSURE"
          },
          {
            "code" : "G0301010102",
            "display" : "OESOPHAGEAL BALLOON CATHETERS, HIGH PRESSURE"
          }]
        },
        {
          "code" : "G03010102",
          "display" : "ACHALASIA BALLOON CATHETERS",
          "concept" : [{
            "code" : "G0301010201",
            "display" : "ACHALASIA BALLOON CATHETERS, LOW PRESSURE"
          },
          {
            "code" : "G0301010202",
            "display" : "ACHALASIA BALLOON CATHETERS, HIGH PRESSURE"
          }]
        },
        {
          "code" : "G03010103",
          "display" : "PYLORIC BALLOON CATHETERS",
          "concept" : [{
            "code" : "G0301010301",
            "display" : "PYLORIC BALLOON CATHETERS, LOW PRESSURE"
          },
          {
            "code" : "G0301010302",
            "display" : "PYLORIC BALLOON CATHETERS, HIGH PRESSURE"
          }]
        },
        {
          "code" : "G03010104",
          "display" : "BILIARY BALLOON CATHETERS",
          "concept" : [{
            "code" : "G0301010401",
            "display" : "BILIARY BALLOON CATHETERS, LOW PRESSURE"
          },
          {
            "code" : "G0301010402",
            "display" : "BILIARY BALLOON CATHETERS, HIGH PRESSURE"
          }]
        },
        {
          "code" : "G03010105",
          "display" : "COLONIC BALLOON CATHETERS",
          "concept" : [{
            "code" : "G0301010501",
            "display" : "COLONIC BALLOON CATHETERS, LOW PRESSURE"
          },
          {
            "code" : "G0301010502",
            "display" : "COLONIC BALLOON CATHETERS, HIGH PRESSURE"
          }]
        },
        {
          "code" : "G03010199",
          "display" : "GASTROINTESTINAL ENDOSCOPY, BALLOON CATHETERS - OTHER"
        }]
      },
      {
        "code" : "G030102",
        "display" : "DIGESTIVE ENDOSCOPY, PROGRESSIVE DILATORS",
        "concept" : [{
          "code" : "G03010201",
          "display" : "DIGESTIVE ENDOSCOPY, PROGRESSIVE RIGID DILATORS"
        },
        {
          "code" : "G03010202",
          "display" : "DIGESTIVE ENDOSCOPY, PROGRESSIVE FLEXIBLE DILATORS"
        }]
      }]
    },
    {
      "code" : "G0302",
      "display" : "DIGESTIVE ENDOSCOPY, HAEMOSTASIS DEVICES",
      "concept" : [{
        "code" : "G030201",
        "display" : "DIGESTIVE ENDOSCOPY, NEEDLES",
        "concept" : [{
          "code" : "G03020101",
          "display" : "DIGESTIVE ENDOSCOPY, SINGLE-LUMEN NEEDLES"
        },
        {
          "code" : "G03020102",
          "display" : "DIGESTIVE ENDOSCOPY, MULTI-LUMEN NEEDLES"
        }]
      },
      {
        "code" : "G030202",
        "display" : "DIGESTIVE ENDOSCOPY, HAEMOSTASIS CLIPS"
      },
      {
        "code" : "G030203",
        "display" : "DIGESTIVE ENDOSCOPY, LIGATURE SYSTEMS",
        "concept" : [{
          "code" : "G03020301",
          "display" : "LIGATURE SYSTEMS, OESOPHAGEAL VARICES"
        },
        {
          "code" : "G03020302",
          "display" : "DIGESTIVE LIGATURE DEVICES, POLYPS"
        },
        {
          "code" : "G03020399",
          "display" : "DIGESTIVE ENDOSCOPY, LIGATURE SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "G030204",
        "display" : "DIGESTIVE ENDOSCOPY, THERMOCOAGULATION PROBES"
      },
      {
        "code" : "G030299",
        "display" : "DIGESTIVE ENDOSCOPY, HAEMOSTASIS DEVICES - OTHER"
      }]
    },
    {
      "code" : "G0303",
      "display" : "POLYPECTOMY DEVICES",
      "concept" : [{
        "code" : "G030301",
        "display" : "POLYPECTOMY SNARES",
        "concept" : [{
          "code" : "G03030101",
          "display" : "POLYPECTOMY SNARES, REVOLVING"
        },
        {
          "code" : "G03030102",
          "display" : "POLYPECTOMY SNARES, NON-REVOLVING"
        },
        {
          "code" : "G03030199",
          "display" : "POLYPECTOMY SNARES - OTHER"
        }]
      },
      {
        "code" : "G030399",
        "display" : "POLYPECTOMY DEVICES - OTHER"
      }]
    },
    {
      "code" : "G0304",
      "display" : "ENDOSCOPIC RETROGRADE CHOLANGIOPANCREATOGRAPHY (ERCP) AND SPHINCTEROTOMY DEVICES",
      "concept" : [{
        "code" : "G030401",
        "display" : "ERCP CANNULAS",
        "concept" : [{
          "code" : "G03040101",
          "display" : "ERCP CANNULAS, SINGLE-LUMEN",
          "concept" : [{
            "code" : "G0304010101",
            "display" : "ERCP CANNULAS, SINGLE-LUMEN, STANDARD TIP"
          },
          {
            "code" : "G0304010102",
            "display" : "ERCP CANNULAS, SINGLE-LUMEN, CONICAL TIP"
          },
          {
            "code" : "G0304010103",
            "display" : "ERCP CANNULAS, SINGLE-LUMEN, TAPERED TIP"
          },
          {
            "code" : "G0304010104",
            "display" : "ERCP CANNULAS, SINGLE-LUMEN, CIRCULAR TIP"
          },
          {
            "code" : "G0304010199",
            "display" : "ERCP CANNULAS, SINGLE-LUMEN - OTHER"
          }]
        },
        {
          "code" : "G03040102",
          "display" : "ERCP CANNULAS, MULTI-LUMEN",
          "concept" : [{
            "code" : "G0304010201",
            "display" : "ERCP CANNULAS, MULTI-LUMEN, STANDARD TIP"
          },
          {
            "code" : "G0304010202",
            "display" : "ERCP CANNULAS, MULTI-LUMEN, CONICAL TIP"
          },
          {
            "code" : "G0304010203",
            "display" : "ERCP CANNULAS, MULTI-LUMEN, TAPERED TIP"
          },
          {
            "code" : "G0304010204",
            "display" : "ERCP CANNULAS, MULTI-LUMEN, CIRCULAR TIP"
          },
          {
            "code" : "G0304010299",
            "display" : "ERCP CANNULAS, MULTI-LUMEN - OTHER"
          }]
        }]
      },
      {
        "code" : "G030402",
        "display" : "PAPILLOTOMES / SPHINCTEROTOMES",
        "concept" : [{
          "code" : "G03040201",
          "display" : "PAPILLOTOMES / SPHINCTEROTOMES, DOUBLE-LUMEN"
        },
        {
          "code" : "G03040202",
          "display" : "PAPILLOTOMES / SPHINCTEROTOMES, TRIPLE (OR MORE) LUMEN"
        },
        {
          "code" : "G03040299",
          "display" : "PAPILLOTOMES / SPHINCTEROTOMES - OTHER"
        }]
      },
      {
        "code" : "G030403",
        "display" : "NASO-BILIARY-PANCREATIC TUBES",
        "concept" : [{
          "code" : "G03040301",
          "display" : "BILIARY TUBES"
        },
        {
          "code" : "G03040302",
          "display" : "HEPATIC DUCT TUBES"
        },
        {
          "code" : "G03040303",
          "display" : "PANCREATIC TUBES"
        }]
      },
      {
        "code" : "G030499",
        "display" : "ERCP AND SPHINCTEROTOMY DEVICES - OTHER"
      }]
    },
    {
      "code" : "G0305",
      "display" : "RETRIEVAL AND LITHOTRIPSY DEVICES (stones, polyps and foreign bodies)",
      "concept" : [{
        "code" : "G030501",
        "display" : "DIGESTIVE ENDOSCOPY, RETRIEVAL DEVICES",
        "concept" : [{
          "code" : "G03050101",
          "display" : "DIGESTIVE ENDOSCOPY, RETRIEVAL BALLOON DEVICES"
        },
        {
          "code" : "G03050102",
          "display" : "DIGESTIVE ENDOSCOPY, RETRIEVAL BASKET DEVICES",
          "concept" : [{
            "code" : "G0305010201",
            "display" : "DIGESTIVE ENDOSCOPY, RETRIEVAL BASKET DEVICES, REVOLVING"
          },
          {
            "code" : "G0305010202",
            "display" : "DIGESTIVE ENDOSCOPY, RETRIEVAL BASKET DEVICES, NON-REVOLVING"
          }]
        },
        {
          "code" : "G03050103",
          "display" : "DIGESTIVE ENDOSCOPY, DEVICES FOR RECOVERY BY ASPIRATION"
        },
        {
          "code" : "G03050199",
          "display" : "DIGESTIVE ENDOSCOPY, RETRIEVAL DEVICES - OTHER"
        }]
      },
      {
        "code" : "G030502",
        "display" : "LITHOTRIPSY DEVICES"
      }]
    },
    {
      "code" : "G0306",
      "display" : "DEVICES FOR THE NON-SURGICAL THERAPY OF OBESITY",
      "concept" : [{
        "code" : "G030601",
        "display" : "INTRAGASTRIC BALLOON SYSTEMS"
      },
      {
        "code" : "G030602",
        "display" : "DEVICES FOR REMOVAL OF INTRAGASTRIC BALLOONS"
      },
      {
        "code" : "G030603",
        "display" : "INTESTINAL COATING YSTEMS FOR ABSORPTION REDUCTION"
      },
      {
        "code" : "G030604",
        "display" : "DEVICES FOR REMOVAL OF INTESTINAL COATING SYSTEMS"
      },
      {
        "code" : "G030699",
        "display" : "DEVICES FOR THE NON-SURGICAL TREATMENT OF OBESITY - OTHER"
      }]
    },
    {
      "code" : "G0307",
      "display" : "GASTROINTESTINAL ENDOSCOPY, DIAGNOSTIC DEVICES",
      "concept" : [{
        "code" : "G030701",
        "display" : "GASTROINTESTINAL IMAGING DIAGNOSTIC DEVICES"
      },
      {
        "code" : "G030702",
        "display" : "PH MONITORING DEVICES"
      },
      {
        "code" : "G030703",
        "display" : "MARKERS FOR EVALUATION OF GASTROINTESTINAL PASSAGE"
      },
      {
        "code" : "G030704",
        "display" : "COLON DYE SPRAYING CATHETERS"
      },
      {
        "code" : "G030799",
        "display" : "GASTROINTESTINAL ENDOSCOPY, DIAGNOSTIC DEVICES - OTHER"
      }]
    },
    {
      "code" : "G0308",
      "display" : "GASTROINTESTINAL ENDOSCOPY AND ECHOENDOSCOPY, SINGLE-USE INSTRUMENTS",
      "concept" : [{
        "code" : "G030801",
        "display" : "GASTROINTESTINAL ENDOSCOPY, FORCEPS, SINGLE-USE",
        "concept" : [{
          "code" : "G03080101",
          "display" : "GASTROINTESTINAL ENDOSCOPY, BIOPSY FORCEPS, SINGLE-USE",
          "concept" : [{
            "code" : "G0308010101",
            "display" : "GASTROINTESTINAL ENDOSCOPY, COLD BIOPSY FORCEPS, SINGLE-USE"
          },
          {
            "code" : "G0308010102",
            "display" : "GASTROINTESTINAL ENDOSCOPY, HOT BIOPSY FORCEPS, SINGLE-USE"
          }]
        },
        {
          "code" : "G03080102",
          "display" : "GASTROINTESTINAL ENDOSCOPY, EXTRACTION FORCEPS, SINGLE-USE"
        },
        {
          "code" : "G03080199",
          "display" : "GASTROINTESTINAL ENDOSCOPY, FORCEPS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "G030803",
        "display" : "GASTROINTESTINAL ENDOSCOPY AND ECHOENDOSCOPY, BRUSHES",
        "concept" : [{
          "code" : "G03080301",
          "display" : "GASTROINTESTINAL CYTOLOGY, BRUSHES"
        },
        {
          "code" : "G03080399",
          "display" : "GASTROINTESTINAL ENDOSCOPY AND ECHOENDOSCOPY, BRUSHES - OTHER"
        }]
      },
      {
        "code" : "G030804",
        "display" : "GASTROINTESTINAL ENDOSCOPY AND ECHOENDOSCOPY, BITE BLOCKS"
      },
      {
        "code" : "G030805",
        "display" : "GASTROINTESTINAL ENDOSCOPIC TATTOOING SYSTEMS"
      },
      {
        "code" : "G030899",
        "display" : "INSTRUMENTS FOR GASTRO-INTESTINAL ENDOSCOPY AND ECO-ENDOSCOPY, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "G0380",
      "display" : "DIGESTIVE ENDOSCOPY DEVICES - ACCESSORIES"
    },
    {
      "code" : "G0399",
      "display" : "DIGESTIVE ENDOSCOPY DEVICES - OTHER"
    }]
  },
  {
    "code" : "G04",
    "display" : "ORALLY ADMINISTERED GASTROINTESTINAL DEVICES",
    "concept" : [{
      "code" : "G0401",
      "display" : "ORALLY ADMINISTERED DEVICES FOR THE THERAPY OF GASTRO-INTESTINAL DISORDERS"
    },
    {
      "code" : "G0402",
      "display" : "ORALLY ADMINISTERED DEVICES FOR APPETITE CONTROL AND REDUCTION OF INTESTINAL ABSORPTION"
    },
    {
      "code" : "G0499",
      "display" : "ORALLY ADMINISTERED GASTROINTESTINAL DEVICES - OTHER"
    }]
  },
  {
    "code" : "G05",
    "display" : "TOPICAL ANORECTAL ADMINISTERED GASTRO-INTESTINAL SYSTEM DEVICES"
  },
  {
    "code" : "G06",
    "display" : "ANAL DILATORS"
  },
  {
    "code" : "G99",
    "display" : "GASTROINTESTINAL DEVICES - OTHER"
  },
  {
    "code" : "H",
    "display" : "SUTURE DEVICES"
  },
  {
    "code" : "H01",
    "display" : "SURGICAL SUTURES",
    "concept" : [{
      "code" : "H0101",
      "display" : "ABSORBABLE SUTURES",
      "concept" : [{
        "code" : "H010101",
        "display" : "ABSORBABLE SYNTHETIC SUTURES",
        "concept" : [{
          "code" : "H01010101",
          "display" : "MONOFILAMENT ABSORBABLE SYNTHETIC SUTURES",
          "concept" : [{
            "code" : "H0101010101",
            "display" : "POLYDIOXANONE MONOFILAMENT",
            "concept" : [{
              "code" : "H010101010101",
              "display" : "POLYDIOXANONE MONOFILAMENT WITH NEEDLE FOR OPEN SURGERY"
            },
            {
              "code" : "H010101010102",
              "display" : "MOUNTED POLYDIOXANONE MONOFILAMENT WITH NEEDLE FOR VIDEO SURGERY"
            },
            {
              "code" : "H010101010103",
              "display" : "POLYDIOXANONE MONOFILAMENT WITHOUT NEEDLE"
            },
            {
              "code" : "H010101010104",
              "display" : "MOUNTED POLYDIOXANONE MONOFILAMENT WITH NEEDLE FOR TISSUE TRACTION ('BARBED')"
            }]
          },
          {
            "code" : "H0101010102",
            "display" : "POLYGLYCONATE AND MONOFILAMENT DERIVATIVES",
            "concept" : [{
              "code" : "H010101010201",
              "display" : "POLYGLYCONATE AND DERIVATIVES MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010101010202",
              "display" : "POLYGLYCONATE AND DERIVATIVES MONOFILAMENT WITHOUT NEEDLE"
            },
            {
              "code" : "H010101010203",
              "display" : "POLYGLYCONATE AND DERIVATIVES MONOFILAMENT WITH NEEDLE FOR TISSUE TRACTION ('BARBED')"
            }]
          },
          {
            "code" : "H0101010103",
            "display" : "POLIGLECAPRONE AND DERIVATIVES MONOFILAMENT",
            "concept" : [{
              "code" : "H010101010301",
              "display" : "POLIGLECAPRONE AND DERIVATIVES MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010101010302",
              "display" : "POLIGLECAPRONE AND DERIVATIVES MONOFILAMENT WITHOUT NEEDLE"
            },
            {
              "code" : "H010101010303",
              "display" : "POLIGLECAPRONE AND DERIVATIVES MONOFILAMENT WITH NEEDLE FOR TISSUE TRACTION ('BARBED')"
            }]
          },
          {
            "code" : "H0101010199",
            "display" : "MONOFILAMENT ABSORBABLE SYNTHETIC SUTURES - OTHER"
          }]
        },
        {
          "code" : "H01010102",
          "display" : "MULTIFILAMENT SYNTHETIC ABSORBABLE SUTURES",
          "concept" : [{
            "code" : "H0101010201",
            "display" : "POLYGLYCOLIC ACID MULTIFILAMENT",
            "concept" : [{
              "code" : "H010101020101",
              "display" : "POLYGLYCOLIC ACID MULTIFILAMENT WITH NEEDLE FOR OPEN SURGERY"
            },
            {
              "code" : "H010101020102",
              "display" : "POLYGLYCOLIC ACID MULTIFILAMENT WITH NEEDLE FOR VIDEO SURGERY"
            },
            {
              "code" : "H010101020103",
              "display" : "POLYGLYCOLIC ACID MULTIFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0101010202",
            "display" : "POLYGLYCOLIC WITH LACTIC ACID MULTIFILAMENT",
            "concept" : [{
              "code" : "H010101020201",
              "display" : "POLYGLYCOLIC WITH LACTIC ACID MULTIFILAMENT WITH NEEDLE FOR OPEN SURGERY"
            },
            {
              "code" : "H010101020202",
              "display" : "POLYGLYCOLIC WITH LACTIC ACID MULTIFILAMENT WITH NEEDLE FOR VIDEO SURGERY"
            },
            {
              "code" : "H010101020203",
              "display" : "POLYGLYCOLIC WITH LACTIC ACID MULTIFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0101010299",
            "display" : "SYNTHETIC ABSORBABLE MULTIFILAMENT SUTURES - OTHER"
          }]
        },
        {
          "code" : "H01010103",
          "display" : "SYNTHETIC ABSORBABLE MONOFILAMENT SUTURES WITH ANTIBACTERIAL",
          "concept" : [{
            "code" : "H0101010301",
            "display" : "POLYDIOXANONE WITH ANTIBACTERIAL MONOFILAMENT",
            "concept" : [{
              "code" : "H010101030101",
              "display" : "POLYDIOXANONE WITH ANTIBACTERIAL MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010101030102",
              "display" : "POLYDIOXANONE WITH ANTIBACTERIAL MONOFILAMENT WITHOUT NEEDLE"
            },
            {
              "code" : "H010101030103",
              "display" : "POLYDIOXANONE MONOFILAMENT WITH NEEDLE FOR TISSUE TRACTION ('BARBED') WITH ANTIBACTERIAL"
            }]
          },
          {
            "code" : "H0101010302",
            "display" : "POLYGLYCOLIC AND LACTIC ACID WITH ANTIBACTERIAL MONOFILAMENT",
            "concept" : [{
              "code" : "H010101030201",
              "display" : "POLYGLYCOLIC AND LACTIC ACID WITH ANTIBACTERIAL MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010101030202",
              "display" : "POLYGLYCOLIC AND LACTIC ACID WITH ANTIBACTERIAL MONOFILAMENT WITHOUT NEEDLE"
            },
            {
              "code" : "H010101030203",
              "display" : "POLYGLYCOLIC AND LACTIC ACID WITH ANTIBACTERIAL MONOFILAMENT WITH NEEDLE FOR TISSUE TRACTION ('BARBED') WITH ANTIBACTERIAL"
            }]
          },
          {
            "code" : "H0101010303",
            "display" : "POLYGECAPRONE AND DERIVATIVES WITH ANTIBACTERIAL MONOFILAMENT",
            "concept" : [{
              "code" : "H010101030301",
              "display" : "POLYGLECAPRONE AND DERIVATIVES WITH ANTIBACTERIAL MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010101030302",
              "display" : "POLIGLECAPRONE AND DERIVATIVES WITH ANTIBACTERIAL MONOFILAMENT WITHOUT NEEDLE"
            },
            {
              "code" : "H010101030303",
              "display" : "POLYGLYCAPRONE AND DERIVATIVES WITH ANTIBACTERIAL MONOFILAMENT WITH NEEDLE FOR TISSUE TRACTION ('BARBED')"
            }]
          },
          {
            "code" : "H0101010399",
            "display" : "SYNTHETIC RESORBABLE SUTURES WITH ANTIBACTERIAL MONOFILAMENT - OTHER"
          }]
        },
        {
          "code" : "H01010104",
          "display" : "SYNTHETIC RESORBABLE SUTURES WITH ANTIBACTERIAL MULTIFILAMENT",
          "concept" : [{
            "code" : "H0101010401",
            "display" : "POLYGLYCOLIC ACID WITH ANTIBACTERIAL MULTIFILAMENT",
            "concept" : [{
              "code" : "H010101040101",
              "display" : "POLYGLYCOLIC ACID WITH ANTIBACTERIAL MULTIFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010101040102",
              "display" : "POLYGLYCOLIC ACID WITH ANTIBACTERIAL MULTIFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0101010402",
            "display" : "POLYGLYCOLIC ACID WITH ANTIBACTERIAL MULTIFILAMENT WITH NEEDLE",
            "concept" : [{
              "code" : "H010101040201",
              "display" : "POLYGLYCOLIC ACID WITH LACTIC ACID WITH ANTIBACTERIAL MULTIFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010101040202",
              "display" : "POLYGLYCOLIC AND LACTIC ACID WITH ANTIBACTERIAL MULTIFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0101010499",
            "display" : "SYNTHETIC RESORBABLE SUTURES WITH ANTIBACTERIAL MULTIFILAMENT - OTHER"
          }]
        }]
      }]
    },
    {
      "code" : "H0102",
      "display" : "NON-ABSORBABLE SUTURES",
      "concept" : [{
        "code" : "H010201",
        "display" : "NON-ABSORBABLE SYNTHETIC SUTURES",
        "concept" : [{
          "code" : "H01020101",
          "display" : "MONOFILAMENT NON-ABSORBABLE SYNTHETIC SUTURES",
          "concept" : [{
            "code" : "H0102010101",
            "display" : "POLYAMIDE MONOFILAMENT",
            "concept" : [{
              "code" : "H010201010101",
              "display" : "POLYAMIDE MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010201010102",
              "display" : "POLYAMIDE MONOFILAMENT WITHOUT NEEDLE"
            },
            {
              "code" : "H010201010103",
              "display" : "POLYAMIDE MONOFILAMENT WITH NEEDLE FOR TISSUE TRACTION ('BARBED')"
            }]
          },
          {
            "code" : "H0102010102",
            "display" : "POLYESTER AND DERIVATIVES MONOFILAMENT",
            "concept" : [{
              "code" : "H010201010201",
              "display" : "POLYESTER AND DERIVATIVES MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010201010202",
              "display" : "POLYESTER AND DERIVATIVES MONOFILAMENT WITHOUT NEEDLE"
            },
            {
              "code" : "H010201010203",
              "display" : "POLYESTER AND DERIVATIVES MONOFILAMENT WITH NEEDLE FOR TISSUE TRACTION ('BARBED')"
            }]
          },
          {
            "code" : "H0102010103",
            "display" : "POLYETHERPOLYURETHANE MONOFILAMENT",
            "concept" : [{
              "code" : "H010201010301",
              "display" : "POLYETHERPOLYURETHANE MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010201010302",
              "display" : "POLYETHERPOLYURETHANE MONOFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102010104",
            "display" : "POLYPROPYLENE MONOFILAMENT",
            "concept" : [{
              "code" : "H010201010401",
              "display" : "POLYPROPYLENE MONOFILAMENT WITH NEEDLE FOR OPEN SURGERY"
            },
            {
              "code" : "H010201010402",
              "display" : "POLYPROPYLENE MONOFILAMENT WITH NEEDLE FOR VIDEO SURGERY"
            },
            {
              "code" : "H010201010403",
              "display" : "POLYPROPYLENE MONOFILAMENT WITHOUT NEEDLE"
            },
            {
              "code" : "H010201010404",
              "display" : "POLYPROPYLENE MONOFILAMENT WITH NEEDLE FOR TISSUE TRACTION ('BARBED')"
            }]
          },
          {
            "code" : "H0102010105",
            "display" : "POLYTETRAFLUOROETHYLENE (PTFE) MONOFILAMENT",
            "concept" : [{
              "code" : "H010201010501",
              "display" : "POLYTETRAFLUOROETHYLENE (PTFE) MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010201010502",
              "display" : "POLYTETRAFLUOROETHYLENE (PTFE)  MONOFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102010106",
            "display" : "POLYVINYLIDENE FLUORIDE AND DERIVATIVES MONOFILAMENT",
            "concept" : [{
              "code" : "H010201010601",
              "display" : "POLYVINYLIDENE FLUORIDE AND DERIVATIVES MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010201010602",
              "display" : "POLYVINYLIDENE FLUORIDE AND DERIVATIVES MONOFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102010199",
            "display" : "NON-ABSORBABLE SYNTHETIC MONOFILAMENT SUTURES - OTHER"
          }]
        },
        {
          "code" : "H01020102",
          "display" : "SYNTHETIC NONABSORBABLE MULTIFILAMENT SUTURES",
          "concept" : [{
            "code" : "H0102010201",
            "display" : "POLYAMIDE MULTIFILAMENT",
            "concept" : [{
              "code" : "H010201020101",
              "display" : "POLYAMIDE MULTIFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010201020102",
              "display" : "POLYAMIDE MULTIFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102010202",
            "display" : "POLYESTER MULTIFILAMENT",
            "concept" : [{
              "code" : "H010201020201",
              "display" : "POLYSTER MULTIFILAMENT WITH NEEDLE FOR OPEN SURGERY"
            },
            {
              "code" : "H010201020202",
              "display" : "POLYSTER MULTIFILAMENT WITH NEEDLE FOR VIDEO SURGERY"
            },
            {
              "code" : "H010201020203",
              "display" : "POLYSTER MULTIFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102010299",
            "display" : "SYNTHETIC NONABSORBABLE MULTIFILAMENT SUTURES - OTHER"
          }]
        }]
      },
      {
        "code" : "H010202",
        "display" : "NON-ABSORBABLE NON-SYNTHETIC SUTURES",
        "concept" : [{
          "code" : "H01020201",
          "display" : "NON-ABSORBABLE NON-SYNTHETIC MONOFILAMENT SUTURES",
          "concept" : [{
            "code" : "H0102020101",
            "display" : "STAINLESS STEEL MONOFILAMENT",
            "concept" : [{
              "code" : "H010202010101",
              "display" : "STAINLESS STEEL MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010202010102",
              "display" : "STAINLESS STEEL MONOFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102020102",
            "display" : "SILVER MONOFILAMENT",
            "concept" : [{
              "code" : "H010202010201",
              "display" : "SILVER MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010202010202",
              "display" : "SILVER MONOFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102020103",
            "display" : "TITANIUM MONOFILAMENT",
            "concept" : [{
              "code" : "H010202010301",
              "display" : "TITANIUM MONOFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010202010302",
              "display" : "TITANIUM MONOFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102020199",
            "display" : "NON-ABSORBABLE NON-SYNTHETIC MONOFILAMENT SUTURES - OTHER"
          }]
        },
        {
          "code" : "H01020202",
          "display" : "NON-ABSORBABLE NON-SYNTHETIC MULTIFILAMENT SUTURES",
          "concept" : [{
            "code" : "H0102020201",
            "display" : "STAINLESS STEEL MULTIFILAMENT",
            "concept" : [{
              "code" : "H010202020101",
              "display" : "STAINLESS STEEL MULTIFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010202020102",
              "display" : "STAINLESS STEEL MULTIFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102020202",
            "display" : "LINEN",
            "concept" : [{
              "code" : "H010202020201",
              "display" : "LINEN WITH NEEDLE"
            },
            {
              "code" : "H010202020202",
              "display" : "LINEN WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102020203",
            "display" : "SILK",
            "concept" : [{
              "code" : "H010202020301",
              "display" : "SILK WITH NEEDLE"
            },
            {
              "code" : "H010202020302",
              "display" : "SILK WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102020204",
            "display" : "TITANIUM MULTIFILAMENT",
            "concept" : [{
              "code" : "H010202020401",
              "display" : "TITANIUM MULTIFILAMENT WITH NEEDLE"
            },
            {
              "code" : "H010202020402",
              "display" : "TITANIUM MULTIFILAMENT WITHOUT NEEDLE"
            }]
          },
          {
            "code" : "H0102020299",
            "display" : "NON-ABSORBABLE NON-SYNTHETIC MULTIFILAMENT SUTURES - OTHER"
          }]
        }]
      }]
    },
    {
      "code" : "H0199",
      "display" : "SURGICAL SUTURES - OTHER"
    }]
  },
  {
    "code" : "H02",
    "display" : "MECHANICAL SURGICAL STAPLERS",
    "concept" : [{
      "code" : "H0201",
      "display" : "SKIN STAPLERS",
      "concept" : [{
        "code" : "H020101",
        "display" : "MECHANICAL SKIN STAPLERS",
        "concept" : [{
          "code" : "H02010101",
          "display" : "SKIN STAPLERS, SINGLE-USE"
        },
        {
          "code" : "H02010102",
          "display" : "SKIN STAPLERS, SINGLE PATIENT"
        },
        {
          "code" : "H02010103",
          "display" : "SKIN STAPLERS, REUSABLE (STAINLESS STEEL)"
        },
        {
          "code" : "H02010104",
          "display" : "SINGLE-USE STAPLER CARTRIDGES FOR SINGLE PATIENT"
        },
        {
          "code" : "H02010105",
          "display" : "SINGLE-USE CARTRIDGES FOR REUSABLE STAPLERS"
        },
        {
          "code" : "H02010106",
          "display" : "METAL SURGICAL STAPLE REMOVERS, SINGLE-USE"
        },
        {
          "code" : "H02010199",
          "display" : "MECHANICAL SKIN STAPLERS - OTHER"
        }]
      },
      {
        "code" : "H020102",
        "display" : "CLIPS",
        "concept" : [{
          "code" : "H02010201",
          "display" : "SKIN CLIPS"
        },
        {
          "code" : "H02010202",
          "display" : "STERNAL CLIPS"
        },
        {
          "code" : "H02010299",
          "display" : "CLIPS - OTHER"
        }]
      },
      {
        "code" : "H020180",
        "display" : "SKIN STAPLERS - ACCESSORIES"
      },
      {
        "code" : "H020199",
        "display" : "SKIN STAPLERS - OTHER"
      }]
    },
    {
      "code" : "H0202",
      "display" : "STAPLERS, OPEN SURGERY",
      "concept" : [{
        "code" : "H020201",
        "display" : "LINEAR STAPLERS, OPEN SURGERY",
        "concept" : [{
          "code" : "H02020101",
          "display" : "STRAIGHT LINEAR STAPLERS FOR OPEN SURGERY",
          "concept" : [{
            "code" : "H0202010101",
            "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS FOR OPEN SURGERY",
            "concept" : [{
              "code" : "H020201010101",
              "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITH BLADE FOR OPEN SURGERY"
            },
            {
              "code" : "H020201010102",
              "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITHOUT BLADE FOR OPEN SURGERY"
            }]
          },
          {
            "code" : "H0202010102",
            "display" : "REUSABLE (STAINLESS STEEL) STRAIGHT LINEAR STAPLERS FOR OPEN SURGERY",
            "concept" : [{
              "code" : "H020201010201",
              "display" : "REUSABLE (STAINLESS STEEL) STRAIGHT LINEAR STAPLERS WITH BLADE FOR OPEN SURGERY"
            },
            {
              "code" : "H020201010202",
              "display" : "REUSABLE (STAINLESS STEEL) STRAIGHT LINEAR STAPLERS WITHOUT BLADE FOR OPEN SURGERY"
            }]
          },
          {
            "code" : "H0202010199",
            "display" : "STRAIGHT LINEAR STAPLERS FOR OPEN SURGERY - OTHER"
          }]
        },
        {
          "code" : "H02020102",
          "display" : "ARTICULATED LINEAR STAPLERS FOR OPEN SURGERY",
          "concept" : [{
            "code" : "H0202010201",
            "display" : "SINGLE-USE ARTICULATED LINEAR STAPLERS FOR OPEN SURGERY",
            "concept" : [{
              "code" : "H020201020101",
              "display" : "SINGLE-USE ARTICULATED LINEAR STAPLERS WITHOUT BLADE FOR OPEN SURGERY"
            },
            {
              "code" : "H020201020102",
              "display" : "SINGLE-USE ARTICULATED LINEAR STAPLERS WITH BLADE FOR OPEN SURGERY"
            }]
          },
          {
            "code" : "H0202010202",
            "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS FOR OPEN SURGERY",
            "concept" : [{
              "code" : "H020201020201",
              "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITH BLADE FOR OPEN SURGERY"
            },
            {
              "code" : "H020201020202",
              "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITHOUT BLADE FOR OPEN SURGERY"
            }]
          },
          {
            "code" : "H0202010299",
            "display" : "ARTICULATED LINEAR STAPLERS FOR OPEN SURGERY- OTHER"
          }]
        },
        {
          "code" : "H02020103",
          "display" : "SINGLE-PATIENT LINEAR SUTURE CARTDRIGES FOR OPEN SURGERY",
          "concept" : [{
            "code" : "H0202010301",
            "display" : "SINGLE-PATIENT LINEAR SUTURE CARTDRIGES WITH BLADE FOR OPEN SURGERY"
          },
          {
            "code" : "H0202010302",
            "display" : "SINGLE-PATIENT LINEAR SUTURE CARTDRIGES WITHOUT BLADE FOR OPEN SURGERY"
          },
          {
            "code" : "H0202010399",
            "display" : "SINGLE-PATIENT LINEAR SUTURE CARTDRIGES FOR OPEN SURGERY - OTHER"
          }]
        },
        {
          "code" : "H02020104",
          "display" : "REUSABLE LINEAR SUTURE CARTDRIGES FOR OPEN SURGERY",
          "concept" : [{
            "code" : "H0202010401",
            "display" : "REUSABLE LINEAR SUTURE CARTDRIGES WITH BLADE FOR OPEN SURGERY"
          },
          {
            "code" : "H0202010402",
            "display" : "REUSABLE LINEAR SUTURE CARTDRIGES WITHOUT BLADE FOR OPEN SURGERY"
          },
          {
            "code" : "H0202010499",
            "display" : "REUSABLE LINEAR SUTURE CARTDRIGES FOR OPEN SURGERY - OTHER"
          }]
        },
        {
          "code" : "H02020199",
          "display" : "LINEAR STAPLERS FOR OPEN SURGERY - OTHER"
        }]
      },
      {
        "code" : "H020202",
        "display" : "CIRCULAR STAPLERS FOR OPEN SURGERY",
        "concept" : [{
          "code" : "H02020201",
          "display" : "STRAIGHT CIRCULAR STAPLERS FOR OPEN SURGERY",
          "concept" : [{
            "code" : "H0202020101",
            "display" : "SINGLE-USE STRAIGHT CIRCULAR STAPLERS FOR OPEN SURGERY"
          },
          {
            "code" : "H0202020102",
            "display" : "REUSABLE STRAIGHT CIRCULAR STAPLERS FOR OPEN SURGERY"
          }]
        },
        {
          "code" : "H02020202",
          "display" : "CURVED CIRCULAR STAPLERS FOR OPEN SURGERY",
          "concept" : [{
            "code" : "H0202020201",
            "display" : "SINGLE-USE CURVED CIRCULAR STAPLERS FOR OPEN SURGERY"
          },
          {
            "code" : "H0202020202",
            "display" : "REUSABL CURVED CIRCULAR STAPLERS FOR OPEN SURGERY"
          }]
        },
        {
          "code" : "H02020203",
          "display" : "PURSE STRING STAPLERS"
        },
        {
          "code" : "H02020204",
          "display" : "REUSABLE CIRCULAR STAPLER CARTDRIGES FOR OPEN SURGERY"
        },
        {
          "code" : "H02020299",
          "display" : "CIRCULAR STAPLERS FOR OPEN SURGERY - OTHER"
        }]
      },
      {
        "code" : "H020203",
        "display" : "SEMICIRCULAR STAPLERS FOR OPEN SURGERY",
        "concept" : [{
          "code" : "H02020301",
          "display" : "SINGLE PATIENT STRAIGHT SEMICIRCULAR STAPLERS WITH BLADE FOR OPEN SURGERY"
        },
        {
          "code" : "H02020302",
          "display" : "SINGLE PATIENT STRAIGHT SEMICIRCULAR STAPLER CARTRIDGES WITH BLADE FOR OPEN SURGERY"
        },
        {
          "code" : "H02020399",
          "display" : "SEMICIRCULAR STAPLERS FOR OPEN SURGERY - OTHER"
        }]
      },
      {
        "code" : "H020280",
        "display" : "STAPLERS FOR OPEN SURGERY - ACCESSORIES"
      },
      {
        "code" : "H020299",
        "display" : "STAPLERS FOR OPEN SURGERY - OTHER"
      }]
    },
    {
      "code" : "H0203",
      "display" : "STAPLERS FOR VIDEOSURGERY",
      "concept" : [{
        "code" : "H020301",
        "display" : "LINEAR STAPLERS FOR VIDEOSURGERY",
        "concept" : [{
          "code" : "H02030104",
          "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS FOR VIDEOSURGERY",
          "concept" : [{
            "code" : "H0203010401",
            "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITH BLADE FOR VIDEOSURGERY",
            "concept" : [{
              "code" : "H020301040101",
              "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITH BLADE FOR THORACOSCOPY"
            },
            {
              "code" : "H020301040102",
              "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITH BLADE FOR LAPAROSCOPY"
            },
            {
              "code" : "H020301040199",
              "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITH BLADE FOR VIDEOSURGERY - OTHER"
            }]
          },
          {
            "code" : "H0203010402",
            "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITHOUT BLADE FOR VIDEOSURGERY",
            "concept" : [{
              "code" : "H020301040201",
              "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITHOUT BLADE FOR THORACOSCOPY"
            },
            {
              "code" : "H020301040202",
              "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITHOUT BLADE FOR LAPAROSCOPY"
            },
            {
              "code" : "H020301040299",
              "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS WITHOUT BLADE FOR VIDEOSURGERY – OTHER"
            }]
          },
          {
            "code" : "H0203010499",
            "display" : "SINGLE PATIENT STRAIGHT LINEAR STAPLERS FOR VIDEOSURGERY – OTHER"
          }]
        },
        {
          "code" : "H02030105",
          "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS FOR VIDEO SURGERY",
          "concept" : [{
            "code" : "H0203010501",
            "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITH BLADE FOR VIDEO SURGERY",
            "concept" : [{
              "code" : "H020301050101",
              "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITH BLADE FOR THORACOSCOPY"
            },
            {
              "code" : "H020301050102",
              "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITH BLADE FOR LAPAROSCOPY"
            },
            {
              "code" : "H020301050199",
              "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITH BLADE FOR VIDEOSURGERY – OTHER"
            }]
          },
          {
            "code" : "H0203010502",
            "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITHOUT BLADE FOR VIDEO SURGERY",
            "concept" : [{
              "code" : "H020301050201",
              "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITHOUT BLADE FOR THORACOSCOPY"
            },
            {
              "code" : "H020301050202",
              "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITHOUT BLADE FOR LAPAROSCOPY"
            },
            {
              "code" : "H020301050299",
              "display" : "SINGLE PATIENT ARTICULATED LINEAR STAPLERS WITHOUT BLADE FOR VIDEOSURGERY – OTHER"
            }]
          }]
        },
        {
          "code" : "H02030106",
          "display" : "LINEAR STAPLER CARTRIDGES FOR VIDEOSURGERY"
        },
        {
          "code" : "H02030199",
          "display" : "LINEAR STAPLERS FOR VIDEOSURGERY - OTHER"
        }]
      },
      {
        "code" : "H020302",
        "display" : "CIRCULAR STAPLERS FOR VIDEOSURGERY",
        "concept" : [{
          "code" : "H02030201",
          "display" : "CURVED CIRCULAR STAPLERS FOR VIDEOSURGERY",
          "concept" : [{
            "code" : "H0203020101",
            "display" : "SINGLE-USE CURVED CIRCULAR STAPLERS FOR VIDEOSURGERY"
          },
          {
            "code" : "H0203020199",
            "display" : "CIRCULAR STAPLERS FOR VIDEOSURGERY - OTHER"
          }]
        },
        {
          "code" : "H02030299",
          "display" : "CIRCULAR STAPLERS FOR VIDEOSURGERY – OTHER"
        }]
      },
      {
        "code" : "H020303",
        "display" : "CLIP APPLIERS"
      },
      {
        "code" : "H020380",
        "display" : "STAPLERS, VIDEOSURGERY - ACCESSORIES"
      },
      {
        "code" : "H020399",
        "display" : "STAPLERS, VIDEOSURGERY - OTHER"
      }]
    },
    {
      "code" : "H0204",
      "display" : "TRANSANAL RECTAL STAPLERS",
      "concept" : [{
        "code" : "H020401",
        "display" : "SINGLE PATIENT TRANSANAL RECTAL STAPLERS"
      },
      {
        "code" : "H020402",
        "display" : "MULTI-USE TRANSANAL RECTAL STAPLERS"
      },
      {
        "code" : "H020403",
        "display" : "TRANSANAL RECTAL STAPLER CARTRIDGES"
      }]
    },
    {
      "code" : "H0299",
      "display" : "MECHANICAL SURGICAL STAPLERS - OTHER"
    }]
  },
  {
    "code" : "H03",
    "display" : "HAEMOSTASIS CLIPS",
    "concept" : [{
      "code" : "H0301",
      "display" : "HAEMOSTASIS CLIPS FOR OPEN SURGERY",
      "concept" : [{
        "code" : "H030101",
        "display" : "MULTIPLE CLIP APPLIERS FOR OPEN SURGERY",
        "concept" : [{
          "code" : "H03010101",
          "display" : "SINGLE-USE MULTIPLE CLIP APPLIERS FOR OPEN SURGERY"
        },
        {
          "code" : "H03010102",
          "display" : "SINGLE-PATIENT MULTIPLE CLIP APPLIERS FOR OPEN SURGERY"
        },
        {
          "code" : "H03010104",
          "display" : "SINGLE-PATIENT MULTIPLE CLIP APPLIER CARTRIDGES FOR OPEN SURGERY"
        },
        {
          "code" : "H03010105",
          "display" : "REUSABLE MULTIPLE CLIP APPLIER CARTRIDGES FOR OPEN SURGERY"
        },
        {
          "code" : "H03010199",
          "display" : "MULTIPLE CLIP APPLIERS FOR OPEN SURGERY - OTHER"
        }]
      },
      {
        "code" : "H030102",
        "display" : "SINGULAR CLIPS FOR OPEN SURGERY",
        "concept" : [{
          "code" : "H03010201",
          "display" : "NON-ABSORBABLE SINGULAR CLIPS FOR OPEN SURGERY"
        },
        {
          "code" : "H03010202",
          "display" : "ABSORBABLE SINGULAR CLIPS FOR OPEN SURGERY"
        }]
      },
      {
        "code" : "H030199",
        "display" : "HAEMOSTASIS CLIPS FOR OPEN SURGERY - OTHER"
      }]
    },
    {
      "code" : "H0302",
      "display" : "HAEMOSTASIS CLIPS FOR VIDEOSURGERY",
      "concept" : [{
        "code" : "H030201",
        "display" : "MULTIPLE CLIP APPLIERS FOR VIDEOSURGERY",
        "concept" : [{
          "code" : "H03020101",
          "display" : "SINGLE-USE MULTIPLE CLIP APPLIERS FOR VIDEOSURGERY"
        },
        {
          "code" : "H03020103",
          "display" : "REUSABLE MULTIPLE CLIP APPLIERS FOR VIDEOSURGERY"
        },
        {
          "code" : "H03020199",
          "display" : "MULTIPLE CLIP APPLIERS FOR VIDEOSURGERY - OTHER"
        }]
      },
      {
        "code" : "H030299",
        "display" : "HAEMOSTASIS CLIPS FOR VIDEOSURGERY - OTHER"
      }]
    },
    {
      "code" : "H0303",
      "display" : "HAEMOSTASIS CLIPS FOR OPEN SURGERY AND VIDEOSURGERY",
      "concept" : [{
        "code" : "H030301",
        "display" : "SINGULAR HAEMOSTASIS CLIPS FOR OPEN SURGERY AND VIDEOSURGERY",
        "concept" : [{
          "code" : "H03030101",
          "display" : "SINGULAR NON-ABSORBABLE HAEMOSTASIS CLIPS FOR OPEN SURGERY AND VIDEOSURGERY"
        },
        {
          "code" : "H03030102",
          "display" : "SINGLE ABSORBABLE CLIPS FOR HEMOSTASIS IN OPEN AND VIDEO SURGERY"
        }]
      }]
    },
    {
      "code" : "H0380",
      "display" : "HEMOSTASIS CLIPS - ACCESSORIES",
      "concept" : [{
        "code" : "H038001",
        "display" : "SINGLE-USE DEVICES FOR REMOVAL OF CLIPS FOR HEMOSTASIS",
        "concept" : [{
          "code" : "H03800101",
          "display" : "SINGLE-USE DEVICES FOR CLIP REMOVAL IN OPEN SURGERY"
        },
        {
          "code" : "H03800102",
          "display" : "SINGLE-USE DEVICES FOR CLIP REMOVAL IN VIDEO SURGERY"
        }]
      },
      {
        "code" : "H038099",
        "display" : "CLIPS FOR HEMOSTASIS - ACCESSORIES OTHER"
      }]
    },
    {
      "code" : "H0399",
      "display" : "HAEMOSTASIS CLIPS - OTHER"
    }]
  },
  {
    "code" : "H90",
    "display" : "SUTURE DEVICES - VARIOUS",
    "concept" : [{
      "code" : "H9001",
      "display" : "TISSUE ADHESIVES",
      "concept" : [{
        "code" : "H900101",
        "display" : "GLUES",
        "concept" : [{
          "code" : "H90010101",
          "display" : "BIOLOGICAL GLUES"
        },
        {
          "code" : "H90010102",
          "display" : "SYNTHETIC GLUES"
        }]
      },
      {
        "code" : "H900102",
        "display" : "BANDAGES FOR SUTURES"
      },
      {
        "code" : "H900199",
        "display" : "TISSUE ADHESIVES - OTHER"
      }]
    },
    {
      "code" : "H9002",
      "display" : "TAPES, MEDICAL/SURGICAL",
      "concept" : [{
        "code" : "H900201",
        "display" : "SUTURE TAPES",
        "concept" : [{
          "code" : "H90020101",
          "display" : "UMBILICAL CORD TAPES"
        },
        {
          "code" : "H90020102",
          "display" : "CERCLAGE TAPES"
        },
        {
          "code" : "H90020103",
          "display" : "PARENCHYMATOUS TISSUE TAPES"
        },
        {
          "code" : "H90020199",
          "display" : "SUTURE TAPES - OTHER"
        }]
      },
      {
        "code" : "H900202",
        "display" : "MARKING TAPES, VASCULAR STRUCTURES"
      },
      {
        "code" : "H900203",
        "display" : "OCCLUSION TAPES, VASCULAR STRUCTURES"
      },
      {
        "code" : "H900299",
        "display" : "TAPES, MEDICAL/SURGICAL - OTHER"
      }]
    },
    {
      "code" : "H9003",
      "display" : "SUTURE REINFORCEMENT OR SUPPORT DEVICES",
      "concept" : [{
        "code" : "H900301",
        "display" : "SUTURE BUTTONS"
      },
      {
        "code" : "H900302",
        "display" : "SUTURE FELTS"
      },
      {
        "code" : "H900303",
        "display" : "PLEDGETS"
      },
      {
        "code" : "H900304",
        "display" : "PLUGS"
      },
      {
        "code" : "H900305",
        "display" : "STAPLER REINFORCEMENTS"
      },
      {
        "code" : "H900399",
        "display" : "SUTURE SUPPORT OR REINFORCEMENT SUPPORT DEVICES - OTHER"
      }]
    },
    {
      "code" : "H9005",
      "display" : "SUTURE ZIPPERS"
    },
    {
      "code" : "H9006",
      "display" : "CRANIAL HOLE COVERS"
    },
    {
      "code" : "H9007",
      "display" : "ANCHORS FOR SOFT TISSUE SUTURE (excluding P09120102 ANCHORS FOR TENDON-LIGAMENT SYNTHESIS)"
    },
    {
      "code" : "H9008",
      "display" : "SINGLE-USE SUTURE INSTRUMENTS",
      "concept" : [{
        "code" : "H900801",
        "display" : "SINGLE-USE NODE PUSHER"
      },
      {
        "code" : "H900802",
        "display" : "SINGLE-USE NEEDLE HOLDERS"
      },
      {
        "code" : "H900899",
        "display" : "SINGLE-USE INSTRUMENTS FOR SUTURES - OTHER"
      }]
    },
    {
      "code" : "H9080",
      "display" : "SUTURE ACCESSORIES"
    },
    {
      "code" : "H9099",
      "display" : "SUTURE DEVICES - OTHER"
    }]
  },
  {
    "code" : "J",
    "display" : "ACTIVE-IMPLANTABLE DEVICES"
  },
  {
    "code" : "J01",
    "display" : "CARDIAC FUNCTIONALITY IMPLANTABLE DEVICES",
    "concept" : [{
      "code" : "J0101",
      "display" : "IMPLANTABLE PACEMAKERS",
      "concept" : [{
        "code" : "J010101",
        "display" : "IMPLANTABLE SINGLE CHAMBER PACEMAKERS",
        "concept" : [{
          "code" : "J01010101",
          "display" : "IMPLANTABLE SINGLE CHAMBER PACEMAKERS (SC)"
        },
        {
          "code" : "J01010102",
          "display" : "IMPLANTABLE SINGLE CHAMBER PACEMAKERS WITH SENSOR (SR)"
        }]
      },
      {
        "code" : "J010102",
        "display" : "IMPLANTABLE SINGLE LEAD PACEMAKERS",
        "concept" : [{
          "code" : "J01010201",
          "display" : "IMPLANTABLE SINGLE LEAD VDD PACEMAKERS"
        },
        {
          "code" : "J01010202",
          "display" : "IMPLANTABLE SINGLE LEAD VDDR PACEMAKERS WITH SENSOR"
        }]
      },
      {
        "code" : "J010103",
        "display" : "IMPLANTABLE DUAL CHAMBER PACEMAKERS",
        "concept" : [{
          "code" : "J01010301",
          "display" : "IMPLANTABLE DUAL CHAMBER PACEMAKERS (DC)"
        },
        {
          "code" : "J01010302",
          "display" : "IMPLANTABLE DUAL CHAMBER PACEMAKERS WITH SENSOR (DR)"
        }]
      },
      {
        "code" : "J010104",
        "display" : "IMPLANTABLE TRIPLE CHAMBER PACEMAKERS",
        "concept" : [{
          "code" : "J01010401",
          "display" : "IMPLANTABLE TRIPLE CHAMBER PACEMAKERS FOR CARDIAC RESYNCHRONIZATION (TR)"
        }]
      },
      {
        "code" : "J010105",
        "display" : "IMPLANTABLE PACEMAKERS WITH INCORPORATED ELECTRODES (LEADLESS)"
      },
      {
        "code" : "J010180",
        "display" : "IMPLANTABLE PACEMAKERS - ACCESSORIES"
      },
      {
        "code" : "J010199",
        "display" : "IMPLANTABLE PACEMAKERS - OTHER"
      }]
    },
    {
      "code" : "J0102",
      "display" : "IMPLANTABLE CARDIAC DIAGNOSTIC DEVICES",
      "concept" : [{
        "code" : "J010201",
        "display" : "IMPLANTABLE DIAGNOSTIC ARRHYTHMIAS RECORDING CARDIAC DEVICES"
      },
      {
        "code" : "J010280",
        "display" : "CARDIAC DIAGNOSTIC DEVICES - ACCESSORIES"
      },
      {
        "code" : "J010299",
        "display" : "CARDIAC DIAGNOSTIC DEVICES - OTHER"
      }]
    },
    {
      "code" : "J0103",
      "display" : "IMPLANTABLE VENTRICULAR ASSISTANCE SYSTEMS",
      "concept" : [{
        "code" : "J010301",
        "display" : "IMPLANTABLE MONOVENTRICULAR AND BIVENTRICULAR ASSISTANCE SYSTEMS",
        "concept" : [{
          "code" : "J01030101",
          "display" : "IMPLANTABLE RIGHT MONOVENTRICULAR ASSISTANCE SYSTEMS (RVAD)"
        },
        {
          "code" : "J01030102",
          "display" : "IMPLANTABLE LEFT MONOVENTRICULAR ASSISTANCE SYSTEMS (LVAD)"
        },
        {
          "code" : "J01030103",
          "display" : "IMPLANTABLE BIVENTRICULAR ASSISTANCE SYSTEMS (BIVAD)"
        }]
      },
      {
        "code" : "J010380",
        "display" : "IMPLANTABLE VENTRICULAR ASSISTANCE SYSTEMS - ACCESSORIES"
      },
      {
        "code" : "J010399",
        "display" : "IMPLANTABLE VENTRICULAR ASSISTANCE SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "J0104",
      "display" : "IMPLANTABLE ARTIFICIAL HEART AND IMPLANT KITS",
      "concept" : [{
        "code" : "J010401",
        "display" : "IMPLANTABLE ARTIFICIAL HEART AND IMPLANT KITS"
      },
      {
        "code" : "J010480",
        "display" : "IMPLANTABLE ARTIFICIAL HEART AND IMPLANT KITS - ACCESSORIES"
      },
      {
        "code" : "J010499",
        "display" : "IMPLANTABLE ARTIFICIAL HEART AND IMPLANT KITS - OTHER"
      }]
    },
    {
      "code" : "J0105",
      "display" : "IMPLANTABLE DEFIBRILLATORS",
      "concept" : [{
        "code" : "J010501",
        "display" : "IMPLANTABLE SINGLE CHAMBER DEFIBRILLATORS",
        "concept" : [{
          "code" : "J01050101",
          "display" : "IMPLANTABLE SINGLE CHAMBER DEFIBRILLATORS, WITH SENSORS"
        }]
      },
      {
        "code" : "J010502",
        "display" : "IMPLANTABLE DUAL CHAMBER DEFIBRILLATORS",
        "concept" : [{
          "code" : "J01050201",
          "display" : "IMPLANTABLE DUAL CHAMBER DEFIBRILLATORS, WITH SENSORS"
        }]
      },
      {
        "code" : "J010503",
        "display" : "IMPLANTABLE TRIPLE CHAMBER DEFIBRILLATORS",
        "concept" : [{
          "code" : "J01050301",
          "display" : "IMPLANTABLE TRIPLE CHAMBER DEFIBRILLATORS, WITH SENSORS"
        }]
      },
      {
        "code" : "J010504",
        "display" : "SUBCUTANEOUS IMPLANTABLE DEFIBRILLATORS"
      },
      {
        "code" : "J010580",
        "display" : "IMPLANTABLE DEFIBRILLATORS - ACCESSORIES"
      },
      {
        "code" : "J010599",
        "display" : "IMPLANTABLE DEFIBRILLATORS - OTHER"
      }]
    },
    {
      "code" : "J0106",
      "display" : "CARDIAC CONTRACTILITY MODULATION IMPLANTABLE DEVICES"
    },
    {
      "code" : "J0107",
      "display" : "ACTIVE IMPLANTABLE CARDIAC DEVICES REMOTE MONITORING SYSTEMS",
      "concept" : [{
        "code" : "J010701",
        "display" : "PULMONARY BLOOD PRESSURE REMOTE MONITORING SYSTEMS (INCLUDING SENSORS)"
      },
      {
        "code" : "J010702",
        "display" : "PACEMAKER AND IMPLANTABLE DEFIBRILLATOR REMOTE MONITORING SYSTEMS"
      },
      {
        "code" : "J010780",
        "display" : "ACTIVE IMPLANTABLE CARDIAC DEVICES REMOTE MONITORING SYSTEMS - HARDWARE ACCESSORIES"
      },
      {
        "code" : "J010782",
        "display" : "ACTIVE IMPLANTABLE CARDIAC DEVICES REMOTE MONITORING SYSTEMS - SOFTWARE ACCESSORIES"
      },
      {
        "code" : "J010792",
        "display" : "ACTIVE IMPLANTABLE CARDIAC DEVICES REMOTE MONITORING SYSTEMS - MEDICAL DEVICE SOFTWARE"
      },
      {
        "code" : "J010799",
        "display" : "ACTIVE IMPLANTABLE CARDIAC DEVICES REMOTE MONITORING SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "J0190",
      "display" : "IMPLANTABLE CARDIAC DEVICES - VARIOUS",
      "concept" : [{
        "code" : "J019001",
        "display" : "PERMANENT CARDIAC LEADS",
        "concept" : [{
          "code" : "J01900101",
          "display" : "PERMANENT PACEMAKER LEADS (WITH OR W/O STEROID-ELUTION)",
          "concept" : [{
            "code" : "J0190010101",
            "display" : "ENDOCARDIAL ATRIAL AND VENTRICULAR LEADS, UNIPOLAR",
            "concept" : [{
              "code" : "J019001010101",
              "display" : "ATRIAL LEADS, PASSIVE FIXATION"
            },
            {
              "code" : "J019001010102",
              "display" : "VENTRICULAR LEADS, PASSIVE FIXATION"
            }]
          },
          {
            "code" : "J0190010102",
            "display" : "ENDOCARDIAL ATRIAL AND VENTRICULAR LEADS, BIPOLAR (WITH ACTIVE OR PASSIVE FIXATION)"
          },
          {
            "code" : "J0190010103",
            "display" : "LEFT VENTRICULAR LEADS WITH CORONARY SINUS CANNULATION SYSTEM (TRIPLE CHAMBER P.M.)"
          },
          {
            "code" : "J0190010104",
            "display" : "ENDOCARDIAL PACEMAKER LEADS, SINGLE-LEAD"
          },
          {
            "code" : "J0190010105",
            "display" : "EPICARDIAL PERMANENT CARDIAC LEADS"
          }]
        },
        {
          "code" : "J01900102",
          "display" : "PERMANENT DEFIBRILLATOR LEADS (STEROID RELEASE INCLUDED)",
          "concept" : [{
            "code" : "J0190010201",
            "display" : "PERMANENT PACING AND DEFIBRILLATION RIGHT VENTRICULAR LEADS (WITH ACTIVE AND PASSIVE FIXATION)",
            "concept" : [{
              "code" : "J019001020101",
              "display" : "PERMANENT CARDIAC DEFIBRILLATOR LEADS, SINGLE COIL"
            },
            {
              "code" : "J019001020102",
              "display" : "PERMANENT CARDIAC DEFIBRILLATOR LEADS, DOUBLE COIL"
            },
            {
              "code" : "J019001020199",
              "display" : "PERMANENT PACING AND DEFIBRILLATION RIGHT VENTRICULAR LEADS - OTHER"
            }]
          },
          {
            "code" : "J0190010202",
            "display" : "PERMANENT SUBCUTANEOUS DEFIBRILLATOR LEADS"
          }]
        },
        {
          "code" : "J01900180",
          "display" : "PERMANENT CARDIAC LEADS - ACCESSORIES"
        },
        {
          "code" : "J01900199",
          "display" : "PERMANENT CARDIAC LEADS - OTHER"
        }]
      },
      {
        "code" : "J019002",
        "display" : "IMPLANTABLE CARDIAC DEVICES PROGRAMMERS AND ACCESSORIES",
        "concept" : [{
          "code" : "J01900203",
          "display" : "IMPLANTABLE CARDIAC DEVICES PROGRAMMERS"
        },
        {
          "code" : "J01900280",
          "display" : "IMPLANTABLE CARDIAC DEVICES PROGRAMMERS - HARDWARE ACCESSORY"
        },
        {
          "code" : "J01900282",
          "display" : "IMPLANTABLE CARDIAC DEVICES PROGRAMMERS - SOFTWARE ACCESSORY"
        },
        {
          "code" : "J01900285",
          "display" : "IMPLANTABLE CARDIAC DEVICES PROGRAMMERS - CONSUMABLES"
        },
        {
          "code" : "J01900292",
          "display" : "IMPLANTABLE CARDIAC DEVICES PROGRAMMERS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "J019003",
        "display" : "ACTIVE-IMPLANTABLE CARDIAC SYSTEMS MAGNETISED DEVICES"
      },
      {
        "code" : "J019004",
        "display" : "ACTIVE-IMPLANTABLE CARDIAC SYSTEMS ADAPTORS"
      },
      {
        "code" : "J019005",
        "display" : "CARDIAC LEADS EXTRACTION SYSTEMS"
      },
      {
        "code" : "J019099",
        "display" : "IMPLANTABLE CARDIAC DEVICES - OTHER"
      }]
    }]
  },
  {
    "code" : "J02",
    "display" : "IMPLANTABLE NEUROSTIMULATORS",
    "concept" : [{
      "code" : "J0201",
      "display" : "CEREBRAL IMPLANTABLE NEUROSTIMULATORS",
      "concept" : [{
        "code" : "J020101",
        "display" : "DEEP BRAIN STIMULATION (DBS) IMPLANTABLE NEUROSTIMULATORS",
        "concept" : [{
          "code" : "J02010101",
          "display" : "DEEP BRAIN STIMULATION (DBS) IMPLANTABLE NEUROSTIMULATORS, RECHARGEABLE"
        },
        {
          "code" : "J02010102",
          "display" : "DEEP BRAIN STIMULATION (DBS) IMPLANTABLE NEUROSTIMULATORS, NOT RECHARGEABLE"
        }]
      },
      {
        "code" : "J020102",
        "display" : "DEEP BRAIN STIMULATION (DBS) LEADS"
      },
      {
        "code" : "J020180",
        "display" : "CEREBRAL IMPLANTABLE NEUROSTIMULATORS - ACCESSORIES"
      },
      {
        "code" : "J020199",
        "display" : "CEREBRAL IMPLANTABLE NEUROSTIMULATORS - OTHER"
      }]
    },
    {
      "code" : "J0202",
      "display" : "SPINAL IMPLANTABLE NEUROSTIMULATORS",
      "concept" : [{
        "code" : "J020201",
        "display" : "RADIOFREQUENCY IMPLANTABLE SPINAL NEUROSTIMULATORS"
      },
      {
        "code" : "J020202",
        "display" : "FULLY IMPLANTABLE SPINAL NEUROSTIMULATORS",
        "concept" : [{
          "code" : "J02020201",
          "display" : "FULLY IMPLANTABLE SPINAL NEUROSTIMULATORS, RECHARGEABLE"
        },
        {
          "code" : "J02020202",
          "display" : "FULLY IMPLANTABLE SPINAL NEUROSTIMULATORSS, NOT RECHARGEABLE"
        }]
      },
      {
        "code" : "J020203",
        "display" : "SPINAL NEUROSTIMULATION LEADS"
      },
      {
        "code" : "J020280",
        "display" : "SPINAL IMPLANTABLE NEUROSTIMULATORS - ACCESSORIES"
      },
      {
        "code" : "J020299",
        "display" : "SPINAL IMPLANTABLE NEUROSTIMULATORS - OTHER"
      }]
    },
    {
      "code" : "J0203",
      "display" : "VAGAL IMPLANTABLE NEUROSTIMULATORS",
      "concept" : [{
        "code" : "J020301",
        "display" : "DRUG-RESISTANT EPILEPSY NON-SURGICAL THERAPY IMPLANTABLE NEUROSTIMULATORS"
      },
      {
        "code" : "J020302",
        "display" : "VAGAL NEUROSTIMULATION LEADS"
      },
      {
        "code" : "J020380",
        "display" : "VAGAL IMPLANTABLE NEUROSTIMULATORS - ACCESSORIES"
      },
      {
        "code" : "J020399",
        "display" : "VAGAL IMPLANTABLE NEUROSTIMULATORS - OTHER"
      }]
    },
    {
      "code" : "J0204",
      "display" : "SACRAL SPINE IMPLANTABLE NEUROSTIMULATORS",
      "concept" : [{
        "code" : "J020401",
        "display" : "BLADDER INCONTINENCE NEUROSTIMULATORS"
      },
      {
        "code" : "J020402",
        "display" : "INTESTINAL INCONTINENCE NEUROSTIMULATORS"
      },
      {
        "code" : "J020403",
        "display" : "SACRAL SPINE NEUROSTIMULATION LEADS"
      },
      {
        "code" : "J020480",
        "display" : "SACRAL SPINE IMPLANTABLE NEUROSTIMULATORS - ACCESSORIES"
      },
      {
        "code" : "J020499",
        "display" : "SACRAL SPINE IMPLANTABLE NEUROSTIMULATORS - OTHER"
      }]
    },
    {
      "code" : "J0206",
      "display" : "FRENIC NERVE IMPLANTABLE NEUROSTIMULATORS"
    },
    {
      "code" : "J0207",
      "display" : "NEUROSTIMULATORS PROGRAMMERS AND ACCESSORIES",
      "concept" : [{
        "code" : "J020701",
        "display" : "NEUROSTIMULATORS PROGRAMMERS"
      },
      {
        "code" : "J020780",
        "display" : "NEUROSTIMULATORS PROGRAMMERS - HARDWARE ACCESSORIES"
      },
      {
        "code" : "J020782",
        "display" : "NEUROSTIMULATORS PROGRAMMERS - SOFTWARE ACCESSORIES"
      },
      {
        "code" : "J020785",
        "display" : "NEUROSTIMULATORS PROGRAMMERS - CONSUMABLES"
      },
      {
        "code" : "J020792",
        "display" : "NEUROSTIMULATORS PROGRAMMERS - MEDICAL DEVICE SOFTWARE"
      }]
    },
    {
      "code" : "J0208",
      "display" : "GASTRIC IMPLANTABLE NEUROSTIMULATORS",
      "concept" : [{
        "code" : "J020801",
        "display" : "INFERIOR ESOPHAGEAL SPHINCTER IMPLANTABLE NEUROSTIMULATORS"
      },
      {
        "code" : "J020802",
        "display" : "GASTRIC IMPLANTABLE OBESITY TREATMENT NEUROSTIMULATORS"
      },
      {
        "code" : "J020803",
        "display" : "GASTRIC IMPLANTABLE NAUSEA THERAPY NEUROSTIMULATORS"
      },
      {
        "code" : "J020804",
        "display" : "GASTRIC NEUROSTIMULATION LEADS"
      }]
    },
    {
      "code" : "J0209",
      "display" : "CAROTID SINUS IMPLANTABLE NEUROSTIMULATORS AND LEADS"
    },
    {
      "code" : "J0210",
      "display" : "PERIPHERAL NERVE IMPLANTABLE NEUROSTIMULATORS AND PAIN THERAPY LEADS"
    },
    {
      "code" : "J0211",
      "display" : "SLEEP APNEA TREATMENT IMPLANTABLE NEUROSTIMULATORS AND LEADS"
    },
    {
      "code" : "J0280",
      "display" : "IMPLANTABLE NEUROSTIMULATORS - ACCESSORIES"
    },
    {
      "code" : "J0299",
      "display" : "IMPLANTABLE NEUROSTIMULATORS - OTHER"
    }]
  },
  {
    "code" : "J03",
    "display" : "AUDITORY ACTIVE-IMPLANTABLE DEVICES",
    "concept" : [{
      "code" : "J0301",
      "display" : "COCHLEAR IMPLANTABLE DEVICES"
    },
    {
      "code" : "J0302",
      "display" : "MIDDLE EAR ACTIVE-IMPLANTABLE DEVICES"
    },
    {
      "code" : "J0303",
      "display" : "PROFOUND DEAFNESS BRAINSTEM ACTIVE-IMPLANTABLE DEVICES"
    },
    {
      "code" : "J0380",
      "display" : "AUDITORY ACTIVE-IMPLANTABLE DEVICES - ACCESSORIES"
    },
    {
      "code" : "J0399",
      "display" : "AUDITORY ACTIVE-IMPLANTABLE DEVICES - OTHER"
    }]
  },
  {
    "code" : "J04",
    "display" : "IMPLANTABLE PUMPS",
    "concept" : [{
      "code" : "J0401",
      "display" : "IMPLANTABLE PUMPS, ELECTRONIC"
    },
    {
      "code" : "J0402",
      "display" : "IMPLANTABLE PUMPS, MECHANICAL"
    },
    {
      "code" : "J0403",
      "display" : "IMPLANTABLE PUMPS PROGRAMMERS AND ACCESSORIES",
      "concept" : [{
        "code" : "J040301",
        "display" : "IMPLANTABLE PUMPS PROGRAMMERS"
      },
      {
        "code" : "J040380",
        "display" : "IMPLANTABLE PUMPS PROGRAMMERS - HARDWARE ACCESSORIES"
      },
      {
        "code" : "J040382",
        "display" : "IMPLANTABLE PUMPS PROGRAMMERS - SOFTWARE ACCESSORIES"
      },
      {
        "code" : "J040385",
        "display" : "IMPLANTABLE PUMPS PROGRAMMERS - CONSUMABLES"
      },
      {
        "code" : "J040392",
        "display" : "IMPLANTABLE PUMPS PROGRAMMERS - MEDICAL DEVICE SOFTWARE"
      }]
    },
    {
      "code" : "J0480",
      "display" : "IMPLANTABLE PUMPS - ACCESSORIES"
    },
    {
      "code" : "J0499",
      "display" : "IMPLANTABLE PUMPS - OTHER"
    }]
  },
  {
    "code" : "J05",
    "display" : "BRACHYTHERAPY IMPLANTABLE DEVICES",
    "concept" : [{
      "code" : "J0501",
      "display" : "BRACHYTHERAPY SOURCES"
    },
    {
      "code" : "J0502",
      "display" : "BRACHYTHERAPY ADMINISTRATION KITS"
    },
    {
      "code" : "J0580",
      "display" : "IMPLANTABLE BRACHYTHERAPY DEVICES - ACCESSORIES"
    }]
  },
  {
    "code" : "J06",
    "display" : "ACTIVE IMPLANTABLE GLUCOSE MONITORING SYSTEMS",
    "concept" : [{
      "code" : "J0601",
      "display" : "IMPLANTABLE GLUCOSE MONITORING SENSORS"
    },
    {
      "code" : "J0602",
      "display" : "ACTIVE IMPLANTABLE GLUCOSE MONITORING SYSTEM TRANSMITTERS"
    },
    {
      "code" : "J0680",
      "display" : "ACTIVE IMPLANTABLE GLUCOSE MONITORING SYSTEMS - ACCESSORIES"
    }]
  },
  {
    "code" : "J07",
    "display" : "OPHTHALMOLOGICAL USE ACTIVE IMPLANTABLE DEVICES",
    "concept" : [{
      "code" : "J0701",
      "display" : "ACTIVE RETINAL IMPLANTABLE DEVICES"
    },
    {
      "code" : "J0702",
      "display" : "INTRAOCULAR PRESSURE MONITORING IMPLANTABLE DEVICES"
    },
    {
      "code" : "J0780",
      "display" : "OPHTHALMOLOGICAL USE ACTIVE IMPLANTABLE DEVICES - ACCESSORIES"
    },
    {
      "code" : "J0799",
      "display" : "OPHTHALMOLOGICAL USE ACTIVE IMPLANTABLE DEVICES - OTHER"
    }]
  },
  {
    "code" : "J99",
    "display" : "ACTIVE-IMPLANTABLE DEVICES - OTHER"
  },
  {
    "code" : "K",
    "display" : "ENDOTHERAPY AND ELECTROSURGICAL DEVICES"
  },
  {
    "code" : "K01",
    "display" : "ENDOTHERAPY DEVICES",
    "concept" : [{
      "code" : "K0101",
      "display" : "TROCAR AND KITS, SINGLE-USE",
      "concept" : [{
        "code" : "K010101",
        "display" : "TROCAR, SINGLE-USE",
        "concept" : [{
          "code" : "K01010101",
          "display" : "TROCAR STANDARD, SINGLE-USE"
        },
        {
          "code" : "K01010102",
          "display" : "HASSON TROCAR, SINGLE-USE"
        },
        {
          "code" : "K01010103",
          "display" : "OPTICAL TROCAR, SINGLE-USE"
        },
        {
          "code" : "K01010104",
          "display" : "THORACIC TROCAR, SINGLE-USE"
        },
        {
          "code" : "K01010105",
          "display" : "SPECIAL TROCAR, SINGLE-USE"
        },
        {
          "code" : "K01010180",
          "display" : "TROCAR, SINGLE-USE - ACCESSORIES"
        },
        {
          "code" : "K01010199",
          "display" : "TROCAR, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "K010102",
        "display" : "MINIMALLY INVASIVE SURGERY KITS, SINGLE-USE"
      }]
    },
    {
      "code" : "K0102",
      "display" : "IMINIMALLY INVASIVE AND ROBOTIC SURGERY INSTRUMENTS, SINGLE-USE",
      "concept" : [{
        "code" : "K010201",
        "display" : "MINIMALLY INVASIVE SURGERY SURGICAL INSTRUMENTS, SINGLE-USE",
        "concept" : [{
          "code" : "K01020101",
          "display" : "MINIMALLY INVASIVE SURGERY DISSECTORS, SINGLE-USE"
        },
        {
          "code" : "K01020102",
          "display" : "MINIMALLY INVASIVE SURGERY SCISSORS, SINGLE-USE"
        },
        {
          "code" : "K01020103",
          "display" : "MINIMALLY INVASIVE SURGERY MANIPULATORS, SINGLE-USE"
        },
        {
          "code" : "K01020104",
          "display" : "MINIMALLY INVASIVE SURGERY FORCEPS, SINGLE-USE"
        },
        {
          "code" : "K01020105",
          "display" : "MINIMALLY INVASIVE SURGERY NEEDLE HOLDERS, SINGLE-USE"
        },
        {
          "code" : "K01020106",
          "display" : "MINIMALLY INVASIVE SURGERY SPREADERS AND RETRACTORS, SINGLE-USE"
        },
        {
          "code" : "K01020107",
          "display" : "MINIMALLY INVASIVE SURGERY RECOVERY BAGS"
        },
        {
          "code" : "K01020109",
          "display" : "MINIMALLY INVASIVE SURGERY SWABS"
        },
        {
          "code" : "K01020110",
          "display" : "MINIMALLY INVASIVE SURGERY CANNULAS, SINGLE-USE"
        },
        {
          "code" : "K01020111",
          "display" : "MINIMALLY INVASIVE SURGERY BLADES, SINGLE-USE"
        },
        {
          "code" : "K01020112",
          "display" : "MINIMALLY INVASIVE SURGERY HOOKS, SINGLE-USE"
        },
        {
          "code" : "K01020113",
          "display" : "MINIMALLY INVASIVE SURGERY SPATULAS, SINGLE-USE"
        },
        {
          "code" : "K01020114",
          "display" : "MINIMALLY INVASIVE SURGERY GUIDES, SINGLE-USE"
        },
        {
          "code" : "K01020115",
          "display" : "MINIMALLY INVASIVE SURGERY HANDPIECES, SINGLE-USE"
        },
        {
          "code" : "K01020116",
          "display" : "ENDOSCOPIC TISSUE SUTURE APPROXIMATORS, SINGLE - USE"
        },
        {
          "code" : "K01020117",
          "display" : "MINIMALLY INVASIVE SURGERY DILATORS, SINGLE-USE"
        },
        {
          "code" : "K01020118",
          "display" : "MINIMALLY INVASIVE SURGERY NEEDLES, SINGLE-USE"
        },
        {
          "code" : "K01020119",
          "display" : "MINIMALLY INVASIVE SURGERY PALPATORS, SINGLE USE"
        },
        {
          "code" : "K01020120",
          "display" : "MINIMALLY INVASIVE SURGERY SURGICAL INSTRUMENT KITS, SINGLE-USE"
        },
        {
          "code" : "K01020199",
          "display" : "MINIMALLY INVASIVE SURGERY SURGICAL INSTRUMENT KITS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "K010202",
        "display" : "ROBOTIC SURGERY INSTRUMENTS, SINGLE-USE",
        "concept" : [{
          "code" : "K01020201",
          "display" : "ROBOTIC SURGERY SCALPELS AND BLADES, SINGLE-USE"
        },
        {
          "code" : "K01020202",
          "display" : "ROBOTIC SURGERY CLIPS, SINGLE-USE"
        },
        {
          "code" : "K01020203",
          "display" : "ROBOTIC SURGERY SCISSORS, SINGLE-USE"
        },
        {
          "code" : "K01020204",
          "display" : "ROBOTIC SURGERY FORCEPS, SINGLE-USE"
        },
        {
          "code" : "K01020205",
          "display" : "ROBOTIC SURGERY INSTRUMENT KITS, SINGLE-USE"
        },
        {
          "code" : "K01020299",
          "display" : "ROBOTIC SURGERY INSTRUMENT, SINGLE-USE - OTHER"
        }]
      }]
    },
    {
      "code" : "K0103",
      "display" : "SPINAL ENDOTHERAPY DEVICES",
      "concept" : [{
        "code" : "K010301",
        "display" : "SPINAL PERCUTANEOUS PLASTIC DEVICES WITH BALLOON"
      },
      {
        "code" : "K010302",
        "display" : "MINIMALLY INVASIVE SPINAL SURGERY INSTRUMENTS, SINGLE-USE"
      },
      {
        "code" : "K010399",
        "display" : "SPINAL ENDOTHERAPY DEVICES - OTHER"
      }]
    },
    {
      "code" : "K0104",
      "display" : "VERESS NEEDLES"
    },
    {
      "code" : "K0105",
      "display" : "MINIMALLY INVASIVE SURGERY STABILITY SCREW THREADS"
    },
    {
      "code" : "K0106",
      "display" : "MINIMALLY INVASIVE SURGERY REDUCERS"
    },
    {
      "code" : "K0107",
      "display" : "CHOLANGIOGRAPHY PROBES"
    },
    {
      "code" : "K0108",
      "display" : "HAND-ASSISTED SURGERY DEVICES"
    },
    {
      "code" : "K0180",
      "display" : "ENDOTHERAPY DEVICES - OTHER ACCESSORIES"
    },
    {
      "code" : "K0199",
      "display" : "ENDOTHERAPY DEVICES - OTHER"
    }]
  },
  {
    "code" : "K02",
    "display" : "ELECTROSURGERY DEVICES, SINGLE-USE",
    "concept" : [{
      "code" : "K0201",
      "display" : "MONO- AND BIPOLAR DEVICES, SINGLE-USE",
      "concept" : [{
        "code" : "K020101",
        "display" : "MONO- AND BIPOLAR SURGICAL INSTRUMENTS, SINGLE-USE",
        "concept" : [{
          "code" : "K02010101",
          "display" : "ELECTROSURGERY MULTIFUNCTIONAL CANNULAS, SINGLE-USE",
          "concept" : [{
            "code" : "K0201010101",
            "display" : "OPEN ELECTROSURGERY MULTIFUNCTIONAL CANNULAS, SINGLE-USE"
          },
          {
            "code" : "K0201010102",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY MULTIFUNCTIONAL CANNULAS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010102",
          "display" : "ELECTROSURGERY DISSECTORS, SINGLE-USE",
          "concept" : [{
            "code" : "K0201010201",
            "display" : "OPEN ELECTROSURGERY DISSECTORS, SINGLE-USE"
          },
          {
            "code" : "K0201010202",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY DISSECTORS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010103",
          "display" : "ELECTROSURGERY ELECTRODES, SINGLE-USE",
          "concept" : [{
            "code" : "K0201010301",
            "display" : "OPEN ELECTROSURGERY ELECTRODES, SINGLE-USE"
          },
          {
            "code" : "K0201010302",
            "display" : "LAPAR AND THORACOSCOPIC ELECTROSURGERY ELECTRODES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010104",
          "display" : "ELECTROSURGERY SCISSORS, SINGLE-USE",
          "concept" : [{
            "code" : "K0201010401",
            "display" : "OPEN ELECTROSURGERY SCISSORS, SINGLE-USE"
          },
          {
            "code" : "K0201010402",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY SCISSORS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010105",
          "display" : "ELECTROSURGERY HANDPIECES, SINGLE-USE",
          "concept" : [{
            "code" : "K0201010501",
            "display" : "OPEN ELECTROSURGERY HANDPIECES, SINGLE-USE"
          },
          {
            "code" : "K0201010502",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY HANDPIECES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010106",
          "display" : "ELECTROSURGERY FORCEPS, SINGLE-USE",
          "concept" : [{
            "code" : "K0201010601",
            "display" : "OPEN ELECTROSURGERY FORCEPS, SINGLE-USE"
          },
          {
            "code" : "K0201010602",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY FORCEPS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010107",
          "display" : "SMOKE EVACUATION SYSTEMS"
        },
        {
          "code" : "K02010108",
          "display" : "ELECTROSURGERY NEEDLES, SINGLE-USE",
          "concept" : [{
            "code" : "K0201010801",
            "display" : "OPEN ELECTROSURGERY NEEDLES, SINGLE-USE"
          },
          {
            "code" : "K0201010802",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY NEEDLES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010109",
          "display" : "ELECTROSURGERY BLADES, SINGLE-USE",
          "concept" : [{
            "code" : "K0201010901",
            "display" : "OPEN ELECTROSURGERY BLADES, SINGLE-USE"
          },
          {
            "code" : "K0201010902",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY BLADES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010110",
          "display" : "ELECTROSURGERY MANIPULATORS, SINGLE-USE",
          "concept" : [{
            "code" : "K0201011001",
            "display" : "OPEN ELECTROSURGERY MANIPULATORS, SINGLE-USE"
          },
          {
            "code" : "K0201011002",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY MANIPULATORS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010111",
          "display" : "ELECTROSURGERY INSTRUMENT KITS, SINGLE-USE",
          "concept" : [{
            "code" : "K0201011101",
            "display" : "OPEN ELECTROSURGERY INSTRUMENT KITS, SINGLE-USE"
          },
          {
            "code" : "K0201011102",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY INSTRUMENT KITS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010112",
          "display" : "ELECTROSURGERY PROBES, SINGLE-USE",
          "concept" : [{
            "code" : "K0201011201",
            "display" : "OPEN ELECTROSURGERY PROBES, SINGLE-USE"
          },
          {
            "code" : "K0201011202",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ELECTROSURGERY PROBES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02010113",
          "display" : "MINIMALLY INVASIVE SURGERY MULTIPURPOSE HANDPIECES, SINGLE-USE"
        },
        {
          "code" : "K02010199",
          "display" : "MONO- AND BIPOLAR INSTRUMENTS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "K020102",
        "display" : "ELECTROSURGERY PADS (NEUTRAL ELECTRODES) AND CABLES, SINGLE-USE",
        "concept" : [{
          "code" : "K02010201",
          "display" : "ELECTROSURGERY SINGLE PATIENT PADS (NEUTRAL ELECTRODES), SINGLE-USE"
        },
        {
          "code" : "K02010202",
          "display" : "ELECTROSURGERY DUAL PATIENT PADS (NEUTRAL ELECTRODES), SINGLE-USE"
        },
        {
          "code" : "K02010203",
          "display" : "ELECTROSURGERY CONNECTION CABLES, SINGLE-USE"
        }]
      },
      {
        "code" : "K020103",
        "display" : "SELF-POWERED BIPOLAR ELECTROCAUTERS SINGLE USE",
        "concept" : [{
          "code" : "K02010301",
          "display" : "LOW TEMPERATURE BIPOLAR ELECTROCAUTERS, SINGLE USE"
        },
        {
          "code" : "K02010302",
          "display" : "MEDIUM TEMPERATURE BIPOLAR ELECTROCAUTERS, SINGLE USE"
        },
        {
          "code" : "K02010303",
          "display" : "HIGH TEMPERATURE BIPOLAR ELECTROCAUTERS, SINGLE USE"
        }]
      },
      {
        "code" : "K020180",
        "display" : "SINGLE- AND BIPOLAR DEVICES, SINGLE USE - ACCESSORIES"
      },
      {
        "code" : "K020199",
        "display" : "MONO- AND BIPOLAR DEVICES, SINGLE USE - OTHER"
      }]
    },
    {
      "code" : "K0202",
      "display" : "DEVICES FOR SURGERY WITH ULTRASONIC GENERATOR, SINGLE-USE",
      "concept" : [{
        "code" : "K020201",
        "display" : "ULTRASONIC SURGERY INSTRUMENTS, SINGLE-USE",
        "concept" : [{
          "code" : "K02020101",
          "display" : "ULTRASONIC SURGERY SCISSORS, SINGLE-USE",
          "concept" : [{
            "code" : "K0202010101",
            "display" : "ULTRASONIC OPEN SURGERY SCISSORS, SINGLE-USE"
          },
          {
            "code" : "K0202010102",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ULTRASONIC SURGERY SCISSORS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02020102",
          "display" : "ULTRASONIC SURGERY HANDPIECES, SINGLE-USE",
          "concept" : [{
            "code" : "K0202010201",
            "display" : "ULTRASONIC OPEN SURGERY HANDPIECES, SINGLE-USE"
          },
          {
            "code" : "K0202010202",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ULTRASONIC SURGERY HANDPIECES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02020103",
          "display" : "ULTRASONIC SURGERY BLADES, SINGLE-USE",
          "concept" : [{
            "code" : "K0202010301",
            "display" : "ULTRASONIC OPEN SURGERY BLADES, SINGLE-USE"
          },
          {
            "code" : "K0202010302",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ULTRASONIC SURGERY BLADES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02020104",
          "display" : "ULTRASONIC SURGERY INSTRUMENT KITS, SINGLE-USE",
          "concept" : [{
            "code" : "K0202010401",
            "display" : "ULTRASONIC OPEN SURGERY INSTRUMENT KITS, SINGLE-USE"
          },
          {
            "code" : "K0202010402",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ULTRASONIC SURGERY INSTRUMENT KITS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02020105",
          "display" : "ULTRASONIC SURGERY CANNULAS, SINGLE-USE",
          "concept" : [{
            "code" : "K0202010501",
            "display" : "ULTRASONIC OPEN SURGERY CANNULAS, SINGLE-USE"
          },
          {
            "code" : "K0202010502",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ULTRASONIC SURGERY CANNULAS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02020106",
          "display" : "ULTRASONIC SURGERY DISSECTORS, SINGLE-USE",
          "concept" : [{
            "code" : "K0202010601",
            "display" : "ULTRASONIC OPEN SURGERY DISSECTORS, SINGLE-USE"
          },
          {
            "code" : "K0202010602",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ULTRASONIC SURGERY DISSECTORS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02020107",
          "display" : "ULTRASONIC SURGERY ELECTRODES, SINGLE-USE",
          "concept" : [{
            "code" : "K0202010701",
            "display" : "ULTRASONIC OPEN SURGERY ELECTRODES, SINGLE-USE"
          },
          {
            "code" : "K0202010702",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ULTRASONIC SURGERY ELECTRODES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02020108",
          "display" : "ULTRASONIC SURGERY FORCEPS, SINGLE-USE",
          "concept" : [{
            "code" : "K0202010801",
            "display" : "ULTRASONIC OPEN SURGERY FORCEPS, SINGLE-USE"
          },
          {
            "code" : "K0202010802",
            "display" : "LAPAROSCOPIC AND THORACOSCOPIC ULTRASONIC SURGERY FORCEPS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02020109",
          "display" : "ULTRASONIC SURGERY MANIPULATORS, SINGLE-USE",
          "concept" : [{
            "code" : "K0202010901",
            "display" : "ULTRASONIC OPEN SURGERY MANIPULATORS, SINGLE-USE"
          },
          {
            "code" : "K0202010902",
            "display" : "ULTRASONIC LAPAROSCOPIC AND THORACOSCOPIC SURGERY MANIPULATORS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02020199",
          "display" : "ULTRASONIC SURGERY INSTRUMENTS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "K020280",
        "display" : "DEVICES FOR SURGERY WITH ULTRASONIC GENERATOR, SINGLE-USE - ACCESSORIES"
      },
      {
        "code" : "K020299",
        "display" : "DEVICES FOR SURGERY WITH ULTRASONIC GENERATOR, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "K0203",
      "display" : "DEVICES FOR SURGERY WITH RADIOFREQUENCY GENERATOR, SINGLE-USE",
      "concept" : [{
        "code" : "K020301",
        "display" : "RADIOFREQUENCY SURGERY INSTRUMENTS, SINGLE-USE",
        "concept" : [{
          "code" : "K02030101",
          "display" : "RADIOFREQUENCY SURGERY ELECTRODES, SINGLE-USE"
        },
        {
          "code" : "K02030102",
          "display" : "RADIOFREQUENCY SURGERY FORCEPS, SINGLE-USE"
        },
        {
          "code" : "K02030103",
          "display" : "RADIOFREQUENCY SURGERY INSTRUMENT KITS, SINGLE-USE"
        },
        {
          "code" : "K02030104",
          "display" : "RADIOFREQUENCY SURGERY NEEDLES, SINGLE-USE"
        },
        {
          "code" : "K02030105",
          "display" : "RADIOFREQUENCY SURGERY DISSECTORS, SINGLE-USE"
        },
        {
          "code" : "K02030106",
          "display" : "RADIOFREQUENCY SURGERY CANNULAS, SINGLE-USE"
        },
        {
          "code" : "K02030107",
          "display" : "RADIOFREQUENCY SURGERY BLADES, SINGLE-USE"
        },
        {
          "code" : "K02030108",
          "display" : "RADIOFREQUENCY SURGERY SCISSORS, SINGLE-USE"
        },
        {
          "code" : "K02030109",
          "display" : "RADIOFREQUENCY SURGERY HANDPIECES, SINGLE-USE"
        },
        {
          "code" : "K02030110",
          "display" : "RADIOFREQUENCY SURGERY MANIPULATORS,  SINGLE-USE"
        },
        {
          "code" : "K02030199",
          "display" : "RADIOFREQUENCY SURGERY INSTRUMENTS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "K020380",
        "display" : "DEVICES FOR SURGERY WITH RADIOFREQUENCY GENERATOR, SINGLE-USE - ACCESSORIES"
      },
      {
        "code" : "K020399",
        "display" : "DEVICES FOR SURGERY WITH RADIOFREQUENCY GENERATOR, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "K0204",
      "display" : "DEVICES FOR SURGERY WITH ARGON GAS GENERATOR, SINGLE-USE",
      "concept" : [{
        "code" : "K020401",
        "display" : "ARGON GAS SURGERY INSTRUMENTS, SINGLE-USE",
        "concept" : [{
          "code" : "K02040101",
          "display" : "ARGON GAS SURGERY ELECTRODES, SINGLE-USE",
          "concept" : [{
            "code" : "K0204010101",
            "display" : "ARGON GAS OPEN SURGERY ELECTRODES, SINGLE-USE"
          },
          {
            "code" : "K0204010102",
            "display" : "ARGON GAS LAPAROSCOPIC AND THORACOSCOPIC SURGERY ELECTRODES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02040102",
          "display" : "ARGON GAS SURGERY HANDPIECES, SINGLE-USE",
          "concept" : [{
            "code" : "K0204010201",
            "display" : "ARGON GAS OPEN SURGERY HANDPIECES, SINGLE-USE"
          },
          {
            "code" : "K0204010202",
            "display" : "ARGON GAS LAPAROSCOPIC AND THORACOSCOPIC GAS SURGERY HANDPIECES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02040103",
          "display" : "ARGON GAS SURGERY FORCEPS, SINGLE-USE",
          "concept" : [{
            "code" : "K0204010301",
            "display" : "ARGON GAS OPEN SURGERY FORCEPS, SINGLE-USE"
          },
          {
            "code" : "K0204010302",
            "display" : "ARGON GAS LAPAROSCOPIC AND THORACOSCOPIC SURGERY FORCEPS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02040104",
          "display" : "ARGON GAS SURGERY SCISSORS, SINGLE-USE",
          "concept" : [{
            "code" : "K0204010401",
            "display" : "ARGON GAS OPEN SURGERY SCISSORS, SINGLE-USE"
          },
          {
            "code" : "K0204010402",
            "display" : "ARGON GAS LAPAROSCOPIC AND THORACOSCOPIC SURGERY SCISSORS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02040105",
          "display" : "ARGON GAS SURGERY BLADES, SINGLE-USE",
          "concept" : [{
            "code" : "K0204010501",
            "display" : "ARGON GAS OPEN SURGERY BLADES, SINGLE-USE"
          },
          {
            "code" : "K0204010502",
            "display" : "ARGON GAS LAPAROSCOPIC AND THORACOSCOPIC SURGERY BLADES, SINGLE-USE"
          }]
        },
        {
          "code" : "K02040106",
          "display" : "ARGON GAS SURGERY DISSECTORS, SINGLE-USE",
          "concept" : [{
            "code" : "K0204010601",
            "display" : "ARGON GAS OPEN SURGERY DISSECTORS, SINGLE-USE"
          },
          {
            "code" : "K0204010602",
            "display" : "ARGON GAS LAPAROSCOPIC AND THORACOSCOPIC SURGERY DISSECTORS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02040107",
          "display" : "ARGON GAS SURGERY CANNULAS, SINGLE-USE",
          "concept" : [{
            "code" : "K0204010701",
            "display" : "ARGON GAS OPEN SURGERY CANNULAS, SINGLE-USE"
          },
          {
            "code" : "K0204010702",
            "display" : "ARGON GAS LAPAROSCOPIC AND THORACOSCOPIC SURGERY CANNULAS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02040108",
          "display" : "ARGON GAS SURGERY MANIPULATORS, SINGLE-USE",
          "concept" : [{
            "code" : "K0204010801",
            "display" : "ARGON GAS OPEN SURGERY MANIPULATORS, SINGLE-USE"
          },
          {
            "code" : "K0204010802",
            "display" : "ARGON GAS LAPAROSCOPIC AND THORACOSCOPIC SURGERY MANIPULATORS, SINGLE-USE"
          }]
        },
        {
          "code" : "K02040109",
          "display" : "ARGON GAS SURGERY INSTRUMENT KITS, SINGLE-USE"
        },
        {
          "code" : "K02040199",
          "display" : "ARGON GAS SURGERY INSTRUMENTS, SINGLE-USE- OTHER"
        }]
      },
      {
        "code" : "K020480",
        "display" : "DEVICES FOR SURGERY WITH ARGON GAS GENERATOR, SINGLE-USE- ACCESSORIES"
      },
      {
        "code" : "K020499",
        "display" : "DEVICES FOR SURGERY WITH ARGON GAS GENERATOR, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "K0205",
      "display" : "DEVICES FOR SURGERY WITH COMBINED RADIOFREQUENCY / ULTRASOUND GENERATORS, SINGLE-USE",
      "concept" : [{
        "code" : "K020501",
        "display" : "COMBINED RADIOFREQUENCY / ULTRASOUND SURGERY INSTRUMENTS, SINGLE-USE",
        "concept" : [{
          "code" : "K02050101",
          "display" : "COMBINED RADIOFREQUENCY / ULTRASONIC SURGERY ELECTRODES, SINGLE-USE"
        },
        {
          "code" : "K02050102",
          "display" : "COMBINED RADIOFREQUENCY / ULTRASONIC SURGERY FORCEPS, SINGLE-USE"
        },
        {
          "code" : "K02050103",
          "display" : "COMBINED RADIOFREQUENCY / ULTRASOUND SURGERY INSTRUMENT KITS, SINGLE-USE"
        },
        {
          "code" : "K02050104",
          "display" : "COMBINED RADIOFREQUENCY / ULTRASONIC SURGERY NEEDLES, SINGLE-USE"
        },
        {
          "code" : "K02050105",
          "display" : "RADIOFREQUENCY / ULTRASONIC SURGERY COMBINED DISSECTORS, SINGLE-USE"
        },
        {
          "code" : "K02050106",
          "display" : "COMBINED RADIOFREQUENCY / ULTRASOUND SURGERY CANNULAS, SINGLE-USE"
        },
        {
          "code" : "K02050107",
          "display" : "COMBINED RADIOFREQUENCY / ULTRASONIC SURGERY BLADES, SINGLE-USE"
        },
        {
          "code" : "K02050108",
          "display" : "COMBINED RADIOFREQUENCY / ULTRASONIC SURGERY SCISSORS, SINGLE-USE"
        },
        {
          "code" : "K02050109",
          "display" : "COMBINED RADIOFREQUENCY / ULTRASONIC SURGERY HANDPIECES, SINGLE-USE"
        },
        {
          "code" : "K02050110",
          "display" : "COMBINED RADIOFREQUENCY / ULTRASONIC SURGERY MANIPULATORS, SINGLE-USE"
        }]
      }]
    },
    {
      "code" : "K0299",
      "display" : "ELECTROSURGERY DEVICES, SINGLE-USE - OTHER"
    }]
  },
  {
    "code" : "K03",
    "display" : "ARTHROSCOPY DEVICES, SINGLE-USE",
    "concept" : [{
      "code" : "K0301",
      "display" : "ARTHROSCOPY TRACTION SYSTEMS, SINGLE-USE"
    },
    {
      "code" : "K0302",
      "display" : "ARTHROSCOPY SURGICAL INSTRUMENTS, SINGLE-USE",
      "concept" : [{
        "code" : "K030201",
        "display" : "ARTHROSCOPY CANNULAS, SINGLE-USE"
      },
      {
        "code" : "K030202",
        "display" : "ARTHROSCOPY GUIDE WIRES, SINGLE-USE"
      },
      {
        "code" : "K030203",
        "display" : "ARTHROSCOPY BLADES, SINGLE-USE"
      },
      {
        "code" : "K030204",
        "display" : "ARTHROSCOPY BURS, SINGLE-USE"
      },
      {
        "code" : "K030205",
        "display" : "ARTHROSCOPY SUTURE DEVICES NOT INCLUDED IN OTHER CLASSES, SINGLE-USE"
      },
      {
        "code" : "K030206",
        "display" : "ARTHROSCOPY DISSECTORS, SINGLE-USE"
      },
      {
        "code" : "K030207",
        "display" : "ARTHROSCOPY ELECTRODES, SINGLE-USE"
      },
      {
        "code" : "K030208",
        "display" : "ARTHROSCOPY FORCEPS, SINGLE-USE"
      },
      {
        "code" : "K030209",
        "display" : "ARTHROSCOPY SCISSORS, SINGLE-USE"
      },
      {
        "code" : "K030210",
        "display" : "ARTHROSCOPY HANDPIECES, SINGLE USE"
      },
      {
        "code" : "K030211",
        "display" : "ARTHROSCOPY MANIPULATORS, SINGLE USE"
      },
      {
        "code" : "K030212",
        "display" : "ARTHROSCOPY INSTRUMENT KITS, SINGLE USE"
      },
      {
        "code" : "K030299",
        "display" : "ARTHROSCOPY SURGICAL INSTRUMENTS, SINGLE USE - OTHER"
      }]
    },
    {
      "code" : "K0380",
      "display" : "ARTHROSCOPY DEVICES, SINGLE USE - ACCESSORIES"
    },
    {
      "code" : "K0399",
      "display" : "ARTHROSCOPY DEVICES, SINGLE USE - OTHER"
    }]
  },
  {
    "code" : "L",
    "display" : "REUSABLE SURGICAL INSTRUMENTS"
  },
  {
    "code" : "L01",
    "display" : "SHARP INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L0101",
      "display" : "SURGICAL SCALPELS, REUSABLE",
      "concept" : [{
        "code" : "L010101",
        "display" : "MONOBLOCK SURGICAL SCALPELS, REUSABLE"
      },
      {
        "code" : "L010102",
        "display" : "SCALPEL BLADES, REUSABLE"
      },
      {
        "code" : "L010103",
        "display" : "HANDLES FOR SCALPELS, REUSABLE"
      }]
    },
    {
      "code" : "L0102",
      "display" : "SURGICAL KNIVES, REUSABLE"
    },
    {
      "code" : "L0103",
      "display" : "DERMOTOMES AND BLADES, REUSABLE"
    },
    {
      "code" : "L0104",
      "display" : "SURGICAL SCISSORS, REUSABLE",
      "concept" : [{
        "code" : "L010401",
        "display" : "SCISSORS FOR BANDAGES AND CLOTHING, REUSABLE",
        "concept" : [{
          "code" : "L01040101",
          "display" : "SCISSORS FOR PLASTERS, REUSABLE"
        },
        {
          "code" : "L01040102",
          "display" : "SCISSORS FOR BANDAGES, REUSABLE"
        },
        {
          "code" : "L01040103",
          "display" : "SCISSORS FOR CLOTHING, REUSABLE"
        },
        {
          "code" : "L01040199",
          "display" : "SCISSORS FOR BANDAGES AND CLOTHING, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L010402",
        "display" : "SURGICAL SUTURES SCISSORS, REUSABLE",
        "concept" : [{
          "code" : "L01040201",
          "display" : "STAPLE REMOVER SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040202",
          "display" : "LIGATURES SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040299",
          "display" : "SURGICAL SUTURES SCISSORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L010403",
        "display" : "SURGICAL DISSECTION SCISSORS, REUSABLE"
      },
      {
        "code" : "L010404",
        "display" : "CARDIOVASCULAR SURGERY SCISSORS, REUSABLE",
        "concept" : [{
          "code" : "L01040401",
          "display" : "CARDIAC SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040402",
          "display" : "VASCULAR SCISSORS, REUSABLE"
        }]
      },
      {
        "code" : "L010405",
        "display" : "OPHTHALMOLOGY SCISSORS, REUSABLE",
        "concept" : [{
          "code" : "L01040501",
          "display" : "CORNEAL SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040502",
          "display" : "OCULAR ENUCLEATION SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040503",
          "display" : "IRIS SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040504",
          "display" : "VITREO-RETINA SURGERY SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040505",
          "display" : "CONJUNCTIVA SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040506",
          "display" : "TENOTOMY AND STRABISM CORRECTION SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040507",
          "display" : "BLEPHAROPLASTY SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040508",
          "display" : "ENDOCULAR IMPLANTS SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040509",
          "display" : "OCULAR ADNEXA SCISSORS, REUSABLE",
          "concept" : [{
            "code" : "L0104050901",
            "display" : "CILIARY SCISSORS, REUSABLE"
          },
          {
            "code" : "L0104050999",
            "display" : "OCULAR ADNEXA SCISSORS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L01040510",
          "display" : "CAPSULOTOMY SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040599",
          "display" : "OPHTHALMOLOGY SCISSORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L010406",
        "display" : "OTOLARYNGOLOGICAL (ENT) SURGERY SCISSORS, REUSABLE",
        "concept" : [{
          "code" : "L01040601",
          "display" : "NASAL SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040602",
          "display" : "EAR SURGERY SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040603",
          "display" : "TONSILLAR SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040604",
          "display" : "LARYNGEAL SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040699",
          "display" : "OTOLARYNGOLOGICAL (ENT) SURGERY SCISSORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L010407",
        "display" : "NEUROSURGERY SCISSORS, REUSABLE",
        "concept" : [{
          "code" : "L01040701",
          "display" : "DURA MATER SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040702",
          "display" : "NERVES SCISSORS, REUSABLE"
        },
        {
          "code" : "L01040799",
          "display" : "NEUROSURGERY SCISSORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L010408",
        "display" : "GASTROENTEROLOGY SCISSORS, REUSABLE",
        "concept" : [{
          "code" : "L01040801",
          "display" : "INTESTINAL SCISSORS, REUSABLE",
          "concept" : [{
            "code" : "L0104080101",
            "display" : "RECTAL SCISSORS, REUSABLE"
          },
          {
            "code" : "L0104080102",
            "display" : "ENTEROTOMY SCISSORS, REUSABLE"
          },
          {
            "code" : "L0104080199",
            "display" : "INTESTINAL SCISSORS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L01040899",
          "display" : "GASTROENTEROLOGY SCISSORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L010409",
        "display" : "THORACIC SURGERY SCISSORS, REUSABLE"
      },
      {
        "code" : "L010410",
        "display" : "ODONTOSTOMATOLOGY SCISSORS, REUSABLE",
        "concept" : [{
          "code" : "L01041001",
          "display" : "GINGIVAL SCISSORS, REUSABLE"
        },
        {
          "code" : "L01041099",
          "display" : "ODONTOSTOMATOLOGY SCISSORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L010411",
        "display" : "OBSTETRIC-GYNECOLOGICAL SURGERY SCISSORS, REUSABLE",
        "concept" : [{
          "code" : "L01041101",
          "display" : "OBSTETRICS SCISSORS, REUSABLE",
          "concept" : [{
            "code" : "L0104110101",
            "display" : "UMBILICAL SCISSORS, REUSABLE"
          },
          {
            "code" : "L0104110102",
            "display" : "EPISIOTOMY SCISSORS, REUSABLE"
          },
          {
            "code" : "L0104110103",
            "display" : "CEPHALOTOMY SCISSORS, REUSABLE"
          },
          {
            "code" : "L0104110199",
            "display" : "OBSTETRICS SCISSORS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L01041102",
          "display" : "GYNECOLOGY SCISSORS, REUSABLE",
          "concept" : [{
            "code" : "L0104110201",
            "display" : "UTERINE SCISSORS, REUSABLE"
          },
          {
            "code" : "L0104110202",
            "display" : "PARAMETRIUM SCISSORS, REUSABLE"
          },
          {
            "code" : "L0104110299",
            "display" : "GYNECOLOGY SCISSORS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L01041199",
          "display" : "OBSTETRIC-GYNECOLOGICAL SURGERY SCISSORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L010412",
        "display" : "ORTHOPAEDIC SURGERY SCISSORS, REUSABLE",
        "concept" : [{
          "code" : "L01041201",
          "display" : "BONE SCISSORS, REUSABLE"
        },
        {
          "code" : "L01041202",
          "display" : "WIRES AND METAL PLATES SCISSORS, REUSABLE"
        },
        {
          "code" : "L01041299",
          "display" : "ORTHOPAEDIC SURGERY SCISSORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L010413",
        "display" : "MICROSURGERY SCISSORS, REUSABLE"
      },
      {
        "code" : "L010499",
        "display" : "SURGICAL SCISSORS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0107",
      "display" : "SURGICAL SAWS AND BLADES, REUSABLE",
      "concept" : [{
        "code" : "L010701",
        "display" : "MANUAL SURGICAL SAWS, REUSABLE"
      },
      {
        "code" : "L010702",
        "display" : "BLADES FOR MANUAL SURGICAL SAWS, REUSABLE"
      },
      {
        "code" : "L010703",
        "display" : "BLADES FOR MOTORISED SURGICAL SAWS, REUSABLE"
      }]
    },
    {
      "code" : "L0180",
      "display" : "SHARP INSTRUMENTS, REUSABLE - ACCESSORIES"
    },
    {
      "code" : "L0199",
      "display" : "SHARP INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L02",
    "display" : "SUTURE INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L0201",
      "display" : "NEEDLES AND APPLICATORS FOR LIGATURES, REUSABLE"
    },
    {
      "code" : "L0202",
      "display" : "SUTURE NEEDLES, REUSABLE"
    },
    {
      "code" : "L0203",
      "display" : "NEEDLE CONTAINERS, REUSABLE"
    },
    {
      "code" : "L0204",
      "display" : "STAPLE REMOVERS, REUSABLE"
    },
    {
      "code" : "L0205",
      "display" : "NEEDLE HOLDERS, REUSABLE"
    },
    {
      "code" : "L0206",
      "display" : "GROOVED PROBES, REUSABLE"
    },
    {
      "code" : "L0207",
      "display" : "KNOT PUSHERS, REUSABLE"
    },
    {
      "code" : "L0208",
      "display" : "MULTIPLE CLIPS APPLICATORS, REUSABLE",
      "concept" : [{
        "code" : "L020801",
        "display" : "MULTIPLE CLIPS APPLICATORS FOR OPEN SURGERY, REUSABLE"
      },
      {
        "code" : "L020802",
        "display" : "MULTIPLE APPLICATORS OF CLIPS FOR VIDEO SURGERY, REUSABLE"
      }]
    },
    {
      "code" : "L0299",
      "display" : "SUTURE INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L03",
    "display" : "GENERAL SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L0301",
      "display" : "GENERAL SURGERY SURGICAL CANNULAS AND HANDPIECES, REUSABLE",
      "concept" : [{
        "code" : "L030101",
        "display" : "SUCTION AND IRRIGATION SURGICAL CANNULAS AND HANDPIECES, REUSABLE"
      },
      {
        "code" : "L030199",
        "display" : "GENERAL SURGERY SURGICAL CANNULAS AND HANDPIECES, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0311",
      "display" : "PROBES AND EXPLORERS, REUSABLE",
      "concept" : [{
        "code" : "L031101",
        "display" : "FISTULA PROBES, REUSABLE"
      },
      {
        "code" : "L031102",
        "display" : "EXPLORATION PROBES, REUSABLE"
      },
      {
        "code" : "L031103",
        "display" : "BUTTONED PROBES, REUSABLE"
      },
      {
        "code" : "L031104",
        "display" : "SURGICAL MIRRORS, REUSABLE"
      },
      {
        "code" : "L031199",
        "display" : "PROBES AND MIRRORS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0312",
      "display" : "SURGICAL TROCAR, REUSABLE",
      "concept" : [{
        "code" : "L031201",
        "display" : "THORACIC TROCAR, REUSABLE"
      },
      {
        "code" : "L031202",
        "display" : "ABDOMINAL TROCAR, REUSABLE"
      },
      {
        "code" : "L031203",
        "display" : "OTOLARYNGOLOGICAL SURGERY TROCAR, REUSABLE"
      },
      {
        "code" : "L031204",
        "display" : "ARTHROSCOPIC SURGERY TROCAR, REUSABLE"
      },
      {
        "code" : "L031205",
        "display" : "ORTHOPAEDIC SURGERY TROCAR, REUSABLE"
      },
      {
        "code" : "L031280",
        "display" : "SURGICAL TROCAR, REUSABLE - ACCESSORIES"
      },
      {
        "code" : "L031299",
        "display" : "SURGICAL TROCAR, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0313",
      "display" : "GENERAL SURGERY FORCEPS, REUSABLE",
      "concept" : [{
        "code" : "L031301",
        "display" : "GENERAL SURGERY BIOPSY FORCEPS, REUSABLE"
      },
      {
        "code" : "L031302",
        "display" : "MEDICATION FORCEPS, REUSABLE"
      },
      {
        "code" : "L031303",
        "display" : "SWAB FORCEPS, REUSABLE"
      },
      {
        "code" : "L031304",
        "display" : "GRASPING FORCEPS, REUSABLE",
        "concept" : [{
          "code" : "L03130401",
          "display" : "TISSUE AND ORGAN GRASPING FORCEPS, REUSABLE"
        },
        {
          "code" : "L03130402",
          "display" : "FORCEPS FOR EXTERNAL BODIES, REUSABLE"
        },
        {
          "code" : "L03130403",
          "display" : "SPLINTER FORCEPS, REUSABLE"
        },
        {
          "code" : "L03130499",
          "display" : "GRASPING FORCEPS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L031305",
        "display" : "FORCEPS FOR FABRICS AND BANDAGES, REUSABLE"
      },
      {
        "code" : "L031306",
        "display" : "HEMOSTATIC FORCEPS, REUSABLE"
      },
      {
        "code" : "L031307",
        "display" : "TOWEL AND TUBE CLAMPS, REUSABLE"
      },
      {
        "code" : "L031308",
        "display" : "SURGICAL AND ANATOMICAL TWEEZERS, REUSABLE"
      },
      {
        "code" : "L031309",
        "display" : "SUTURE NEEDLE PASSERS, REUSABLE"
      },
      {
        "code" : "L031310",
        "display" : "DISSECTION FORCEPS, REUSABLE"
      },
      {
        "code" : "L031312",
        "display" : "INTUBATION FORCEPS, REUSABLE"
      },
      {
        "code" : "L031399",
        "display" : "GENERAL SURGERY FORCEPS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0314",
      "display" : "GENERAL SURGERY SPREADERS AND SPATULAS, REUSABLE",
      "concept" : [{
        "code" : "L031401",
        "display" : "GENERAL SURGERY SPREADERS AND RETRACTORS, REUSABLE",
        "concept" : [{
          "code" : "L03140101",
          "display" : "SELF-STATIC SPREADERS, REUSABLE"
        },
        {
          "code" : "L03140102",
          "display" : "VAGINAL SPREADERS, REUSABLE"
        },
        {
          "code" : "L03140103",
          "display" : "VASCULAR SPREADERS AND RETRACTORS, REUSABLE"
        },
        {
          "code" : "L03140104",
          "display" : "SPREADERS HOOKS, REUSABLE"
        },
        {
          "code" : "L03140105",
          "display" : "SKIN RETRACTORS, REUSABLE"
        },
        {
          "code" : "L03140199",
          "display" : "SPREADERS AND RETRACTORS FOR GENERAL SURGERY, REUSABLE   - OTHER"
        }]
      },
      {
        "code" : "L031402",
        "display" : "GENERAL SURGERY SPATULAS, REUSABLE"
      }]
    },
    {
      "code" : "L0315",
      "display" : "GENERAL SURGERY DISSECTORS, REUSABLE"
    },
    {
      "code" : "L0316",
      "display" : "HELMETS AND BINOCULAR GLASSES FOR SURGEONS"
    },
    {
      "code" : "L0317",
      "display" : "GENERAL SURGERY ADAPTERS AND CONNECTORS, REUSABLE"
    },
    {
      "code" : "L0318",
      "display" : "INSTRUMENTS FOR SUPPORT OF SURGICAL DEVICES, REUSABLE"
    },
    {
      "code" : "L0399",
      "display" : "GENERAL SURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L04",
    "display" : "ABDOMINAL SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L0406",
      "display" : "RIGID RECTOSCOPES AND ANOSCOPES, REUSABLE"
    },
    {
      "code" : "L0408",
      "display" : "ABDOMINAL SURGERY SPECIAL FORCEPS, REUSABLE",
      "concept" : [{
        "code" : "L040801",
        "display" : "LIVER AND BILIARY TRACT SPECIAL FORCEPS, REUSABLE",
        "concept" : [{
          "code" : "L04080101",
          "display" : "GALLBLADDER FORCEPS, REUSABLE"
        },
        {
          "code" : "L04080102",
          "display" : "GALLSTONES FORCEPS, REUSABLE"
        },
        {
          "code" : "L04080103",
          "display" : "BILIARY TRACT FORCEPS, REUSABLE"
        },
        {
          "code" : "L04080199",
          "display" : "LIVER AND BILIARY TRACT SPECIAL FORCEPS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L040802",
        "display" : "GASTROINTESTINAL SYSTEM SPECIAL FORCEPS, REUSABLE",
        "concept" : [{
          "code" : "L04080201",
          "display" : "ESOPHAGEAL FORCEPS, REUSABLE"
        },
        {
          "code" : "L04080202",
          "display" : "GASTRIC FORCEPS, REUSABLE"
        },
        {
          "code" : "L04080203",
          "display" : "INTESTINAL FORCEPS, REUSABLE",
          "concept" : [{
            "code" : "L0408020301",
            "display" : "INTESTINAL TISSUE GRIPPERS, REUSABLE"
          },
          {
            "code" : "L0408020302",
            "display" : "ENTEROSTATS, REUSABLE"
          },
          {
            "code" : "L0408020303",
            "display" : "RECTAL BIOPTIC FORCEPS, REUSABLE"
          },
          {
            "code" : "L0408020304",
            "display" : "INTESTINAL COMPRESSION FORCEPS, REUSABLE"
          },
          {
            "code" : "L0408020305",
            "display" : "INTESTINAL ANASTOMOSIS FORCEPS, REUSABLE"
          },
          {
            "code" : "L0408020306",
            "display" : "HEMORROIDAL FORCEPS, REUSABLE"
          },
          {
            "code" : "L0408020399",
            "display" : "INTESTINAL FORCEPS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L04080204",
          "display" : "PERITONEAL FORCEPS, REUSABLE"
        },
        {
          "code" : "L04080299",
          "display" : "GASTROINTESTINAL SYSTEM SPECIAL FORCEPS, REUSABLE - OTHER"
        }]
      }]
    },
    {
      "code" : "L0409",
      "display" : "ABDOMINAL SURGERY DILATORS AND SPREADERS, REUSABLE",
      "concept" : [{
        "code" : "L040901",
        "display" : "ABDOMINAL SPREADERS, REUSABLE"
      },
      {
        "code" : "L040902",
        "display" : "RECTAL AND ANAL SPREADERS, REUSABLE"
      },
      {
        "code" : "L040903",
        "display" : "GASTRIC DILATORS, REUSABLE"
      },
      {
        "code" : "L040999",
        "display" : "ABDOMINAL SURGERY DILATORS AND SPREADERS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0410",
      "display" : "ABDOMINAL SURGERY PROBES, REUSABLE",
      "concept" : [{
        "code" : "L041001",
        "display" : "LIVER AND BILIARY ROUTES SURGICAL PROBES, MULTIPURPOSE",
        "concept" : [{
          "code" : "L04100101",
          "display" : "BILIARY SURGICAL PROBES, REUSABLE"
        },
        {
          "code" : "L04100102",
          "display" : "LIVER SURGICAL PROBES, REUSABLE"
        }]
      },
      {
        "code" : "L041002",
        "display" : "DIGESTIVE SYSTEM SURGICAL PROBES, REUSABLE",
        "concept" : [{
          "code" : "L04100201",
          "display" : "ESOPHAGEAL SURGICAL PROBES, REUSABLE"
        },
        {
          "code" : "L04100202",
          "display" : "RECTAL SURGICAL PROBES, REUSABLE"
        },
        {
          "code" : "L04100299",
          "display" : "DIGESTIVE SYSTEM SURGICAL PROBES, REUSABLE - OTHER"
        }]
      }]
    },
    {
      "code" : "L0411",
      "display" : "ABDOMINAL SURGERY INSTRUMENT KITS, REUSABLE"
    },
    {
      "code" : "L0499",
      "display" : "ABDOMINAL SURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L05",
    "display" : "OBSTETRICS AND GYNECOLOGY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L0508",
      "display" : "OBSTETRICS INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L050801",
        "display" : "OBSTETRICS FORCEPS, REUSABLE"
      },
      {
        "code" : "L050802",
        "display" : "AMNIOTOMES, REUSABLE"
      },
      {
        "code" : "L050803",
        "display" : "OBSTETRIC SURGERY FORCEPS, REUSABLE",
        "concept" : [{
          "code" : "L05080301",
          "display" : "OBSTETRIC SURGERY CLAMPS, REUSABLE",
          "concept" : [{
            "code" : "L0508030101",
            "display" : "UMBILICAL CLAMPING FORCEPS, REUSABLE"
          },
          {
            "code" : "L0508030199",
            "display" : "OBSTETRIC SURGERY CLAMPS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L05080302",
          "display" : "OBSTETRIC GRIPPERS, REUSABLE"
        },
        {
          "code" : "L05080303",
          "display" : "PLACENTA AND ABORTIVE TISSUE FORCEPS, REUSABLE"
        },
        {
          "code" : "L05080399",
          "display" : "OBSTETRIC SURGERY FORCEPS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L050804",
        "display" : "OBSTETRICS HOOKS, REUSABLE"
      },
      {
        "code" : "L050899",
        "display" : "OBSTETRICS INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0509",
      "display" : "GYNECOLOGICAL SURGERY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L050901",
        "display" : "UTERINE CURETTES, REUSABLE"
      },
      {
        "code" : "L050902",
        "display" : "GYNECOLOGICAL USE DILATORS AND SPREADERS, REUSABLE",
        "concept" : [{
          "code" : "L05090201",
          "display" : "GYNECOLOGICAL USE DILATORS, REUSABLE",
          "concept" : [{
            "code" : "L0509020101",
            "display" : "VAGINAL DILATORS, REUSABLE"
          },
          {
            "code" : "L0509020102",
            "display" : "CERVICAL DILATORS, REUSABLE"
          },
          {
            "code" : "L0509020103",
            "display" : "TUBES DILATORS, REUSABLE"
          },
          {
            "code" : "L0509020199",
            "display" : "GYNECOLOGICAL USE DILATORS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L05090202",
          "display" : "GYNECOLOGICAL USE SPREADERS, REUSABLE",
          "concept" : [{
            "code" : "L0509020201",
            "display" : "UTERINE RETRACTORS, REUSABLE"
          },
          {
            "code" : "L0509020299",
            "display" : "GYNECOLOGICAL USE SPREADERS, REUSABLE - OTHER"
          }]
        }]
      },
      {
        "code" : "L050903",
        "display" : "GYNECOLOGICAL SURGERY FORCEPS, REUSABLE",
        "concept" : [{
          "code" : "L05090301",
          "display" : "GYNECOLOGICAL BIOPSY FORCEPS, REUSABLE"
        },
        {
          "code" : "L05090302",
          "display" : "UTERINE FORCEPS, REUSABLE",
          "concept" : [{
            "code" : "L0509030201",
            "display" : "HYSTERECTOMY FORCEPS, REUSABLE"
          },
          {
            "code" : "L0509030202",
            "display" : "UTERINE GRIPPERS, REUSABLE"
          },
          {
            "code" : "L0509030203",
            "display" : "PARAMETRIUM FORCEPS, REUSABLE"
          },
          {
            "code" : "L0509030299",
            "display" : "UTERINE FORCEPS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L05090399",
          "display" : "GYNECOLOGICAL SURGERY FORCEPS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L050905",
        "display" : "GYNECOLOGICAL SURGERY PROBES, REUSABLE",
        "concept" : [{
          "code" : "L05090501",
          "display" : "UTERINE SURGICAL PROBES, REUSABLE"
        },
        {
          "code" : "L05090599",
          "display" : "GYNECOLOGICAL SURGERY PROBES, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L050906",
        "display" : "GYNECOLOGICAL PROSTHETIC INSTRUMENTS AND KIT, REUSABLE"
      }]
    },
    {
      "code" : "L0590",
      "display" : "OBSTETRICS AND GYNECOLOGY INSTRUMENTS, REUSABLE - VARIOUS",
      "concept" : [{
        "code" : "L059001",
        "display" : "VAGINAL SPECULUMS, REUSABLE"
      },
      {
        "code" : "L059002",
        "display" : "UTERINE LEVERS, REUSABLE"
      },
      {
        "code" : "L059003",
        "display" : "GYNECOLOGICAL USE HOOKS, REUSABLE"
      },
      {
        "code" : "L059004",
        "display" : "UTERINE MANIPULATORS, REUSABLE"
      },
      {
        "code" : "L059005",
        "display" : "CERVICAL CERCLAGE NEEDLES, REUSABLE"
      },
      {
        "code" : "L059006",
        "display" : "OBSTETRIC AND GYNECOLOGICAL SURGERY SCALPELS AND KNIVES, REUSABLE"
      },
      {
        "code" : "L059007",
        "display" : "UTERINE MYOMA EXTRACTORS, REUSABLE"
      },
      {
        "code" : "L059008",
        "display" : "OBSTETRIC AND GYNECOLOGICAL SURGERY INSTRUMENT KITS, REUSABLE"
      },
      {
        "code" : "L059099",
        "display" : "OBSTETRICS AND GYNECOLOGY INSTRUMENTS, REUSABLE - OTHER"
      }]
    }]
  },
  {
    "code" : "L06",
    "display" : "UROLOGY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L0604",
      "display" : "ENDOSCOPIC UROLOGY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L060401",
        "display" : "ENDOSCOPIC UROLOGY SCISSORS, REUSABLE"
      },
      {
        "code" : "L060402",
        "display" : "ENDOSCOPIC UROLOGY MANIPULATORS, REUSABLE"
      },
      {
        "code" : "L060403",
        "display" : "ENDOSCOPIC UROLOGY FORCEPS, REUSABLE"
      },
      {
        "code" : "L060404",
        "display" : "ENDOSCOPIC UROLOGY DISSECTORS, REUSABLE"
      },
      {
        "code" : "L060405",
        "display" : "ENDOSCOPIC UROLOGY SCALPELS, REUSABLE",
        "concept" : [{
          "code" : "L06040501",
          "display" : "ENDOSCOPIC SURGERY URETHROTOMES AND URETHEROTOMES, REUSABLE"
        },
        {
          "code" : "L06040599",
          "display" : "ENDOSCOPIC UROLOGY SCALPELS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L060406",
        "display" : "ENDOSCOPIC UROLOGY RECOVERY BASKETS, REUSABLE"
      },
      {
        "code" : "L060407",
        "display" : "ENDOSCOPIC UROLOGY SHIRTS, REUSABLE"
      },
      {
        "code" : "L060408",
        "display" : "ENDOSCOPIC UROLOGY FILLERS, REUSABLE"
      },
      {
        "code" : "L060409",
        "display" : "ENDOSCOPIC UROLOGY CANNULAS, REUSABLE"
      },
      {
        "code" : "L060410",
        "display" : "ENDOSCOPIC UROLOGY NEEDLES, REUSABLE"
      },
      {
        "code" : "L060411",
        "display" : "ENDOSCOPIC UROLOGY SPREADERS AND RETRACTORS, REUSABLE"
      },
      {
        "code" : "L060412",
        "display" : "ENDOSCOPIC UROLOGY DILATORS, REUSABLE"
      },
      {
        "code" : "L060413",
        "display" : "ENDOSCOPIC UROLOGY ADAPTERS AND CONNECTORS, REUSABLE"
      },
      {
        "code" : "L060480",
        "display" : "ENDOSCOPIC UROLOGY INSTRUMENTS, REUSABLE - ACCESSORIES"
      },
      {
        "code" : "L060499",
        "display" : "ENDOSCOPIC UROLOGY INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0605",
      "display" : "NON-ENDOSCOPIC UROLOGY DILATORS AND SPREADERS, REUSABLE",
      "concept" : [{
        "code" : "L060501",
        "display" : "NON-ENDOSCOPIC UROLOGICAL EXPANSION INSTRUMENTS, REUSABLE",
        "concept" : [{
          "code" : "L06050101",
          "display" : "NON-ENDOSCOPIC URETHRAL EXPANSION INSTRUMENTS, REUSABLE"
        },
        {
          "code" : "L06050199",
          "display" : "NON-ENDOSCOPIC UROLOGICAL DILATION INSTRUMENTS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L060502",
        "display" : "NON-ENDOSCOPIC UROLOGY SPREADERS, REUSABLE",
        "concept" : [{
          "code" : "L06050201",
          "display" : "NON-ENDOSCOPIC BLADDER SPREADERS AND RETRACTORS, REUSABLE"
        },
        {
          "code" : "L06050202",
          "display" : "NON-ENDOSCOPIC PROSTATIC SPREADERS AND RETRACTORS, REUSABLE"
        },
        {
          "code" : "L06050299",
          "display" : "NON-ENDOSCOPIC UROLOGY RETRACTORS, REUSABLE - OTHER"
        }]
      }]
    },
    {
      "code" : "L0606",
      "display" : "NON-ENDOSCOPIC UROLOGY FORCEPS, REUSABLE",
      "concept" : [{
        "code" : "L060601",
        "display" : "NON-ENDOSCOPIC KIDNEY FORCEPS, REUSABLE",
        "concept" : [{
          "code" : "L06060101",
          "display" : "KIDNEY STONES NON-ENDOSCOPIC FORCEPS, REUSABLE"
        },
        {
          "code" : "L06060102",
          "display" : "NON-ENDOSCOPIC UROLOGICAL SURGERY SPATULAS, REUSABLE"
        },
        {
          "code" : "L06060103",
          "display" : "NON-ENDOSCOPIC KIDNEY GRIPPERS, REUSABLE"
        },
        {
          "code" : "L06060199",
          "display" : "NON-ENDOSCOPIC KIDNEY FORCEPS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L060602",
        "display" : "NON-ENDOSCOPIC URINARY TRACT FORCEPS, REUSABLE"
      },
      {
        "code" : "L060603",
        "display" : "EXTERNAL MALE GENITALS FORCEPS, REUSABLE",
        "concept" : [{
          "code" : "L06060301",
          "display" : "EXTERNAL MALE GENITALS CLAMPS, REUSABLE",
          "concept" : [{
            "code" : "L0606030101",
            "display" : "PENILE CLAMPS, REUSABLE"
          },
          {
            "code" : "L0606030199",
            "display" : "EXTERNAL MALE GENITALS CLAMPS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L06060399",
          "display" : "EXTERNAL MALE GENITALS FORCEPS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L060604",
        "display" : "NON-ENDOSCOPIC PROSTATIC FORCEPS, REUSABLE"
      },
      {
        "code" : "L060699",
        "display" : "NON-ENDOSCOPIC UROLOGY FORCEPS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0607",
      "display" : "SUPRAPUBIC ACCESS HANDPIECES, REUSABLE"
    },
    {
      "code" : "L0608",
      "display" : "NON-ENDOSCOPIC URINARY TRACT SURGICAL MANIPULATORS, REUSABLE"
    },
    {
      "code" : "L0609",
      "display" : "UROLOGICAL SURGERY INSTRUMENT KITS, REUSABLE"
    },
    {
      "code" : "L0610",
      "display" : "NON-ENDOSCOPIC UROLOGICAL SURGERY SPATULAS, REUSABLE"
    },
    {
      "code" : "L0611",
      "display" : "NON-ENDOSCOPIC UROLOGY NEEDLES, REUSABLE"
    },
    {
      "code" : "L0612",
      "display" : "UROLOGY PROSTHETIC INSTRUMENTS AND KIT, REUSABLE"
    },
    {
      "code" : "L0699",
      "display" : "UROLOGY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L07",
    "display" : "CARDIOVASCULAR SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L0707",
      "display" : "CARDIAC SURGERY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L070701",
        "display" : "CARDIAC SURGERY FORCEPS, REUSABLE"
      },
      {
        "code" : "L070702",
        "display" : "CARDIAC DILATORS AND RETRACTORS, REUSABLE",
        "concept" : [{
          "code" : "L07070201",
          "display" : "CARDIAC DILATORS, REUSABLE",
          "concept" : [{
            "code" : "L0707020101",
            "display" : "VALVE DILATORS, REUSABLE"
          },
          {
            "code" : "L0707020199",
            "display" : "CARDIAC DILATORS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L07070202",
          "display" : "CARDIAC RETRACTORS, REUSABLE"
        }]
      },
      {
        "code" : "L070703",
        "display" : "CARDIAC VALVULOTOMES, REUSABLE"
      },
      {
        "code" : "L070704",
        "display" : "CARDIAC SURGERY MEASUREMENT INSTRUMENTS, REUSABLE"
      },
      {
        "code" : "L070705",
        "display" : "CARDIAC SURGERY INSTRUMENT KITS, REUSABLE"
      },
      {
        "code" : "L070799",
        "display" : "CARDIAC SURGERY INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0708",
      "display" : "VASCULAR SURGERY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L070801",
        "display" : "VASCULAR SURGERY FORCEPS, REUSABLE",
        "concept" : [{
          "code" : "L07080101",
          "display" : "VASCULAR CLIPS, REUSABLE",
          "concept" : [{
            "code" : "L0708010101",
            "display" : "BULLDOG VASCULAR CLIPS, REUSABLE"
          },
          {
            "code" : "L0708010180",
            "display" : "VASCULAR CLIPS, REUSABLE- ACCESSORIES",
            "concept" : [{
              "code" : "L070801018001",
              "display" : "FORCEPS FOR THE APPLICATION AND REMOVAL OF VASCULAR CLIPS, REUSABLE"
            },
            {
              "code" : "L070801018099",
              "display" : "VASCULAR CLIPS, REUSABLE - OTHER - ACCESSORIES"
            }]
          },
          {
            "code" : "L0708010199",
            "display" : "VASCULAR CLIPS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L07080102",
          "display" : "GENERIC VASCULAR CLAMPING ANGIOSTATS AND FORCEPS, REUSABLE"
        },
        {
          "code" : "L07080103",
          "display" : "VASCULAR ANASTOMOSIS FORCEPS, REUSABLE"
        },
        {
          "code" : "L07080104",
          "display" : "VASCULAR APPROXIMATORS, REUSABLE"
        },
        {
          "code" : "L07080105",
          "display" : "SPECIFIC VESSELS CLAMPS, REUSABLE",
          "concept" : [{
            "code" : "L0708010501",
            "display" : "AORTIC CLAMPS, REUSABLE"
          },
          {
            "code" : "L0708010502",
            "display" : "CAROTID CLAMPS, REUSABLE"
          },
          {
            "code" : "L0708010503",
            "display" : "VENA CAVA CLAMPS, REUSABLE"
          },
          {
            "code" : "L0708010599",
            "display" : "SPECIFIC VESSELS CLAMPS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L07080199",
          "display" : "VASCULAR SURGERY CLAMPS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L070802",
        "display" : "VASCULAR DILATORS, REUSABLE"
      },
      {
        "code" : "L070803",
        "display" : "VASCULAR SPATULAS, REUSABLE"
      },
      {
        "code" : "L070804",
        "display" : "VENOUS STRIPPERS, REUSABLE"
      },
      {
        "code" : "L070805",
        "display" : "VASCULAR TUNNELLERS, REUSABLE"
      },
      {
        "code" : "L070806",
        "display" : "CARDIOVASCULAR PROSTHETICS INSTRUMENTS, REUSABLE",
        "concept" : [{
          "code" : "L07080601",
          "display" : "VASCULAR PROSTHETICS FORCEPS, REUSABLE",
          "concept" : [{
            "code" : "L0708060101",
            "display" : "FORCEPS FOR THE APPLICATION OF VASCULAR PROSTHESES, REUSABLE"
          },
          {
            "code" : "L0708060199",
            "display" : "VASCULAR PROSTHETICS FORCEPS, REUSABLE - OTHER"
          }]
        },
        {
          "code" : "L07080699",
          "display" : "CARDIOVASCULAR PROSTHETICS INSTRUMENTS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L070807",
        "display" : "VASCULAR PERFORATORS, REUSABLE"
      },
      {
        "code" : "L070808",
        "display" : "VASCULAR SURGERY MANIPULATORS, REUSABLE",
        "concept" : [{
          "code" : "L07080801",
          "display" : "VASCULAR DEPRESSORS, REUSABLE"
        },
        {
          "code" : "L07080899",
          "display" : "VASCULAR SURGERY MANIPULATORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L070809",
        "display" : "ENDOARTERIECTOMY INSTRUMENTS, REUSABLE"
      },
      {
        "code" : "L070810",
        "display" : "VASCULAR SURGERY INSTRUMENT KITS, REUSABLE"
      },
      {
        "code" : "L070899",
        "display" : "VASCULAR SURGERY INSTRUMENTS, REUSABLE - OTHER"
      }]
    }]
  },
  {
    "code" : "L08",
    "display" : "THORACIC SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L0801",
      "display" : "COSTOTOMES, REUSABLE"
    },
    {
      "code" : "L0804",
      "display" : "STERNOTOMY SURGICAL INSTRUMENTS, REUSABLE"
    },
    {
      "code" : "L0805",
      "display" : "THORACIC SURGERY FORCEPS, REUSABLE",
      "concept" : [{
        "code" : "L080501",
        "display" : "BRONCHUS CLAMPS, REUSABLE"
      },
      {
        "code" : "L080502",
        "display" : "PULMONARY CLAMPS, REUSABLE",
        "concept" : [{
          "code" : "L08050201",
          "display" : "PULMONARY TISSUE GRIPPERS, REUSABLE"
        },
        {
          "code" : "L08050299",
          "display" : "PULMONARY CLAMPS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L080599",
        "display" : "THORACIC SURGERY CLAMPS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0806",
      "display" : "THORACIC SURGERY DILATORS AND SPREADERS, REUSABLE",
      "concept" : [{
        "code" : "L080601",
        "display" : "THORACIC SURGERY DILATORS, REUSABLE",
        "concept" : [{
          "code" : "L08060101",
          "display" : "PULMONARY DILATORS, REUSABLE"
        },
        {
          "code" : "L08060199",
          "display" : "THORACIC SURGERY DILATORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L080602",
        "display" : "THORACIC SURGERY SPREADERS, REUSABLE",
        "concept" : [{
          "code" : "L08060201",
          "display" : "COSTAL AND STERNAL RETRACTORS, REUSABLE"
        },
        {
          "code" : "L08060299",
          "display" : "THORACIC SURGERY SPREADERS, REUSABLE - OTHER"
        }]
      }]
    },
    {
      "code" : "L0807",
      "display" : "THORACIC SURGERY SPATULAS, REUSABLE"
    },
    {
      "code" : "L0808",
      "display" : "BRONCHOSCOPIC SURGERY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L080801",
        "display" : "BRONCHOSCOPIC SURGERY DISSECTORS, REUSABLE"
      },
      {
        "code" : "L080802",
        "display" : "BRONCHOSCOPIC SURGERY SCISSORS, REUSABLE"
      },
      {
        "code" : "L080803",
        "display" : "BRONCHOSCOPIC SURGERY CLAMPS, REUSABLE"
      },
      {
        "code" : "L080804",
        "display" : "BRONCHOSCOPIC SURGERY CURETTES, REUSABLE"
      },
      {
        "code" : "L080805",
        "display" : "BRONCHOSCOPIC SURGERY CANNULAS, REUSABLE"
      },
      {
        "code" : "L080806",
        "display" : "BRONCHOSCOPY ADAPTERS AND CONNECTORS, REUSABLE"
      },
      {
        "code" : "L080899",
        "display" : "BRONCHOSCOPIC SURGERY INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0809",
      "display" : "THORACIC SURGERY INSTRUMENT KITS, REUSABLE"
    },
    {
      "code" : "L0899",
      "display" : "THORACIC SURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L09",
    "display" : "ORTHOPAEDIC AND TRAUMATOLOGICAL SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L0901",
      "display" : "ORTHOPAEDIC SURGERY SPOONS AND CURETTES, REUSABLE"
    },
    {
      "code" : "L0902",
      "display" : "ORTHOPAEDIC SURGERY LEVERS, REUSABLE"
    },
    {
      "code" : "L0903",
      "display" : "ORTHOPAEDIC SURGERY HAMMERS, REUSABLE"
    },
    {
      "code" : "L0904",
      "display" : "OSTEOTOMES AND SCALPELS, REUSABLE",
      "concept" : [{
        "code" : "L090401",
        "display" : "ORTHOPAEDIC SURGERY OSTEOTOMES, REUSABLE"
      },
      {
        "code" : "L090402",
        "display" : "ORTHOPAEDIC SURGERY SCALPELS, REUSABLE"
      },
      {
        "code" : "L090403",
        "display" : "ORTHOPAEDIC SURGERY GOUGES, REUSABLE"
      },
      {
        "code" : "L090404",
        "display" : "OSTEOTOMES AND SCALPELS BLADES, REUSABLE"
      }]
    },
    {
      "code" : "L0908",
      "display" : "ORTHOPAEDIC AND TRAUMATOLOGICAL TRACTION INSTRUMENTS, REUSABLE"
    },
    {
      "code" : "L0909",
      "display" : "ORTHOPAEDIC SURGERY CUTTING INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L090901",
        "display" : "BONE CUTTERS, REUSABLE"
      },
      {
        "code" : "L090902",
        "display" : "ORTHOPAEDIC SURGERY TREPHINES, REUSABLE"
      },
      {
        "code" : "L090903",
        "display" : "ORTHOPAEDIC SURGERY SCALPELS AND KNIVES, REUSABLE"
      },
      {
        "code" : "L090999",
        "display" : "ORTHOPAEDIC SURGERY CUTTING INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0910",
      "display" : "OSTEOSYNTHESIS INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L091001",
        "display" : "INSTRUMENTS FOR INSERTION AND EXTRACTION OF MATERIALS FOR OSTEOSYNTHESIS, REUSABLE"
      },
      {
        "code" : "L091002",
        "display" : "INSTRUMENTS FOR PROCESSING MATERIALS FOR OSTEOSYNTHESIS, REUSABLE"
      },
      {
        "code" : "L091099",
        "display" : "OSTEOSYNTHESIS INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0911",
      "display" : "ORTHOPAEDIC PROSTHETICS INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L091101",
        "display" : "ORTHOPAEDIC PROSTHESES AND TRAUMATOLOGICAL IMPLANTS EXTRACTORS, REUSABLE"
      },
      {
        "code" : "L091102",
        "display" : "ORTHOPAEDIC PROSTHESES REAMERS AND BURS, REUSABLE"
      },
      {
        "code" : "L091103",
        "display" : "ORTHOPAEDIC PROSTHESES FORCEPS, REUSABLE"
      },
      {
        "code" : "L091104",
        "display" : "ORTHOPAEDIC PROSTHESES POSITIONERS, REUSABLE"
      },
      {
        "code" : "L091105",
        "display" : "CEMENTATION INSTRUMENTS, REUSABLE"
      },
      {
        "code" : "L091106",
        "display" : "INSTRUMENTS FOR THE PREPARATION OF TISSUE IMPLANTS IN ORTHOPAEDIC AND TRAUMATOLOGICAL SURGERY, REUSABLE"
      },
      {
        "code" : "L091199",
        "display" : "ORTHOPAEDIC PROSTHETICS INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0912",
      "display" : "ORTHOPAEDIC RASPS AND FILES, REUSABLE",
      "concept" : [{
        "code" : "L091201",
        "display" : "ORTHOPAEDIC SURGERY RASPS, REUSABLE"
      },
      {
        "code" : "L091202",
        "display" : "ORTHOPAEDIC SURGERY FILES, REUSABLE"
      }]
    },
    {
      "code" : "L0913",
      "display" : "ORTHOPAEDIC SURGERY FORCEPS, REUSABLE",
      "concept" : [{
        "code" : "L091301",
        "display" : "BONE GRASPS, REUSABLE"
      },
      {
        "code" : "L091302",
        "display" : "BONE RONGEURS, REUSABLE"
      },
      {
        "code" : "L091303",
        "display" : "BONE REDUCTION FORCEPS, REUSABLE"
      },
      {
        "code" : "L091304",
        "display" : "SEQUESTRIAL PLIERS, REUSABLE"
      },
      {
        "code" : "L091305",
        "display" : "FORCEPS FOR TENDONS AND LIGAMENTS, REUSABLE"
      },
      {
        "code" : "L091306",
        "display" : "CARTILAGE FORCEPS, REUSABLE"
      },
      {
        "code" : "L091307",
        "display" : "ORTHOPAEDIC SURGERY RONGEURS, REUSABLE"
      },
      {
        "code" : "L091399",
        "display" : "ORTHOPAEDIC SURGERY FORCEPS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L0914",
      "display" : "SCOLLAPERIOSTIUM AND PERIOSTEOTOMES, REUSABLE"
    },
    {
      "code" : "L0915",
      "display" : "SPREADERS AND RETRACTORS FOR ORTHOPAEDIC SURGERY, REUSABLE"
    },
    {
      "code" : "L0916",
      "display" : "ORTHOPAEDIC SURGERY BURS AND TIPS, REUSABLE"
    },
    {
      "code" : "L0917",
      "display" : "ORTHOPAEDIC SPATULAS, REUSABLE"
    },
    {
      "code" : "L0918",
      "display" : "ORTHOPAEDIC TUNNELISERS, REUSABLE"
    },
    {
      "code" : "L0919",
      "display" : "ORTHOPAEDIC AND TRAUMATOLOGICAL SURGERY INSTRUMENT KITS, REUSABLE"
    },
    {
      "code" : "L0920",
      "display" : "ORTHOPAEDIC SURGERY DISTRACTORS, REUSABLE"
    },
    {
      "code" : "L0921",
      "display" : "NON-IMPLANTABLE ORTHOPAEDIC DEVICES EXTRACTORS, REUSABLE"
    },
    {
      "code" : "L0922",
      "display" : "ORTHOPAEDIC SURGERY GUIDES, REUSABLE"
    },
    {
      "code" : "L0923",
      "display" : "ORTHOPAEDICS SURGICAL MEASURERS, REUSABLE"
    },
    {
      "code" : "L0924",
      "display" : "TENOTOMES, REUSABLE"
    },
    {
      "code" : "L0925",
      "display" : "ORTHOPAEDIC SURGERY DILATORS, REUSABLE"
    },
    {
      "code" : "L0926",
      "display" : "ORTHOPAEDIC SURGERY DISSECTORS, REUSABLE"
    },
    {
      "code" : "L0927",
      "display" : "ORTHOPAEDIC SURGERY MANUAL PERFORATORS, REUSABLE"
    },
    {
      "code" : "L0980",
      "display" : "ORTHOPAEDIC AND TRAUMATOLOGICAL SURGERY INSTRUMENTS, REUSABLE - ACCESSORIES",
      "concept" : [{
        "code" : "L098001",
        "display" : "ORTHOPAEDIC AND TRAUMATOLOGICAL SURGERY MANDRELS, REUSABLE"
      },
      {
        "code" : "L098002",
        "display" : "ORTHOPAEDIC INSTRUMENTS KEYS, REUSABLE"
      },
      {
        "code" : "L098003",
        "display" : "ORTHOPAEDIC AND TRAUMATOLOGICAL SURGERY TAPS, REUSABLE"
      },
      {
        "code" : "L098099",
        "display" : "ORTHOPAEDIC AND TRAUMATOLOGICAL SURGERY INSTRUMENTS, REUSABLE - OTHER ACCESSORIES"
      }]
    },
    {
      "code" : "L0999",
      "display" : "ORTHOPAEDIC AND TRAUMATOLOGICAL SURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L10",
    "display" : "MICROSURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1001",
      "display" : "MICROSURGERY APPROXIMATORS, REUSABLE"
    },
    {
      "code" : "L1003",
      "display" : "MICROSURGERY FORCEPS, REUSABLE"
    },
    {
      "code" : "L1004",
      "display" : "MICROSURGERY NEEDLE HOLDERS, REUSABLE"
    },
    {
      "code" : "L1005",
      "display" : "MICROSURGERY INSTRUMENT KITS, REUSABLE"
    },
    {
      "code" : "L1099",
      "display" : "MICROSURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L11",
    "display" : "NEUROSURGERY AND SPINAL SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1102",
      "display" : "NEUROSURGERY SPATULAS AND DISSECTORS, REUSABLE"
    },
    {
      "code" : "L1103",
      "display" : "CERVICAL TRACTION BRACKETS, REUSABLE"
    },
    {
      "code" : "L1104",
      "display" : "BITS FOR NEUROSURGERY DRILLS, REUSABLE"
    },
    {
      "code" : "L1105",
      "display" : "NEUROSURGERY SPREADERS AND RETRACTORS, REUSABLE",
      "concept" : [{
        "code" : "L110501",
        "display" : "VERTEBRAL SURGERY SPREADERS AND RETRACTORS, REUSABLE",
        "concept" : [{
          "code" : "L11050101",
          "display" : "LAMINECTOMY SPREADERS AND RETRACTORS, REUSABLE"
        },
        {
          "code" : "L11050199",
          "display" : "VERTEBRAL SURGERY SPREADERS AND RETRACTORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L110502",
        "display" : "NERVES AND VESSELS HOOK RETRACTORS, REUSABLE"
      },
      {
        "code" : "L110503",
        "display" : "CRANIAL SURGERY SPREADERS AND RETRACTORS, REUSABLE",
        "concept" : [{
          "code" : "L11050301",
          "display" : "CEREBRAL SPREADERS AND RETRACTORS, REUSABLE"
        },
        {
          "code" : "L11050399",
          "display" : "CRANIAL SURGERY SPREADERS AND RETRACTORS, REUSABLE- OTHER"
        }]
      },
      {
        "code" : "L110599",
        "display" : "NEUROSURGERY SPREADERS AND RETRACTORS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1106",
      "display" : "NEUROSURGERY FORCEPS, REUSABLE",
      "concept" : [{
        "code" : "L110601",
        "display" : "DISC HERNIA FORCEPS, REUSABLE"
      },
      {
        "code" : "L110602",
        "display" : "NEUROSURGERY GRIPPERS, REUSABLE"
      },
      {
        "code" : "L110603",
        "display" : "CRANIAL CLIPS, REUSABLE",
        "concept" : [{
          "code" : "L11060301",
          "display" : "SCALP CLIPS, REUSABLE"
        },
        {
          "code" : "L11060399",
          "display" : "CRANIAL CLIPS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L110604",
        "display" : "NEUROSURGERY RONGEURS, REUSABLE"
      },
      {
        "code" : "L110699",
        "display" : "NEUROSURGERY FORCEPS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1107",
      "display" : "NEUROSURGERY SCALPELS AND KNIVES, REUSABLE",
      "concept" : [{
        "code" : "L110701",
        "display" : "CEREBRAL AND MENINGEAL SURGERY SCALPELS AND KNIVES, REUSABLE",
        "concept" : [{
          "code" : "L11070101",
          "display" : "LEUCOTOMES, REUSABLE"
        },
        {
          "code" : "L11070199",
          "display" : "CEREBRAL AND MENINGEAL SURGERY SCALPELS AND KNIVES, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L110702",
        "display" : "CRANIAL TREPHINES, REUSABLE"
      },
      {
        "code" : "L110799",
        "display" : "NEUROSURGERY SCALPELS AND KNIVES, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1108",
      "display" : "NEUROSURGERY LEVERS, REUSABLE"
    },
    {
      "code" : "L1109",
      "display" : "NEUROSURGERY AND SPINAL SURGERY INSTRUMENT KITS, REUSABLE"
    },
    {
      "code" : "L1110",
      "display" : "NEUROSURGERY OBTURATORS, REUSABLE"
    },
    {
      "code" : "L1111",
      "display" : "NEUROSURGERY MANIPULATORS, REUSABLE"
    },
    {
      "code" : "L1112",
      "display" : "NEUROSURGERY SUCTION CANNULES, REUSABLE"
    },
    {
      "code" : "L1113",
      "display" : "NEUROSURGERY BURS AND TIPS, REUSABLE"
    },
    {
      "code" : "L1199",
      "display" : "NEUROSURGERY INSTRUMENTS, REUSABLE- OTHER"
    }]
  },
  {
    "code" : "L12",
    "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1201",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY DISSECTORS, REUSABLE"
    },
    {
      "code" : "L1202",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY SCISSORS, REUSABLE"
    },
    {
      "code" : "L1203",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY MANIPULATORS, REUSABLE"
    },
    {
      "code" : "L1204",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY FORCEPS REUSABLE"
    },
    {
      "code" : "L1205",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY NEEDLE HOLDERS, REUSABLE"
    },
    {
      "code" : "L1206",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY SPREADERS AND RETRACTORS, REUSABLE"
    },
    {
      "code" : "L1207",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY CANNULAS, REUSABLE"
    },
    {
      "code" : "L1208",
      "display" : "SUTURING ENDOSCOPIC TISSUE APPROXIMATORS, REUSABLE"
    },
    {
      "code" : "L1209",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY SCALPELS, REUSABLE"
    },
    {
      "code" : "L1210",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY HOOKS, REUSABLE"
    },
    {
      "code" : "L1211",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY SPATULAS, REUSABLE"
    },
    {
      "code" : "L1212",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY GUIDES, REUSABLE"
    },
    {
      "code" : "L1213",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY HANDPIECES, REUSABLE"
    },
    {
      "code" : "L1214",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY DILATORS, REUSABLE"
    },
    {
      "code" : "L1215",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY NEEDLES, REUSABLE"
    },
    {
      "code" : "L1216",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY PALPATORS, REUSABLE"
    },
    {
      "code" : "L1217",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY INSTRUMENT KITS, REUSABLE"
    },
    {
      "code" : "L1218",
      "display" : "LAPAROSCOPIC AND THORACOSCOPY ADAPTERS AND CONNECTORS, REUSABLE"
    },
    {
      "code" : "L1280",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC SURGERY INSTRUMENTS, REUSABLE - ACCESSORIES"
    },
    {
      "code" : "L1299",
      "display" : "LAPAROSCOPIC AND THORACOSCOPIC INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L13",
    "display" : "ROBOTIC SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1301",
      "display" : "ROBOTIC SURGERY SCALPELS, REUSABLE"
    },
    {
      "code" : "L1302",
      "display" : "ROBOTIC SURGERY CLIPS, REUSABLE"
    },
    {
      "code" : "L1303",
      "display" : "ROBOTIC SURGERY SCISSORS, REUSABLE"
    },
    {
      "code" : "L1304",
      "display" : "ROBOTIC SURGERY FORCEPS, REUSABLE"
    },
    {
      "code" : "L1305",
      "display" : "ROBOTIC SURGERY SPREADERS AND RETRACTORS, REUSABLE"
    },
    {
      "code" : "L1306",
      "display" : "ULTRASONIC GENERATOR ROBOTIC SURGERY INSTRUMENTS, REUSABLE"
    },
    {
      "code" : "L1307",
      "display" : "ROBOTIC SURGERY INSTRUMENT KITS, REUSABLE"
    },
    {
      "code" : "L1399",
      "display" : "ROBOTIC SURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L14",
    "display" : "ENT INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1401",
      "display" : "PHARYNX SURGERY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L140101",
        "display" : "RHINOPHARYNGAL SURGERY INSTRUMENTS, REUSABLE",
        "concept" : [{
          "code" : "L14010101",
          "display" : "ADENOTOMES, REUSABLE"
        },
        {
          "code" : "L14010102",
          "display" : "RHINOPHARYNGAL SURGERY SCALPELS AND KNIVES, REUSABLE"
        },
        {
          "code" : "L14010103",
          "display" : "RHINOPHARYNGAL SURGERY CURETTES, REUSABLE"
        },
        {
          "code" : "L14010199",
          "display" : "RHINOPHARYNGAL SURGERY INSTRUMENTS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L140102",
        "display" : "OROPHARYNX SURGERY INSTRUMENTS, REUSABLE",
        "concept" : [{
          "code" : "L14010201",
          "display" : "TONSILLARY PLIERS, REUSABLE"
        },
        {
          "code" : "L14010202",
          "display" : "TONSILLARY HOOKS, REUSABLE"
        },
        {
          "code" : "L14010203",
          "display" : "OROPHARYNGAL SURGERY TONSILOTOMES AND SCALPELS, REUSABLE"
        },
        {
          "code" : "L14010204",
          "display" : "OROPHARYNX SURGERY PLIERS NOT INCLUDED IN OTHER CLASSES, REUSABLE"
        },
        {
          "code" : "L14010205",
          "display" : "OROPHARYNGAL SURGERY DEPRESSORS, REUSABLE"
        },
        {
          "code" : "L14010206",
          "display" : "OROPHARYNGAL SURGERY CANNULAS, REUSABLE"
        },
        {
          "code" : "L14010299",
          "display" : "OROPHARYNGAL SURGERY INSTRUMENTS, REUSABLE - OTHER"
        }]
      }]
    },
    {
      "code" : "L1402",
      "display" : "NASAL AND PARANASAL CAVITY SURGERY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L140201",
        "display" : "NASAL DILATORS, REUSABLE"
      },
      {
        "code" : "L140202",
        "display" : "NASAL AND PARANASAL CAVITY SURGERY PLIERS, REUSABLE"
      },
      {
        "code" : "L140203",
        "display" : "NASAL HOOKS, REUSABLE"
      },
      {
        "code" : "L140204",
        "display" : "NASAL SURGERY RASPS AND FILES, REUSABLE"
      },
      {
        "code" : "L140205",
        "display" : "NASAL AND PARANASAL CAVITY SURGERY RASPS AND KNIVES, REUSABLE"
      },
      {
        "code" : "L140206",
        "display" : "NASAL AND PARANASAL CAVITY SURGERY CANNULAS, REUSABLE"
      },
      {
        "code" : "L140299",
        "display" : "NASAL AND PARANASAL CAVITY SURGERY INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1403",
      "display" : "LARYNX SURGERY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L140301",
        "display" : "LARYNX SURGERY SCALPELS, REUSABLE"
      },
      {
        "code" : "L140399",
        "display" : "LARYNX SURGERY INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1404",
      "display" : "TRACHEA SURGERY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L140401",
        "display" : "TRACHEAL DILATORS, REUSABLE"
      },
      {
        "code" : "L140402",
        "display" : "TRACHEOTOMY INSTRUMENTS, REUSABLE",
        "concept" : [{
          "code" : "L14040201",
          "display" : "TRACHEOTOMY INSTRUMENT KITS, REUSABLE"
        },
        {
          "code" : "L14040202",
          "display" : "CRICOTHYROTOMY INSTRUMENT KITS, REUSABLE"
        },
        {
          "code" : "L14040203",
          "display" : "TRACHEOTOMES, REUSABLE"
        },
        {
          "code" : "L14040204",
          "display" : "CRICOTHYROTOMES, REUSABLE"
        },
        {
          "code" : "L14040299",
          "display" : "TRACHEOTOMY INSTRUMENTS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L140499",
        "display" : "TRACHEA SURGERY INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1405",
      "display" : "EAR SURGERY INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L140501",
        "display" : "MIDDLE EAR SURGERY INSTRUMENTS, REUSABLE",
        "concept" : [{
          "code" : "L14050101",
          "display" : "BONE SURGERY HOOKS, REUSABLE"
        },
        {
          "code" : "L14050102",
          "display" : "OSSICULAR SURGERY RASPS AND FILES, REUSABLE"
        },
        {
          "code" : "L14050103",
          "display" : "BONE SURGERY SPATULAS, REUSABLE"
        },
        {
          "code" : "L14050199",
          "display" : "MIDDLE EAR SURGERY INSTRUMENTS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L140502",
        "display" : "EAR SURGERY PLIERS, REUSABLE"
      },
      {
        "code" : "L140503",
        "display" : "EAR SURGERY SCALPELS AND KNIVES, REUSABLE"
      },
      {
        "code" : "L140599",
        "display" : "EAR SURGERY INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1406",
      "display" : "ENT OSTEOTOMES AND SCALPELS, REUSABLE",
      "concept" : [{
        "code" : "L140601",
        "display" : "ENT OSTEOTOMES, REUSABLE"
      },
      {
        "code" : "L140602",
        "display" : "ENT CHISELS, REUSABLE"
      }]
    },
    {
      "code" : "L1490",
      "display" : "ENT INSTRUMENTS, REUSABLE - VARIOUS",
      "concept" : [{
        "code" : "L149001",
        "display" : "ENT CURETTES, REUSABLE"
      },
      {
        "code" : "L149002",
        "display" : "ENT LEVERS, REUSABLE"
      },
      {
        "code" : "L149003",
        "display" : "ENT RETRACTORS, REUSABLE"
      },
      {
        "code" : "L149004",
        "display" : "ENT SPECULUMS, REUSABLE"
      },
      {
        "code" : "L149005",
        "display" : "ENT PROBES, REUSABLE"
      },
      {
        "code" : "L149006",
        "display" : "ENT PERFORATORS, REUSABLE"
      },
      {
        "code" : "L149007",
        "display" : "ENT SPOONS, REUSABLE"
      },
      {
        "code" : "L149008",
        "display" : "ENT ENUCLEATION INSTRUMENTS, REUSABLE"
      },
      {
        "code" : "L149009",
        "display" : "ENT SURGERY BURS, REUSABLE"
      },
      {
        "code" : "L149010",
        "display" : "ENT SURGERY MANIPULATORS, REUSABLE"
      },
      {
        "code" : "L149011",
        "display" : "ENT SURGERY DISSECTORS, REUSABLE"
      },
      {
        "code" : "L149012",
        "display" : "ENT SURGERY PUNCHES, REUSABLE"
      },
      {
        "code" : "L149013",
        "display" : "ENT SURGERY INSTRUMENT KITS NOT INCLUDED IN OTHER CLASSES, REUSABLE"
      },
      {
        "code" : "L149099",
        "display" : "ENT INSTRUMENTS, REUSABLE - OTHER"
      }]
    }]
  },
  {
    "code" : "L15",
    "display" : "ODONTOSTOMATOLOGY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1501",
      "display" : "ODONTOSTOMATOLOGY OSTEOTOMES AND SCALPELS, REUSABLE",
      "concept" : [{
        "code" : "L150101",
        "display" : "ODONTOSTOMATOLOGY OSTEOTOMES, REUSABLE"
      },
      {
        "code" : "L150102",
        "display" : "ODONTOSTOMATOLOGY CHISELS, REUSABLE"
      },
      {
        "code" : "L150103",
        "display" : "DENTAL OSTEOTOME BLADES, REUSABLE"
      }]
    },
    {
      "code" : "L1502",
      "display" : "ODONTOSTOMATOLOGY SPREADERS AND RETRACTORS, REUSABLE",
      "concept" : [{
        "code" : "L150201",
        "display" : "DENTAL RETRACTORS, REUSABLE"
      },
      {
        "code" : "L150202",
        "display" : "BUCCAL SPREADERS, REUSABLE"
      },
      {
        "code" : "L150299",
        "display" : "ODONTOSTOMATOLOGY SPREADERS AND RETRACTORS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1503",
      "display" : "ODONTOSTOMATOLOGY FORCEPS, REUSABLE",
      "concept" : [{
        "code" : "L150301",
        "display" : "DENTAL EXTRACTION TOOTH FORCEPS, REUSABLE"
      },
      {
        "code" : "L150302",
        "display" : "DENTAL RONGEURS, REUSABLE"
      },
      {
        "code" : "L150399",
        "display" : "ODONTOSTOMATOLOGY FORCEPS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1504",
      "display" : "ODONTOSTOMATOLOGY MODELERS, REUSABLE"
    },
    {
      "code" : "L1505",
      "display" : "ODONTOSTOMATOLOGY LEVERS, REUSABLE"
    },
    {
      "code" : "L1506",
      "display" : "ODONTOSTOMATOLOGY OBTURATORS, REUSABLE"
    },
    {
      "code" : "L1507",
      "display" : "ORTHODONTIC INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L150701",
        "display" : "ORTHODONTIC LIGATURE TOOLS, REUSABLE"
      },
      {
        "code" : "L150702",
        "display" : "ORTHODONTIC PLIERS, REUSABLE"
      },
      {
        "code" : "L150703",
        "display" : "ORTHODONTIC CUTTERS, REUSABLE"
      },
      {
        "code" : "L150704",
        "display" : "ORTHODONTIC BAND PUSHERS, REUSABLE"
      },
      {
        "code" : "L150705",
        "display" : "ORTHODONTIC MEASUREMENT INSTRUMENTS, REUSABLE"
      },
      {
        "code" : "L150799",
        "display" : "ORTHODONTIC INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1508",
      "display" : "REAMERS, REUSABLE"
    },
    {
      "code" : "L1590",
      "display" : "ODONTOSTOMATOLOGY INSTRUMENTS, REUSABLE - VARIOUS",
      "concept" : [{
        "code" : "L159001",
        "display" : "DENTAL AND PERIODONTAL CURETTES, REUSABLE"
      },
      {
        "code" : "L159002",
        "display" : "DENTAL EXCAVATORS, REUSABLE"
      },
      {
        "code" : "L159003",
        "display" : "DENTAL AND PERIODONTAL PROBES AND EXPLORERS, REUSABLE"
      },
      {
        "code" : "L159004",
        "display" : "ENDODONTIC RASPS AND FILES, REUSABLE"
      },
      {
        "code" : "L159005",
        "display" : "SYNDESMOTOMES, REUSABLE"
      },
      {
        "code" : "L159006",
        "display" : "DENTAL MATERIAL PROCESSING TOOLS, REUSABLE",
        "concept" : [{
          "code" : "L15900601",
          "display" : "DENTAL MATERIAL PROCESSING MILLS, REUSABLE"
        },
        {
          "code" : "L15900602",
          "display" : "DENTAL MATERIAL PROCESSING SHARP INSTRUMENTS, REUSABLE"
        },
        {
          "code" : "L15900699",
          "display" : "DENTAL MATERIAL PROCESSING INSTRUMENTS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L159007",
        "display" : "ODONTOSTOMATOLOGY BURS, REUSABLE"
      },
      {
        "code" : "L159008",
        "display" : "DENTAL EQUIPMENT TIPS NOT INCLUDED IN OTHER CLASSES, REUSABLE",
        "concept" : [{
          "code" : "L15900801",
          "display" : "PNEUMATIC SYSTEM TIPS FOR DENTAL USE, REUSABLE"
        },
        {
          "code" : "L15900899",
          "display" : "DENTAL EQUIPMENT TIPS NOT INCLUDED IN OTHER CLASSES, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L159009",
        "display" : "ODONTOSTOMATOLOGY SCALERS, REUSABLE"
      },
      {
        "code" : "L159010",
        "display" : "STOMATOLOGICAL SURGERY DILATORS, REUSABLE"
      },
      {
        "code" : "L159011",
        "display" : "POSITIONING INSTRUMENTS FOR DENTAL DEVICES, REUSABLE",
        "concept" : [{
          "code" : "L15901101",
          "display" : "POSITIONING INSTRUMENTS FOR DENTAL MATRICES, REUSABLE"
        },
        {
          "code" : "L15901102",
          "display" : "DAM POSITIONING INSTRUMENTS, REUSABLE"
        },
        {
          "code" : "L15901199",
          "display" : "POSITIONING INSTRUMENTS FOR DENTAL DEVICES, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L159012",
        "display" : "ENDODONTIC SPREADERS AND PLUGGERS, REUSABLE"
      },
      {
        "code" : "L159013",
        "display" : "DENTAL SPATULAS, REUSABLE"
      },
      {
        "code" : "L159014",
        "display" : "ODONTOSTOMATOLOGY BURNISHERS, REUSABLE"
      },
      {
        "code" : "L159015",
        "display" : "HONEYCOMB SPOONS, REUSABLE"
      },
      {
        "code" : "L159016",
        "display" : "DENTAL SURGERY INSTRUMENT KITS, REUSABLE"
      },
      {
        "code" : "L159017",
        "display" : "DENTAL RESTORATION CARVERS, REUSABLE"
      },
      {
        "code" : "L159018",
        "display" : "ODONTOSTOMATOLOGICAL SURGERY SCALPELS, REUSABLE"
      },
      {
        "code" : "L159019",
        "display" : "DENTAL FINISHING RASPS AND FILES, REUSABLE"
      },
      {
        "code" : "L159099",
        "display" : "ODONTOSTOMATOLOGY INSTRUMENTS, REUSABLE - OTHER"
      }]
    }]
  },
  {
    "code" : "L16",
    "display" : "DIAGNOSTIC INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1601",
      "display" : "DIAGNOSTIC HAMMERS, REUSABLE",
      "concept" : [{
        "code" : "L160101",
        "display" : "NEUROLOGICAL HAMMERS, REUSABLE"
      },
      {
        "code" : "L160199",
        "display" : "DIAGNOSTIC HAMMERS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1602",
      "display" : "DIAGNOSTIC USE MIRRORS, REUSABLE",
      "concept" : [{
        "code" : "L160201",
        "display" : "DENTAL MIRRORS AND HANDLES, REUSABLE"
      },
      {
        "code" : "L160202",
        "display" : "LARYNGEAL MIRRORS AND HANDLES, REUSABLE"
      },
      {
        "code" : "L160299",
        "display" : "DIAGNOSTIC USE MIRRORS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1699",
      "display" : "DIAGNOSTIC INSTRUMENTS, REUSABLE- OTHER"
    }]
  },
  {
    "code" : "L17",
    "display" : "OPHTHALMOLOGY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1701",
      "display" : "OPHTHALMOLOGY DILATORS AND RETRACTORS, REUSABLE",
      "concept" : [{
        "code" : "L170101",
        "display" : "OCULAR DILATORS, REUSABLE",
        "concept" : [{
          "code" : "L17010101",
          "display" : "LACRIMAL DUCTS DILATORS, REUSABLE"
        },
        {
          "code" : "L17010199",
          "display" : "OCULAR DILATORS, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L170102",
        "display" : "OCULAR AND ENDOCULAR RETRACTORS, REUSABLE"
      }]
    },
    {
      "code" : "L1702",
      "display" : "OPHTHALMOLOGY FORCEPS, REUSABLE",
      "concept" : [{
        "code" : "L170201",
        "display" : "OPHTHALMIC GRASPING FORCEPS, REUSABLE"
      },
      {
        "code" : "L170202",
        "display" : "ENDOCULAR IMPLANTS FORCEPS, REUSABLE"
      },
      {
        "code" : "L170203",
        "display" : "FORCEPS FOR HANDLING DEVICES FOR OPHTHALMIC USE, REUSABLE"
      },
      {
        "code" : "L170299",
        "display" : "OPHTHALMOLOGY FORCEPS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1703",
      "display" : "OPHTHALMOLOGY CURETTES, REUSABLE"
    },
    {
      "code" : "L1704",
      "display" : "OPHTHALMOLOGY SHARP INSTRUMENTS (EXCLUDING SCISSORS), REUSABLE",
      "concept" : [{
        "code" : "L170401",
        "display" : "CORNEAL TREPHINES, REUSABLE"
      },
      {
        "code" : "L170402",
        "display" : "KERATOMES AND BLADES, REUSABLE"
      },
      {
        "code" : "L170499",
        "display" : "OPHTHALMOLOGY SHARP INSTRUMENTS (EXCLUDING SCISSORS), REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L1705",
      "display" : "OPHTHALMOLOGY PROBES, REUSABLE"
    },
    {
      "code" : "L1706",
      "display" : "OPHTHALMOLOGY SPATULAS, REUSABLE"
    },
    {
      "code" : "L1707",
      "display" : "OPHTHALMOLOGY SPOONS, REUSABLE"
    },
    {
      "code" : "L1708",
      "display" : "OPHTHALMOLOGY ENUCLEATION INSTRUMENTS (EXCLUDING SCISSORS), REUSABLE"
    },
    {
      "code" : "L1709",
      "display" : "OCULAR IMPLANT INSTRUMENTS NOT INCLUDED IN OTHER CLASSES, REUSABLE"
    },
    {
      "code" : "L1710",
      "display" : "EYE SURGERY HANDPIECES, REUSABLE"
    },
    {
      "code" : "L1711",
      "display" : "OPHTHALMOLOGY HOOKS, REUSABLE"
    },
    {
      "code" : "L1712",
      "display" : "SCLEROTOMES, REUSABLE"
    },
    {
      "code" : "L1713",
      "display" : "OCULAR IRRIGATION OR SUCTION CANNULAS, REUSABLE"
    },
    {
      "code" : "L1714",
      "display" : "TRABECULOTOMES, REUSABLE"
    },
    {
      "code" : "L1715",
      "display" : "SCLERAL MARKERS, REUSABLE"
    },
    {
      "code" : "L1790",
      "display" : "OPHTHALMOLOGY INSTRUMENTS, REUSABLE - VARIOUS",
      "concept" : [{
        "code" : "L179001",
        "display" : "OPHTHALMOLOGY SURGICAL GAUGES, REUSABLE"
      },
      {
        "code" : "L179002",
        "display" : "INTRAOPERATIVE KERATOMETERS, REUSABLE"
      },
      {
        "code" : "L179003",
        "display" : "OCULAR ADNEXA INSTRUMENTS NOT INCLUDED IN OTHER CLASSES, REUSABLE",
        "concept" : [{
          "code" : "L17900301",
          "display" : "POSITIONERS AND MODELERS OF LACRIMAL TUBES, REUSABLE"
        },
        {
          "code" : "L17900399",
          "display" : "OCULAR ADNEXA INSTRUMENTS NOT INCLUDED IN OTHER CLASSES, REUSABLE - OTHER"
        }]
      },
      {
        "code" : "L179004",
        "display" : "OCULAR IRRIGATION OR SUCTION HANDPIECES, REUSABLE"
      },
      {
        "code" : "L179005",
        "display" : "OPHTHALMIC SURGERY INSTRUMENT KITS, REUSABLE"
      }]
    },
    {
      "code" : "L1799",
      "display" : "OPHTHALMOLOGY INSTRUMENTS, REUSABLE- OTHER"
    }]
  },
  {
    "code" : "L18",
    "display" : "ELECTROSURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1801",
      "display" : "ELECTROSURGERY DISSECTORS, REUSABLE",
      "concept" : [{
        "code" : "L180101",
        "display" : "OPEN ELECTROSURGERY DISSECTORS, REUSABLE"
      },
      {
        "code" : "L180102",
        "display" : "ENDOSCOPIC ELECTROSURGERY DISSECTORS, REUSABLE"
      }]
    },
    {
      "code" : "L1802",
      "display" : "ELECTROSURGERY SCISSORS, REUSABLE",
      "concept" : [{
        "code" : "L180201",
        "display" : "OPEN ELECTROSURGERY SCISSORS, REUSABLE"
      },
      {
        "code" : "L180202",
        "display" : "ENDOSCOPIC ELECTROSURGERY SCISSORS, REUSABLE"
      }]
    },
    {
      "code" : "L1803",
      "display" : "ELECTROSURGERY HANDPIECES, REUSABLE",
      "concept" : [{
        "code" : "L180301",
        "display" : "OPEN ELECTROSURGERY HANDPIECES, REUSABLE"
      },
      {
        "code" : "L180302",
        "display" : "ENDOSCOPIC ELECTROSURGERY HANDPIECES, REUSABLE"
      }]
    },
    {
      "code" : "L1804",
      "display" : "ELECTROSURGERY FORCEPS, REUSABLE",
      "concept" : [{
        "code" : "L180401",
        "display" : "OPEN ELECTROSURGERY FORCEPS, REUSABLE"
      },
      {
        "code" : "L180402",
        "display" : "ENDOSCOPIC ELECTROSURGERY FORCEPS, REUSABLE"
      }]
    },
    {
      "code" : "L1805",
      "display" : "ELECTROSURGERY MULTIFUNCTIONAL CANNULAS, REUSABLE",
      "concept" : [{
        "code" : "L180501",
        "display" : "OPEN ELECTROSURGERY MULTIFUNCTIONAL CANNULAS, REUSABLE"
      },
      {
        "code" : "L180502",
        "display" : "ENDOSCOPIC ELECTROSURGERY MULTIFUNCTIONAL CANNULAS, REUSABLE"
      }]
    },
    {
      "code" : "L1806",
      "display" : "ELECTROSURGERY ELECTRODES, REUSABLE",
      "concept" : [{
        "code" : "L180601",
        "display" : "OPEN ELECTROSURGERY ELECTRODES, REUSABLE"
      },
      {
        "code" : "L180602",
        "display" : "ENDOSCOPIC ELECTROSURGERY ELECTRODES, REUSABLE"
      }]
    },
    {
      "code" : "L1807",
      "display" : "ELECTROSURGERY PROBES, REUSABLE",
      "concept" : [{
        "code" : "L180701",
        "display" : "OPEN ELECTROSURGERY PROBES, REUSABLE"
      },
      {
        "code" : "L180702",
        "display" : "ENDOSCOPIC ELECTROSURGERY PROBES, REUSABLE"
      }]
    },
    {
      "code" : "L1808",
      "display" : "ELECTROSURGERY MANIPULATORS, REUSABLE",
      "concept" : [{
        "code" : "L180801",
        "display" : "OPEN ELECTROSURGERY MANIPULATORS, REUSABLE"
      },
      {
        "code" : "L180802",
        "display" : "ENDOSCOPIC ELECTROSURGERY MANIPULATORS, REUSABLE"
      }]
    },
    {
      "code" : "L1809",
      "display" : "ELECTROSURGERY NEEDLES, REUSABLE",
      "concept" : [{
        "code" : "L180901",
        "display" : "OPEN ELECTROSURGERY NEEDLES, REUSABLE"
      },
      {
        "code" : "L180902",
        "display" : "ENDOSCOPIC ELECTROSURGERY NEEDLES, REUSABLE"
      }]
    },
    {
      "code" : "L1810",
      "display" : "ELECTROSURGERY PADS (NEUTRAL ELECTRODES) AND CABLES, REUSABLE",
      "concept" : [{
        "code" : "L181001",
        "display" : "ELECTROSURGERY SINGLE PATIENT PADS (NEUTRAL ELECTRODES), REUSABLE"
      },
      {
        "code" : "L181002",
        "display" : "ELECTROSURGERY DUAL PATIENT PADS (NEUTRAL ELECTRODES), REUSABLE"
      },
      {
        "code" : "L181003",
        "display" : "ELECTROSURGERY CONNECTION CABLES, REUSABLE"
      }]
    },
    {
      "code" : "L1890",
      "display" : "ELECTROSURGERY INSTRUMENTS, REUSABLE - VARIOUS",
      "concept" : [{
        "code" : "L189001",
        "display" : "ELECTROSURGICAL DENERVATION PROBES, REUSABLE"
      },
      {
        "code" : "L189002",
        "display" : "ELECTROSURGERY INSTRUMENT KITS, REUSABLE"
      }]
    },
    {
      "code" : "L1899",
      "display" : "ELECTROSURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L19",
    "display" : "ARTHROSCOPIC SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L1901",
      "display" : "ARTHROSCOPIC SURGERY DISSECTORS, REUSABLE"
    },
    {
      "code" : "L1902",
      "display" : "ARTHROSCOPIC SURGERY SCISSORS, REUSABLE"
    },
    {
      "code" : "L1903",
      "display" : "ARTHROSCOPIC SURGERY MANIPULATORS, REUSABLE"
    },
    {
      "code" : "L1904",
      "display" : "ARTHROSCOPIC SURGERY FORCEPS AND PUNCHES, REUSABLE"
    },
    {
      "code" : "L1905",
      "display" : "ARTHROSCOPIC SURGERY NEEDLE HOLDERS, REUSABLE"
    },
    {
      "code" : "L1906",
      "display" : "ARTHROSCOPIC SURGERY SPREADERS AND RETRACTORS, REUSABLE"
    },
    {
      "code" : "L1907",
      "display" : "ARTHROSCOPIC SURGERY CANNULAS, REUSABLE"
    },
    {
      "code" : "L1908",
      "display" : "ARTHROSCOPIC SURGERY INSTRUMENT KITS, REUSABLE"
    },
    {
      "code" : "L1909",
      "display" : "ARTHROSCOPIC SURGERY SCALPELS, MENISCOTOMES AND KNIVES REUSABLE"
    },
    {
      "code" : "L1910",
      "display" : "ARTHROSCOPIC SURGERY HOOKS, REUSABLE"
    },
    {
      "code" : "L1911",
      "display" : "ARTHROSCOPIC SURGERY SPATULAS, REUSABLE"
    },
    {
      "code" : "L1912",
      "display" : "ARTHROSCOPIC SURGERY GUIDES, REUSABLE"
    },
    {
      "code" : "L1913",
      "display" : "ARTHROSCOPIC SURGERY HANDPIECES, REUSABLE"
    },
    {
      "code" : "L1914",
      "display" : "ARTHROSCOPIC SURGERY DILATORS, REUSABLE"
    },
    {
      "code" : "L1915",
      "display" : "ARTHROSCOPIC SURGERY NEEDLES, REUSABLE"
    },
    {
      "code" : "L1916",
      "display" : "ARTHROSCOPIC SURGERY PALPATORS, REUSABLE"
    },
    {
      "code" : "L1917",
      "display" : "ARTHROSCOPY ADAPTERS AND CONNECTORS, REUSABLE"
    },
    {
      "code" : "L1918",
      "display" : "MICROFRACTORS FOR BONE STIMULATION, REUSABLE"
    },
    {
      "code" : "L1919",
      "display" : "ARTHROSCOPIC SURGERY SPOONS AND CURETTES, REUSABLE"
    },
    {
      "code" : "L1920",
      "display" : "ARTHROSCOPIC SURGERY FILES AND RASPS, REUSABLE"
    },
    {
      "code" : "L1921",
      "display" : "ARTHROSCOPIC SURGERY PROBES, REUSABLE"
    },
    {
      "code" : "L1980",
      "display" : "ARTHROSCOPIC SURGERY INSTRUMENTS, REUSABLE - ACCESSORIES"
    },
    {
      "code" : "L1999",
      "display" : "ARTHROSCOPIC SURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L20",
    "display" : "THYROID SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L2001",
      "display" : "THYROID RETRACTORS, REUSABLE"
    },
    {
      "code" : "L2099",
      "display" : "THYROID SURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L21",
    "display" : "CLIP REMOVAL SURGICAL FORCEPS, REUSABLE"
  },
  {
    "code" : "L22",
    "display" : "IMPLANTABLE TISSUES HANDLING GRASPING FORCEPS, REUSABLE"
  },
  {
    "code" : "L23",
    "display" : "SURGICAL TUNNELIZATION FORCEPS, REUSABLE"
  },
  {
    "code" : "L24",
    "display" : "DERMATOLOGICAL SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L2401",
      "display" : "DERMATOLOGICAL SURGERY CURETTES, REUSABLE"
    },
    {
      "code" : "L2402",
      "display" : "DERMATOLOGICAL SURGERY TREPHINES AND PUNCHES, REUSABLE"
    },
    {
      "code" : "L2403",
      "display" : "DERMATOLOGICAL SURGERY SCALPELS AND KNIVES, REUSABLE"
    },
    {
      "code" : "L2499",
      "display" : "DERMATOLOGICAL SURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L25",
    "display" : "PLASTIC SURGERY INSTRUMENTS, REUSABLE",
    "concept" : [{
      "code" : "L2501",
      "display" : "PLASTIC SURGERY OSTEOTOMES, REUSABLE"
    },
    {
      "code" : "L2502",
      "display" : "PLASTIC SURGERY RASPS AND FILES, REUSABLE"
    },
    {
      "code" : "L2503",
      "display" : "LIPOSUCTION INSTRUMENTS, REUSABLE",
      "concept" : [{
        "code" : "L250301",
        "display" : "LIPOSUCTION CANNULAS, REUSABLE"
      },
      {
        "code" : "L250399",
        "display" : "LIPOSUCTION INSTRUMENTS, REUSABLE - OTHER"
      }]
    },
    {
      "code" : "L2599",
      "display" : "PLASTIC SURGERY INSTRUMENTS, REUSABLE - OTHER"
    }]
  },
  {
    "code" : "L26",
    "display" : "SURGICAL SCREWDRIVERS, REUSABLE"
  },
  {
    "code" : "L80",
    "display" : "SURGICAL INSTRUMENTS, REUSABLE - VARIOUS ACCESSORIES"
  },
  {
    "code" : "L99",
    "display" : "SURGICAL INSTRUMENTS, REUSABLE - OTHER"
  },
  {
    "code" : "M",
    "display" : "DEVICES FOR GENERAL AND SPECIALIST DRESSINGS"
  },
  {
    "code" : "M01",
    "display" : "COTTON AND SYNTHETIC WADDING",
    "concept" : [{
      "code" : "M0101",
      "display" : "COTTON WADDING",
      "concept" : [{
        "code" : "M010101",
        "display" : "HYDROPHILIC COTTON"
      },
      {
        "code" : "M010102",
        "display" : "PURE COTTON"
      },
      {
        "code" : "M010103",
        "display" : "COTTON PAD"
      },
      {
        "code" : "M010199",
        "display" : "COTTON WADDING - OTHER"
      }]
    },
    {
      "code" : "M0102",
      "display" : "ORTHOPAEDIC WADDING",
      "concept" : [{
        "code" : "M010201",
        "display" : "ORTHOPAEDICS COTTON WADDING"
      },
      {
        "code" : "M010202",
        "display" : "SYNTHETIC WOOL WADDING",
        "concept" : [{
          "code" : "M01020201",
          "display" : "SYNTHETIC WOOL WADDING RUBBERISED"
        },
        {
          "code" : "M01020202",
          "display" : "SYNTHETIC WOOL WADDING NON-RUBBERISED"
        }]
      },
      {
        "code" : "M010203",
        "display" : "PADDING FELT"
      },
      {
        "code" : "M010299",
        "display" : "ORTHOPAEDIC WADDING - OTHER"
      }]
    },
    {
      "code" : "M0199",
      "display" : "WOOL AND SYNTHETIC COTTON - OTHER"
    }]
  },
  {
    "code" : "M02",
    "display" : "GAUZES",
    "concept" : [{
      "code" : "M0201",
      "display" : "COTTON GAUZES",
      "concept" : [{
        "code" : "M020101",
        "display" : "COTTON GAUZES, CUT",
        "concept" : [{
          "code" : "M02010101",
          "display" : "COTTON GAUZES, CUT, WITHOUT X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0201010101",
            "display" : "COTTON GAUZE, CUT, WITHOUT X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0201010102",
            "display" : "COTTON GAUZES, CUT, WITHOUT X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        },
        {
          "code" : "M02010102",
          "display" : "COTTON GAUZES, CUT, WITH X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0201010201",
            "display" : "COTTON GAUZES, CUT, WITH X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0201010202",
            "display" : "COTTON GAUZES, CUT, WITH X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        }]
      },
      {
        "code" : "M020102",
        "display" : "COTTON GAUZES, FOLDED",
        "concept" : [{
          "code" : "M02010201",
          "display" : "COTTON GAUZES, FOLDED, WITHOUT X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0201020101",
            "display" : "COTTON GAUZES, FOLDED, WITHOUT X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0201020102",
            "display" : "COTTON GAUZES, FOLDED, WITHOUT X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        },
        {
          "code" : "M02010202",
          "display" : "COTTON GAUZES, FOLDED, WITH X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0201020201",
            "display" : "COTTON GAUZES, FOLDED, WITH X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0201020202",
            "display" : "COTTON GAUZES, FOLDED, WITH X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        }]
      },
      {
        "code" : "M020103",
        "display" : "LAPAROTOMY COTTON GAUZES",
        "concept" : [{
          "code" : "M02010301",
          "display" : "LAPAROTOMY COTTON GAUZES, WITHOUT X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0201030101",
            "display" : "LAPAROTOMY COTTON GAUZES, WITHOUT X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0201030102",
            "display" : "LAPAROTOMY COTTON GAUZES, WITHOUT X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        },
        {
          "code" : "M02010302",
          "display" : "LAPAROTOMY COTTON GAUZES, WITH X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0201030201",
            "display" : "LAPAROTOMY COTTON GAUZES, WITH X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0201030202",
            "display" : "LAPAROTOMY COTTON GAUZES, WITH X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        }]
      },
      {
        "code" : "M020104",
        "display" : "STARCHED COTTON GAUZES"
      },
      {
        "code" : "M020105",
        "display" : "COTTON GAUZE PADS",
        "concept" : [{
          "code" : "M02010501",
          "display" : "COTTON GAUZE PADS, WITHOUT X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0201050101",
            "display" : "COTTON GAUZE PADS, WITHOUT X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0201050102",
            "display" : "COTTON GAUZE PADS, WITH X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        },
        {
          "code" : "M02010502",
          "display" : "COTTON GAUZE PADS, WITH X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0201050201",
            "display" : "COTTON GAUZE PADS, WITH X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0201050202",
            "display" : "COTTON GAUZE PADS, WITH X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        }]
      },
      {
        "code" : "M020106",
        "display" : "COTTON GAUZES IN PIECES"
      },
      {
        "code" : "M020107",
        "display" : "COTTON GAUZES IN ROLLS"
      },
      {
        "code" : "M020199",
        "display" : "COTTON GAUZES - OTHER"
      }]
    },
    {
      "code" : "M0202",
      "display" : "NON-WOVEN GAUZES",
      "concept" : [{
        "code" : "M020201",
        "display" : "NON-WOVEN FOLDED GAUZES",
        "concept" : [{
          "code" : "M02020101",
          "display" : "NON-WOVEN FOLDED GAUZES, WITHOUT X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0202010101",
            "display" : "NON-WOVEN FOLDED GAUZES, WITHOUT X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0202010102",
            "display" : "NON-WOVEN FOLDED GAUZES, WITHOUT X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        },
        {
          "code" : "M02020102",
          "display" : "NON-WOVEN FOLDED GAUZES, WITH X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0202010201",
            "display" : "NON-WOVEN FOLDED GAUZES, WITH X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0202010202",
            "display" : "NON-WOVEN FOLDED GAUZES, WITH X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        }]
      },
      {
        "code" : "M020202",
        "display" : "NON-WOVEN LAPAROTOMY GAUZES",
        "concept" : [{
          "code" : "M02020201",
          "display" : "NON-WOVEN LAPAROTOMY GAUZES, WITHOUT X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0202020101",
            "display" : "NON-WOVEN LAPAROTOMY GAUZES, WITHOUT X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0202020102",
            "display" : "NON-WOVEN LAPAROTOMY GAUZES, WITHOUT X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        },
        {
          "code" : "M02020202",
          "display" : "NON-WOVEN LAPAROTOMY GAUZES, WITH X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0202020201",
            "display" : "NON-WOVEN LAPAROTOMY GAUZES, WITH X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0202020202",
            "display" : "NON-WOVEN LAPAROTOMY GAUZES, WITH X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        }]
      },
      {
        "code" : "M020203",
        "display" : "NON-WOVEN GAUZE PADS",
        "concept" : [{
          "code" : "M02020301",
          "display" : "NON-WOVEN GAUZE PADS, WITHOUT X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0202030101",
            "display" : "NON-WOVEN GAUZE PADS, WITHOUT X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0202030102",
            "display" : "NON-WOVEN GAUZE PADS, WITHOUT X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        },
        {
          "code" : "M02020302",
          "display" : "NON-WOVEN GAUZE PADS, WITH X-RAY DETECTABLE THREAD",
          "concept" : [{
            "code" : "M0202030201",
            "display" : "NON-WOVEN GAUZE PADS, WITH X-RAY DETECTABLE THREAD, STERILE"
          },
          {
            "code" : "M0202030202",
            "display" : "NON-WOVEN GAUZE PADS, WITH X-RAY DETECTABLE THREAD, NON-STERILE"
          }]
        }]
      },
      {
        "code" : "M020204",
        "display" : "NON-WOVEN GAUZES IN PIECES"
      },
      {
        "code" : "M020205",
        "display" : "NON-WOVEN GAUZES IN ROLLS"
      },
      {
        "code" : "M020299",
        "display" : "NON-WOVEN GAUZES - OTHER"
      }]
    },
    {
      "code" : "M0203",
      "display" : "MEDICATED GAUZES",
      "concept" : [{
        "code" : "M020301",
        "display" : "IODOFORM GAUZES"
      },
      {
        "code" : "M020302",
        "display" : "IMPREGNATED GAUZES",
        "concept" : [{
          "code" : "M02030201",
          "display" : "GAUZE IMPREGNATED WITHOUT ANTISEPTIC"
        },
        {
          "code" : "M02030202",
          "display" : "GAUZE IMPREGNATED WITH ANTISEPTIC"
        }]
      },
      {
        "code" : "M020399",
        "display" : "MEDICATED GAUZES - OTHER"
      }]
    },
    {
      "code" : "M0299",
      "display" : "GAUZES - OTHER"
    }]
  },
  {
    "code" : "M03",
    "display" : "BANDAGES",
    "concept" : [{
      "code" : "M0301",
      "display" : "HYDROPHILIC AND NON-WOVEN GAUZE BANDAGES",
      "concept" : [{
        "code" : "M030101",
        "display" : "HYDROPHILIC GAUZE BANDAGES"
      },
      {
        "code" : "M030102",
        "display" : "NON-WOVEN BANDAGES"
      }]
    },
    {
      "code" : "M0302",
      "display" : "MEDICATED BANDAGES",
      "concept" : [{
        "code" : "M030201",
        "display" : "IODOFORM MEDICATED BANDAGES"
      },
      {
        "code" : "M030202",
        "display" : "MEDICATED BANDAGES, WITH ZINC OXIDE AND OTHER COMPONENTS",
        "concept" : [{
          "code" : "M03020201",
          "display" : "MEDICATED BANDAGES, WITH ZINC OXIDE"
        },
        {
          "code" : "M03020202",
          "display" : "MEDICATED BANDAGES, WITH ZINC OXIDE AND AMMONIUM BITUMINOSULFONATE"
        },
        {
          "code" : "M03020299",
          "display" : "MEDICATED BANDAGES, WITH ZINC OXIDE AND OTHER COMPONENTS - OTHER"
        }]
      },
      {
        "code" : "M030299",
        "display" : "MEDICATED BANDAGES - OTHER"
      }]
    },
    {
      "code" : "M0303",
      "display" : "ELASTIC FIXING OR PROTECTION BANDAGES",
      "concept" : [{
        "code" : "M030301",
        "display" : "ELASTIC FIXING BANDAGES",
        "concept" : [{
          "code" : "M03030101",
          "display" : "ELASTIC FIXING BANDAGES, NON-ADHESIVE",
          "concept" : [{
            "code" : "M0303010101",
            "display" : "ELASTIC FIXING BANDAGES, NON-ADHESIVE, EXTENSIBLE IN ONE DIRECTION"
          },
          {
            "code" : "M0303010103",
            "display" : "ELASTIC FIXING BANDAGES, NON-ADHESIVE, EXTENSIBLE IN TWO DIRECTIONS"
          }]
        },
        {
          "code" : "M03030102",
          "display" : "ELASTIC FIXING BANDAGES, SELF-ADHESIVE",
          "concept" : [{
            "code" : "M0303010201",
            "display" : "ELASTIC FIXING BANDAGES, SELF-ADHESIVE, EXTENSIBLE IN ONE DIRECTION"
          },
          {
            "code" : "M0303010203",
            "display" : "ELASTIC FIXING BANDAGES, SELF-ADHESIVE, EXTENSIBLE IN TWO DIRECTIONS"
          }]
        },
        {
          "code" : "M03030103",
          "display" : "TUBULAR NET BANDAGES"
        },
        {
          "code" : "M03030199",
          "display" : "ELASTIC FIXING BANDAGES - OTHER"
        }]
      },
      {
        "code" : "M030302",
        "display" : "PROTECTION SYSTEMS",
        "concept" : [{
          "code" : "M03030201",
          "display" : "TUBULAR MESH"
        },
        {
          "code" : "M03030202",
          "display" : "SKIN PROTECTIVE BANDAGES"
        },
        {
          "code" : "M03030203",
          "display" : "FOAM PADS"
        },
        {
          "code" : "M03030299",
          "display" : "PROTECTION SYSTEMS - OTHER"
        }]
      }]
    },
    {
      "code" : "M0304",
      "display" : "ELASTIC BANDAGES, SUPPORT AND COMPRESSION",
      "concept" : [{
        "code" : "M030401",
        "display" : "ELASTIC COMPRESSION BANDAGES",
        "concept" : [{
          "code" : "M03040101",
          "display" : "ELASTIC COMPRESSION BANDAGES, NON-ADHESIVE",
          "concept" : [{
            "code" : "M0304010101",
            "display" : "ELASTIC COMPRESSION BANDAGES, NON-ADHESIVE, LOW EXTENSIBILITY (<70%)"
          },
          {
            "code" : "M0304010102",
            "display" : "ELASTIC COMPRESSION BANDAGES, NON-ADHESIVE, MEDIUM EXTENSIBILITY (70-140%)"
          },
          {
            "code" : "M0304010103",
            "display" : "ELASTIC COMPRESSION BANDAGES, NON-ADHESIVE, HIGH EXTENSIBILITY (>140%)"
          }]
        },
        {
          "code" : "M03040102",
          "display" : "ELASTIC COMPRESSION BANDAGES, COHESIVE",
          "concept" : [{
            "code" : "M0304010201",
            "display" : "ELASTIC COMPRESSION BANDAGES, COHESIVE, LOW EXTENSIBILITY (<70%)"
          },
          {
            "code" : "M0304010202",
            "display" : "ELASTIC COMPRESSION BANDAGES, COHESIVE, MEDIUM EXTENSIBILITY (70-140%)"
          },
          {
            "code" : "M0304010203",
            "display" : "ELASTIC COMPRESSION BANDAGES, COHESIVE, HIGH EXTENSIBILITY (>140%)"
          }]
        },
        {
          "code" : "M03040103",
          "display" : "ELASTIC COMPRESSION BANDAGES, ADHESIVE",
          "concept" : [{
            "code" : "M0304010301",
            "display" : "ELASTIC COMPRESSION BANDAGES, ADHESIVE, LOW EXTENSIBILITY (<70%)"
          },
          {
            "code" : "M0304010302",
            "display" : "ELASTIC COMPRESSION BANDAGES, ADHESIVE, MEDIUM EXTENSIBILITY (70-140%)"
          },
          {
            "code" : "M0304010303",
            "display" : "ELASTIC COMPRESSION BANDAGES, ADHESIVE, HIGH EXTENSIBILITY (> 140%)"
          }]
        },
        {
          "code" : "M03040199",
          "display" : "ELASTIC COMPRESSION BANDAGES - OTHER"
        }]
      },
      {
        "code" : "M030402",
        "display" : "ELASTIC SUPPORT BANDAGES",
        "concept" : [{
          "code" : "M03040201",
          "display" : "ELASTIC SUPPORT BANDAGES, NON-ADHESIVE",
          "concept" : [{
            "code" : "M0304020101",
            "display" : "ELASTIC SUPPORT BANDAGES, NON-ADHESIVE, HIGH EXTENSIBILITY (>140%)",
            "concept" : [{
              "code" : "M030402010101",
              "display" : "ELASTIC SUPPORT BANDAGES, NON-ADHESIVE, EXTENSIBLE IN ONE DIRECTION, HIGH EXTENSIBILITY"
            },
            {
              "code" : "M030402010103",
              "display" : "ELASTIC SUPPORT BANDAGES, NON-ADHESIVE, EXTENSIBLE IN TWO DIRECTIONS, HIGH EXTENSIBILITY"
            }]
          }]
        },
        {
          "code" : "M03040202",
          "display" : "ELASTIC SUPPORT BANDAGES, COHESIVE (SELF-ADHESIVE)",
          "concept" : [{
            "code" : "M0304020201",
            "display" : "ELASTIC SUPPORT BANDAGES, COHESIVE, HIGH EXTENSIBILITY (>140%)",
            "concept" : [{
              "code" : "M030402020101",
              "display" : "ELASTIC SUPPORT BANDAGES, COHESIVE, EXTENSIBLE IN ONE DIRECTION, HIGH EXTENSIBILITY"
            },
            {
              "code" : "M030402020103",
              "display" : "ELASTIC SUPPORT BANDAGES, COHESIVE, EXTENSIBLE IN TWO DIRECTIONS, HIGH EXTENSIBILITY"
            }]
          }]
        },
        {
          "code" : "M03040203",
          "display" : "ELASTIC SUPPORT BANDAGES, ADHESIVE",
          "concept" : [{
            "code" : "M0304020301",
            "display" : "ELASTIC SUPPORT BANDAGES, ADHESIVE, HIGH EXTENSIBILITY (>140%)",
            "concept" : [{
              "code" : "M030402030102",
              "display" : "ELASTIC SUPPORT BANDAGES, ADHESIVE EXTENSIBLE IN ONE DIRECTION, HIGH EXTENSIBILITY"
            },
            {
              "code" : "M030402030103",
              "display" : "ELASTIC SUPPORT BANDAGES, ADHESIVE, EXTENSIBLE IN TWO DIRECTIONS, HIGH EXTENSIBILITY"
            }]
          }]
        },
        {
          "code" : "M03040299",
          "display" : "ELASTIC SUPPORT BANDAGES - OTHER"
        }]
      },
      {
        "code" : "M030403",
        "display" : "FUNCTIONAL BANDAGES WITH ANELASTIC TAPES"
      },
      {
        "code" : "M030404",
        "display" : "DIALYSIS FISTULA, BANDAGES"
      },
      {
        "code" : "M030405",
        "display" : "COMPRESSION STOCKINGS"
      },
      {
        "code" : "M030499",
        "display" : "ELASTIC BANDAGES, SUPPORT AND COMPRESSION - OTHER"
      }]
    },
    {
      "code" : "M0305",
      "display" : "IMMOBILISATION SYSTEMS AND DEVICES",
      "concept" : [{
        "code" : "M030501",
        "display" : "IMMOBILISATION BANDAGES FOR SHOULDER, ARM AND COLLARBONE"
      },
      {
        "code" : "M030502",
        "display" : "BANDAGES AND SPLINTS",
        "concept" : [{
          "code" : "M03050201",
          "display" : "NATURAL CAST BANDAGES AND SPLINTS"
        },
        {
          "code" : "M03050202",
          "display" : "SYNTHETIC CAST BANDAGES AND SPLINTS"
        },
        {
          "code" : "M03050299",
          "display" : "BANDAGES AND SPLINTS - OTHER"
        }]
      },
      {
        "code" : "M030503",
        "display" : "SKIN TRACTION SYSTEMS"
      },
      {
        "code" : "M030504",
        "display" : "IMMOBILISATION SYSTEMS, MOULDABLE UNDER COLD AND HOT TEMPRATURES"
      },
      {
        "code" : "M030505",
        "display" : "ZIMMER SPLINTS"
      },
      {
        "code" : "M030506",
        "display" : "FERULES"
      },
      {
        "code" : "M030599",
        "display" : "IMMOBILISATION SYSTEMS AND DEVICES - OTHER"
      }]
    },
    {
      "code" : "M0399",
      "display" : "BANDAGES - OTHER (see Y06 for collars, tutors, etc.)"
    }]
  },
  {
    "code" : "M04",
    "display" : "SPECIAL DRESSINGS",
    "concept" : [{
      "code" : "M0401",
      "display" : "PREPARED DRESSINGS",
      "concept" : [{
        "code" : "M040101",
        "display" : "ADHESIVE DRESSINGS, WITH ABSORBENT PAD",
        "concept" : [{
          "code" : "M04010101",
          "display" : "NON-WOVEN ADHESIVE DRESSINGS, WITH ABSORBENT PAD"
        },
        {
          "code" : "M04010102",
          "display" : "POLYURETHANE (OR OTHER MATERIAL) ADHESIVE DRESSINGS, WITH ABSORBENT PAD"
        },
        {
          "code" : "M04010199",
          "display" : "ADHESIVE DRESSINGS, WITH ABSORBENT PAD - OTHER"
        }]
      },
      {
        "code" : "M040102",
        "display" : "FIXING DRESSINGS",
        "concept" : [{
          "code" : "M04010201",
          "display" : "NON-WOVEN FIXING DRESSINGS"
        },
        {
          "code" : "M04010202",
          "display" : "POLYURETHANE FIXING DRESSINGS"
        },
        {
          "code" : "M04010203",
          "display" : "SILICONE DRESSINGS"
        },
        {
          "code" : "M04010299",
          "display" : "FIXING DRESSINGS - OTHER"
        }]
      },
      {
        "code" : "M040199",
        "display" : "PREPARED DRESSINGS - OTHER"
      }]
    },
    {
      "code" : "M0402",
      "display" : "NON-ADHESIVE ABSORBENT DRESSINGS",
      "concept" : [{
        "code" : "M040201",
        "display" : "ABSORBENT DRESSINGS WITH CELLULOSE PAD AND NON-WOVEN WRAPS"
      },
      {
        "code" : "M040202",
        "display" : "ALUMINIUM NON-WOVEN ABSORBENT DRESSINGS"
      },
      {
        "code" : "M040203",
        "display" : "TRACHEOSTOMY DRESSINGS"
      },
      {
        "code" : "M040204",
        "display" : "NON-ADHERENT ABSORBENT DRESSINGS"
      },
      {
        "code" : "M040299",
        "display" : "NON-ADHESIVE ABSORBENT DRESSINGS - OTHER"
      }]
    },
    {
      "code" : "M0403",
      "display" : "OPHTHALMIC DRESSINGS",
      "concept" : [{
        "code" : "M040301",
        "display" : "EYE PADS, COTTON OR NON-WOVEN MATERIALS"
      },
      {
        "code" : "M040302",
        "display" : "STICKS/LANCETS/STRIPS FOR OPHTHALMIC USE"
      },
      {
        "code" : "M040303",
        "display" : "ORTHOPTIC EYE PATCHES"
      },
      {
        "code" : "M040304",
        "display" : "OPHTHALMIC DRESSINGS CONTAINING COMPONENTS OF HUMAN ORIGIN"
      },
      {
        "code" : "M040305",
        "display" : "OPHTHALMIC DRESSINGS IN THE FORM OF EYE DROPS/GEL/CREAMS"
      },
      {
        "code" : "M040306",
        "display" : "OPHTHALMIC PROTECTORS"
      },
      {
        "code" : "M040399",
        "display" : "OPHTHALMIC DRESSINGS - OTHER"
      }]
    },
    {
      "code" : "M0404",
      "display" : "DRESSINGS FOR WOUNDS, SORES AND ULCERATIONS",
      "concept" : [{
        "code" : "M040401",
        "display" : "SALINE DRESSINGS",
        "concept" : [{
          "code" : "M04040101",
          "display" : "SALINE DRESSINGS, NON-COMBINED"
        },
        {
          "code" : "M04040102",
          "display" : "SALINE DRESSINGS IN COMBINATION WITH OTHER SUBSTANCES"
        }]
      },
      {
        "code" : "M040402",
        "display" : "ALGINATE DRESSINGS",
        "concept" : [{
          "code" : "M04040201",
          "display" : "ALGINATE DRESSINGS, NON-COMBINED"
        },
        {
          "code" : "M04040202",
          "display" : "ALGINATE DRESSINGS, COMBINED WITH OTHER SUBSTANCES"
        }]
      },
      {
        "code" : "M040403",
        "display" : "HYDROCOLLOID DRESSINGS",
        "concept" : [{
          "code" : "M04040301",
          "display" : "HYDROCOLLOID DRESSINGS, NON-COMBINED"
        },
        {
          "code" : "M04040302",
          "display" : "HYDROCOLLOID DRESSINGS, COMBINED WITH OTHER SUBSTANCES"
        }]
      },
      {
        "code" : "M040404",
        "display" : "CELLULOSE AND/OR MODIFIED CELLULOSE DRESSINGS, NON-COMBINED OR COMBINED WITH OTHER SUBSTANCES"
      },
      {
        "code" : "M040405",
        "display" : "HYDROGEL DRESSINGS",
        "concept" : [{
          "code" : "M04040501",
          "display" : "HYDROGEL DRESSINGS, NON-COMBINED"
        },
        {
          "code" : "M04040502",
          "display" : "HYDROGEL DRESSINGS, COMBINED WITH OTHER SUBSTANCES"
        }]
      },
      {
        "code" : "M040406",
        "display" : "POLYURETHANE DRESSINGS",
        "concept" : [{
          "code" : "M04040601",
          "display" : "POLYURETHANE DRESSINGS, NON-COMBINED"
        },
        {
          "code" : "M04040602",
          "display" : "POLYURETHANE DRESSINGS, COMBINED WITH OTHER SUBSTANCES"
        }]
      },
      {
        "code" : "M040407",
        "display" : "SILICONE DRESSINGS",
        "concept" : [{
          "code" : "M04040701",
          "display" : "SILICONE DRESSINGS, NON-COMBINED"
        },
        {
          "code" : "M04040702",
          "display" : "SILICONE DRESSINGS, COMBINED WITH OTHER SUBSTANCES"
        }]
      },
      {
        "code" : "M040408",
        "display" : "SILVER DRESSINGS",
        "concept" : [{
          "code" : "M04040801",
          "display" : "SILVER DRESSINGS, NON-COMBINED"
        },
        {
          "code" : "M04040802",
          "display" : "SILVER DRESSINGS, COMBINED WITH OTHER SUBSTANCES"
        }]
      },
      {
        "code" : "M040409",
        "display" : "ACTIVATED CHARCOAL DRESSINGS",
        "concept" : [{
          "code" : "M04040901",
          "display" : "ACTIVATED CHARCOAL DRESSINGS, NON-COMBINED"
        },
        {
          "code" : "M04040902",
          "display" : "ACTIVATED CHARCOAL DRESSINGS, COMBINED WITH OTHER SUBSTANCES"
        }]
      },
      {
        "code" : "M040410",
        "display" : "ANIMAL-DERIVED COLLAGEN DRESSINGS",
        "concept" : [{
          "code" : "M04041001",
          "display" : "ANIMAL-DERIVED COLLAGEN DRESSINGS, NON-COMBINED"
        },
        {
          "code" : "M04041002",
          "display" : "ANIMAL-DERIVED COLLAGEN DRESSINGS, COMBINED WITH OTHER SUBSTANCES"
        }]
      },
      {
        "code" : "M040411",
        "display" : "INSTRUMENT DRESSINGS"
      },
      {
        "code" : "M040412",
        "display" : "ANTISEPTICS-BASED DRESSINGS"
      },
      {
        "code" : "M040413",
        "display" : "INTERACTIVE DRESSINGS"
      },
      {
        "code" : "M040414",
        "display" : "MULTI-LAYER ABSORBENT DRESSINGS"
      },
      {
        "code" : "M040415",
        "display" : "DRESSINGS IN SOLUTIONS, EMULSIONS, GELS, POWDERS",
        "concept" : [{
          "code" : "M04041501",
          "display" : "DRESSINGS IN SOLUTIONS, EMULSIONS, GELS, POWDERS WITH HERBAL COMPONENTS"
        },
        {
          "code" : "M04041502",
          "display" : "DRESSINGS IN SOLUTIONS, EMULSIONS, GELS, POWDERS WITH ANIMAL COMPONENTS"
        },
        {
          "code" : "M04041503",
          "display" : "DRESSINGS IN SOLUTIONS, EMULSIONS, GELS, POWDERS WITH SYNTHETIC COMPONENTS"
        }]
      },
      {
        "code" : "M040416",
        "display" : "HYDROPHOBIC DRESSINGS"
      },
      {
        "code" : "M040499",
        "display" : "DRESSINGS FOR WOUNDS, SORES AND ULCERATIONS - OTHER"
      }]
    },
    {
      "code" : "M0405",
      "display" : "HAEMOSTATIC DRESSINGS",
      "concept" : [{
        "code" : "M040501",
        "display" : "POLYSACCHARIDE HAEMOSTATIC DRESSINGS"
      },
      {
        "code" : "M040502",
        "display" : "ANIMAL COLLAGEN HAEMOSTATIC DRESSINGS"
      },
      {
        "code" : "M040503",
        "display" : "GELATINE SPONGE HAEMOSTATIC DRESSINGS"
      },
      {
        "code" : "M040504",
        "display" : "INORGANIC HAEMOSTATIC DEVICES"
      },
      {
        "code" : "M040505",
        "display" : "HAEMOSTATIC DEVICES BASED ON CLOTTING FACTORS",
        "concept" : [{
          "code" : "M04050501",
          "display" : "HEMOSTATIC DRESSINGS BASED ON COAGULATION FACTORS OF ANIMAL ORIGIN"
        },
        {
          "code" : "M04050502",
          "display" : "HEMOSTATIC DRESSINGS BASED ON COAGULATION FACTORS OF HUMAN ORIGIN"
        }]
      },
      {
        "code" : "M040506",
        "display" : "HEMOSTATIC WAXES"
      },
      {
        "code" : "M040599",
        "display" : "HAEMOSTATIC DRESSINGS - OTHER"
      }]
    },
    {
      "code" : "M0406",
      "display" : "DRESSINGS FOR THE PREVENTION OF POST-OPERATIVE ADHESIONS"
    },
    {
      "code" : "M0407",
      "display" : "SPECIAL PADS",
      "concept" : [{
        "code" : "M040701",
        "display" : "NASAL PADS"
      },
      {
        "code" : "M040702",
        "display" : "SURGICAL PADS"
      },
      {
        "code" : "M040703",
        "display" : "WOUND DEBRIDEMENT PADS"
      },
      {
        "code" : "M040799",
        "display" : "SPECIAL PADS - OTHER"
      }]
    },
    {
      "code" : "M0408",
      "display" : "DRESSINGS FOR BURNS ONLY"
    },
    {
      "code" : "M0409",
      "display" : "DRESSINGS FOR PHOTO- AND THERMOTHERAPY IN THE FORM OF GELS AND SOLUTIONS"
    },
    {
      "code" : "M0410",
      "display" : "DRESSINGS FOR NAILS IN THE FORM OF LIQUIDS, GELS AND CREAMS"
    },
    {
      "code" : "M0411",
      "display" : "OSMOTIC DRESSINGS"
    },
    {
      "code" : "M0412",
      "display" : "DRESSINGS FOR THE TREATMENT OF WARTS, CORNS AND CALLUSES"
    },
    {
      "code" : "M0499",
      "display" : "SPECIAL DRESSINGS - OTHER"
    }]
  },
  {
    "code" : "M05",
    "display" : "PLASTERS",
    "concept" : [{
      "code" : "M0501",
      "display" : "SURGICAL PLASTERS",
      "concept" : [{
        "code" : "M050101",
        "display" : "PLASTERS ON SPOOLS (ROLLS)"
      },
      {
        "code" : "M050102",
        "display" : "MEDICATED PLASTERS"
      },
      {
        "code" : "M050199",
        "display" : "SURGICAL PLASTERS - OTHER"
      }]
    },
    {
      "code" : "M0502",
      "display" : "PLASTERS FOR EXTENSIVE AREAS",
      "concept" : [{
        "code" : "M050201",
        "display" : "EXTENSIBLE NON-WOVEN PLASTERS"
      },
      {
        "code" : "M050202",
        "display" : "NON-EXTENSIBLE WOVEN PLASTERS"
      },
      {
        "code" : "M050299",
        "display" : "PLASTERS FOR EXTENSIVE AREAS - OTHER"
      }]
    },
    {
      "code" : "M0599",
      "display" : "MEDICAL PLASTERS - OTHER"
    }]
  },
  {
    "code" : "M90",
    "display" : "DEVICES FOR GENERAL AND SPECIALIST DRESSINGS - VARIOUS",
    "concept" : [{
      "code" : "M9001",
      "display" : "CRYOTHERAPY AND THERMOTHERAPY DEVICES"
    },
    {
      "code" : "M9002",
      "display" : "PROTECTIVE DEVICES, LUBRICANTS AND SOOTHING DEVICES (SPRAYS, GELS, FLUIDS AND CREAMS)"
    },
    {
      "code" : "M9003",
      "display" : "SOLUTIONS FOR ADHESIVE TAPE REMOVAL"
    },
    {
      "code" : "M9099",
      "display" : "GENERAL AND SPECIALIST MEDICAL DEVICES – OTHER (SUTURE PATCHES SEE H900102)"
    }]
  },
  {
    "code" : "N",
    "display" : "NERVOUS AND MEDULLARY SYSTEMS DEVICES"
  },
  {
    "code" : "N01",
    "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM DEVICES",
    "concept" : [{
      "code" : "N0101",
      "display" : "NEUROPHYSIOLOGY DEVICES",
      "concept" : [{
        "code" : "N010101",
        "display" : "ELECTROMYOGRAPHIC ELECTRODES"
      },
      {
        "code" : "N010102",
        "display" : "ELECTROENCEPHALOGRAPHIC ELECTRODES",
        "concept" : [{
          "code" : "N01010201",
          "display" : "EEG INTRACRANIC ELECTRODES",
          "concept" : [{
            "code" : "N0101020101",
            "display" : "EEG CORTICAL ELECTRODES"
          },
          {
            "code" : "N0101020102",
            "display" : "EEG DEPTH ELECTRODES"
          },
          {
            "code" : "N0101020199",
            "display" : "EEG INTRACRANIC ELECTRODES - OTHER"
          }]
        },
        {
          "code" : "N01010202",
          "display" : "EEG EXTRACRANIC ELECTRODES"
        },
        {
          "code" : "N01010203",
          "display" : "EEG HEADSETS"
        },
        {
          "code" : "N01010299",
          "display" : "EEG ELECTRODES - OTHER"
        }]
      },
      {
        "code" : "N010103",
        "display" : "BIPOLAR NERVOUS ELECTROSTIMULATORS, BATTERY-POWERED"
      },
      {
        "code" : "N010180",
        "display" : "NEUROPHYSIOLOGY DEVICES - ACCESSORIES"
      },
      {
        "code" : "N010199",
        "display" : "NEUROPHYSIOLOGY DEVICES - OTHER"
      }]
    },
    {
      "code" : "N0102",
      "display" : "NEUROLOGIC PHYSIOTHERAPHY DEVICES",
      "concept" : [{
        "code" : "N010201",
        "display" : "TENS SYSTEM ELECTRODES"
      },
      {
        "code" : "N010202",
        "display" : "STIMULATION POINT LOCATORS"
      },
      {
        "code" : "N010280",
        "display" : "NEUROLOGICAL PHYSIOTHERAPY DEVICES - ACCESSORIES",
        "concept" : [{
          "code" : "N01028001",
          "display" : "SPONGES FOR THE APPLICATION OF CUTANEOUS NEUROLOGICAL ELECTRODES"
        },
        {
          "code" : "N01028002",
          "display" : "NEUROLOGICAL PHYSIOTHERAPY CONNECTORS"
        },
        {
          "code" : "N01028003",
          "display" : "NEUROLOGICAL ELECTRODES BANDS"
        },
        {
          "code" : "N01028099",
          "display" : "NEUROLOGICAL PHYSIOTHERAPY DEVICES - ACCESSORIES - OTHER"
        }]
      },
      {
        "code" : "N010299",
        "display" : "NEUROLOGIC PHYSIOTHERAPHY DEVICES - OTHER"
      }]
    },
    {
      "code" : "N0103",
      "display" : "CRANIAL DRAINAGE DEVICES AND KITS",
      "concept" : [{
        "code" : "N010301",
        "display" : "VENTRICULAR-PERITONEAL SHUNTS"
      },
      {
        "code" : "N010302",
        "display" : "VENTRICULAR-ATRIAL SHUNTS"
      },
      {
        "code" : "N010303",
        "display" : "CEREBRAL FLUID EXTERNAL DRAINS AND KITS"
      },
      {
        "code" : "N010380",
        "display" : "INTRACRANIAL DRAINAGE DEVICES AND KITS - ACCESSORIES",
        "concept" : [{
          "code" : "N01038001",
          "display" : "INTRACRANIAL DRAINAGE DEVICES ADAPTERS AND CONNECTORS, SINGLE-USE"
        },
        {
          "code" : "N01038002",
          "display" : "INTRACRANIAL DRAINAGE DEVICE VALVES"
        },
        {
          "code" : "N01038099",
          "display" : "INTRACRANIAL DRAINAGE DEVICES AND KITS - ACCESSORIES - OTHER"
        }]
      },
      {
        "code" : "N010399",
        "display" : "INTRACRANIAL DRAINAGE DEVICES AND KITS - OTHER"
      }]
    },
    {
      "code" : "N0104",
      "display" : "PERIPHERAL NERVOUS SYSTEM CATHETERS",
      "concept" : [{
        "code" : "N010401",
        "display" : "PERIPHERAL NERVOUS SYSTEM CATHETERS AND KITS"
      },
      {
        "code" : "N010480",
        "display" : "PERIPHERAL NERVOUS SYSTEM CATHETERS - ACCESSORIES"
      },
      {
        "code" : "N010499",
        "display" : "PERIPHERAL NERVOUS SYSTEM CATHETERS - OTHER"
      }]
    },
    {
      "code" : "N0180",
      "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM DEVICES - ACCESSORIES",
      "concept" : [{
        "code" : "N018001",
        "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM SURGICAL INSTRUMENTS, SINGLE-USE",
        "concept" : [{
          "code" : "N01800101",
          "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM SURGICAL FORCEPS, SINGLE-USE"
        },
        {
          "code" : "N01800102",
          "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM SURGICAL SCISSORS, SINGLE-USE"
        },
        {
          "code" : "N01800103",
          "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM NEEDLE HOLDERS, SINGLE-USE"
        },
        {
          "code" : "N01800104",
          "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM SPREADERS AND RETRACTORS, SINGLE-USE"
        },
        {
          "code" : "N01800105",
          "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM SURGICAL BLADES, SINGLE-USE"
        },
        {
          "code" : "N01800106",
          "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM SURGICAL INSTRUMENT KITS, SINGLE-USE"
        },
        {
          "code" : "N01800199",
          "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM SURGICAL INSTRUMENTS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "N018099",
        "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM DEVICES - ACCESSORIES - OTHER"
      }]
    },
    {
      "code" : "N0199",
      "display" : "ENCEPHALIC AND PERIPHERAL NERVOUS SYSTEM DEVICES - OTHER"
    }]
  },
  {
    "code" : "N02",
    "display" : "SPINAL MEDULLAR SYSTEM DEVICES",
    "concept" : [{
      "code" : "N0201",
      "display" : "SPINAL CATHETERS AND KITS",
      "concept" : [{
        "code" : "N020101",
        "display" : "PERIDURAL / EPIDURAL SPINAL CATHETERS AND KITS",
        "concept" : [{
          "code" : "N02010101",
          "display" : "EPIDUROSCOPY AND EPIDUROPLASTICS CATHETERS AND KITS"
        },
        {
          "code" : "N02010102",
          "display" : "PERIDURAL / EPIDURAL CATHETERS FOR CONTINUOUS ANALGESIA AND KITS"
        },
        {
          "code" : "N02010180",
          "display" : "PERIDURAL / EPIDURAL SPINAL CATHETERS AND KITS - ACCESSORIES"
        },
        {
          "code" : "N02010199",
          "display" : "PERIDURAL / EPIDURAL SPINAL CATHETERS AND KITS - OTHER"
        }]
      },
      {
        "code" : "N020102",
        "display" : "SUBARACHNOID SPINAL CATHETERS AND KITS"
      },
      {
        "code" : "N020180",
        "display" : "SPINAL CATHETERS AND KITS - ACCESSORIES"
      },
      {
        "code" : "N020199",
        "display" : "SPINAL CATHETERS AND KITS - OTHER"
      }]
    },
    {
      "code" : "N0202",
      "display" : "SPINAL ACCESS SYSTEMS FOR INFUSION THERAPY",
      "concept" : [{
        "code" : "N020201",
        "display" : "PERIDURAL / EPIDURAL ACCESS SYSTEMS FOR INFUSION THERAPY"
      },
      {
        "code" : "N020202",
        "display" : "SUBARACHNOID ACCESS SYSTEMS FOR INFUSION THERAPY"
      },
      {
        "code" : "N020280",
        "display" : "SPINAL ACCESS SYSTEMS FOR INFUSION THERAPY - ACCESSORIES"
      },
      {
        "code" : "N020299",
        "display" : "SPINAL ACCESS SYSTEMS FOR INFUSION THERAPY - OTHER"
      }]
    },
    {
      "code" : "N0203",
      "display" : "SPINAL LUMBAR DRAINAGE DEVICES AND KITS",
      "concept" : [{
        "code" : "N020301",
        "display" : "LUMBO-PERITONEAL SHUNTS"
      },
      {
        "code" : "N020302",
        "display" : "EXTERNAL SPINAL FLUID DRAINS AND KITS"
      },
      {
        "code" : "N020380",
        "display" : "SPINAL LUMBAR DRAINAGE DEVICES AND KITS - ACCESSORIES"
      },
      {
        "code" : "N020399",
        "display" : "SPINAL LUMBAR DRAINAGE DEVICES AND KITS - OTHER"
      }]
    },
    {
      "code" : "N0280",
      "display" : "SPINAL MEDULLARY SYSTEM DEVICES - ACCESSORIES",
      "concept" : [{
        "code" : "N028001",
        "display" : "FILTERS FOR CONTINUOUS SPINAL ANALGESIA"
      },
      {
        "code" : "N028002",
        "display" : "SPINAL MEDULLARY SYSTEM SURGICAL INSTRUMENTS, SINGLE-USE",
        "concept" : [{
          "code" : "N02800201",
          "display" : "SPINAL MEDULLARY SYSTEM SURGICAL FORCEPS, SINGLE-USE"
        },
        {
          "code" : "N02800202",
          "display" : "SPINAL MEDULLARY SYSTEM SURGICAL SCISSORS, SINGLE-USE"
        },
        {
          "code" : "N02800203",
          "display" : "SPINAL MEDULLARY SYSTEM NEEDLE HOLDERS, SINGLE-USE"
        },
        {
          "code" : "N02800204",
          "display" : "SPINAL MEDULLARY SYSTEM SPREADERS AND RETRACTORS, SINGLE-USE"
        },
        {
          "code" : "N02800205",
          "display" : "SPINAL MEDULLAR SYSTEM SURGICAL BLADES, SINGLE-USE"
        },
        {
          "code" : "N02800206",
          "display" : "DILATORS FOR POSITIONING OF SPINAL DEVICES, SINGLE-USE"
        },
        {
          "code" : "N02800207",
          "display" : "SPINAL DEVICES INTRODUCERS, SINGLE-USE"
        },
        {
          "code" : "N02800208",
          "display" : "SPINAL DEVICES TUNNELISERS, SINGLE-USE"
        },
        {
          "code" : "N02800209",
          "display" : "SPINAL MEDULLARY SYSTEM SURGICAL INSTRUMENT KITS, SINGLE-USE"
        },
        {
          "code" : "N02800299",
          "display" : "SPINAL MEDULLARY SYSTEM SURGICAL INSTRUMENTS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "N028099",
        "display" : "SPINAL MEDULLARY SYSTEM DEVICES - ACCESSORIES - OTHER"
      }]
    },
    {
      "code" : "N0299",
      "display" : "SPINAL MEDULLARY SYSTEM DEVICES - OTHER"
    }]
  },
  {
    "code" : "N99",
    "display" : "NERVOUS AND MEDULLARY SYSTEM DEVICES - OTHER"
  },
  {
    "code" : "P",
    "display" : "IMPLANTABLE PROSTHETIC AND OSTEOSYNTHESIS DEVICES"
  },
  {
    "code" : "P01",
    "display" : "PROSTHESES, FACIAL, ODONTOLOGICAL, AND CRANIAL",
    "concept" : [{
      "code" : "P0101",
      "display" : "FACIAL PROSTHESES",
      "concept" : [{
        "code" : "P010101",
        "display" : "CHIN PROSTHESES"
      },
      {
        "code" : "P010102",
        "display" : "ZYGOMATIC PROSTHESES"
      },
      {
        "code" : "P010103",
        "display" : "MANDIBULAR PROSTHESES"
      },
      {
        "code" : "P010104",
        "display" : "PROSTHESES, ORBITAL CAVITY",
        "concept" : [{
          "code" : "P01010401",
          "display" : "PROSTHESES, ORBITAL CAVITY - PARTIAL"
        },
        {
          "code" : "P01010402",
          "display" : "PROSTHESES, ORBITAL CAVITY - TOTAL"
        }]
      },
      {
        "code" : "P010199",
        "display" : "FACIAL PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0102",
      "display" : "ODONTOLOGICAL PROSTHESES",
      "concept" : [{
        "code" : "P010201",
        "display" : "DENTAL IMPLANTS AND ACCESSORIES",
        "concept" : [{
          "code" : "P01020101",
          "display" : "DENTAL IMPLANTS"
        },
        {
          "code" : "P01020180",
          "display" : "DENTAL IMPLANTS - ACCESSORIES"
        }]
      },
      {
        "code" : "P010299",
        "display" : "ODONTOLOGICAL PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0103",
      "display" : "PROSTHESES, CRANIAL"
    },
    {
      "code" : "P0180",
      "display" : "FACIAL AND ODONTOLOGICAL PROSTHESES - ACCESSORIES"
    },
    {
      "code" : "P0199",
      "display" : "PROSTHESES, FACIAL, ODONTOLOGICAL, AND CRANIAL - OTHERS"
    }]
  },
  {
    "code" : "P02",
    "display" : "ENT PROSTHESES",
    "concept" : [{
      "code" : "P0201",
      "display" : "OTOLOGIC PROSTHESES",
      "concept" : [{
        "code" : "P020101",
        "display" : "MIDDLE EAR IMPLANTS",
        "concept" : [{
          "code" : "P02010101",
          "display" : "OSSICULAR PROSTHESES (PORP AND TORP)"
        },
        {
          "code" : "P02010102",
          "display" : "STAPEDIOPLASTIC PROSTHESES"
        },
        {
          "code" : "P02010103",
          "display" : "EUSTACHIAN TUBE PROSTHESIS"
        },
        {
          "code" : "P02010199",
          "display" : "MIDDLE EAR IMPLANTS - OTHER"
        }]
      },
      {
        "code" : "P020102",
        "display" : "EXTERNAL-MIDDLE EAR IMPLANTS",
        "concept" : [{
          "code" : "P02010201",
          "display" : "TRANSTYMPANIC DRAINAGE PROSTHESES (VENTILATION TUBES)"
        },
        {
          "code" : "P02010202",
          "display" : "TYMPANIC PROSTHESES"
        },
        {
          "code" : "P02010299",
          "display" : "EXTERNAL-MIDDLE EAR IMPLANTS- OTHER"
        }]
      },
      {
        "code" : "P020103",
        "display" : "EXTERNAL EAR PROSTHESES"
      },
      {
        "code" : "P020180",
        "display" : "OTOLOGIC PROSTHESES - ACCESSORIES"
      },
      {
        "code" : "P020199",
        "display" : "OTOLOGIC PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0202",
      "display" : "RHINOLOGY PROSTHESES",
      "concept" : [{
        "code" : "P020201",
        "display" : "NASAL SEPTAL PLUGGERS"
      },
      {
        "code" : "P020202",
        "display" : "NASAL SINUS STENTS"
      },
      {
        "code" : "P020203",
        "display" : "NASAL SPLINTS"
      },
      {
        "code" : "P020299",
        "display" : "RHINOLOGY PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0203",
      "display" : "PHARYNGO-OESOPHAGEAL PROSTHESES",
      "concept" : [{
        "code" : "P020301",
        "display" : "PHARYNX PROSTHESES"
      },
      {
        "code" : "P020399",
        "display" : "PHARYNGO-OOESOPHAGEAL PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0204",
      "display" : "LARYNX PROSTHESES"
    },
    {
      "code" : "P0205",
      "display" : "PHONATION PROSTHESES"
    },
    {
      "code" : "P0280",
      "display" : "ENT PROSTHESES- ACCESSORIES"
    },
    {
      "code" : "P0299",
      "display" : "ENT PROSTHESES - OTHER"
    }]
  },
  {
    "code" : "P03",
    "display" : "OCULAR PROSTHESES",
    "concept" : [{
      "code" : "P0301",
      "display" : "INTRAOCULAR LENSES (IOL)",
      "concept" : [{
        "code" : "P030101",
        "display" : "IOLs, PHAKIC",
        "concept" : [{
          "code" : "P03010103",
          "display" : "IOLs, PHAKIC, MONOFOCAL",
          "concept" : [{
            "code" : "P0301010301",
            "display" : "IOLs, PHAKIC, MONOFOCAL, SPHERICAL",
            "concept" : [{
              "code" : "P030101030101",
              "display" : "IOLs, PHAKIC, MONOFOCAL, SPHERICAL, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030101030102",
              "display" : "IOLs, PHAKIC, MONOFOCAL, SPHERICAL, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030101030103",
              "display" : "IOLs, PHAKIC, MONOFOCAL, SPHERICAL, SILICONE"
            },
            {
              "code" : "P030101030104",
              "display" : "IOLs, PHAKIC, MONOFOCAL, SPHERICAL, PMMA"
            },
            {
              "code" : "P030101030199",
              "display" : "IOLs, PHAKIC, MONOFOCAL, SPHERICAL - OTHER"
            }]
          },
          {
            "code" : "P0301010302",
            "display" : "IOLs, PHAKIC, MONOFOCAL, ASPHERIC",
            "concept" : [{
              "code" : "P030101030201",
              "display" : "IOLs, PHAKIC, MONOFOCAL, ASPHERIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030101030202",
              "display" : "IOLs, PHAKIC, MONOFOCAL, ASPHERIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030101030203",
              "display" : "IOLs, PHAKIC, MONOFOCAL, ASPHERIC, SILICONE"
            },
            {
              "code" : "P030101030299",
              "display" : "IOLs, PHAKIC, MONOFOCAL, ASPHERIC - OTHER"
            }]
          },
          {
            "code" : "P0301010303",
            "display" : "IOLs, PHAKIC, MONOFOCAL, TORIC",
            "concept" : [{
              "code" : "P030101030301",
              "display" : "IOLs, PHAKIC, MONOFOCAL, TORIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030101030302",
              "display" : "IOLs, PHAKIC, MONOFOCAL, TORIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030101030303",
              "display" : "IOLs, PHAKIC, MONOFOCAL, TORIC, SILICONE"
            },
            {
              "code" : "P030101030399",
              "display" : "IOLs, PHAKIC, MONOFOCAL, TORIC - OTHER"
            }]
          }]
        },
        {
          "code" : "P03010104",
          "display" : "IOLs, PHAKIC, MULTIFOCAL",
          "concept" : [{
            "code" : "P0301010401",
            "display" : "IOLs, PHAKIC, MULTIFOCAL, SPHERICAL",
            "concept" : [{
              "code" : "P030101040101",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, SPHERICAL, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030101040102",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, SPHERICAL, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030101040103",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, SPHERICAL, SILICONE"
            },
            {
              "code" : "P030101040199",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, SPHERICAL - OTHER"
            }]
          },
          {
            "code" : "P0301010402",
            "display" : "IOLs, PHAKIC, MULTIFOCAL, ASPHERIC",
            "concept" : [{
              "code" : "P030101040201",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, ASPHERIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030101040202",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, ASPHERIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030101040203",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, ASPHERIC, SILICONE"
            },
            {
              "code" : "P030101040299",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, ASPHERIC - OTHER"
            }]
          },
          {
            "code" : "P0301010403",
            "display" : "IOLs, PHAKIC, MULTIFOCAL, TORIC",
            "concept" : [{
              "code" : "P030101040301",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, TORIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030101040302",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, TORIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030101040303",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, TORIC, SILICONE"
            },
            {
              "code" : "P030101040399",
              "display" : "IOLs, PHAKIC, MULTIFOCAL, TORIC - OTHER"
            }]
          }]
        }]
      },
      {
        "code" : "P030102",
        "display" : "IOLs, APHAKIC",
        "concept" : [{
          "code" : "P03010209",
          "display" : "IOLs, APHAKIC, MONOFOCAL",
          "concept" : [{
            "code" : "P0301020901",
            "display" : "IOLs, APHAKIC, MONOFOCAL, SPHERICAL",
            "concept" : [{
              "code" : "P030102090101",
              "display" : "IOLs, APHAKIC, MONOFOCAL, SPHERICAL, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030102090102",
              "display" : "IOLs, APHAKIC, MONOFOCAL, SPHERICAL, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030102090103",
              "display" : "IOLs, APHAKIC, MONOFOCAL, SPHERICAL, SILICONE"
            },
            {
              "code" : "P030102090104",
              "display" : "IOLs, APHAKIC, MONOFOCAL, SPHERICAL, PMMA"
            },
            {
              "code" : "P030102090199",
              "display" : "IOLs, APHAKIC, MONOFOCAL, SPHERICAL - OTHER"
            }]
          },
          {
            "code" : "P0301020902",
            "display" : "IOLs, APHAKIC, MONOFOCAL, ASPHERIC",
            "concept" : [{
              "code" : "P030102090201",
              "display" : "IOLs, APHAKIC, MONOFOCAL, ASPHERIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030102090202",
              "display" : "IOLs, APHAKIC, MONOFOCAL, ASPHERIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030102090203",
              "display" : "IOLs, APHAKIC, MONOFOCAL, ASPHERIC, SILICONE"
            },
            {
              "code" : "P030102090299",
              "display" : "IOLs, APHAKIC, MONOFOCAL, ASPHERIC - OTHER"
            }]
          },
          {
            "code" : "P0301020903",
            "display" : "IOLs, APHAKIC, MONOFOCAL, TORIC",
            "concept" : [{
              "code" : "P030102090301",
              "display" : "IOLs, APHAKIC, MONOFOCAL, TORIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030102090302",
              "display" : "IOLs, APHAKIC, MONOFOCAL, TORIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030102090303",
              "display" : "IOLs, APHAKIC, MONOFOCAL, TORIC, SILICONE"
            },
            {
              "code" : "P030102090399",
              "display" : "IOLs, APHAKIC, MONOFOCAL, TORIC - OTHER"
            }]
          }]
        },
        {
          "code" : "P03010210",
          "display" : "IOLs, APHAKIC, MULTIFOCAL",
          "concept" : [{
            "code" : "P0301021001",
            "display" : "IOLs, APHAKIC, MULTIFOCAL, SPHERICAL",
            "concept" : [{
              "code" : "P030102100101",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, SPHERICAL, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030102100102",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, SPHERICAL, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030102100103",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, SPHERICAL, SILICONE"
            },
            {
              "code" : "P030102100199",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, SPHERICAL - OTHER"
            }]
          },
          {
            "code" : "P0301021002",
            "display" : "IOLs, APHAKIC, MULTIFOCAL, ASPHERIC",
            "concept" : [{
              "code" : "P030102100201",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, ASPHERIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030102100202",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, ASPHERIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030102100203",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, ASPHERIC, SILICONE"
            },
            {
              "code" : "P030102100299",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, ASPHERIC - OTHER"
            }]
          },
          {
            "code" : "P0301021003",
            "display" : "IOLs, APHAKIC, MULTIFOCAL, TORIC",
            "concept" : [{
              "code" : "P030102100301",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, TORIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030102100302",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, TORIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030102100303",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, TORIC, SILICONE"
            },
            {
              "code" : "P030102100399",
              "display" : "IOLs, APHAKIC, MULTIFOCAL, TORIC - OTHER"
            }]
          }]
        },
        {
          "code" : "P03010211",
          "display" : "IOLs, APHAKIC, ACCOMMODATIVE",
          "concept" : [{
            "code" : "P0301021101",
            "display" : "IOLs, APHAKIC, ACCOMMODATIVE, SPHERICAL",
            "concept" : [{
              "code" : "P030102110101",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, SPHERICAL, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030102110102",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, SPHERICAL, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030102110103",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, SPHERICAL, SILICONE"
            },
            {
              "code" : "P030102110199",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, SPHERICAL - OTHER"
            }]
          },
          {
            "code" : "P0301021102",
            "display" : "IOLs, APHAKIC, ACCOMMODATIVE, ASPHERIC",
            "concept" : [{
              "code" : "P030102110201",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, ASPHERIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030102110202",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, ASPHERIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030102110203",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, ASPHERIC, SILICONE"
            },
            {
              "code" : "P030102110299",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, ASPHERIC - OTHER"
            }]
          },
          {
            "code" : "P0301021103",
            "display" : "IOLs, APHAKIC, ACCOMMODATIVE, TORIC",
            "concept" : [{
              "code" : "P030102110301",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, TORIC, HYDROPHOBIC ACRYLIC"
            },
            {
              "code" : "P030102110302",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, TORIC, HYDROPHILIC ACRYLIC"
            },
            {
              "code" : "P030102110303",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, TORIC, SILICONE"
            },
            {
              "code" : "P030102110399",
              "display" : "IOLs, APHAKIC, ACCOMMODATIVE, TORIC - OTHER"
            }]
          }]
        }]
      },
      {
        "code" : "P030190",
        "display" : "INTRAOCULAR LENSES (IOL) - VARIOUS",
        "concept" : [{
          "code" : "P03019001",
          "display" : "MACULOPATHY LOW VISION CORRECTION LENSES"
        }]
      },
      {
        "code" : "P030199",
        "display" : "INTRAOCULAR LENSES (IOL) - OTHER"
      }]
    },
    {
      "code" : "P0380",
      "display" : "OCULAR PROSTHESES - ACCESSORIES"
    },
    {
      "code" : "P0399",
      "display" : "OCULAR PROSTHESES - OTHER"
    }]
  },
  {
    "code" : "P04",
    "display" : "RESPIRATORY PROSTHESES",
    "concept" : [{
      "code" : "P0401",
      "display" : "TRACHEOBRONCHIAL PROSTHESES"
    },
    {
      "code" : "P0480",
      "display" : "RESPIRATORY PROSTHESES - ACCESSORIES"
    },
    {
      "code" : "P0499",
      "display" : "RESPIRATORY PROSTHESES - OTHER"
    }]
  },
  {
    "code" : "P05",
    "display" : "OESOPHAGEAL AND GASTROINTESTINAL PROSTHESES",
    "concept" : [{
      "code" : "P0501",
      "display" : "OESOPHAGEAL PROSTHESES",
      "concept" : [{
        "code" : "P050101",
        "display" : "GASTRO-ESOPHAGEAL REFLUX CORRECTION PROSTHESES"
      },
      {
        "code" : "P050199",
        "display" : "ESOPHAGEAL PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0502",
      "display" : "BILIARY AND PANCREATIC PROSTHESES"
    },
    {
      "code" : "P0503",
      "display" : "COLONIC AND DUODENAL PROSTHESES"
    },
    {
      "code" : "P0504",
      "display" : "FAECAL INCONTINENCE PROSTHESES",
      "concept" : [{
        "code" : "P050401",
        "display" : "ANAL SPHINCTERS"
      },
      {
        "code" : "P050499",
        "display" : "FAECAL INCONTINENCE PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0580",
      "display" : "OESOPHAGEAL AND GASTROINTESTINAL PROSTHESES - ACCESSORIES",
      "concept" : [{
        "code" : "P058001",
        "display" : "OESOPHAGEAL AND GASTROINTESTINAL PROSTHESES POSITIONING DEVICES"
      },
      {
        "code" : "P058099",
        "display" : "OESOPHAGEAL AND GASTROINTESTINAL PROSTHESES - OTHER ACCESSORIES"
      }]
    },
    {
      "code" : "P0599",
      "display" : "PROSTHESES, OESOPHAGEAL AND GASTROINTESTINAL PROSTHESES - OTHER"
    }]
  },
  {
    "code" : "P06",
    "display" : "BREAST IMPLANTS",
    "concept" : [{
      "code" : "P0601",
      "display" : "PERMANENT, NON-EXPANDABLE BREAST IMPLANTS",
      "concept" : [{
        "code" : "P060101",
        "display" : "BREAST PROSTHESES, ROUND",
        "concept" : [{
          "code" : "P06010101",
          "display" : "BREAST IMPLANTS, ROUND, SALINE",
          "concept" : [{
            "code" : "P0601010101",
            "display" : "BREAST IMPLANTS, ROUND, SALINE, WITH SMOOTH SURFACE"
          },
          {
            "code" : "P0601010102",
            "display" : "BREAST IMPLANTS, ROUND, SALINE, WITH TEXTURED SURFACE"
          },
          {
            "code" : "P0601010199",
            "display" : "BREAST IMPLANTS, ROUND, SALINE - OTHER"
          }]
        },
        {
          "code" : "P06010102",
          "display" : "BREAST IMPLANTS, ROUND, MADE OF SILICONE",
          "concept" : [{
            "code" : "P0601010201",
            "display" : "BREAST IMPLANTS, ROUND, MADE OF SILICONE, WITH SMOOTH SURFACE"
          },
          {
            "code" : "P0601010202",
            "display" : "BREAST IMPLANTS, ROUND, MADE OF SILICONE, WITH TEXTURED SURFACE"
          },
          {
            "code" : "P0601010299",
            "display" : "BREAST IMPLANTS, ROUND, MADE OF SILICONE - OTHER"
          }]
        }]
      },
      {
        "code" : "P060102",
        "display" : "BREAST IMPLANTS, ANATOMIC",
        "concept" : [{
          "code" : "P06010201",
          "display" : "BREAST IMPLANTS, ANATOMICAL, SALINE",
          "concept" : [{
            "code" : "P0601020101",
            "display" : "BREAST IMPLANTS, ANATOMICAL, SALINE, WITH SMOOTH SURFACE"
          },
          {
            "code" : "P0601020102",
            "display" : "BREAST IMPLANTS, ANATOMICAL, SALINE, WITH TEXTURED SURFACE"
          },
          {
            "code" : "P0601020199",
            "display" : "BREAST IMPLANTS, ANATOMICAL, SALINE - OTHER"
          }]
        },
        {
          "code" : "P06010202",
          "display" : "BREAST IMPLANTS, ANATOMICAL, MADE OF SILICONE",
          "concept" : [{
            "code" : "P0601020201",
            "display" : "BREAST IMPLANTS, ANATOMICAL, MADE OF SILICONE, WITH SMOOTH SURFACE"
          },
          {
            "code" : "P0601020202",
            "display" : "BREAST IMPLANTS, ANATOMICAL, MADE OF SILICONE, WITH TEXTURED SURFACE"
          },
          {
            "code" : "P0601020299",
            "display" : "BREAST IMPLANTS, ANATOMICAL, MADE OF SILICONE - OTHER"
          }]
        }]
      },
      {
        "code" : "P060199",
        "display" : "BREAST IMPLANTS, STANDARD - OTHER"
      }]
    },
    {
      "code" : "P0602",
      "display" : "BREAST IMPLANTS, EXPANDER",
      "concept" : [{
        "code" : "P060201",
        "display" : "BREAST IMPLANTS, BECKER TYPE"
      },
      {
        "code" : "P060299",
        "display" : "BREAST IMPLANTS, EXPANDER - OTHER"
      }]
    },
    {
      "code" : "P0680",
      "display" : "BREAST IMPLANTS - ACCESSORIES"
    },
    {
      "code" : "P0699",
      "display" : "BREAST IMPLANTS - OTHER"
    }]
  },
  {
    "code" : "P07",
    "display" : "VASCULAR AND CARDIAC PROSTHESES",
    "concept" : [{
      "code" : "P0701",
      "display" : "VASCULAR PROSTHESES",
      "concept" : [{
        "code" : "P070101",
        "display" : "BIOLOGICAL VASCULAR PROSTHESES",
        "concept" : [{
          "code" : "P07010101",
          "display" : "PERICARDIUM VASCULAR PROSTHESES",
          "concept" : [{
            "code" : "P0701010101",
            "display" : "PERICARDIUM VASCULAR PROSTHESES, STRAIGHT"
          },
          {
            "code" : "P0701010102",
            "display" : "PERICARDIUM VASCULAR PROSTHESES, BIFURCATED"
          }]
        },
        {
          "code" : "P07010102",
          "display" : "HOMOLOGOUS VASCULAR PROSTHESES,",
          "concept" : [{
            "code" : "P0701010201",
            "display" : "HOMOLOGOUS VASCULAR PROSTHESES, STRAIGHT"
          },
          {
            "code" : "P0701010202",
            "display" : "HOMOLOGOUS VASCULAR PROSTHESES, BIFURCATED"
          }]
        },
        {
          "code" : "P07010199",
          "display" : "BIOLOGICAL VASCULAR PROSTHESES - OTHER"
        }]
      },
      {
        "code" : "P070102",
        "display" : "VASCULAR PROSTHESES, SYNTHETIC",
        "concept" : [{
          "code" : "P07010201",
          "display" : "DACRON VASCULAR PROSTHESES",
          "concept" : [{
            "code" : "P0701020101",
            "display" : "DACRON VASCULAR PROSTHESES, STRAIGHT",
            "concept" : [{
              "code" : "P070102010101",
              "display" : "DACRON VASCULAR PROSTHESES, STRAIGHT, KNITTED"
            },
            {
              "code" : "P070102010102",
              "display" : "DACRON VASCULAR PROSTHESES, STRAIGHT, WOVEN"
            }]
          },
          {
            "code" : "P0701020102",
            "display" : "DACRON VASCULAR PROSTHESES, MULTIFURCATED",
            "concept" : [{
              "code" : "P070102010201",
              "display" : "DACRON VASCULAR PROSTHESES, MULTIFURCATED (AORTIC ARCH (ALSO COLLATERAL AND MULTIPLE) AND THORACIC-ABDOMINAL)"
            },
            {
              "code" : "P070102010202",
              "display" : "DACRON VASCULAR PROSTHESES, WOVEN, MULTIFURCATED"
            }]
          }]
        },
        {
          "code" : "P07010202",
          "display" : "PTFE VASCULAR PROSTHESES",
          "concept" : [{
            "code" : "P0701020201",
            "display" : "PTFE VASCULAR PROSTHESES, STRAIGHT",
            "concept" : [{
              "code" : "P070102020101",
              "display" : "PTFE VASCULAR PROSTHESES, STRAIGHT, SIMPLE"
            },
            {
              "code" : "P070102020102",
              "display" : "PTFE VASCULAR PROSTHESES, STRAIGHT, REINFORCED"
            }]
          },
          {
            "code" : "P0701020202",
            "display" : "PTFE VASCULAR PROSTHESES, BIFURCATED",
            "concept" : [{
              "code" : "P070102020201",
              "display" : "PTFE VASCULAR PROSTHESES, BIFURCATED, SIMPLE"
            },
            {
              "code" : "P070102020202",
              "display" : "PTFE VASCULAR PROSTHESES, BIFURCATED, REINFORCED"
            }]
          }]
        },
        {
          "code" : "P07010299",
          "display" : "VASCULAR PROSTHESES, SYNTHETIC - OTHER"
        }]
      },
      {
        "code" : "P070180",
        "display" : "VASCULAR PROSTHESES - ACCESSORIES"
      }]
    },
    {
      "code" : "P0702",
      "display" : "VASCULAR PATCHES",
      "concept" : [{
        "code" : "P070201",
        "display" : "BIOLOGICAL VASCULAR PATCHES",
        "concept" : [{
          "code" : "P07020101",
          "display" : "PERICARDIUM VASCULAR PATCHES"
        },
        {
          "code" : "P07020102",
          "display" : "SIS (SMALL INTESTINAL SUBMUCOSA) VASCULAR PATCHES"
        },
        {
          "code" : "P07020199",
          "display" : "BIOLOGICAL VASCULAR PATCHES - OTHER"
        }]
      },
      {
        "code" : "P070202",
        "display" : "SYNTHETIC VASCULAR PATCHES",
        "concept" : [{
          "code" : "P07020201",
          "display" : "DACRON VASCULAR PATCHES"
        },
        {
          "code" : "P07020202",
          "display" : "PTFE VASCULAR PATCHES"
        },
        {
          "code" : "P07020203",
          "display" : "PET VASCULAR PATCHES"
        },
        {
          "code" : "P07020204",
          "display" : "PU VASCULAR PATCHES"
        },
        {
          "code" : "P07020299",
          "display" : "SYNTHETIC VASCULAR PATCHES - OTHER"
        }]
      }]
    },
    {
      "code" : "P0703",
      "display" : "CARDIAC VALVES",
      "concept" : [{
        "code" : "P070301",
        "display" : "BIOLOGICAL CARDIAC VALVES",
        "concept" : [{
          "code" : "P07030101",
          "display" : "BIOLOGICAL CARDIAC VALVES FOR SURGICAL IMPLANT WITH SUPPORT",
          "concept" : [{
            "code" : "P0703010101",
            "display" : "STENTED BIOLOGICAL HEART VALVES FOR SURGICAL IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN",
            "concept" : [{
              "code" : "P070301010101",
              "display" : "STENTED AORTIC BIOLOGICAL VALVES FOR SURGICAL IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301010102",
              "display" : "STENTED MITRAL BIOLOGICAL VALVES FOR SURGICAL IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301010103",
              "display" : "STENTED PULMONARY BIOLOGICAL VALVES FOR SURGICAL IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301010104",
              "display" : "STENTED TRICUSPID BIOLOGICAL VALVES FOR SURGICAL IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN"
            }]
          },
          {
            "code" : "P0703010102",
            "display" : "STENTED BIOLOGICAL HEART VALVES FOR SURGICAL IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN",
            "concept" : [{
              "code" : "P070301010201",
              "display" : "STENTED AORTIC BIOLOGICAL VALVES FOR SURGICAL IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301010202",
              "display" : "STENTED MITRAL BIOLOGICAL VALVES FOR SURGICAL IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301010203",
              "display" : "STENTED PULMONARY BIOLOGICAL VALVES FOR SURGICAL IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301010204",
              "display" : "STENTED TRICUSPID BIOLOGICAL VALVES FOR SURGICAL IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN"
            }]
          }]
        },
        {
          "code" : "P07030102",
          "display" : "STENTLESS BIOLOGICAL HEART VALVES FOR SURGICAL IMPLANT",
          "concept" : [{
            "code" : "P0703010201",
            "display" : "STENTLESS BIOLOGICAL HEART VALVES FOR SURGICAL IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN"
          },
          {
            "code" : "P0703010202",
            "display" : "STENTLESS BIOLOGICAL HEART VALVES FOR SURGICAL IMPLANT - TISSUE OF ANIMAL ORIGIN"
          }]
        },
        {
          "code" : "P07030103",
          "display" : "BIOLOGICAL HEART VALVES FOR PERCUTANEOUS IMPLANTATION, WITH SUPPORT",
          "concept" : [{
            "code" : "P0703010301",
            "display" : "STENTED BIOLOGICAL HEART VALVES FOR PERCUTANEOUS IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN",
            "concept" : [{
              "code" : "P070301030101",
              "display" : "STENTED BIOLOGICAL AORTIC VALVES FOR PERCUTANEOUS IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301030102",
              "display" : "STENTED BIOLOGICAL MITRAL VALVES FOR PERCUTANEOUS IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301030103",
              "display" : "STENTED BIOLOGICAL PULMONARY VALVES FOR PERCUTANEOUS IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301030104",
              "display" : "STENTED BIOLOGICAL TRICUSPID VALVES FOR PERCUTANEOUS IMPLANT - VALVE TISSUE OF ANIMAL ORIGIN"
            }]
          },
          {
            "code" : "P0703010302",
            "display" : "BIOLOGICAL HEART VALVES WITH SUPPORT FOR PERCUTANEOUS IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN",
            "concept" : [{
              "code" : "P070301030201",
              "display" : "STENTED BIOLOGICAL AORTIC VALVES FOR PERCUTANEOUS IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301030202",
              "display" : "STENTED BIOLOGICAL MITRAL VALVES FOR PERCUTANEOUS IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301030203",
              "display" : "STENTED BIOLOGICAL PULMONARY VALVES FOR PERCUTANEOUS IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN"
            },
            {
              "code" : "P070301030204",
              "display" : "STENTED BIOLOGICAL TRICUSPID VALVES FOR PERCUTANEOUS IMPLANT - NON-VALVE TISSUE OF ANIMAL ORIGIN"
            }]
          }]
        },
        {
          "code" : "P07030104",
          "display" : "BIOLOGICAL VALVES, BICAVAL"
        },
        {
          "code" : "P07030199",
          "display" : "BIOLOGICAL HEART VALVES - OTHER"
        }]
      },
      {
        "code" : "P070302",
        "display" : "MECHANICAL HEART VALVES",
        "concept" : [{
          "code" : "P07030201",
          "display" : "MECHANICAL HEART VALVES, BALL-VALVES"
        },
        {
          "code" : "P07030202",
          "display" : "MECHANICAL HEART VALVES, SINGLE-DISC"
        },
        {
          "code" : "P07030203",
          "display" : "MECHANICAL HEART VALVES DOUBLE-DISC",
          "concept" : [{
            "code" : "P0703020301",
            "display" : "BILEAFLET MECHANICAL AORTIC VALVES"
          },
          {
            "code" : "P0703020302",
            "display" : "BILEAFLET MECHANICAL MITRAL VALVES"
          },
          {
            "code" : "P0703020399",
            "display" : "BILEAFLET MECHANICAL HEART VALVES - OTHER"
          }]
        },
        {
          "code" : "P07030299",
          "display" : "MECHANICAL HEART VALVES - OTHER"
        }]
      },
      {
        "code" : "P070303",
        "display" : "HEART VALVE TUBES",
        "concept" : [{
          "code" : "P07030301",
          "display" : "BIOLOGICAL HEART VALVE TUBES"
        },
        {
          "code" : "P07030302",
          "display" : "MECHANICAL HEART VALVE TUBES"
        },
        {
          "code" : "P07030399",
          "display" : "HEART VALVE TUBES - OTHER"
        }]
      },
      {
        "code" : "P070304",
        "display" : "HEART VALVE RINGS",
        "concept" : [{
          "code" : "P07030401",
          "display" : "FLEXIBLE OR UNSUPPORTED HEART VALVE RINGS"
        },
        {
          "code" : "P07030402",
          "display" : "RIGID OR SEMI-RIGID HEART VALVE RINGS WITH SUPPORT"
        },
        {
          "code" : "P07030403",
          "display" : "INCOMPLETE SEMI-RIGID HEART VALVE RINGS"
        },
        {
          "code" : "P07030499",
          "display" : "HEART VALVE RINGS - OTHER"
        }]
      },
      {
        "code" : "P070380",
        "display" : "HEART VALVES - ACCESSORIES",
        "concept" : [{
          "code" : "P07038001",
          "display" : "HEART VALVE IMPLANT SIZERS"
        },
        {
          "code" : "P07038002",
          "display" : "CARDIAC VALVE TRANSCATHETER IMPLANT ACCESSORIES"
        },
        {
          "code" : "P07038003",
          "display" : "MECHANICAL HEART VALVE IMPLANT ACCESSORIES"
        },
        {
          "code" : "P07038004",
          "display" : "HEART VALVE RECONSTRUCTION IMPLANTS"
        },
        {
          "code" : "P07038099",
          "display" : "HEART VALVE ACCESSORIES - OTHER"
        }]
      },
      {
        "code" : "P070399",
        "display" : "CARDIAC VALVES - OTHER"
      }]
    },
    {
      "code" : "P0704",
      "display" : "VASCULAR AND CARDIAC ENDOPROSTHESES",
      "concept" : [{
        "code" : "P070401",
        "display" : "VASCULAR ENDOPROSTHESES",
        "concept" : [{
          "code" : "P07040101",
          "display" : "DACRON VASCULAR ENDOPROSTHESES",
          "concept" : [{
            "code" : "P0704010101",
            "display" : "DACRON VASCULAR ENDOPROSTHESES, STRAIGHT",
            "concept" : [{
              "code" : "P070401010101",
              "display" : "DACRON VASCULAR ENDOPROSTHESES, STRAIGHT - ABDOMINAL"
            },
            {
              "code" : "P070401010102",
              "display" : "DACRON VASCULAR ENDOPROSTHESES, STRAIGHT - THORACIC"
            },
            {
              "code" : "P070401010199",
              "display" : "DACRON VASCULAR ENDOPROSTHESES, STRAIGHT - OTHER"
            }]
          },
          {
            "code" : "P0704010102",
            "display" : "DACRON VASCULAR ENDOPROSTHESES, BIFURCATED"
          },
          {
            "code" : "P0704010103",
            "display" : "DACRON VASCULAR ENDOPROSTHESES, AUXILIARY"
          }]
        },
        {
          "code" : "P07040102",
          "display" : "PTFE VASCULAR ENDOPROSTHESES",
          "concept" : [{
            "code" : "P0704010201",
            "display" : "PTFE VASCULAR ENDOPROSTHESES, STRAIGHT",
            "concept" : [{
              "code" : "P070401020101",
              "display" : "PTFE VASCULAR ENDOPROSTHESES, STRAIGHT - ABDOMINAL"
            },
            {
              "code" : "P070401020102",
              "display" : "PTFE VASCULAR ENDOPROSTHESES, STRAIGHT - THORACIC"
            },
            {
              "code" : "P070401020103",
              "display" : "PTFE VASCULAR ENDOPROSTHESES, STRAIGHT - PERIPHERAL"
            },
            {
              "code" : "P070401020199",
              "display" : "PTFE VASCULAR ENDOPROSTHESES, STRAIGHT - OTHER"
            }]
          },
          {
            "code" : "P0704010202",
            "display" : "PTFE VASCULAR ENDOPROSTHESES, BIFURCATED"
          },
          {
            "code" : "P0704010203",
            "display" : "PTFE VASCULAR ENDOPROSTHESES, AUXILIARY"
          }]
        },
        {
          "code" : "P07040199",
          "display" : "VASCULAR ENDOPROSTHESES - OTHER"
        }]
      },
      {
        "code" : "P070402",
        "display" : "VASCULAR STENTS",
        "concept" : [{
          "code" : "P07040201",
          "display" : "CORONARY STENTS",
          "concept" : [{
            "code" : "P0704020101",
            "display" : "CORONARY BARE METAL STENTS (BMS)",
            "concept" : [{
              "code" : "P070402010101",
              "display" : "STAINLESS STEEL CORONARY BARE METAL STENTS (BMS)"
            },
            {
              "code" : "P070402010102",
              "display" : "METALLIC NON-STAINLESS STEEL CORONARY STENTS"
            },
            {
              "code" : "P070402010199",
              "display" : "CORONARY BARE METAL STENTS (BMS) - OTHER"
            }]
          },
          {
            "code" : "P0704020102",
            "display" : "COATED CORONARY STENTS"
          },
          {
            "code" : "P0704020103",
            "display" : "CORONARY DRUG ELUTING STENTS (DES)",
            "concept" : [{
              "code" : "P070402010301",
              "display" : "CORONARY DRUG ELUTING STENTS (DES) WITH POLYMERS"
            },
            {
              "code" : "P070402010302",
              "display" : "CORONARY DRUG ELUTING STENTS (DES) WITHOUT POLYMERS"
            }]
          },
          {
            "code" : "P0704020104",
            "display" : "CORONARY STENTS, ABSORBABLE"
          },
          {
            "code" : "P0704020105",
            "display" : "CORONARY STENTS, BIOACTIVE"
          },
          {
            "code" : "P0704020199",
            "display" : "CORONARY STENTS - OTHER"
          }]
        },
        {
          "code" : "P07040202",
          "display" : "PERIPHERAL VASCULAR STENTS",
          "concept" : [{
            "code" : "P0704020201",
            "display" : "PERIPHERAL VASCULAR STENTS, BMS",
            "concept" : [{
              "code" : "P070402020101",
              "display" : "STAINLESS STEEL PERIPHERAL VASCULAR BARE METAL STENTS"
            },
            {
              "code" : "P070402020102",
              "display" : "NON-STAINLESS STEEL PERIPHERAL VASCULAR BARE METAL STENTS"
            },
            {
              "code" : "P070402020199",
              "display" : "PERIPHERAL VASCULAR BARE STENTS - OTHER"
            }]
          },
          {
            "code" : "P0704020202",
            "display" : "PERIPHERAL VASCULAR COATED STENTS"
          },
          {
            "code" : "P0704020203",
            "display" : "PERIPHERAL VASCULAR DRUG ELUTING STENTS (DES)"
          },
          {
            "code" : "P0704020204",
            "display" : "PERIPHERAL VASCULAR STENTS, BIOACTIVE"
          },
          {
            "code" : "P0704020299",
            "display" : "PERIPHERAL VASCULAR STENTS - OTHER"
          }]
        }]
      },
      {
        "code" : "P070403",
        "display" : "CARDIAC AND CORONARY DEFECT OCCLUDERS",
        "concept" : [{
          "code" : "P07040301",
          "display" : "CARDIAC OCCLUDERS, VENTRICULAR SEPTAL DEFECTS"
        },
        {
          "code" : "P07040302",
          "display" : "CARDIAC OCCLUDERS, ATRIAL SEPTAL DEFECTS"
        },
        {
          "code" : "P07040303",
          "display" : "CARDIAC OCCLUDERS, FORAMEN OVALE AND BOTALLO DUCT"
        },
        {
          "code" : "P07040399",
          "display" : "HEART AND CORONARY DEFECT OCCLUDERS - OTHER"
        }]
      },
      {
        "code" : "P070404",
        "display" : "LEFT ATRIAL APPENDAGE OCCLUDERS"
      }]
    },
    {
      "code" : "P0780",
      "display" : "VASCULAR AND CARDIAC PROSTHESES - ACCESSORIES"
    },
    {
      "code" : "P0799",
      "display" : "VASCULAR AND CARDIAC PROSTHESES - OTHER"
    }]
  },
  {
    "code" : "P08",
    "display" : "UROGENITAL PROSTHESES",
    "concept" : [{
      "code" : "P0801",
      "display" : "URINARY INCONTINENCE PROSTHESES",
      "concept" : [{
        "code" : "P080102",
        "display" : "ARTIFICIAL URINARY SPHINCTERS"
      },
      {
        "code" : "P080199",
        "display" : "URINARY INCONTINENCE PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0802",
      "display" : "MALE GENITAL SYSTEM PROSTHESES",
      "concept" : [{
        "code" : "P080201",
        "display" : "TESTICLE PROSTHESES"
      },
      {
        "code" : "P080202",
        "display" : "PENILE PROSTHESES"
      },
      {
        "code" : "P080299",
        "display" : "MALE GENITAL SYSTEM PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0803",
      "display" : "URINARY OBSTRUCTION PROSTHESES",
      "concept" : [{
        "code" : "P080301",
        "display" : "URETHRAL PROSTHESES",
        "concept" : [{
          "code" : "P08030101",
          "display" : "TRANS-PROSTATIC URETHRAL PROSTHESES"
        },
        {
          "code" : "P08030102",
          "display" : "VAS DEFERENS PROSTHESES"
        },
        {
          "code" : "P08030199",
          "display" : "ENDOURETHRAL PROSTHESES - OTHER"
        }]
      },
      {
        "code" : "P080302",
        "display" : "URETERAL PROSTHESES"
      },
      {
        "code" : "P080399",
        "display" : "URINARY OBSTRUCTION PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0804",
      "display" : "FEMALE GENITAL SYSTEM PROSTHESES",
      "concept" : [{
        "code" : "P080401",
        "display" : "FALLOPIAN TUBE PROSTHESES"
      },
      {
        "code" : "P080499",
        "display" : "FEMALE GENITAL SYSTEM PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0805",
      "display" : "URINARY TRACT IMPLANTABLE VALVES"
    },
    {
      "code" : "P0880",
      "display" : "UROGENITAL PROSTHESES - ACCESSORIES"
    },
    {
      "code" : "P0899",
      "display" : "UROGENITAL PROSTHESES - OTHER"
    }]
  },
  {
    "code" : "P09",
    "display" : "ORTHOPAEDIC PROSTHESES, OSTEOSYNTHESIS DEVICES, DEVICES FOR TENDON AND LIGAMENT SYNTHESIS",
    "concept" : [{
      "code" : "P0901",
      "display" : "SHOULDER PROSTHESES",
      "concept" : [{
        "code" : "P090103",
        "display" : "GLENOID COMPONENTS",
        "concept" : [{
          "code" : "P09010301",
          "display" : "METAL BACK AND METAGLENE GLENOID BASEPLATES"
        },
        {
          "code" : "P09010302",
          "display" : "ANATOMICAL SHOULDER PROSTHESIS INSERTS"
        },
        {
          "code" : "P09010303",
          "display" : "GLENOSPHERES"
        },
        {
          "code" : "P09010304",
          "display" : "MONOBLOCK GLENOIDS"
        },
        {
          "code" : "P09010399",
          "display" : "GLENOID COMPONENTS - OTHER"
        }]
      },
      {
        "code" : "P090104",
        "display" : "SHOULDER PROSTHESES HUMERAL COMPONENTS",
        "concept" : [{
          "code" : "P09010401",
          "display" : "EPIPHYSARY HUMERAL COMPONENTS",
          "concept" : [{
            "code" : "P0901040101",
            "display" : "EPIPHYSARY HUMERAL COMPONENTS FOR ANATOMICAL PROSTHESES",
            "concept" : [{
              "code" : "P090104010101",
              "display" : "EPIPHYSARY HUMERAL COMPONENTS FOR ANATOMICAL PROSTHESES - HUMERAL HEADS"
            },
            {
              "code" : "P090104010102",
              "display" : "EPIPHYSARY HUMERAL COMPONENTS FOR RESURFACING ANATOMICAL PROSTHESES"
            }]
          },
          {
            "code" : "P0901040102",
            "display" : "EPIPHYSARY HUMERAL COMPONENTS FOR REVERSE PROSTHESES",
            "concept" : [{
              "code" : "P090104010201",
              "display" : "EPIPHYSARY HUMERAL COMPONENTS FOR REVERSE PROSTHESES - INSERTS"
            },
            {
              "code" : "P090104010202",
              "display" : "EPIPHYSARY HUMERAL COMPONENTS FOR REVERSE PROSTHESES - HUMERAL CUPS"
            }]
          },
          {
            "code" : "P0901040199",
            "display" : "EPIPHYSARY HUMERAL COMPONENTS - OTHER"
          }]
        },
        {
          "code" : "P09010402",
          "display" : "DIAPHYSARY HUMERAL COMPONENTS",
          "concept" : [{
            "code" : "P0901040201",
            "display" : "SHOULDER PROSTHESES NON MODULAR STEMS"
          },
          {
            "code" : "P0901040202",
            "display" : "SHOULDER PROSTHESES MODULAR STEMS"
          },
          {
            "code" : "P0901040203",
            "display" : "MONOBLOCK DIAPHYSARY HUMERAL COMPONENTS (STEM + EPIPHYSARY COMPONENT)",
            "concept" : [{
              "code" : "P090104020301",
              "display" : "MONOBLOCK DIAPHYSARY HUMERAL COMPONENTS FOR ANATOMICAL PROSTHESIS (STEM + HEAD)"
            },
            {
              "code" : "P090104020302",
              "display" : "MONOBLOCK DIAPHYSARY HUMERAL COMPONENTS FOR REVERSE PROSTHESIS (STEM + CUP)"
            }]
          },
          {
            "code" : "P0901040204",
            "display" : "SHOULDER PROSTHESES REVISION STEMS"
          },
          {
            "code" : "P0901040205",
            "display" : "SHOULDER PROSTHESES LARGE RESECTIONS STEMS"
          },
          {
            "code" : "P0901040299",
            "display" : "DIAPHYSARY HUMERAL COMPONENTS - OTHER"
          }]
        },
        {
          "code" : "P09010403",
          "display" : "SHOULDER PROSTHESES SPACERS"
        },
        {
          "code" : "P09010499",
          "display" : "HUMERAL COMPONENTS FOR SHOULDER PROSTHESES - OTHER"
        }]
      },
      {
        "code" : "P090180",
        "display" : "SHOULDER PROSTHESES - ACCESSORIES",
        "concept" : [{
          "code" : "P09018001",
          "display" : "SHOULDER PROSTHESES FIXING SCREWS"
        },
        {
          "code" : "P09018002",
          "display" : "SHOULDER PROSTHESES ADAPTERS (INCLUDING CONES AND SLEEVES)",
          "concept" : [{
            "code" : "P0901800201",
            "display" : "GLENOID COMPONENTS ADAPTERS"
          },
          {
            "code" : "P0901800202",
            "display" : "HUMERAL COMPONENTS ADAPTERS"
          }]
        },
        {
          "code" : "P09018003",
          "display" : "SHOULDER PROSTHESES ENDOMIDOLLAR CAPS"
        },
        {
          "code" : "P09018099",
          "display" : "SHOULDER PROSTHESES - ACCESSORIES - OTHER"
        }]
      },
      {
        "code" : "P090199",
        "display" : "SHOULDER PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0902",
      "display" : "ELBOW PROSTHESES",
      "concept" : [{
        "code" : "P090203",
        "display" : "ELBOW PROSTHESES HUMERAL COMPONENTS"
      },
      {
        "code" : "P090204",
        "display" : "ELBOW PROSTHESES RADIAL COMPONENTS"
      },
      {
        "code" : "P090205",
        "display" : "ELBOW PROSTHESES ULNAR COMPONENTS"
      },
      {
        "code" : "P090280",
        "display" : "ELBOW PROSTHESES - ACCESSORIES"
      },
      {
        "code" : "P090299",
        "display" : "ELBOW PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0903",
      "display" : "WRIST PROSTHESES",
      "concept" : [{
        "code" : "P090303",
        "display" : "WRIST PROSTHESES CARPAL COMPONENTS"
      },
      {
        "code" : "P090304",
        "display" : "WRIST PROSTHESES RADIAL-ULNAR COMPONENTS",
        "concept" : [{
          "code" : "P09030401",
          "display" : "WRIST PROSTHESES RADIAL COMPONENTS"
        },
        {
          "code" : "P09030402",
          "display" : "WRIST PROSTHESES ULNAR COMPONENTS"
        }]
      },
      {
        "code" : "P090305",
        "display" : "TOTAL WRIST PROSTHESES"
      },
      {
        "code" : "P090380",
        "display" : "WRIST PROSTHESES - ACCESSORIES"
      },
      {
        "code" : "P090399",
        "display" : "WRIST PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0904",
      "display" : "HAND PROSTHESES",
      "concept" : [{
        "code" : "P090403",
        "display" : "HAND PROSTHESES INTERPHALANGE COMPONENTS"
      },
      {
        "code" : "P090404",
        "display" : "HAND PROSTHESES TRAPEZIO-METACARPAL COMPONENTS"
      },
      {
        "code" : "P090480",
        "display" : "HAND PROSTHESES - ACCESSORIES"
      },
      {
        "code" : "P090499",
        "display" : "HAND PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0905",
      "display" : "ANKLE PROSTHESES",
      "concept" : [{
        "code" : "P090506",
        "display" : "ANKLE PROSTHESIS WITH MOBILE INSERT",
        "concept" : [{
          "code" : "P09050601",
          "display" : "ANKLE PROSTHESES WITH CEMENTED MOBILE INSERT",
          "concept" : [{
            "code" : "P0905060101",
            "display" : "ANKLE PROSTHESES WITH CEMENTED MOBILE INSERT - TIBIAL COMPONENTS"
          },
          {
            "code" : "P0905060102",
            "display" : "ANKLE PROSTHESES WITH CEMENTED MOBILE INSERT - TALAR COMPONENTS"
          }]
        },
        {
          "code" : "P09050602",
          "display" : "ANKLE PROSTHESES WITH UNCEMENTED MOBILE INSERT",
          "concept" : [{
            "code" : "P0905060201",
            "display" : "ANKLE PROSTHESES WITH UNCEMENTED MOBILE INSERT - TIBIAL COMPONENTS"
          },
          {
            "code" : "P0905060202",
            "display" : "ANKLE PROSTHESES WITH UNCEMENTED MOBILE INSERT - TALAR COMPONENTS"
          }]
        },
        {
          "code" : "P09050603",
          "display" : "ANKLE PROSTHESES MOBILE INSERTS"
        }]
      },
      {
        "code" : "P090507",
        "display" : "ANKLE PROSTHESIS WITH FIXED INSERT",
        "concept" : [{
          "code" : "P09050701",
          "display" : "ANKLE PROSTHESES WITH CEMENTED FIXED INSERT",
          "concept" : [{
            "code" : "P0905070101",
            "display" : "ANKLE PROSTHESES WITH CEMENTED FIXED INSERT - TIBIAL COMPONENTS"
          },
          {
            "code" : "P0905070102",
            "display" : "ANKLE PROSTHESES WITH CEMENTED FIXED INSERT - TALAR COMPONENTS"
          }]
        },
        {
          "code" : "P09050702",
          "display" : "ANKLE PROSTHESES WITH UNCEMENTED FIXED INSERT",
          "concept" : [{
            "code" : "P0905070201",
            "display" : "ANKLE PROSTHESES WITH UNCEMENTED FIXED INSERT - TIBIAL COMPONENTS"
          },
          {
            "code" : "P0905070202",
            "display" : "ANKLE PROSTHESES WITH UNCEMENTED FIXED INSERT - TALAR COMPONENTS"
          }]
        },
        {
          "code" : "P09050703",
          "display" : "ANKLE PROSTHESES FIXED INSERTS"
        }]
      },
      {
        "code" : "P090508",
        "display" : "ANKLE PROSTHESES SPACERS"
      },
      {
        "code" : "P090580",
        "display" : "ANKLE PROSTHESES - ACCESSORIES",
        "concept" : [{
          "code" : "P09058001",
          "display" : "ANKLE PROSTHESES TIBIAL STEMS"
        },
        {
          "code" : "P09058099",
          "display" : "ANKLE PROSTHESES - ACCESSORIES - OTHER"
        }]
      },
      {
        "code" : "P090599",
        "display" : "ANKLE PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0906",
      "display" : "FOOT PROSTHESES",
      "concept" : [{
        "code" : "P090603",
        "display" : "FOOT PROSTHESES INTERPHALANGEAL COMPONENTS"
      },
      {
        "code" : "P090604",
        "display" : "FOOT PROSTHESES METATARSALPHALANGEAL COMPONENTS"
      },
      {
        "code" : "P090605",
        "display" : "FOOT ENDORTHESIS"
      },
      {
        "code" : "P090680",
        "display" : "FOOT PROSTHESES - ACCESSORIES"
      },
      {
        "code" : "P090699",
        "display" : "FOOT PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0907",
      "display" : "SPINE STABILISATION PROSTHESES AND SYSTEMS",
      "concept" : [{
        "code" : "P090701",
        "display" : "SPINAL FUSION SYSTEMS",
        "concept" : [{
          "code" : "P09070101",
          "display" : "SPINAL CAGES"
        },
        {
          "code" : "P09070199",
          "display" : "SPINAL FUSION SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "P090702",
        "display" : "INTERVERTEBRAL DISCS REPLACEMENT SYSTEMS",
        "concept" : [{
          "code" : "P09070201",
          "display" : "DISC PROSTHESES"
        }]
      },
      {
        "code" : "P090703",
        "display" : "IMPLANTABLE VERTEBRAL STABILISATION OR FIXATION SYSTEMS",
        "concept" : [{
          "code" : "P09070301",
          "display" : "CERVICAL FIXATION SYSTEMS"
        },
        {
          "code" : "P09070302",
          "display" : "THORACOLUMBOSACRAL FIXATION SYSTEMS"
        },
        {
          "code" : "P09070304",
          "display" : "SPINE FIXATION SYSTEM CONNECTORS"
        },
        {
          "code" : "P09070305",
          "display" : "SPINAL STABILISERS, DYNAMIC TYPE"
        },
        {
          "code" : "P09070399",
          "display" : "IMPLANTABLE SPINAL STABILISATION OR FIXATION SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "P090780",
        "display" : "SPINAL PROSTHESES AND STABILISATION SYSTEMS - ACCESSORIES"
      },
      {
        "code" : "P090799",
        "display" : "SPINAL PROSTHESES AND STABILISATION SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "P0908",
      "display" : "HIP PROSTHESES",
      "concept" : [{
        "code" : "P090803",
        "display" : "HIP PROSTHESES ACETABULAR COMPONENTS",
        "concept" : [{
          "code" : "P09080301",
          "display" : "PRIMARY IMPLANT ACETABULAR CUPS",
          "concept" : [{
            "code" : "P0908030101",
            "display" : "PRIMARY IMPLANT CEMENTED ACETABULAR CUPS",
            "concept" : [{
              "code" : "P090803010101",
              "display" : "PRIMARY IMPLANT CEMENTED METAL ACETABULAR CUPS"
            },
            {
              "code" : "P090803010102",
              "display" : "PRIMARY IMPLANT CEMENTED POLYETHYLENE ACETABULAR CUPS, ONE-PIECE"
            },
            {
              "code" : "P090803010199",
              "display" : "PRIMARY IMPLANT CEMENTED ACETABULAR CUPS - OTHER"
            }]
          },
          {
            "code" : "P0908030102",
            "display" : "PRIMARY IMPLANT UNCEMENTED ACETABULAR CUPS",
            "concept" : [{
              "code" : "P090803010201",
              "display" : "PRIMARY IMPLANT UNCEMENTED METAL ACETABULAR CUPS"
            },
            {
              "code" : "P090803010202",
              "display" : "PRIMARY IMPLANT UNCEMENTED ONE-PIECE POLYETHYLENE ACETABULAR CUPS"
            },
            {
              "code" : "P090803010203",
              "display" : "PRIMARY IMPLANT UNCEMENTED ONE-PIECE METAL ACETABULAR CUPS"
            },
            {
              "code" : "P090803010299",
              "display" : "PRIMARY IMPLANT UNCEMENTED ACETABULAR CUPS - OTHER"
            }]
          }]
        },
        {
          "code" : "P09080302",
          "display" : "HIP RESURFACING ACETABULAR COMPONENTS"
        },
        {
          "code" : "P09080303",
          "display" : "REVISION SURGERY ACETABULAR CUPS",
          "concept" : [{
            "code" : "P0908030301",
            "display" : "REVISION SURGERY CEMENTED ACETABULAR CUPS"
          },
          {
            "code" : "P0908030302",
            "display" : "REVISION SURGERY UNCEMENTED ACETABULAR CUPS"
          }]
        },
        {
          "code" : "P09080304",
          "display" : "HIP PROSTHESES ACETABULAR INSERTS",
          "concept" : [{
            "code" : "P0908030401",
            "display" : "HIP PROSTHESES POLYETHYLENE ACETABULAR INSERTS",
            "concept" : [{
              "code" : "P090803040101",
              "display" : "STANDARD POLYETHYLENE HIP PROSTHESES INSERTS"
            },
            {
              "code" : "P090803040102",
              "display" : "ECCENTRIC POLYETHYLENE HIP PROSTHESES INSERTS"
            },
            {
              "code" : "P090803040103",
              "display" : "RETENTIVE POLYETHYLENE HIP PROSTHESES INSERTS, ANTI-DISLOCATION"
            }]
          },
          {
            "code" : "P0908030402",
            "display" : "HIP PROSTHESES CERAMIC ACETABULAR INSERTS"
          },
          {
            "code" : "P0908030403",
            "display" : "HIP PROSTHESES METAL ACETABULAR INSERTS"
          },
          {
            "code" : "P0908030499",
            "display" : "HIP PROSTHESES ACETABULAR INSERTS - OTHER"
          }]
        },
        {
          "code" : "P09080305",
          "display" : "DUAL-MOBILITY ACETABULAR COMPONENTS",
          "concept" : [{
            "code" : "P0908030501",
            "display" : "DOUBLE-MOBILITY ACETABULAR CUPS",
            "concept" : [{
              "code" : "P090803050101",
              "display" : "CEMENTED DOUBLE-MOBILITY ACETABULAR CUPS"
            },
            {
              "code" : "P090803050102",
              "display" : "UNCEMENTED DOUBLE-MOBILITY ACETABULAR CUPS"
            }]
          },
          {
            "code" : "P0908030502",
            "display" : "DOUBLE-MOBILITY ACETABULAR COMPONENTS INSERTS"
          }]
        },
        {
          "code" : "P09080306",
          "display" : "PRE-ASSEMBLED ACETABULAR COMPONENTS (ACETABULAR CUP + INSERT)",
          "concept" : [{
            "code" : "P0908030601",
            "display" : "PRE-ASSEMBLED ACETABULAR COMPONENTS WITH CERAMIC INSERT"
          },
          {
            "code" : "P0908030602",
            "display" : "PRE-ASSEMBLED ACETABULAR COMPONENTS WITH POLYETHYLENE INSERTS"
          },
          {
            "code" : "P0908030699",
            "display" : "PRE-ASSEMBLED ACETABULAR COMPONENTS - OTHER"
          }]
        }]
      },
      {
        "code" : "P090804",
        "display" : "HIP PROSTHESES FEMORAL COMPONENTS",
        "concept" : [{
          "code" : "P09080401",
          "display" : "PRIMARY IMPLANT FEMORAL STEMS",
          "concept" : [{
            "code" : "P0908040101",
            "display" : "PRIMARY IMPLANT CEMENTED FEMORAL STEMS",
            "concept" : [{
              "code" : "P090804010101",
              "display" : "CEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH FIXED NECK, STRAIGHT"
            },
            {
              "code" : "P090804010102",
              "display" : "CEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH FIXED NECK, ANATOMICAL"
            },
            {
              "code" : "P090804010105",
              "display" : "CEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH FIXED NECK, FOR PRESERVATION"
            },
            {
              "code" : "P090804010106",
              "display" : "CEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH MODULAR NECK, STRAIGHT"
            },
            {
              "code" : "P090804010107",
              "display" : "CEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH MODULAR NECK, ANATOMICAL"
            }]
          },
          {
            "code" : "P0908040102",
            "display" : "PRIMARY IMPLANT UNCEMENTED FEMORAL STEMS",
            "concept" : [{
              "code" : "P090804010201",
              "display" : "UNCEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH FIXED NECK, STRAIGHT"
            },
            {
              "code" : "P090804010202",
              "display" : "UNCEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH FIXED NECK, ANATOMICAL"
            },
            {
              "code" : "P090804010205",
              "display" : "UNCEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH FIXED NECK, FOR PRESERVATION"
            },
            {
              "code" : "P090804010206",
              "display" : "UNCEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH MODULAR NECK, STRAIGHT"
            },
            {
              "code" : "P090804010207",
              "display" : "UNCEMENTED FEMORAL STEMS FOR PRIMARY IMPLANT, WITH MODULAR NECK, ANATOMICAL"
            }]
          }]
        },
        {
          "code" : "P09080402",
          "display" : "HIP RESURFACING FEMORAL COMPONENTS"
        },
        {
          "code" : "P09080403",
          "display" : "REVISION SURGERY FEMORAL STEMS",
          "concept" : [{
            "code" : "P0908040301",
            "display" : "REVISION SURGERY CEMENTED FEMORAL STEMS",
            "concept" : [{
              "code" : "P090804030101",
              "display" : "REVISION CEMENTED FEMORAL STEMS, WITH FIXED NECK"
            },
            {
              "code" : "P090804030102",
              "display" : "REVISION CEMENTED FEMORAL STEMS, WITH MODULAR NECK"
            }]
          },
          {
            "code" : "P0908040302",
            "display" : "REVISION UNCEMENTED FEMORAL STEMS",
            "concept" : [{
              "code" : "P090804030201",
              "display" : "REVISION UNCEMENTED FEMORAL STEMS, WITH FIXED NECK"
            },
            {
              "code" : "P090804030202",
              "display" : "REVISION UNCEMENTED FEMORAL STEMS, WITH MODULAR NECK"
            }]
          }]
        },
        {
          "code" : "P09080404",
          "display" : "LARGE RESECTIONS FEMORAL STEMS"
        },
        {
          "code" : "P09080405",
          "display" : "FEMORAL HEADS",
          "concept" : [{
            "code" : "P0908040501",
            "display" : "FEMORAL HEADS FOR PRIMARY IMPLANT OF PARTIAL PROSTHESES",
            "concept" : [{
              "code" : "P090804050101",
              "display" : "CERAMIC FEMORAL HEADS, PARTIAL HIP REPLACEMENT"
            },
            {
              "code" : "P090804050102",
              "display" : "METAL FEMORAL HEADS, PARTIAL HIP REPLACEMENT"
            },
            {
              "code" : "P090804050199",
              "display" : "FEMORAL HEADS FOR PRIMARY IMPLANT OF PARTIAL PROSTHESES - OTHER"
            }]
          },
          {
            "code" : "P0908040502",
            "display" : "FEMORAL HEADS FOR PRIMARY IMPLANT OF TOTAL PROSTHESES",
            "concept" : [{
              "code" : "P090804050201",
              "display" : "CERAMIC FEMORAL HEADS, TOTAL HIP REPLACEMENT"
            },
            {
              "code" : "P090804050202",
              "display" : "METAL FEMORAL HEADS, TOTAL HIP REPLACEMENT"
            },
            {
              "code" : "P090804050299",
              "display" : "FEMORAL HEADS FOR PRIMARY IMPLANT OF TOTAL PROSTHESES - OTHER"
            }]
          },
          {
            "code" : "P0908040503",
            "display" : "HIP PROSTHESES, BI-ARTICULAR CUPS"
          },
          {
            "code" : "P0908040504",
            "display" : "REVISION FEMORAL HEADS"
          }]
        },
        {
          "code" : "P09080406",
          "display" : "ONE-PIECE FEMORAL PROSTHESES (STEM+HEAD)"
        },
        {
          "code" : "P09080407",
          "display" : "MODULAR NECKS"
        }]
      },
      {
        "code" : "P090805",
        "display" : "HIP PROSTHESES SPACERS"
      },
      {
        "code" : "P090880",
        "display" : "HIP PROSTHESES - ACCESSORIES",
        "concept" : [{
          "code" : "P09088001",
          "display" : "ACETABULAR RINGS"
        },
        {
          "code" : "P09088002",
          "display" : "ACETABULAR MESHES"
        },
        {
          "code" : "P09088003",
          "display" : "HIP PROSTHESES AUGMENTS"
        },
        {
          "code" : "P09088004",
          "display" : "HIP PROSTHESES ADAPTERS (INCLUDING CONES AND SLEEVES)"
        },
        {
          "code" : "P09088005",
          "display" : "HIP PROSTHESES CENTRALIZERS"
        },
        {
          "code" : "P09088006",
          "display" : "FEMORAL INTRAMEDULLARY CAPS"
        },
        {
          "code" : "P09088007",
          "display" : "HIP PROSTHESES FIXING SCREWS"
        },
        {
          "code" : "P09088099",
          "display" : "HIP PROSTHESES - OTHER ACCESSORIES"
        }]
      },
      {
        "code" : "P090899",
        "display" : "HIP PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0909",
      "display" : "KNEE PROSTHESES",
      "concept" : [{
        "code" : "P090903",
        "display" : "BICOMPARTMENTAL PRIMARY IMPLANT KNEE PROSTHESES",
        "concept" : [{
          "code" : "P09090301",
          "display" : "BICOMPARTMENTAL PRIMARY IMPLANT FEMORAL COMPONENTS",
          "concept" : [{
            "code" : "P0909030101",
            "display" : "BICOMPARTMENTAL PRIMARY IMPLANT CEMENTED FEMORAL COMPONENTS"
          },
          {
            "code" : "P0909030102",
            "display" : "BICOMPARTMENTAL PRIMARY IMPLANT UNCEMENTED FEMORAL COMPONENTS"
          },
          {
            "code" : "P0909030103",
            "display" : "BICOMPARTMENTAL PRIMARY IMPLANT CEMENTABLE FEMORAL COMPONENTS"
          }]
        },
        {
          "code" : "P09090302",
          "display" : "BICOMPARTMENTAL PRIMARY IMPLANT TIBIAL COMPONENTS",
          "concept" : [{
            "code" : "P0909030201",
            "display" : "BICOMPARTMENTAL PRIMARY IMPLANT TIBIAL PLATES",
            "concept" : [{
              "code" : "P090903020101",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT CEMENTED MOBILE BEARING TIBIAL PLATES"
            },
            {
              "code" : "P090903020102",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT UNCEMENTED MOBILE BEARING TIBIAL PLATES"
            },
            {
              "code" : "P090903020103",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT CEMENTABLE MOBILE BEARING TIBIAL PLATES"
            },
            {
              "code" : "P090903020104",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT CEMENTED FIXED BEARING TIBIAL PLATES"
            },
            {
              "code" : "P090903020105",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT UNCEMENTED FIXED BEARING TIBIAL PLATES"
            },
            {
              "code" : "P090903020106",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT CEMENTABLE FIXED BEARING TIBIAL PLATES"
            }]
          },
          {
            "code" : "P0909030202",
            "display" : "BICOMPARTMENTAL PRIMARY IMPLANT TIBIAL INSERTS",
            "concept" : [{
              "code" : "P090903020201",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT MOBILE BEARING TIBIAL INSERTS"
            },
            {
              "code" : "P090903020202",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT FIXED BEARING TIBIAL INSERTS"
            }]
          },
          {
            "code" : "P0909030203",
            "display" : "BICOMPARTMENTAL PRIMARY IMPLANT TIBIAL COMPONENTS, MONOBLOCK",
            "concept" : [{
              "code" : "P090903020301",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT TIBIAL COMPONENTS, MONOBLOCK MADE OF POLYETHYLENE"
            },
            {
              "code" : "P090903020399",
              "display" : "BICOMPARTMENTAL PRIMARY IMPLANT TIBIAL COMPONENTS, MONOBLOCK - OTHER"
            }]
          }]
        }]
      },
      {
        "code" : "P090904",
        "display" : "UNICOMPARTMENTAL KNEE PROSTHESES (UNICONDYLAR)",
        "concept" : [{
          "code" : "P09090401",
          "display" : "UNICOMPARTMENTAL KNEE PROSTHESES FEMORAL COMPONENTS (UNICONDYLAR)",
          "concept" : [{
            "code" : "P0909040101",
            "display" : "UNICOMPARTMENTAL KNEE PROSTHESES FEMORAL COMPONENTS (UNICONDYLAR), CEMENTED"
          },
          {
            "code" : "P0909040102",
            "display" : "UNICOMPARTMENTAL KNEE PROSTHESES FEMORAL COMPONENTS (UNICONDYLAR), UNCEMENTED"
          }]
        },
        {
          "code" : "P09090402",
          "display" : "UNICOMPARTMENTAL KNEE PROSTHESES TIBIAL COMPONENTS",
          "concept" : [{
            "code" : "P0909040201",
            "display" : "UNICOMPARTMENTAL KNEE PROSTHESES TIBIAL PLATES",
            "concept" : [{
              "code" : "P090904020101",
              "display" : "MOBILE CEMENTED UNICOMPARTMENTAL PRIMARY IMPLANT TIBIAL PLATES"
            },
            {
              "code" : "P090904020102",
              "display" : "MOBILE UNCEMENTED UNICOMPARTMENTAL PRIMARY IMPLANT TIBIAL PLATES"
            },
            {
              "code" : "P090904020103",
              "display" : "FIXED CEMENTED UNICOMPARTMENTAL PRIMARY IMPLANT TIBIAL PLATES"
            },
            {
              "code" : "P090904020104",
              "display" : "FIXED UNCEMENTED UNICOMPARTMENTAL PRIMARY IMPLANT TIBIAL PLATES"
            }]
          },
          {
            "code" : "P0909040202",
            "display" : "UNICOMPARTMENTAL KNEE REPLACEMENT TIBIAL INSERTS",
            "concept" : [{
              "code" : "P090904020201",
              "display" : "MOBILE UNICOMPARTMENTAL KNEE PROSTHESES TIBIAL INSERTS"
            },
            {
              "code" : "P090904020202",
              "display" : "UNICOMPARTMENTAL KNEE PROSTHESES TIBIAL INSERTS, FIXED"
            }]
          },
          {
            "code" : "P0909040203",
            "display" : "PRE-ASSEMBLED UNICOMPARTMENTAL KNEE PROSTHESES TIBIAL COMPONENTS (INSERT + TIBIAL PLATE)",
            "concept" : [{
              "code" : "P090904020301",
              "display" : "KNEE PROSTHESES TIBIAL COMPONENTS, PREASSEMBLED, CEMENTED"
            },
            {
              "code" : "P090904020302",
              "display" : "UNICOMPARTMENTAL KNEE PROSTHESES TIBIAL COMPONENTS, PREASSEMBLED, UNCEMENTED"
            }]
          },
          {
            "code" : "P0909040204",
            "display" : "UNICOMPARTMENTAL KNEE PROSTHESES TIBIAL COMPONENTS, MONOBLOCK",
            "concept" : [{
              "code" : "P090904020401",
              "display" : "UNICOMPARTMENTAL KNEE PROSTHESES TIBIAL COMPONENTS, MONOBLOCK, MADE OF POLYETHYLENE"
            },
            {
              "code" : "P090904020499",
              "display" : "UNICOMPARTMENTAL KNEE PROSTHESES TIBIAL COMPONENTS, MONOBLOCK - OTHER"
            }]
          }]
        }]
      },
      {
        "code" : "P090905",
        "display" : "REVISION KNEE PROSTHESES",
        "concept" : [{
          "code" : "P09090501",
          "display" : "REVISION KNEE PROSTHESES FEMORAL COMPONENTS"
        },
        {
          "code" : "P09090502",
          "display" : "REVISION KNEE PROSTHESES TIBIAL COMPONENTS",
          "concept" : [{
            "code" : "P0909050201",
            "display" : "REVISION KNEE PROSTHESES TIBIAL PLATES",
            "concept" : [{
              "code" : "P090905020101",
              "display" : "REVISION KNEE PROSTHESES MOBILE BEARING TIBIAL PLATES"
            },
            {
              "code" : "P090905020102",
              "display" : "REVISION KNEE PROSTHESES FIXED BEARING TIBIAL PLATES"
            }]
          },
          {
            "code" : "P0909050202",
            "display" : "REVISION KNEE PROSTHESES TIBIAL INSERTS",
            "concept" : [{
              "code" : "P090905020201",
              "display" : "REVISION KNEE PROSTHESES MOBILE BEARING TIBIAL INSERTS"
            },
            {
              "code" : "P090905020202",
              "display" : "REVISION KNEE PROSTHESES FIXED BEARING TIBIAL INSERTS"
            }]
          }]
        }]
      },
      {
        "code" : "P090906",
        "display" : "KNEE PROSTHESES FOR LARGE RESECTIONS"
      },
      {
        "code" : "P090907",
        "display" : "PATELLO-FEMORAL KNEE PROSTHESES",
        "concept" : [{
          "code" : "P09090701",
          "display" : "FEMORAL TROCHLEA RESURFACING COMPONENTS"
        },
        {
          "code" : "P09090702",
          "display" : "PATELLAR COMPONENTS",
          "concept" : [{
            "code" : "P0909070201",
            "display" : "PATELLAR COMPONENTS, MONOBLOCK"
          },
          {
            "code" : "P0909070202",
            "display" : "PATELLAR COMPONENTS, MODULAR"
          }]
        }]
      },
      {
        "code" : "P090908",
        "display" : "KNEE PROSTHESES SPACERS"
      },
      {
        "code" : "P090980",
        "display" : "KNEE PROSTHESES - ACCESSORIES",
        "concept" : [{
          "code" : "P09098001",
          "display" : "KNEE PROSTHESES AUGMENTS"
        },
        {
          "code" : "P09098002",
          "display" : "KNEE PROSTHESES ADAPTERS (INCLUDING CONES AND SLEEVES)"
        },
        {
          "code" : "P09098003",
          "display" : "KNEE PROSTHESES OBTURATORS AND PLUGS"
        },
        {
          "code" : "P09098004",
          "display" : "KNEE PROSTHESES CENTRALISERS"
        },
        {
          "code" : "P09098006",
          "display" : "KNEE PROSTHESES STEMS",
          "concept" : [{
            "code" : "P0909800601",
            "display" : "KNEE PROSTHESES FEMORAL STEMS"
          },
          {
            "code" : "P0909800602",
            "display" : "KNEE PROSTHESES TIBIAL STEMS"
          }]
        },
        {
          "code" : "P09098099",
          "display" : "KNEE PROSTHESES - ACCESSORIES - OTHER"
        }]
      },
      {
        "code" : "P090999",
        "display" : "KNEE PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "P0910",
      "display" : "LIGAMENT PROSTHESES"
    },
    {
      "code" : "P0912",
      "display" : "OSTEOSYNTHESIS DEVICES, DEVICES FOR TENDON AND LIGAMENT SYNTHESIS",
      "concept" : [{
        "code" : "P091201",
        "display" : "OSTEOSYNTHESIS STAPLES AND ANCHORS",
        "concept" : [{
          "code" : "P09120101",
          "display" : "OSTEOSYNTHESIS STAPLES"
        },
        {
          "code" : "P09120102",
          "display" : "ANCHORS, TENDON AND LIGAMENT SYNTHESIS"
        }]
      },
      {
        "code" : "P091202",
        "display" : "BONE FIXATION NAILS",
        "concept" : [{
          "code" : "P09120201",
          "display" : "INTRAMEDULLARY NAILS"
        },
        {
          "code" : "P09120202",
          "display" : "INTRAMEDULLARY NAILS IN COMPLEX SYSTEMS"
        },
        {
          "code" : "P09120299",
          "display" : "OSTEOSYNTHESIS NAILS - OTHER"
        }]
      },
      {
        "code" : "P091203",
        "display" : "BONE FIXATION WIRES",
        "concept" : [{
          "code" : "P09120301",
          "display" : "KIRSCHNER BONE WIRES"
        },
        {
          "code" : "P09120302",
          "display" : "CERCLAGE DEVICES, WIRES AND BINDERS"
        },
        {
          "code" : "P09120399",
          "display" : "BONE FIXATION WIRES - OTHER"
        }]
      },
      {
        "code" : "P091204",
        "display" : "EXTERNAL BONE FIXATION SYSTEMS",
        "concept" : [{
          "code" : "P09120401",
          "display" : "BONE FIXATION SYSTEMS",
          "concept" : [{
            "code" : "P0912040101",
            "display" : "RADIAL BONE FIXATION SYSTEMS"
          },
          {
            "code" : "P0912040102",
            "display" : "AXIAL BONE FIXATION SYSTEMS"
          }]
        },
        {
          "code" : "P09120402",
          "display" : "SCREWS"
        },
        {
          "code" : "P09120403",
          "display" : "OSTEOSYNTHESIS DISTRACTORS"
        },
        {
          "code" : "P09120499",
          "display" : "EXTERNAL BONE FIXATION SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "P091205",
        "display" : "BONE FIXATION PLATES",
        "concept" : [{
          "code" : "P09120501",
          "display" : "OSTEOSYNTHESIS COMPRESSION PLATES"
        },
        {
          "code" : "P09120502",
          "display" : "OSTEOSYNTHESIS NEUTRALISATION AND SUPPORT PLATES"
        },
        {
          "code" : "P09120503",
          "display" : "OSTEOSYNTHESIS SCREW-PLATE SYSTEMS"
        },
        {
          "code" : "P09120504",
          "display" : "OSTEOSYNTHESIS BLADE-PLATE SYSTEMS"
        },
        {
          "code" : "P09120599",
          "display" : "BONE FIXATION PLATES - OTHER"
        }]
      },
      {
        "code" : "P091206",
        "display" : "BONE FIXATION SCREWS, TENDON AND LIGAMENT SYNTHESIS SCREWS",
        "concept" : [{
          "code" : "P09120601",
          "display" : "CORTICAL SCREWS"
        },
        {
          "code" : "P09120602",
          "display" : "CANCELLOUS SCREWS"
        },
        {
          "code" : "P09120603",
          "display" : "CANNULATED SCREWS"
        },
        {
          "code" : "P09120604",
          "display" : "OSTEOSYNTHESIS NAIL-SCREW SYSTEMS"
        },
        {
          "code" : "P09120605",
          "display" : "INTERFERENCE SCREWS"
        },
        {
          "code" : "P09120606",
          "display" : "OSTEOSYNTHESIS DEVICES, BIODEGRADABLE SCREWS AND BARS"
        },
        {
          "code" : "P09120699",
          "display" : "BONE FIXATION SCREWS, TENDON AND LIGAMENT SYNTHESIS SCREWS - OTHER"
        }]
      },
      {
        "code" : "P091280",
        "display" : "OSTEOSYNTHESIS DEVICES, DEVICES FOR TENDON AND LIGAMENT SYNTHESIS - ACCESSORIES"
      },
      {
        "code" : "P091299",
        "display" : "OSTEOSYNTHESIS DEVICES, DEVICES FOR TENDON AND LIGAMENT SYNTHESIS - OTHER"
      }]
    },
    {
      "code" : "P0913",
      "display" : "ORTHOPAEDIC IMPLANT INSTRUMENTS, SINGLE-USE",
      "concept" : [{
        "code" : "P091301",
        "display" : "ORTHOPAEDIC IMPLANT REAMERS, SINGLE-USE"
      },
      {
        "code" : "P091302",
        "display" : "ORTHOPAEDIC IMPLANT BLADES, SINGLE-USE"
      },
      {
        "code" : "P091303",
        "display" : "ORTHOPAEDIC IMPLANT DRILL BITS, SINGLE-USE"
      },
      {
        "code" : "P091304",
        "display" : "CRANIAL PERFORATORS, SINGLE-USE"
      },
      {
        "code" : "P091305",
        "display" : "BONE SAWS, SINGLE-USE"
      },
      {
        "code" : "P091399",
        "display" : "ORTHOPAEDIC IMPLANT INSTRUMENTS, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "P0990",
      "display" : "ORTHOPAEDIC PROSTHESES - VARIOUS",
      "concept" : [{
        "code" : "P099001",
        "display" : "ORTHOPAEDIC PROSTHESES CEMENTS AND ACCESSORIES FOR MIXING"
      },
      {
        "code" : "P099002",
        "display" : "ORTHOPAEDIC CEMENT PREPARATION AND APPLICATION DEVICES AND KITS"
      },
      {
        "code" : "P099003",
        "display" : "ORTHOPAEDIC PROSTHESES FIXING ELEMENTS - NOT OTHERWISE CLASSIFIED"
      }]
    },
    {
      "code" : "P0999",
      "display" : "ORTHOPAEDIC PROSTHESES, OSTEOSYNTHESIS DEVICES, DEVICES FOR TENDON AND LIGAMENT SYNTHESIS - OTHER"
    }]
  },
  {
    "code" : "P10",
    "display" : "EXTRA-VASCULAR SUPPORT PROSTHESES",
    "concept" : [{
      "code" : "P1001",
      "display" : "LOWER LIMB EXTRAVENOUS VALVE SUPPORT PROSTHESES"
    },
    {
      "code" : "P1002",
      "display" : "CORONARY BYPASS EXTRAVENOUS SUPPORTS"
    },
    {
      "code" : "P1099",
      "display" : "EXTRAVASCULAR SUPPORT PROSTHESES - OTHER"
    }]
  },
  {
    "code" : "P90",
    "display" : "IMPLANTABLE PROSTHETIC AND OSTEOSYNTHESIS DEVICES - VARIOUS",
    "concept" : [{
      "code" : "P9001",
      "display" : "TEMPORARY TISSUE EXPANDERS",
      "concept" : [{
        "code" : "P900101",
        "display" : "CYLINDRICAL TISSUE EXPANDERS"
      },
      {
        "code" : "P900102",
        "display" : "ELLIPTICAL TISSUE EXPANDERS"
      },
      {
        "code" : "P900103",
        "display" : "BREAST TISSUE EXPANDERS"
      },
      {
        "code" : "P900104",
        "display" : "RECTANGULAR TISSUE EXPANDERS"
      },
      {
        "code" : "P900105",
        "display" : "ROUND TISSUE EXPANDERS"
      },
      {
        "code" : "P900106",
        "display" : "SEMILUNAR OR CRESCENT TISSUE EXPANDERS"
      },
      {
        "code" : "P900199",
        "display" : "TISSUE EXPANDERS - OTHER"
      }]
    },
    {
      "code" : "P9002",
      "display" : "SURGICAL MESHES",
      "concept" : [{
        "code" : "P900201",
        "display" : "POLYGLYCOLIC ACID AND ASSOCIATIONS MESHES"
      },
      {
        "code" : "P900202",
        "display" : "POLYPROPYLENE SURGICAL MESHES"
      },
      {
        "code" : "P900203",
        "display" : "PTFE SURGICAL MESHES"
      },
      {
        "code" : "P900204",
        "display" : "SURGICAL MESHES, MORE THAN ONE COMPONENT"
      },
      {
        "code" : "P900205",
        "display" : "POLYESTER SURGICAL MESHES"
      },
      {
        "code" : "P900206",
        "display" : "METALLIC SURGICAL MESHES"
      },
      {
        "code" : "P900299",
        "display" : "SURGICAL MESHES - OTHER"
      }]
    },
    {
      "code" : "P9003",
      "display" : "TISSUE PATCHES",
      "concept" : [{
        "code" : "P900301",
        "display" : "PTFE TISSUE PATCHES"
      },
      {
        "code" : "P900302",
        "display" : "POLYESTER TISSUE PATCHES"
      },
      {
        "code" : "P900399",
        "display" : "TISSUE PATCHES - OTHER"
      }]
    },
    {
      "code" : "P9004",
      "display" : "STRUCTURES FILLING, REPLACEMENT AND RECONSTRUCTION DEVICES",
      "concept" : [{
        "code" : "P900401",
        "display" : "BONE AND TENDON REPLACEMENT DEVICES"
      },
      {
        "code" : "P900402",
        "display" : "RESORBABLE FILLING AND RECONSTRUCTION DEVICES"
      },
      {
        "code" : "P900403",
        "display" : "NON-RESORBABLE FILLING AND RECONSTRUCTION DEVICES"
      },
      {
        "code" : "P900404",
        "display" : "AUTOLOGOUS GRAFT SUPPORTS"
      }]
    },
    {
      "code" : "P9005",
      "display" : "IMPLANTABLE SPACERS FOR PROTECTION DURING RADIATION THERAPY"
    },
    {
      "code" : "P9099",
      "display" : "IMPLANTABLE PROSTHETIC DEVICES - OTHER"
    }]
  },
  {
    "code" : "Q",
    "display" : "DENTAL, OPHTHALMOLOGIC AND ENT DEVICES"
  },
  {
    "code" : "Q01",
    "display" : "DENTAL DEVICES",
    "concept" : [{
      "code" : "Q0101",
      "display" : "DEVICES FOR CONSERVATIVE DENTISTRY AND ENDODONTICS",
      "concept" : [{
        "code" : "Q010101",
        "display" : "DENTAL RESTORATION DEVICES",
        "concept" : [{
          "code" : "Q01010101",
          "display" : "DENTAL CONSERVATION AMALGAMS"
        },
        {
          "code" : "Q01010102",
          "display" : "TEMPORARY AND PERMANENT DENTAL RESTORATION CEMENTS",
          "concept" : [{
            "code" : "Q0101010201",
            "display" : "DENTAL BASE CEMENTS"
          },
          {
            "code" : "Q0101010202",
            "display" : "ROOT CANAL CEMENTS"
          },
          {
            "code" : "Q0101010203",
            "display" : "TEMPORARY DENTAL CEMENTS"
          },
          {
            "code" : "Q0101010204",
            "display" : "ENDODONTIC SURGERY CEMENTS"
          },
          {
            "code" : "Q0101010299",
            "display" : "TEMPORARY AND PERMANENT DENTAL RESTORATION CEMENTS - OTHER"
          }]
        },
        {
          "code" : "Q01010103",
          "display" : "DENTAL CONSERVATION COMPOSITES"
        },
        {
          "code" : "Q01010104",
          "display" : "DENTAL BONDING AGENTS"
        },
        {
          "code" : "Q01010105",
          "display" : "DENTAL RESTORATION COMPOMERS"
        },
        {
          "code" : "Q01010106",
          "display" : "DENTAL RESTORATION GLASS IONOMERS"
        },
        {
          "code" : "Q01010199",
          "display" : "DENTAL RESTORATION DEVICES - OTHER"
        }]
      },
      {
        "code" : "Q010102",
        "display" : "ROOT CANAL FILLING DEVICES",
        "concept" : [{
          "code" : "Q01010201",
          "display" : "ROOT CANAL FILLING DENTAL PASTES"
        },
        {
          "code" : "Q01010202",
          "display" : "ROOT CANAL FILLING DENTAL CEMENTS"
        },
        {
          "code" : "Q01010203",
          "display" : "DENTAL CONES"
        },
        {
          "code" : "Q01010299",
          "display" : "ROOT CANAL FILLING DEVICES - OTHER"
        }]
      },
      {
        "code" : "Q010103",
        "display" : "DENTAL MEDICATION DEVICES",
        "concept" : [{
          "code" : "Q01010301",
          "display" : "DENTAL MEDICATION COMPOUNDS WITH DISINFECTANTS, ANTIBIOTICS AND ANTI-INFLAMMATORIES"
        },
        {
          "code" : "Q01010399",
          "display" : "DENTAL MEDICATION DEVICES - OTHER"
        }]
      },
      {
        "code" : "Q010104",
        "display" : "DENTAL PROCEDURE DEVICES - VARIOUS",
        "concept" : [{
          "code" : "Q01010401",
          "display" : "PAPER AND GUTTA-PERCHA TIPS, MATRICES AND WEDGES FOR DENTISTRY"
        },
        {
          "code" : "Q01010402",
          "display" : "ENAMEL-DENTINAL ETCHING MATERIALS"
        },
        {
          "code" : "Q01010403",
          "display" : "DENTAL ABRASIVE AND POLISHING MATERIALS"
        }]
      },
      {
        "code" : "Q010105",
        "display" : "RECONSTRUCTION ENDODONTIC PINS"
      },
      {
        "code" : "Q010199",
        "display" : "CONSERVATIVE DENTISTRY AND ENDODONTICS DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0102",
      "display" : "DEVICES FOR PROSTHETIC DENTISTRY",
      "concept" : [{
        "code" : "Q010201",
        "display" : "DENTAL IMPRESSION MATERIALS",
        "concept" : [{
          "code" : "Q01020101",
          "display" : "DENTAL IMPRESSION ALGINATES"
        },
        {
          "code" : "Q01020102",
          "display" : "DENTAL IMPRESSION VINYLSILOXANS"
        },
        {
          "code" : "Q01020103",
          "display" : "DENTAL IMPRESSION POLYETHERS"
        },
        {
          "code" : "Q01020104",
          "display" : "DENTAL IMPRESSION SILICONES"
        },
        {
          "code" : "Q01020199",
          "display" : "DENTAL IMPRESSION MATERIALS - OTHER"
        }]
      },
      {
        "code" : "Q010202",
        "display" : "DENTAL CONTACT INDICATORS",
        "concept" : [{
          "code" : "Q01020201",
          "display" : "ARTICULATION PAPERS"
        },
        {
          "code" : "Q01020202",
          "display" : "SPRAY AND LIQUID DENTAL CONTACT INDICATORS"
        },
        {
          "code" : "Q01020203",
          "display" : "OCCLUSAL WAXES"
        },
        {
          "code" : "Q01020299",
          "display" : "DENTAL CONTACT INDICATORS - OTHER"
        }]
      },
      {
        "code" : "Q010204",
        "display" : "RETRACTION WIRES AND GINGIVAL RETRACTORS"
      },
      {
        "code" : "Q010205",
        "display" : "PRE-FORMED RESINS AND DENTAL CROWNS",
        "concept" : [{
          "code" : "Q01020501",
          "display" : "DENTISTRY RESINS",
          "concept" : [{
            "code" : "Q0102050101",
            "display" : "TEMPORARY TEETH RESINS"
          },
          {
            "code" : "Q0102050102",
            "display" : "DENTAL REBASING RESINS"
          },
          {
            "code" : "Q0102050199",
            "display" : "DENTISTRY RESINS - OTHER"
          }]
        },
        {
          "code" : "Q01020502",
          "display" : "PRE-FORMED DENTAL CROWNS"
        }]
      },
      {
        "code" : "Q010206",
        "display" : "DENTAL PROSTHESES (FOR DENTAL IMPLANTS SEE P010201)",
        "concept" : [{
          "code" : "Q01020601",
          "display" : "MOBILE DENTAL PROSTHESES"
        },
        {
          "code" : "Q01020602",
          "display" : "COMBINED DENTAL PROSTHESES"
        },
        {
          "code" : "Q01020603",
          "display" : "SKELETAL DENTAL PROSTHESES"
        },
        {
          "code" : "Q01020604",
          "display" : "ORTHODONTIC DENTAL PROSTHESES"
        },
        {
          "code" : "Q01020605",
          "display" : "TEMPORARY DENTAL PROSTHESES"
        }]
      },
      {
        "code" : "Q010207",
        "display" : "DENTAL IMPRESSION DEVICES FOR PROSTHETIC DENTISTRY"
      },
      {
        "code" : "Q010280",
        "display" : "PROSTHETIC DENTISTRY DEVICES - ACCESSORIES"
      },
      {
        "code" : "Q010299",
        "display" : "PROSTHETIC DENTISTRY DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0103",
      "display" : "SURGICAL DENTAL DEVICES",
      "concept" : [{
        "code" : "Q010301",
        "display" : "PERIODONTAL MEMBRANES"
      },
      {
        "code" : "Q010302",
        "display" : "DENTAL GRAFT DEVICES"
      },
      {
        "code" : "Q010303",
        "display" : "RETROGRADE FILLING DEVICES"
      },
      {
        "code" : "Q010304",
        "display" : "PERIODONTAL DRESSINGS"
      },
      {
        "code" : "Q010305",
        "display" : "SURGICAL DENTISTRY CEMENTS"
      },
      {
        "code" : "Q010399",
        "display" : "SURGICAL DENTAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0104",
      "display" : "ORTHODONTIC DEVICES",
      "concept" : [{
        "code" : "Q010401",
        "display" : "ORTHODONTIC FACE BOWS"
      },
      {
        "code" : "Q010402",
        "display" : "ORTHODONTIC BANDS"
      },
      {
        "code" : "Q010403",
        "display" : "ORTHODONTIC BRACKETS AND BUTTONS"
      },
      {
        "code" : "Q010404",
        "display" : "ORTHODONTIC ELASTICS, CHAINS AND SPRINGS"
      },
      {
        "code" : "Q010405",
        "display" : "ORTHODONTIC WIRES"
      },
      {
        "code" : "Q010406",
        "display" : "ORTHODONTIC LIGATURES"
      },
      {
        "code" : "Q010407",
        "display" : "ORTHODONTIC CEMENTS"
      },
      {
        "code" : "Q010499",
        "display" : "ORTHODONTIC DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0105",
      "display" : "INSTRUMENTS FOR DENTISTRY, SINGLE-USE",
      "concept" : [{
        "code" : "Q010501",
        "display" : "DENTAL BURS AND ABRASIVE DISKS, SINGLE-USE"
      },
      {
        "code" : "Q010502",
        "display" : "DENTAL POLISHING CUPS, SINGLE-USE"
      },
      {
        "code" : "Q010503",
        "display" : "IMPRESSION MATERIAL TRAYS, SINGLE-USE"
      },
      {
        "code" : "Q010504",
        "display" : "DENTISTRY MIRRORS AND STYLETS, SINGLE-USE"
      },
      {
        "code" : "Q010505",
        "display" : "AMALGAM APPLICATORS, SINGLE-USE"
      },
      {
        "code" : "Q010506",
        "display" : "PASTE APPLICATORS, SINGLE-USE"
      },
      {
        "code" : "Q010507",
        "display" : "ENDODONTIC INSTRUMENTS (CANAL ENLARGERS, FILES, RASPS, ETC.), SINGLE-USE"
      },
      {
        "code" : "Q010508",
        "display" : "DENTAL SURGERY INSTRUMENT KITS, SINGLE-USE"
      },
      {
        "code" : "Q010599",
        "display" : "DENTAL INSTRUMENTS, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "Q0106",
      "display" : "MATERIALS FOR THE PREPARATION OF CUSTOM-MADE DENTAL DEVICES",
      "concept" : [{
        "code" : "Q010601",
        "display" : "DENTAL ALLOYS"
      },
      {
        "code" : "Q010699",
        "display" : "MATERIALS FOR THE PREPARATION OF CUSTOM-MADE DENTAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0190",
      "display" : "DENTAL DEVICES - VARIOUS",
      "concept" : [{
        "code" : "Q019001",
        "display" : "SALIVA ASPIRATORS AND SALIVA ABSORBENTS"
      },
      {
        "code" : "Q019002",
        "display" : "DENTISTRY DAMS AND HOOKS, SINGLE-USE"
      },
      {
        "code" : "Q019003",
        "display" : "DENTAL FLOSS AND OTHER DEVICES FOR ORAL HYGIENE (FOR PROFESSIONAL USE)"
      },
      {
        "code" : "Q019004",
        "display" : "DENTAL COTTON ROLLS"
      },
      {
        "code" : "Q019005",
        "display" : "CASTABLE DENTAL POSTS"
      },
      {
        "code" : "Q019006",
        "display" : "DENTAL MATERIAL APPLICATION TIPS AND BRUSHES, SINGLE-USE"
      },
      {
        "code" : "Q019007",
        "display" : "BUCCAL TOPICAL TREATMENT PREPARATIONS NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "Q019008",
        "display" : "DENTINAL DESENSITISERS"
      }]
    },
    {
      "code" : "Q0199",
      "display" : "ODONTOLOGY DEVICES - OTHER"
    }]
  },
  {
    "code" : "Q02",
    "display" : "OPHTHALMIC DEVICES",
    "concept" : [{
      "code" : "Q0201",
      "display" : "OPHTHALMIC MICROKNIVES AND CUTTING DEVICES",
      "concept" : [{
        "code" : "Q020101",
        "display" : "OPHTHALMIC MICROKNIVES",
        "concept" : [{
          "code" : "Q02010101",
          "display" : "OPHTHALMIC MICROKNIVES, STRAIGHT"
        },
        {
          "code" : "Q02010102",
          "display" : "OPHTHALMIC MICROKNIVES, ANGLED"
        },
        {
          "code" : "Q02010103",
          "display" : "OPHTHALMIC CALIBRATED MICROKNIVES, PHACO (UPPER SHARPENED BEVEL UP, DOUBLE EDGED, GLAZED)"
        },
        {
          "code" : "Q02010199",
          "display" : "OPHTHALMIC MICROKNIVES - OTHER"
        }]
      },
      {
        "code" : "Q020102",
        "display" : "SCLERAL SCALPELS"
      },
      {
        "code" : "Q020199",
        "display" : "OPHTHALMIC CUTTING DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0202",
      "display" : "DEVICES FOR CORNEA EXPLANTATION AND TRANSPLANTATION",
      "concept" : [{
        "code" : "Q020201",
        "display" : "CORNEAL PUNCHES AND TREPHINES, SINGLE-USE"
      },
      {
        "code" : "Q020202",
        "display" : "CORNEAL DRILLS, SINGLE-USE (MECHANICAL AND HAND-ASSISTED)"
      },
      {
        "code" : "Q020203",
        "display" : "CORNEAL MARKERS"
      },
      {
        "code" : "Q020204",
        "display" : "CORNEAL EXPLANTS STORING AND TRANSPORT SUBSTANCES"
      },
      {
        "code" : "Q020299",
        "display" : "CORNEA EXPLANTATION AND TRANSPLANTATION DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0203",
      "display" : "GASEOUS, LIQUID AND VISCOELASTIC FLUIDS FOR OPHTHALMIC SURGERY AND CLINICAL OPHTHALMOLOGY",
      "concept" : [{
        "code" : "Q020301",
        "display" : "OPHTHALMIC SURGERY, GASEOUS FLUIDS",
        "concept" : [{
          "code" : "Q02030101",
          "display" : "INTRAOCULAR FLUORINATED DERIVATIVES"
        },
        {
          "code" : "Q02030199",
          "display" : "OPHTHALMIC SURGERY, GASEOUS FLUIDS – OTHER"
        }]
      },
      {
        "code" : "Q020302",
        "display" : "OPHTHALMOLOGY, LIQUID FLUIDS",
        "concept" : [{
          "code" : "Q02030201",
          "display" : "OPHTHALMIC DYES"
        },
        {
          "code" : "Q02030202",
          "display" : "OPHTHALMIC SURGERY, SILICONE OILS, PURE AND COMBINED WITH OTHER SUBSTANCES"
        },
        {
          "code" : "Q02030203",
          "display" : "OPHTHALMIC SURGERY BALANCED SALINE SOLUTIONS"
        },
        {
          "code" : "Q02030204",
          "display" : "CONTACT LENSES STORING AND CLEANING SOLUTIONS"
        },
        {
          "code" : "Q02030205",
          "display" : "OPHTHALMIC SURGERY, PERFLUOROCARBONS PURE AND COMBINED WITH OTHER SUBSTANCES"
        },
        {
          "code" : "Q02030206",
          "display" : "EYE LUBRICANT SOLUTIONS"
        },
        {
          "code" : "Q02030299",
          "display" : "OPHTHALMOLOGY, LIQUID FLUIDS - OTHER"
        }]
      },
      {
        "code" : "Q020303",
        "display" : "OPHTHALMOLOGY, VISCOELASTIC FLUIDS",
        "concept" : [{
          "code" : "Q02030301",
          "display" : "OPHTHALMOLOGY, HYALURONIC ACID AND DERIVATIVES"
        },
        {
          "code" : "Q02030399",
          "display" : "OPHTHALMOLOGY, VISCOELASTIC FLUIDS - OTHER"
        }]
      }]
    },
    {
      "code" : "Q0204",
      "display" : "VITRECTOMY DEVICES",
      "concept" : [{
        "code" : "Q020401",
        "display" : "ANTERIOR VITRECTOMY SETS"
      },
      {
        "code" : "Q020402",
        "display" : "POSTERIOR VITRECTOMY SETS"
      },
      {
        "code" : "Q020403",
        "display" : "OPHTHALMOLOGY LASER THERAPY FIBERS, SINGLE-USE",
        "concept" : [{
          "code" : "Q02040301",
          "display" : "OCULAR ENDOPHOTOCOAGULATION FIBERS, SINGLE-USE"
        },
        {
          "code" : "Q02040302",
          "display" : "OCULAR CYCLOPHOTOCOAGULATION FIBERS, SINGLE-USE"
        },
        {
          "code" : "Q02040399",
          "display" : "OPHTHALMOLOGY LASER THERAPY FIBERS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "Q020499",
        "display" : "VITRECTOMY DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0205",
      "display" : "RETINAL DETACHMENT DEVICES",
      "concept" : [{
        "code" : "Q020501",
        "display" : "RETINAL CERCLAGE BANDS"
      },
      {
        "code" : "Q020502",
        "display" : "RETINAL DETACHMENT RAILS"
      },
      {
        "code" : "Q020503",
        "display" : "RETINAL SPONGES"
      },
      {
        "code" : "Q020504",
        "display" : "RETINAL DETACHMENT CLIPS, METALLIC"
      },
      {
        "code" : "Q020599",
        "display" : "RETINAL DETACHMENT DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0206",
      "display" : "PHACOEMULSIFICATION DEVICES",
      "concept" : [{
        "code" : "Q020601",
        "display" : "PHACOEMULSIFICATION SETS"
      },
      {
        "code" : "Q020680",
        "display" : "PHACOEMULSIFICATION DEVICES - ACCESSORIES"
      },
      {
        "code" : "Q020699",
        "display" : "PHACOEMULSIFICATION DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0207",
      "display" : "LACRIMAL DUCT DEVICES",
      "concept" : [{
        "code" : "Q020701",
        "display" : "LACRIMAL DUCT DILATORS"
      },
      {
        "code" : "Q020702",
        "display" : "LACRIMAL DUCT OCCLUDERS"
      },
      {
        "code" : "Q020703",
        "display" : "LACRIMAL DUCT PLUGS"
      },
      {
        "code" : "Q020704",
        "display" : "LACRIMAL TUBES, SETS"
      },
      {
        "code" : "Q020705",
        "display" : "LACRIMAL DYSFUNCTIONS, TESTS"
      },
      {
        "code" : "Q020706",
        "display" : "LACRIMAL TUBES, SILICONE"
      },
      {
        "code" : "Q020799",
        "display" : "LACRIMAL DUCT DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0208",
      "display" : "GLAUCOMA DRAINAGES AND KITS"
    },
    {
      "code" : "Q0209",
      "display" : "STRABISMUS DEVICES"
    },
    {
      "code" : "Q0210",
      "display" : "CORRECTIVE OPTICAL DEVICES",
      "concept" : [{
        "code" : "Q021001",
        "display" : "OPHTHALMIC LENSES",
        "concept" : [{
          "code" : "Q02100101",
          "display" : "ORGANIC OPHTHALMIC LENSES (PLASTIC MATERIALS)",
          "concept" : [{
            "code" : "Q0210010101",
            "display" : "MONOFOCAL ORGANIC OPHTHALMIC LENSES"
          },
          {
            "code" : "Q0210010102",
            "display" : "MULTIFOCAL ORGANIC OPHTHALMIC LENSES (BIFOCAL, TRIFOCAL)"
          },
          {
            "code" : "Q0210010103",
            "display" : "PROGRESSIVE ORGANIC OPHTHALMIC LENSES"
          },
          {
            "code" : "Q0210010199",
            "display" : "ORGANIC OPHTHALMIC LENSES - OTHER"
          }]
        },
        {
          "code" : "Q02100102",
          "display" : "MINERAL OPHTHALMIC LENSES (GLASS)",
          "concept" : [{
            "code" : "Q0210010201",
            "display" : "MONOFOCAL MINERAL OPHTHALMIC LENSES"
          },
          {
            "code" : "Q0210010202",
            "display" : "MULTIFOCAL MINERAL OPHTHALMIC LENSES (BIFOCAL, TRIFOCAL)"
          },
          {
            "code" : "Q0210010203",
            "display" : "PROGRESSIVE MINERAL OPHTHALMIC LENSES"
          },
          {
            "code" : "Q0210010299",
            "display" : "MINERAL OPHTHALMIC LENSES - OTHER"
          }]
        }]
      },
      {
        "code" : "Q021002",
        "display" : "SPECTACLE FRAMES WITHOUT LENSES",
        "concept" : [{
          "code" : "Q02100201",
          "display" : "METAL SPECTACLE FRAMES WITHOUT LENSES"
        },
        {
          "code" : "Q02100202",
          "display" : "PLASTIC SPECTACLE FRAMES WITHOUT LENSES"
        },
        {
          "code" : "Q02100203",
          "display" : "METAL AND PLASTIC SPECTACLE FRAMES WITHOUT LENSES"
        },
        {
          "code" : "Q02100299",
          "display" : "SPECTACLE FRAMES WITHOUT LENSES - OTHER"
        }]
      },
      {
        "code" : "Q021003",
        "display" : "READY TO WEAR SPECTACLES",
        "concept" : [{
          "code" : "Q02100301",
          "display" : "READY TO WEAR SPECTACLES WITH ORGANIC LENSES",
          "concept" : [{
            "code" : "Q0210030101",
            "display" : "READY TO WEAR METAL SPECTACLES WITH ORGANIC LENSES"
          },
          {
            "code" : "Q0210030102",
            "display" : "READY TO WEAR PLASTIC SPECTACLES WITH ORGANIC LENSES"
          },
          {
            "code" : "Q0210030103",
            "display" : "READY TO WEAR METAL AND PLASTIC SPECTACLES WITH ORGANIC LENSES"
          },
          {
            "code" : "Q0210030199",
            "display" : "READY TO WEAR SPECTACLES WITH ORGANIC LENSES - OTHER"
          }]
        },
        {
          "code" : "Q02100302",
          "display" : "READY TO WEAR SPECTACLES WITH MINERAL LENSES",
          "concept" : [{
            "code" : "Q0210030201",
            "display" : "READY TO WEAR METAL SPECTACLES WITH MINERAL LENSES"
          },
          {
            "code" : "Q0210030202",
            "display" : "READY TO WEAR PLASTIC SPECTACLES WITH MINERAL LENSES"
          },
          {
            "code" : "Q0210030203",
            "display" : "READY TO WEAR METAL AND PLASTIC SEPECTACLES WITH MINERAL LENSES"
          },
          {
            "code" : "Q0210030299",
            "display" : "READY TO WEAR SPECTACLES WITH MINERAL LENSES - OTHER"
          }]
        }]
      },
      {
        "code" : "Q021004",
        "display" : "CONTACT LENSES",
        "concept" : [{
          "code" : "Q02100401",
          "display" : "CONTACT LENSES - HYDROGEL",
          "concept" : [{
            "code" : "Q0210040101",
            "display" : "CONTACT LENSES - HYDROGEL, SINGLE-USE",
            "concept" : [{
              "code" : "Q021004010101",
              "display" : "CONTACT LENSES - HYDROGEL, DAILY SINGLE-USE"
            },
            {
              "code" : "Q021004010102",
              "display" : "CONTACT LENSES - HYDROGEL, EXTENDED SINGLE-USE"
            }]
          },
          {
            "code" : "Q0210040102",
            "display" : "CONTACT LENSES - HYDROGEL, REUSABLE"
          }]
        },
        {
          "code" : "Q02100402",
          "display" : "CONTACT LENSES - NON HYDROGEL"
        },
        {
          "code" : "Q02100499",
          "display" : "CONTACT LENSES - OTHER"
        }]
      },
      {
        "code" : "Q021099",
        "display" : "CORRECTIVE OPTICAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0211",
      "display" : "OPHTHALMIC SURGERY INSTRUMENTS, SINGLE-USE",
      "concept" : [{
        "code" : "Q021101",
        "display" : "OCCULAR IRRIGATION AND ASPIRATION CANNULAS, SINGLE-USE"
      },
      {
        "code" : "Q021102",
        "display" : "OPHTHALMIC SURGERY FORCEPS, SINGLE-USE"
      },
      {
        "code" : "Q021103",
        "display" : "OPHTHALMIC SURGERY SCISSORS, SINGLE-USE"
      },
      {
        "code" : "Q021104",
        "display" : "OPHTHALMIC SURGERY MANIPULATORS, SINGLE-USE"
      },
      {
        "code" : "Q021105",
        "display" : "OPHTHALMIC SURGERY NEEDLE HOLDERS, SINGLE-USE"
      },
      {
        "code" : "Q021106",
        "display" : "OPHTHALMIC SURGERY DILATORS, SINGLE-USE"
      },
      {
        "code" : "Q021107",
        "display" : "OPHTHALMIC SURGERY RETRACTORS, SINGLE-USE"
      },
      {
        "code" : "Q021108",
        "display" : "OPHTHALMIC SURGERY PROBES, SINGLE-USE"
      },
      {
        "code" : "Q021109",
        "display" : "OPHTHALMIC SURGERY SPATULAS, SINGLE-USE"
      },
      {
        "code" : "Q021110",
        "display" : "OPHTHALMIC SURGERY SPOONS, SINGLE-USE"
      },
      {
        "code" : "Q021111",
        "display" : "OCULAR IMPLANT INSTRUMENTS, SINGLE-USE"
      },
      {
        "code" : "Q021112",
        "display" : "OCULAR ADNEXA INSTRUMENTS, SINGLE-USE"
      },
      {
        "code" : "Q021113",
        "display" : "OPHTHALMIC SURGERY INSTRUMENT KITS, SINGLE-USE"
      },
      {
        "code" : "Q021199",
        "display" : "OPHTHALMIC SURGERY INSTRUMENTS, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "Q0290",
      "display" : "OPHTHALMIC DEVICES - VARIOUS",
      "concept" : [{
        "code" : "Q029001",
        "display" : "RIGID MONOCULAR MASKS"
      },
      {
        "code" : "Q029002",
        "display" : "OPHTHALMOLOGICAL DIAGNOSTIC ELECTRODES, SINGLE-USE"
      },
      {
        "code" : "Q029003",
        "display" : "CORNEAL PROTECTION MECHANICAL DEVICES"
      }]
    },
    {
      "code" : "Q0299",
      "display" : "OPHTHALMIC DEVICES - OTHER"
    }]
  },
  {
    "code" : "Q03",
    "display" : "ENT DEVICES",
    "concept" : [{
      "code" : "Q0301",
      "display" : "NASOPHARYNGEAL DEVICES",
      "concept" : [{
        "code" : "Q030101",
        "display" : "TURBINATE REDUCTION DEVICES",
        "concept" : [{
          "code" : "Q03010101",
          "display" : "RADIOFREQUENCY TURBINATE REDUCTION DEVICES"
        },
        {
          "code" : "Q03010199",
          "display" : "DEVICES FOR TURBINATE REDUCTION - OTHER"
        }]
      },
      {
        "code" : "Q030102",
        "display" : "ANTISNORING AND OBSTRUCTIVE SLEEP APNOEA DEVICES",
        "concept" : [{
          "code" : "Q03010201",
          "display" : "RADIOFREQUENCY ANTISNORING AND OBSTRUCTIVE SLEEP APNOEA DEVICES"
        },
        {
          "code" : "Q03010299",
          "display" : "ANTISNORING AND OBSTRUCTIVE SLEEP APNOEA DEVICES - OTHER"
        }]
      },
      {
        "code" : "Q030103",
        "display" : "NASAL IRRIGATION SOLUTIONS"
      },
      {
        "code" : "Q030199",
        "display" : "NASOPHARYNGEAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0302",
      "display" : "EPISTAXIS DEVICES",
      "concept" : [{
        "code" : "Q030201",
        "display" : "EPISTAXIS CATHETERS"
      },
      {
        "code" : "Q030299",
        "display" : "EPISTAXIS DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0303",
      "display" : "ENT SURGERY INSTRUMENTS, SINGLE-USE",
      "concept" : [{
        "code" : "Q030301",
        "display" : "ENT SURGERY BLADES, SINGLE-USE"
      },
      {
        "code" : "Q030302",
        "display" : "ENT SURGERY BURS AND HANDPIECES, SINGLE-USE"
      },
      {
        "code" : "Q030303",
        "display" : "NASAL MIRRORS, SINGLE-USE"
      },
      {
        "code" : "Q030304",
        "display" : "ENT SURGERY FORCEPS, SINGLE-USE"
      },
      {
        "code" : "Q030305",
        "display" : "ENT SURGERY SCISSORS, SINGLE-USE"
      },
      {
        "code" : "Q030306",
        "display" : "ENT SURGERY CURETTES, SINGLE-USE"
      },
      {
        "code" : "Q030307",
        "display" : "ENT SURGERY DISSECTORS, SINGLE-USE"
      },
      {
        "code" : "Q030308",
        "display" : "ENT SURGERY DILATORS, SINGLE-USE"
      },
      {
        "code" : "Q030309",
        "display" : "ADENOTOMES, SINGLE-USE"
      },
      {
        "code" : "Q030310",
        "display" : "ENT SURGERY HOOKS, SINGLE-USE"
      },
      {
        "code" : "Q030311",
        "display" : "ENT SURGERY RASPS AND FILES, SINGLE-USE"
      },
      {
        "code" : "Q030312",
        "display" : "ENT SURGERY SPATULAS, SINGLE-USE"
      },
      {
        "code" : "Q030313",
        "display" : "ENT SURGERY PROBES, SINGLE-USE"
      },
      {
        "code" : "Q030314",
        "display" : "ENT SURGERY SPOONS, SINGLE-USE"
      },
      {
        "code" : "Q030315",
        "display" : "ENT SURGERY MANIPULATORS, SINGLE-USE"
      },
      {
        "code" : "Q030316",
        "display" : "ENT SURGERY INSTRUMENT KITS NOT INCLUDED IN OTHER CLASSES, SINGLE-USE"
      },
      {
        "code" : "Q030399",
        "display" : "INSTRUMENTS FOR ENT SURGERY, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "Q0304",
      "display" : "OTOLOGY DEVICES",
      "concept" : [{
        "code" : "Q030401",
        "display" : "EAR DRAINAGE AND VENTILATION DEVICES",
        "concept" : [{
          "code" : "Q03040101",
          "display" : "EAR DRAINAGE AND VENTILATION CATHETERS AND CANNULAS"
        },
        {
          "code" : "Q03040102",
          "display" : "ENDOLYMPHATIC SHUNTS"
        },
        {
          "code" : "Q03040199",
          "display" : "EAR DRAINAGE AND VENTILATION DEVICES - OTHER"
        }]
      },
      {
        "code" : "Q030402",
        "display" : "EAR IRRIGATION DEVICES",
        "concept" : [{
          "code" : "Q03040201",
          "display" : "EAR DROPPERS"
        },
        {
          "code" : "Q03040299",
          "display" : "EAR IRRIGATION DEVICES - OTHER"
        }]
      },
      {
        "code" : "Q030499",
        "display" : "OTOLOGY DEVICES - OTHER"
      }]
    },
    {
      "code" : "Q0399",
      "display" : "ENT DEVICES - OTHER"
    }]
  },
  {
    "code" : "R",
    "display" : "RESPIRATORY AND ANAESTHESIA DEVICES"
  },
  {
    "code" : "R01",
    "display" : "INTUBATION DEVICES",
    "concept" : [{
      "code" : "R0101",
      "display" : "NASO-OROPHARYNGEAL TUBES",
      "concept" : [{
        "code" : "R010101",
        "display" : "NASOPHARYNGEAL TUBES"
      },
      {
        "code" : "R010102",
        "display" : "GUEDEL AIRWAY TUBES"
      },
      {
        "code" : "R010199",
        "display" : "NASO-OROPHARYNGEAL TUBES - OTHER"
      }]
    },
    {
      "code" : "R0102",
      "display" : "LARYNGEAL MASKS AND TUBES",
      "concept" : [{
        "code" : "R010201",
        "display" : "LARYNGEAL MASKS",
        "concept" : [{
          "code" : "R01020101",
          "display" : "LARYNGEAL MASKS, SINGLE-LUMEN"
        },
        {
          "code" : "R01020102",
          "display" : "LARYNGEAL MASKS, DOUBLE-LUMEN"
        },
        {
          "code" : "R01020199",
          "display" : "LARYNGEAL MASKS - OTHER"
        }]
      },
      {
        "code" : "R010202",
        "display" : "LARYNGEAL TUBES"
      },
      {
        "code" : "R010203",
        "display" : "LARYNGEAL KITS"
      },
      {
        "code" : "R010280",
        "display" : "LARYNGEAL MASKS AND TUBES - ACCESSORIES"
      },
      {
        "code" : "R010299",
        "display" : "LARYNGEAL MASKS AND TUBES - OTHER"
      }]
    },
    {
      "code" : "R0103",
      "display" : "ENDOTRACHEAL TUBES",
      "concept" : [{
        "code" : "R010301",
        "display" : "ENDOTRACHEAL TUBES, CUFFLESS",
        "concept" : [{
          "code" : "R01030101",
          "display" : "ENDOTRACHEAL TUBES, CUFFLESS, NOT REINFORCED"
        },
        {
          "code" : "R01030102",
          "display" : "ENDOTRACHEAL TUBES, CUFFLESS, REINFORCED"
        }]
      },
      {
        "code" : "R010302",
        "display" : "ENDOTRACHEAL TUBES, CUFFED",
        "concept" : [{
          "code" : "R01030201",
          "display" : "ENDOTRACHEAL TUBES, CUFFED, NOT REINFORCED"
        },
        {
          "code" : "R01030202",
          "display" : "ENDOTRACHEAL TUBES, CUFFED, REINFORCED"
        }]
      },
      {
        "code" : "R010380",
        "display" : "ENDOTRACHEAL TUBES - ACCESSORIES",
        "concept" : [{
          "code" : "R01038001",
          "display" : "ENDOTRACHEAL TUBE CUFFS INFLATION SYSTEMS"
        },
        {
          "code" : "R01038099",
          "display" : "ENDOTRACHEAL TUBES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
        }]
      },
      {
        "code" : "R010399",
        "display" : "ENDOTRACHEAL TUBES - OTHER"
      }]
    },
    {
      "code" : "R0104",
      "display" : "ENDOBRONCHIAL TUBES",
      "concept" : [{
        "code" : "R010401",
        "display" : "ENDOBRONCHIAL TUBES, RIGHT",
        "concept" : [{
          "code" : "R01040101",
          "display" : "ENDOBRONCHIAL TUBES, RIGHT, SINGLE-LUMEN"
        },
        {
          "code" : "R01040102",
          "display" : "ENDOBRONCHIAL TUBES, RIGHT, DOUBLE-LUMEN"
        },
        {
          "code" : "R01040103",
          "display" : "ENDOBRONCHIAL TUBES, RIGHT, DOUBLE-LUMEN, TRACHEOSTOMY"
        },
        {
          "code" : "R01040199",
          "display" : "ENDOBRONCHIAL TUBES, RIGHT - OTHER"
        }]
      },
      {
        "code" : "R010402",
        "display" : "ENDOBRONCHIAL TUBES, LEFT",
        "concept" : [{
          "code" : "R01040201",
          "display" : "ENDOBRONCHIAL TUBES, LEFT, SINGLE-LUMEN"
        },
        {
          "code" : "R01040202",
          "display" : "ENDOBRONCHIAL TUBES, LEFT, DOUBLE-LUMEN"
        },
        {
          "code" : "R01040203",
          "display" : "ENDOBRONCHIAL TUBES, LEFT, DOUBLE-LUMEN, TRACHEOSTOMY"
        },
        {
          "code" : "R01040299",
          "display" : "ENDOBRONCHIAL TUBES, LEFT - OTHER"
        }]
      },
      {
        "code" : "R010480",
        "display" : "ENDOBRONCHIAL TUBES - ACCESSORIES"
      },
      {
        "code" : "R010499",
        "display" : "ENDOBRONCHIAL TUBES - OTHER"
      }]
    },
    {
      "code" : "R0105",
      "display" : "TRACHEOSTOMY AND LARINGECTOMY CANNULAS",
      "concept" : [{
        "code" : "R010501",
        "display" : "TRACHEOSTOMY AND LARINGECTOMY CANNULAS AND KITS, UNCUFFED",
        "concept" : [{
          "code" : "R01050101",
          "display" : "TRACHEOSTOMY CANNULAS, CUFFLESS, NOT REINFORCED, AND KITS",
          "concept" : [{
            "code" : "R0105010101",
            "display" : "TRACHEOSTOMIC CANNULAS, CUFFLESS, NOT REINFORCED, WITH FIXED FLANGE, AND KITS"
          },
          {
            "code" : "R0105010102",
            "display" : "TRACHEOSTOMIC CANNUALS, CUFFLESS, NOT REINFORCED, WITH ADJUSTABLE FLANGE, AND KITS"
          }]
        },
        {
          "code" : "R01050102",
          "display" : "TRACHEOSTOMIC CANNULAS, CUFFLESS, REINFORCED, AND KITS",
          "concept" : [{
            "code" : "R0105010201",
            "display" : "TRACHEOSTOMIC CANNULAS, CUFFLESS, REINFORCED, WITH FIXED FLANGE, AND KITS"
          },
          {
            "code" : "R0105010202",
            "display" : "TRACHEOSTOMIC CANNULAS, CUFFLESS, REINFORCED, WITH ADJUSTABLE FLANGE, AND KITS"
          }]
        }]
      },
      {
        "code" : "R010502",
        "display" : "TRACHEOSTOMY AND LARINGECTOMY CANNULAS AND KITS, CUFFED",
        "concept" : [{
          "code" : "R01050201",
          "display" : "TRACHEOSTOMY CANNULAS, CUFFED, NOT REINFORCED, AND KITS",
          "concept" : [{
            "code" : "R0105020101",
            "display" : "TRACHEOSTOMIC CANNULAS, CUFFED, NOT REINFORCED, WITH FIXED FLANGE, AND KITS"
          },
          {
            "code" : "R0105020102",
            "display" : "TRACHEOSTOMIC CANNULAS, CUFFED, NOT REINFORCED, WITH ADJUSTABLE FLANGE, AND KITS"
          }]
        },
        {
          "code" : "R01050202",
          "display" : "TRACHEOSTOMY CANNULAS, CUFFED, REINFORCED, AND KITS",
          "concept" : [{
            "code" : "R0105020201",
            "display" : "TRACHEOSTOMIC CANNULAS, CUFFED, REINFORCED, WITH FIXED FLANGE, AND KITS"
          },
          {
            "code" : "R0105020202",
            "display" : "TRACHEOSTOMIC CANNULAS, CUFFED, REINFORCED, WITH ADJUSTABLE FLANGE, AND KITS"
          }]
        }]
      },
      {
        "code" : "R010503",
        "display" : "TRACHEOSTOMY INNER CANNULAS"
      },
      {
        "code" : "R010580",
        "display" : "TRACHEOSTOMY AND LARINGECTOMY CANNULAS - ACCESSORIES",
        "concept" : [{
          "code" : "R01058001",
          "display" : "TRACHEOSTOMIC CANNULAS SUPPORTS"
        },
        {
          "code" : "R01058002",
          "display" : "TRACHEOSTOMY FILTERS"
        },
        {
          "code" : "R01058099",
          "display" : "TRACHEOSTOMY AND LARYNGECTOMY CANNULAS - VARIOUS ACCESSORIES"
        }]
      },
      {
        "code" : "R010599",
        "display" : "TRACHEOSTOMY AND LARYNGECTOMY CANNULAS - OTHER"
      }]
    },
    {
      "code" : "R0106",
      "display" : "PERCUTANEOUS TRACHEOSTOMY KITS",
      "concept" : [{
        "code" : "R010601",
        "display" : "CIAGLIA TRACHEOSTOMY KITS"
      },
      {
        "code" : "R010602",
        "display" : "FANTONI TRACHEOSTOMY KITS"
      },
      {
        "code" : "R010603",
        "display" : "GRIGGS TRACHEOSTOMY KITS"
      },
      {
        "code" : "R010604",
        "display" : "SELDINGER TRACHEOSTOMY KITS"
      },
      {
        "code" : "R010699",
        "display" : "PERCUTANEOUS TRACHEOSTOMY KITS - OTHER"
      }]
    },
    {
      "code" : "R0180",
      "display" : "INTUBATION DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES",
      "concept" : [{
        "code" : "R018001",
        "display" : "INTUBATION DEVICE SPINDLES"
      },
      {
        "code" : "R018002",
        "display" : "INTUBATION DEVICE SUPPORTS"
      },
      {
        "code" : "R018003",
        "display" : "CARBON DIOXIDE ABSORBERS"
      },
      {
        "code" : "R018004",
        "display" : "INTUBATION DEVICE GUIDES"
      },
      {
        "code" : "R018099",
        "display" : "INTUBATION DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
      }]
    },
    {
      "code" : "R0199",
      "display" : "INTUBATION DEVICES - OTHER"
    }]
  },
  {
    "code" : "R02",
    "display" : "BREATHING CIRCUITS AND CATHETER MOUNTS",
    "concept" : [{
      "code" : "R0201",
      "display" : "RESPIRATORY CIRCUITS AND KITS",
      "concept" : [{
        "code" : "R020101",
        "display" : "STANDARD BREATHING CIRCUITS",
        "concept" : [{
          "code" : "R02010101",
          "display" : "BREATHING CIRCUITS, W/O WATER TRAP"
        },
        {
          "code" : "R02010102",
          "display" : "BREATHING CIRCUITS, WITH WATER TRAP"
        },
        {
          "code" : "R02010199",
          "display" : "STANDARD BREATHING CIRCUITS - OTHER"
        }]
      },
      {
        "code" : "R020102",
        "display" : "COAXIAL BREATHING CIRCUITS"
      },
      {
        "code" : "R020103",
        "display" : "INSULATED BREATHING CIRCUITS"
      },
      {
        "code" : "R020104",
        "display" : "CPAP AND NIV BREATHING CIRCUITS",
        "concept" : [{
          "code" : "R02010401",
          "display" : "CPAP CIRCUITS"
        },
        {
          "code" : "R02010402",
          "display" : "NIV CIRCUITS"
        }]
      },
      {
        "code" : "R020106",
        "display" : "IPPB CIRCUITS"
      },
      {
        "code" : "R020107",
        "display" : "THERMOREGULATED BREATHING CIRCUITS"
      },
      {
        "code" : "R020108",
        "display" : "RESPIRATORY GAS MONITORING AND SAMPLING CIRCUITS AND KITS"
      },
      {
        "code" : "R020109",
        "display" : "SPIROMETRY CIRCUITS AND KITS"
      },
      {
        "code" : "R020199",
        "display" : "BREATHING CIRCUITS AND KITS - OTHER"
      }]
    },
    {
      "code" : "R0202",
      "display" : "CATHETER MOUNTS",
      "concept" : [{
        "code" : "R020201",
        "display" : "FIXED CATHETER MOUNTS"
      },
      {
        "code" : "R020202",
        "display" : "MOBILE CATHETER MOUNTS"
      },
      {
        "code" : "R020299",
        "display" : "MOUNT CATHETERS - OTHER"
      }]
    },
    {
      "code" : "R0203",
      "display" : "ANAESTHESIA AND RESUSCITATION CONNECTORS",
      "concept" : [{
        "code" : "R020301",
        "display" : "RESPIRATORY CIRCUITS CONNECTION PIPES"
      },
      {
        "code" : "R020302",
        "display" : "RESPIRATORY CIRCUITS ADAPTERS AND CONNECTORS"
      },
      {
        "code" : "R020399",
        "display" : "ANESTHESIA AND RESUSCITATION CONNECTORS - OTHER"
      }]
    },
    {
      "code" : "R0280",
      "display" : "BREATHING CIRCUITS AND CATHETER MOUNTS - ACCESSORIES",
      "concept" : [{
        "code" : "R028001",
        "display" : "RESPIRATORY CIRCUITS VALVES"
      },
      {
        "code" : "R028002",
        "display" : "RESPIRATORY CIRCUITS SUPPORTS"
      },
      {
        "code" : "R028003",
        "display" : "RESPIRATORY CIRCUITS WATER TRAPS"
      },
      {
        "code" : "R028099",
        "display" : "RESPIRATORY CIRCUITS AND MOUNT CATHETERS - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
      }]
    }]
  },
  {
    "code" : "R03",
    "display" : "RESPIRATORY MASKS AND BALLOONS, SINGLE-USE AND REUSABLE",
    "concept" : [{
      "code" : "R0301",
      "display" : "RESPIRATORY MASKS",
      "concept" : [{
        "code" : "R030101",
        "display" : "VENTILATION MASKS",
        "concept" : [{
          "code" : "R03010101",
          "display" : "ANAESTHETIC FACE MASKS"
        },
        {
          "code" : "R03010102",
          "display" : "CPAP AND NIV MASKS",
          "concept" : [{
            "code" : "R0301010201",
            "display" : "CPAP MASKS"
          },
          {
            "code" : "R0301010202",
            "display" : "NIV MASKS"
          }]
        },
        {
          "code" : "R03010104",
          "display" : "CPAP AND NIV HELMETS AND KITS",
          "concept" : [{
            "code" : "R0301010401",
            "display" : "CPAP HELMETS AND KITS"
          },
          {
            "code" : "R0301010402",
            "display" : "NIV HELMETS AND KITS"
          }]
        },
        {
          "code" : "R03010180",
          "display" : "ARTIFICIAL VENTILATION MASKS - ACCESSORIES"
        },
        {
          "code" : "R03010199",
          "display" : "VENTILATION MASKS - OTHER"
        }]
      },
      {
        "code" : "R030102",
        "display" : "AIR/OXYGEN MASKS AND NASAL CANNULAS",
        "concept" : [{
          "code" : "R03010201",
          "display" : "AIR/OXYGEN MASKS"
        },
        {
          "code" : "R03010202",
          "display" : "VENTURI MASKS"
        },
        {
          "code" : "R03010203",
          "display" : "OXYGEN THERAPY NASAL CANNULAS",
          "concept" : [{
            "code" : "R0301020301",
            "display" : "OXYGEN THERAPY STANDARD NASAL CANNULAS (GOGGLES)"
          },
          {
            "code" : "R0301020302",
            "display" : "HIGH FLOW THERAPY NASAL CANNULAS (HFNC)"
          }]
        },
        {
          "code" : "R03010204",
          "display" : "OXYGEN ADMINISTRATION TUBINGS"
        },
        {
          "code" : "R03010205",
          "display" : "TRACHEOSTOMY O2 SUPPLIERS"
        },
        {
          "code" : "R03010206",
          "display" : "MASKS WITH RESERVOIR"
        },
        {
          "code" : "R03010207",
          "display" : "OXYGEN THERAPY KITS"
        },
        {
          "code" : "R03010280",
          "display" : "OXYGEN THERAPY MASKS AND NASAL CANNULAS - ACCESSORIES"
        },
        {
          "code" : "R03010299",
          "display" : "OXYGEN THERAPY MASKS AND NASAL CANNULAS - OTHER"
        }]
      },
      {
        "code" : "R030103",
        "display" : "AEROSOL THERAPY MASKS AND SYSTEMS",
        "concept" : [{
          "code" : "R03010301",
          "display" : "AEROSOL THERAPY MASKS"
        },
        {
          "code" : "R03010302",
          "display" : "AEROSOL PORTABLE INHALERS"
        },
        {
          "code" : "R03010303",
          "display" : "AEROSOL THERAPY TUBINGS"
        },
        {
          "code" : "R03010304",
          "display" : "AEROSOL THERAPY KITS"
        },
        {
          "code" : "R03010380",
          "display" : "AEROSOL THERAPY SYSTEMS - ACCESSORIES"
        },
        {
          "code" : "R03010399",
          "display" : "AEROSOL THERAPY SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "R030180",
        "display" : "RESPIRATORY MASKS - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "R030199",
        "display" : "RESPIRATORY MASKS - OTHER"
      }]
    },
    {
      "code" : "R0302",
      "display" : "RESPIRATORY BALLOONS",
      "concept" : [{
        "code" : "R030201",
        "display" : "VENTILATION BALLOONS",
        "concept" : [{
          "code" : "R03020101",
          "display" : "ANAESTHESIA BALLOONS"
        },
        {
          "code" : "R03020102",
          "display" : "CPAP BALLOONS"
        },
        {
          "code" : "R03020199",
          "display" : "VENTILATION BALLOONS - OTHER"
        }]
      },
      {
        "code" : "R030202",
        "display" : "MANUALLY OPERATED VENTILATION BALLOONS",
        "concept" : [{
          "code" : "R03020201",
          "display" : "MANUALLY OPERATED PULMONARY RESUSCITATORS"
        },
        {
          "code" : "R03020202",
          "display" : "SELF-INFLATING VENTILATION BALLOONS"
        }]
      },
      {
        "code" : "R030280",
        "display" : "RESPIRATORY BALLONS - ACCESSORIES"
      },
      {
        "code" : "R030299",
        "display" : "RESPIRATORY BALLOONS - OTHER"
      }]
    }]
  },
  {
    "code" : "R04",
    "display" : "RESPIRATORY FILTERS",
    "concept" : [{
      "code" : "R0401",
      "display" : "VENTILATION FILTERS",
      "concept" : [{
        "code" : "R040101",
        "display" : "ANTIBACTERIAL AND ANTIVIRAL RESPIRATORY FILTERS"
      },
      {
        "code" : "R040102",
        "display" : "ANTIBACTERIAL AND ANTIVIRAL RESPIRATORY FILTERS HUMIDIFIERS"
      },
      {
        "code" : "R040199",
        "display" : "VENTILATION FILTERS - OTHER"
      }]
    },
    {
      "code" : "R0402",
      "display" : "NATURAL BREATHING FILTERS",
      "concept" : [{
        "code" : "R040201",
        "display" : "TRACHEOSTOMY HUMIDIFIERS"
      },
      {
        "code" : "R040299",
        "display" : "NATURAL BREATHING FILTERS - OTHER"
      }]
    },
    {
      "code" : "R0490",
      "display" : "RESPIRATORY FILTERS - VARIOUS",
      "concept" : [{
        "code" : "R049001",
        "display" : "PULMONARY FUNCTION TEST FILTERS"
      }]
    },
    {
      "code" : "R0499",
      "display" : "RESPIRATORY FILTERS - OTHER"
    }]
  },
  {
    "code" : "R05",
    "display" : "SUCTION AND DILATATION SYSTEMS FOR THE RESPIRATORY SYSTEM",
    "concept" : [{
      "code" : "R0501",
      "display" : "RESPIRATORY SUCTION PROBES AND SYSTEMS",
      "concept" : [{
        "code" : "R050101",
        "display" : "RESPIRATORY SUCTION PROBES",
        "concept" : [{
          "code" : "R05010101",
          "display" : "RESPIRATORY SUCTION PROBES WITHOUT A CONTROL HOLE"
        },
        {
          "code" : "R05010102",
          "display" : "RESPIRATORY SUCTION PROBES WITH CONTROL HOLE"
        }]
      },
      {
        "code" : "R050102",
        "display" : "CLOSED-CIRCUIT RESPIRATORY SUCTION AND IRRIGATION SYSTEMS (NON-ENDOSCOPIC)"
      },
      {
        "code" : "R050103",
        "display" : "MUCOUS ASPIRATORS",
        "concept" : [{
          "code" : "R05010301",
          "display" : "SINGLE-CHAMBER MUCOUS MEMBRANE ASPIRATORS"
        },
        {
          "code" : "R05010302",
          "display" : "DOUBLE-CHAMBER MUCOUS MEMBRANE ASPIRATORS"
        },
        {
          "code" : "R05010399",
          "display" : "MUCOSITY ASPIRATORS - OTHER"
        }]
      }]
    },
    {
      "code" : "R0502",
      "display" : "RESPIRATORY DILATION SYSTEMS",
      "concept" : [{
        "code" : "R050201",
        "display" : "BRONCHIAL DILATION CATHETERS"
      },
      {
        "code" : "R050280",
        "display" : "RESPIRATORY TRACT EXPANSION SYSTEMS - ACCESSORIES"
      },
      {
        "code" : "R050299",
        "display" : "RESPIRATORY DILATION SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "R0580",
      "display" : "RESPIRATORY SYSTEM SUCTION AND DILATATION SYSTEMS - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
    },
    {
      "code" : "R0599",
      "display" : "RESPIRATORY DEVICES, SUCTION AND DILATION SYSTEMS - OTHER"
    }]
  },
  {
    "code" : "R06",
    "display" : "NEBULISATION AND HUMIDIFICATION SYSTEMS",
    "concept" : [{
      "code" : "R0601",
      "display" : "NEBULISATION SYSTEMS",
      "concept" : [{
        "code" : "R060101",
        "display" : "COLD NEBULISATION SYSTEMS"
      },
      {
        "code" : "R060102",
        "display" : "HOT NEBULISATION SYSTEMS"
      }]
    },
    {
      "code" : "R0602",
      "display" : "HUMIDIFICATION SYSTEMS",
      "concept" : [{
        "code" : "R060201",
        "display" : "ACTIVE VENTILATION HUMIDIFICATION SYSTEMS,"
      },
      {
        "code" : "R060202",
        "display" : "OXYGEN ADMINISTRATION HUMIDIFICATION SYSTEMS"
      },
      {
        "code" : "R060203",
        "display" : "INHALATION THERAPY HUMIDIFICATION LIQUIDS"
      },
      {
        "code" : "R060280",
        "display" : "HUMIDIFICATION SYSTEMS - ACCESSORIES"
      },
      {
        "code" : "R060299",
        "display" : "HUMIDIFICATION SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "R0680",
      "display" : "NEBULISATION AND HUMIDIFICATION SYSTEMS - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
    },
    {
      "code" : "R0699",
      "display" : "NEBULISATION AND HUMIDIFICATION SYSTEMS - OTHER"
    }]
  },
  {
    "code" : "R07",
    "display" : "BRONCHOPULMONARY ENDOSCOPY DEVICES, SINGLE-USE",
    "concept" : [{
      "code" : "R0701",
      "display" : "BRONCHOPULMONARY ENDOSCOPY PROBES, SINGLE-USE",
      "concept" : [{
        "code" : "R070101",
        "display" : "BRONCHOSCOPY PROBES, SINGLE-USE"
      },
      {
        "code" : "R070102",
        "display" : "RESPIRATORY SYSTEM ENDOSCOPIC HEMOSTASIS PROBES, SINGLE-USE"
      },
      {
        "code" : "R070103",
        "display" : "BRONCHIAL ASPIRATION AND WASHING PROBES, SINGLE-USE"
      },
      {
        "code" : "R070180",
        "display" : "BRONCHOPULMONARY ENDOSCOPY PROBES, SINGLE-USE - ACCESSORIES"
      },
      {
        "code" : "R070199",
        "display" : "BRONCHOPULMONARY ENDOSCOPY PROBES, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "R0702",
      "display" : "BRONCHOSCOPIC SURGERY INSTRUMENTS, SINGLE-USE",
      "concept" : [{
        "code" : "R070201",
        "display" : "BRONCHOSCOPIC SURGERY FORCEPS, SINGLE-USE",
        "concept" : [{
          "code" : "R07020101",
          "display" : "BRONCHOSCOPIC SURGERY BIOPTIC FORCEPS, SINGLE-USE",
          "concept" : [{
            "code" : "R0702010101",
            "display" : "BRONCHOSCOPIC SURGERY COLD BIOPTIC FORCEPS, SINGLE-USE"
          },
          {
            "code" : "R0702010102",
            "display" : "BRONCHOSCOPIC SURGERY HOT BIOPTIC FORCEPS, SINGLE-USE"
          }]
        },
        {
          "code" : "R07020102",
          "display" : "BRONCHOSCOPIC SURGERY EXTRACTION FORCEPS, SINGLE-USE"
        },
        {
          "code" : "R07020199",
          "display" : "BRONCHOSCOPIC SURGERY FORCEPS, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "R070203",
        "display" : "BRONCOPULMONARY ENDOSCOPY BRUSHES, SINGLE-USE",
        "concept" : [{
          "code" : "R07020301",
          "display" : "BRONCOPULMONARY CYTOLOGY BRUSHES, SINGLE-USE"
        }]
      },
      {
        "code" : "R070204",
        "display" : "BRONCHOSCOPIC SURGERY DISSECTORS, SINGLE-USE"
      },
      {
        "code" : "R070205",
        "display" : "BRONCHOSCOPIC SURGERY SCISSORS, SINGLE-USE"
      },
      {
        "code" : "R070206",
        "display" : "BRONCHOSCOPIC SURGERY CURETTES, SINGLE-USE"
      },
      {
        "code" : "R070207",
        "display" : "BRONCHOSCOPIC SURGERY CANNULAS, SINGLE-USE"
      },
      {
        "code" : "R070208",
        "display" : "BRONCHOSCOPIC SURGERY KITS, SINGLE-USE"
      },
      {
        "code" : "R070280",
        "display" : "BRONCHOSCOPIC SURGERY INSTRUMENTS, SINGLE-USE - ACCESSORIES"
      },
      {
        "code" : "R070299",
        "display" : "BRONCHOSCOPIC SURGERY INSTRUMENTS, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "R0799",
      "display" : "BRONCOPULMONARY ENDOSCOPY DEVICES, SINGLE-USE - OTHER"
    }]
  },
  {
    "code" : "R90",
    "display" : "RESPIRATORY AND ANAESTHESIA DEVICES - VARIOUS",
    "concept" : [{
      "code" : "R9001",
      "display" : "RESPIRATORY MOUTHPIECES"
    },
    {
      "code" : "R9002",
      "display" : "LARYNGOSCOPE BLADES, SINGLE-USE"
    },
    {
      "code" : "R9003",
      "display" : "RESPIRATORY SYSTEM SURGERY INSTRUMENTS, SINGLE-USE",
      "concept" : [{
        "code" : "R900301",
        "display" : "RESPIRATORY SYSTEM SURGERY FORCEPS, SINGLE-USE"
      },
      {
        "code" : "R900302",
        "display" : "RESPIRATORY SYSTEM SURGERY DILATORS, SINGLE-USE"
      },
      {
        "code" : "R900399",
        "display" : "RESPIRATORY SYSTEM SURGERY INSTRUMENTS, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "R9004",
      "display" : "PLEURAL TALCAGE DEVICES"
    },
    {
      "code" : "R9005",
      "display" : "ENDOBRONCHIAL VALVES AND RELEASE SYSTEMS"
    },
    {
      "code" : "R9006",
      "display" : "PHONATION VALVES",
      "concept" : [{
        "code" : "R900602",
        "display" : "PHONATION VALVES FOR TRACHEOSTOMY",
        "concept" : [{
          "code" : "R90060201",
          "display" : "PHONATION VALVES FOR TRACHEOSTOMY FOR VENTILATOR USE"
        },
        {
          "code" : "R90060202",
          "display" : "PHONATION VALVES FOR TRACHEOSTOMY NOT FOR VENTILATOR USE"
        }]
      },
      {
        "code" : "R900680",
        "display" : "PHONATION VALVES - ACCESSORIES"
      }]
    },
    {
      "code" : "R9007",
      "display" : "LUNG FUNCTIONALITY TESTING DEVICES, SINGLE-USE - NOT INCLUDED IN OTHER CLASSES"
    },
    {
      "code" : "R9008",
      "display" : "RESPIRATORY SYSTEM ACTIVE SUBSTANCES"
    },
    {
      "code" : "R9009",
      "display" : "RESPIRATORY THERAPY AIDS",
      "concept" : [{
        "code" : "R900901",
        "display" : "INHALERS"
      },
      {
        "code" : "R900902",
        "display" : "INSPIRATORY AND EXPIRATORY FLOW STIMULATORS/RESPIRATORY MUSCLES TRAINERS"
      }]
    },
    {
      "code" : "R9080",
      "display" : "RESPIRATORY AND ANESTHESIA DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
    },
    {
      "code" : "R9099",
      "display" : "RESPIRATORY AND ANAESTHESIA DEVICES - OTHER"
    }]
  },
  {
    "code" : "S",
    "display" : "STERILISATION DEVICES (EXCLUDING CAT. D - Z)"
  },
  {
    "code" : "S01",
    "display" : "DEVICES FOR STERILISATION AND PACKAGING (EXCLUDING CAT. D - Z)",
    "concept" : [{
      "code" : "S0101",
      "display" : "STERILISATION POUCHES",
      "concept" : [{
        "code" : "S010101",
        "display" : "STERILISATION POUCHES, PAPER/PLASTIC FILM",
        "concept" : [{
          "code" : "S01010101",
          "display" : "STERILISATION POUCHES, FLAT, PAPER/PLASTIC FILM"
        },
        {
          "code" : "S01010102",
          "display" : "STERILISATION POUCHES, GUSSETED, PAPER/PLASTIC FILM"
        }]
      },
      {
        "code" : "S010102",
        "display" : "STERILISATION POUCHES, TYVEK/PLASTIC FILM",
        "concept" : [{
          "code" : "S01010201",
          "display" : "FLAT STERILISATION POUCHES, TYVEK/PLASTIC FILM"
        }]
      },
      {
        "code" : "S010103",
        "display" : "STERILISATION POUCHES, POLYETHYLENE",
        "concept" : [{
          "code" : "S01010301",
          "display" : "FLAT STERILISATION POUCHES, POLYETHYLENE"
        }]
      },
      {
        "code" : "S010199",
        "display" : "STERILISATION POUCHES - OTHER"
      }]
    },
    {
      "code" : "S0102",
      "display" : "STERILISATION REELS",
      "concept" : [{
        "code" : "S010201",
        "display" : "STERILISATION REELS, PAPER/PLASTIC FILM",
        "concept" : [{
          "code" : "S01020101",
          "display" : "FLAT STERILISATION REELS, PAPER/PLASTIC FILM"
        },
        {
          "code" : "S01020102",
          "display" : "STERILISATION REELS, GUSSETED, PAPER/PLASTIC FILM"
        }]
      },
      {
        "code" : "S010202",
        "display" : "STERILISATION REELS, TYVEK/PLASTIC FILM",
        "concept" : [{
          "code" : "S01020201",
          "display" : "FLAT STERILISATION REELS, TYVEK/PLASTIC FILM"
        }]
      },
      {
        "code" : "S010203",
        "display" : "STERILISATION REELS, POLYETHYLENE",
        "concept" : [{
          "code" : "S01020301",
          "display" : "FLAT STERILISATION REELS, POLYETHYLENE"
        }]
      },
      {
        "code" : "S010299",
        "display" : "STERILISATION REELS - OTHER"
      }]
    },
    {
      "code" : "S0103",
      "display" : "MATERIALS FOR PACKAGING PACKS TO BE STERILIZED",
      "concept" : [{
        "code" : "S010301",
        "display" : "MEDICAL CREPE PAPER FOR STERILISATION"
      },
      {
        "code" : "S010302",
        "display" : "NON-WOVEN FABRIC FOR STERILISATION"
      },
      {
        "code" : "S010399",
        "display" : "MATERIALS FOR PACKAGING PACKS TO BE STERILIZED - OTHER"
      }]
    },
    {
      "code" : "S0104",
      "display" : "CONTAINERS FOR STERILISATION",
      "concept" : [{
        "code" : "S010401",
        "display" : "TRAYS, BASKETS, TUBS FOR STERILISATION AND THEIR COMPONENTS"
      },
      {
        "code" : "S010402",
        "display" : "FILTERS FOR STERILISATION CONTAINERS"
      },
      {
        "code" : "S010499",
        "display" : "STERILISATION CONTAINERS - OTHER"
      }]
    },
    {
      "code" : "S0199",
      "display" : "DEVICES FOR STERILISATION AND PACKAGING (EXCLUDING CAT. D - Z) - OTHER"
    }]
  },
  {
    "code" : "S90",
    "display" : "DEVICES FOR STERILISATION (EXCLUDING CAT. D - Z) - VARIOUS",
    "concept" : [{
      "code" : "S9001",
      "display" : "DEVICES FOR GAS PLASMA STERILISATION (EXCLUDING CAT. D - Z)",
      "concept" : [{
        "code" : "S900101",
        "display" : "HYDROGEN PEROXIDE CARTRIDGES"
      },
      {
        "code" : "S900102",
        "display" : "HYDROGEN PEROXIDE DIFFUSERS"
      },
      {
        "code" : "S900103",
        "display" : "DIFFUSER ADAPTORS"
      },
      {
        "code" : "S900199",
        "display" : "DEVICES FOR GAS PLASMA STERILISATION (EXCLUDING CAT. D - Z) - OTHER"
      }]
    },
    {
      "code" : "S9002",
      "display" : "DEVICES FOR STERILISATION WITH PERACETIC ACID (EXCLUDING CAT. D - Z)"
    },
    {
      "code" : "S9003",
      "display" : "DEVICES FOR STERILISATION WITH ETHYLENE OXIDE (EXCLUDING CAT. D - Z)"
    },
    {
      "code" : "S9080",
      "display" : "DEVICES FOR STERILISATION (EXCLUDING CAT. D - Z) - ACCESSORIES"
    },
    {
      "code" : "S9099",
      "display" : "STERILISATION DEVICES (EXCLUDING CAT. D - Z) - OTHER"
    }]
  },
  {
    "code" : "T",
    "display" : "PATIENT PROTECTIVE EQUIPMENT AND INCONTINENCE AIDS (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE)"
  },
  {
    "code" : "T01",
    "display" : "GLOVES (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE)",
    "concept" : [{
      "code" : "T0101",
      "display" : "SURGICAL GLOVES",
      "concept" : [{
        "code" : "T010101",
        "display" : "LATEX SURGICAL GLOVES",
        "concept" : [{
          "code" : "T01010101",
          "display" : "POWDERED LATEX SURGICAL GLOVES"
        },
        {
          "code" : "T01010102",
          "display" : "NON-POWDERED LATEX SURGICAL GLOVES"
        }]
      },
      {
        "code" : "T010102",
        "display" : "SYNTHETIC SURGICAL GLOVES",
        "concept" : [{
          "code" : "T01010201",
          "display" : "POLYCHLOROPREN SURGICAL GLOVES"
        },
        {
          "code" : "T01010202",
          "display" : "NITRILE SURGICAL GLOVES"
        },
        {
          "code" : "T01010203",
          "display" : "POLYISOPREN SURGICAL GLOVES"
        },
        {
          "code" : "T01010299",
          "display" : "SYNTHETIC SURGICAL GLOVES - OTHER"
        }]
      },
      {
        "code" : "T010199",
        "display" : "SURGICAL GLOVES - OTHER"
      }]
    },
    {
      "code" : "T0102",
      "display" : "EXAMINATION / TREATMENT GLOVES",
      "concept" : [{
        "code" : "T010201",
        "display" : "LATEX EXAMINATION / TREATMENT GLOVES"
      },
      {
        "code" : "T010202",
        "display" : "SYNTHETIC EXAMINATION / TREATMENT GLOVES",
        "concept" : [{
          "code" : "T01020201",
          "display" : "VINYL EXAMINATION / TREATMENT GLOVES"
        },
        {
          "code" : "T01020202",
          "display" : "POLYETHYLENE EXAMINATION / TREATMENT GLOVES"
        },
        {
          "code" : "T01020203",
          "display" : "POLYCHLOROPREN EXAMINATION / TREATMENT GLOVES"
        },
        {
          "code" : "T01020204",
          "display" : "NITRILE EXAMINATION / TREATMENT GLOVES"
        },
        {
          "code" : "T01020299",
          "display" : "SYNTHETIC EXAMINATION / TREATMENT GLOVES - OTHER"
        }]
      },
      {
        "code" : "T010299",
        "display" : "EXAMINATION / TREATMENT GLOVES - OTHER"
      }]
    },
    {
      "code" : "T0199",
      "display" : "GLOVES - OTHER"
    }]
  },
  {
    "code" : "T02",
    "display" : "PROTECTIVE CLOTHING AND DRAPES (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE)",
    "concept" : [{
      "code" : "T0201",
      "display" : "SURGICAL DRAPES",
      "concept" : [{
        "code" : "T020101",
        "display" : "INCISION DRAPES",
        "concept" : [{
          "code" : "T02010101",
          "display" : "INCISION DRAPES, WITHOUT ANTIBACTERIAL AGENT"
        },
        {
          "code" : "T02010102",
          "display" : "INCISION DRAPES, WITH ANTIBACTERIAL AGENT"
        }]
      },
      {
        "code" : "T020102",
        "display" : "SPECIALISTIC SURGERY DRAPES"
      },
      {
        "code" : "T020103",
        "display" : "SURGICAL THERMAL DRAPES"
      },
      {
        "code" : "T020199",
        "display" : "SURGICAL DRAPES - OTHER"
      }]
    },
    {
      "code" : "T0202",
      "display" : "SURGICAL PROCEDURAL KITS (EXCLUDING SURGICAL INSTRUMENT KITS)"
    },
    {
      "code" : "T0203",
      "display" : "DRESSING AND ASSISTANCE KITS"
    },
    {
      "code" : "T0204",
      "display" : "SURGICAL GOWNS (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE)",
      "concept" : [{
        "code" : "T020401",
        "display" : "STANDARD SURGICAL GOWNS"
      },
      {
        "code" : "T020402",
        "display" : "REINFORCED SURGICAL GOWNS"
      },
      {
        "code" : "T020499",
        "display" : "SURGICAL GOWNS - OTHER"
      }]
    },
    {
      "code" : "T0205",
      "display" : "NON-SURGICAL GOWNS (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE)"
    },
    {
      "code" : "T0206",
      "display" : "MEDICAL USE FACE MASKS (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE)",
      "concept" : [{
        "code" : "T020603",
        "display" : "MEDICAL USE FACE MASKS, TYPE I (NOT FOR HEALTHCARE PROFESSIONALS)"
      },
      {
        "code" : "T020604",
        "display" : "MEDICAL USE FACE MASKS, TYPE II AND IIR"
      },
      {
        "code" : "T020699",
        "display" : "MEDICAL USE FACE MASKS (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE) - OTHER"
      }]
    },
    {
      "code" : "T0207",
      "display" : "CAPS AND HEADWEAR (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE)"
    },
    {
      "code" : "T0208",
      "display" : "SHOE COVERS (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE)"
    },
    {
      "code" : "T0209",
      "display" : "SURGICAL APRONS (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE)"
    },
    {
      "code" : "T0210",
      "display" : "NON-SURGICAL DRAPES"
    },
    {
      "code" : "T0299",
      "display" : "PROTECTION DRAPES AND GARMENTS - OTHER"
    }]
  },
  {
    "code" : "T03",
    "display" : "PROTECTIONS (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT PPE)",
    "concept" : [{
      "code" : "T0301",
      "display" : "INSTRUMENTS AND EQUIPMENT COVERS",
      "concept" : [{
        "code" : "T030101",
        "display" : "COVER CAPS, INSTRUMENTS AND EQUIPMENT"
      },
      {
        "code" : "T030102",
        "display" : "COVER SHEATHS, INSTRUMENTS AND EQUIPMENTS"
      },
      {
        "code" : "T030103",
        "display" : "ATRAUMATIC INSERTS FOR INSTRUMENTS"
      },
      {
        "code" : "T030199",
        "display" : "COVERS, INSTRUMENTS AND EQUIPMENT - OTHER"
      }]
    },
    {
      "code" : "T0302",
      "display" : "ROBOTIC SURGERY COVERS",
      "concept" : [{
        "code" : "T030201",
        "display" : "MECHANICAL ARMS COVERS"
      },
      {
        "code" : "T030202",
        "display" : "CAMERAS COVERS"
      },
      {
        "code" : "T030203",
        "display" : "OPTICS COVERS"
      },
      {
        "code" : "T030299",
        "display" : "ROBOTIC SURGERY COVERS - OTHER"
      }]
    },
    {
      "code" : "T0303",
      "display" : "NON-SURGICAL HEATING COVERS",
      "concept" : [{
        "code" : "T030301",
        "display" : "AIR FLOW BLANKETS"
      },
      {
        "code" : "T030399",
        "display" : "HEATING COVERS - OTHER"
      }]
    },
    {
      "code" : "T0304",
      "display" : "RADIOTHERAPY PROTECTION DEVICES",
      "concept" : [{
        "code" : "T030401",
        "display" : "RADIOTHERAPY PROTECTION MASKS"
      },
      {
        "code" : "T030402",
        "display" : "RADIOTHERAPY PROTECTION SHEATHS"
      },
      {
        "code" : "T030403",
        "display" : "RADIOTHERAPY PROTECTIVE SCREENS"
      },
      {
        "code" : "T030404",
        "display" : "RADIOTHERAPY PROTECTIVE DRAPES"
      },
      {
        "code" : "T030405",
        "display" : "RADIOTHERAPY EYE PROTECTION"
      },
      {
        "code" : "T030406",
        "display" : "LEAD HANDS"
      },
      {
        "code" : "T030499",
        "display" : "RADIOTHERAPY PROTECTION DEVICES - OTHER"
      }]
    },
    {
      "code" : "T0305",
      "display" : "HEALTH SERVICE PREMISES PROTECTION DEVICES",
      "concept" : [{
        "code" : "T030501",
        "display" : "OPERATION ROOMS AND VISIT ROOMS HYGIENIC COVERS"
      },
      {
        "code" : "T030502",
        "display" : "BED AND STRETCHER HYGIENIC COVERS"
      },
      {
        "code" : "T030599",
        "display" : "HEALTH SERVICE PREMISES PROTECTION DEVICES - OTHER"
      }]
    },
    {
      "code" : "T0306",
      "display" : "PATIENT PROTECTION DEVICES DURING CLINICAL PROCEDURES"
    },
    {
      "code" : "T0399",
      "display" : "PROTECTION DEVICES (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT PPE) - OTHER"
    }]
  },
  {
    "code" : "T04",
    "display" : "INCONTINENCE DEVICES",
    "concept" : [{
      "code" : "T0401",
      "display" : "URINE ABSORBING DEVICES",
      "concept" : [{
        "code" : "T040101",
        "display" : "INCONTINENCE NAPPIES",
        "concept" : [{
          "code" : "T04010101",
          "display" : "RECTANGULAR INCONTINENCE NAPPIES"
        },
        {
          "code" : "T04010102",
          "display" : "SHAPED INCONTINENCE NAPPIES"
        },
        {
          "code" : "T04010103",
          "display" : "INCONTINENCE NAPPIES WITH INTEGRATED FIXING SYSTEM"
        },
        {
          "code" : "T04010104",
          "display" : "NET PANTS"
        },
        {
          "code" : "T04010199",
          "display" : "INCONTINENCE NAPPIES - OTHER"
        }]
      },
      {
        "code" : "T040102",
        "display" : "ABSORBENT BED PADS",
        "concept" : [{
          "code" : "T04010201",
          "display" : "UNTUCKABLE UNDERPADS"
        },
        {
          "code" : "T04010202",
          "display" : "TUCKABLE UNDERPADS"
        },
        {
          "code" : "T04010203",
          "display" : "ABSORBENT ANTIMICROBIAL UNDERPADS"
        },
        {
          "code" : "T04010299",
          "display" : "ABSORBENT UNDERPADS - OTHER"
        }]
      }]
    },
    {
      "code" : "T0499",
      "display" : "INCONTINENCE DEVICES - OTHER"
    }]
  },
  {
    "code" : "T99",
    "display" : "PROTECTIVE DEVICES AND AIDS FOR INCONTINENCE (EXCLUDING PERSONAL PROTECTIVE EQUIPMENT - PPE) - OTHER"
  },
  {
    "code" : "U",
    "display" : "DEVICES FOR UROGENITAL SYSTEM"
  },
  {
    "code" : "U01",
    "display" : "URETHRAL, PROSTATIC AND BLADDER CATHETERS",
    "concept" : [{
      "code" : "U0101",
      "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, WITHOUT BALLOON",
      "concept" : [{
        "code" : "U010101",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, CONICAL-OLIVARY TIP (URETHRAL CALIBRATION)"
      },
      {
        "code" : "U010102",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, COUVELAIRE"
      },
      {
        "code" : "U010103",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, MALECOT"
      },
      {
        "code" : "U010104",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, MERCIER"
      },
      {
        "code" : "U010105",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, NELATON",
        "concept" : [{
          "code" : "U01010501",
          "display" : "NELATON CATHETERS, SELF-LUBRICATING"
        },
        {
          "code" : "U01010502",
          "display" : "NELATON CATHETERS, NON SELF-LUBRICATING"
        }]
      },
      {
        "code" : "U010106",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, TIEMANN",
        "concept" : [{
          "code" : "U01010601",
          "display" : "TIEMANN CATHETERS, SELF-LUBRICATING"
        },
        {
          "code" : "U01010602",
          "display" : "TIEMANN CATHETERS, NON SELF-LUBRICATING"
        }]
      },
      {
        "code" : "U010107",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, PEZZER"
      },
      {
        "code" : "U010199",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, NOT SELF-RETAINED - OTHER"
      }]
    },
    {
      "code" : "U0102",
      "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, WITH BALLOON",
      "concept" : [{
        "code" : "U010201",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, NELATON, WITH BALLOON"
      },
      {
        "code" : "U010202",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, COUVELAIRE, WITH BALLOON"
      },
      {
        "code" : "U010203",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, DELINOTTE, WITH BALLOON"
      },
      {
        "code" : "U010204",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, DUFOUR, WITH BALLOON"
      },
      {
        "code" : "U010205",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, MERCIER, WITH BALLOON"
      },
      {
        "code" : "U010206",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, TIEMANN WITH BALLOON"
      },
      {
        "code" : "U010299",
        "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS, WITH BALLOON - OTHER"
      }]
    },
    {
      "code" : "U0103",
      "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS WITH TEMPERATURE SENSORS"
    },
    {
      "code" : "U0180",
      "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS - ACCESSORIES"
    },
    {
      "code" : "U0199",
      "display" : "URETHRAL PROSTATIC AND BLADDER CATHETERS - OTHER"
    }]
  },
  {
    "code" : "U02",
    "display" : "URETERAL CATHETERS AND STENTS",
    "concept" : [{
      "code" : "U0201",
      "display" : "URETERAL CATHETERS WITHOUT BALLOON",
      "concept" : [{
        "code" : "U020101",
        "display" : "URETERAL CATHETERS WITH CYLINDRICAL TIP"
      },
      {
        "code" : "U020102",
        "display" : "URETERALCATHETERS WITH OPEN FLUTE BEAK TIP"
      },
      {
        "code" : "U020103",
        "display" : "URETERAL CATHETERS WITH CHEVASSU TIP"
      },
      {
        "code" : "U020104",
        "display" : "URETERAL CATHETERS WITH OLIVARE TIP"
      },
      {
        "code" : "U020199",
        "display" : "URETERAL CATHETERS WITHOUT BALLOON - OTHER"
      }]
    },
    {
      "code" : "U0202",
      "display" : "URETERAL CATHETERS WITH BALLOON",
      "concept" : [{
        "code" : "U020201",
        "display" : "URETERAL CATHETERS FOR OCCLUSION"
      },
      {
        "code" : "U020202",
        "display" : "URETERAL CATHETERS WITH FLUTE TIP WITH BALLOON"
      },
      {
        "code" : "U020299",
        "display" : "URETERAL CATHETERS WITH BALLOON - OTHER"
      }]
    },
    {
      "code" : "U0203",
      "display" : "URETERAL STENTS",
      "concept" : [{
        "code" : "U020301",
        "display" : "SINGLE LOOP URETERAL STENTS"
      },
      {
        "code" : "U020302",
        "display" : "DOUBLE LOOP URETERAL STENTS"
      },
      {
        "code" : "U020399",
        "display" : "URETERAL STENTS - OTHER"
      }]
    },
    {
      "code" : "U0204",
      "display" : "TRANSILLUMINATING URETERAL CATHETERS"
    },
    {
      "code" : "U0280",
      "display" : "URETERAL CATHETERS AND STENTS - ACCESSORIES"
    },
    {
      "code" : "U0299",
      "display" : "URETERAL CATHETERS - OTHER"
    }]
  },
  {
    "code" : "U03",
    "display" : "DEVICES FOR URETHRAL, URETERAL AND NEPHROSTOMIC DILATION",
    "concept" : [{
      "code" : "U0301",
      "display" : "DEVICES FOR RIGID DILATION OF THE URINARY TRACT",
      "concept" : [{
        "code" : "U030101",
        "display" : "SEQUENTIAL DILATORS FOR PERCUTANEOUS NEPHROSTOMY",
        "concept" : [{
          "code" : "U03010101",
          "display" : "AMPLATZ CANNULAS FOR URINARY DILATION"
        },
        {
          "code" : "U03010199",
          "display" : "PERCUTANEOUS NEPHROSTOMY, SEQUENTIAL DILATORS - OTHER"
        }]
      },
      {
        "code" : "U030102",
        "display" : "URETHRAL AND URETERAL DILATORS",
        "concept" : [{
          "code" : "U03010201",
          "display" : "URETHRAL DILATORS"
        },
        {
          "code" : "U03010202",
          "display" : "URETERAL DILATORS"
        }]
      }]
    },
    {
      "code" : "U0302",
      "display" : "DEVICES FOR PNEUMATIC DILATION OF THE URINARY TRACT",
      "concept" : [{
        "code" : "U030201",
        "display" : "URETHRAL DILATORS, WITH BALLOON"
      },
      {
        "code" : "U030202",
        "display" : "URETERAL DILATORS, WITH BALLOON"
      }]
    },
    {
      "code" : "U0380",
      "display" : "DEVICES FOR URINARY TRACT DILATION - ACCESSORIES"
    },
    {
      "code" : "U0399",
      "display" : "DEVICES FOR URINARY TRACT DILATION - OTHER"
    }]
  },
  {
    "code" : "U04",
    "display" : "DEVICES FOR PERCUTANEOUS URINARY DRAINAGE AND NEPHROSTOMY CATHETERS",
    "concept" : [{
      "code" : "U0401",
      "display" : "DEVICES FOR SUPRAPUBIC URINARY DRAINAGE",
      "concept" : [{
        "code" : "U040101",
        "display" : "KITS WITH DRAINAGE CATHETERS, DIRECT PUNCTURE"
      },
      {
        "code" : "U040102",
        "display" : "KITS WITH DRAINAGE CATHETERS AND INTRODUCERS"
      },
      {
        "code" : "U040199",
        "display" : "DEVICES FOR SUPRAPUBIC URINARY DRAINAGE - OTHER"
      }]
    },
    {
      "code" : "U0402",
      "display" : "DEVICES FOR PERCUTANEOUS NEPHROSTOMY",
      "concept" : [{
        "code" : "U040201",
        "display" : "NEPHROSTOMY KITS, DIRECT PUNCTURE"
      },
      {
        "code" : "U040202",
        "display" : "NEPHROSTOMY KITS, SELDINGER METHOD"
      },
      {
        "code" : "U040203",
        "display" : "NEPHROSTOMY CATHETERS"
      },
      {
        "code" : "U040299",
        "display" : "DEVICES FOR PERCUTANEOUS NEPHROSTOMY - OTHER"
      }]
    },
    {
      "code" : "U0403",
      "display" : "DEVICES FOR URETERAL DIVERSION AND URETEROCUTANEOSTOMY",
      "concept" : [{
        "code" : "U040301",
        "display" : "URETERAL DIVERSION PROBES, BRACCI"
      },
      {
        "code" : "U040302",
        "display" : "URETEROCUTANEOSTOMY PROBES"
      },
      {
        "code" : "U040399",
        "display" : "DEVICES FOR URETERAL DIVERSION AND URETEROCUTANEOSTOMY - OTHER"
      }]
    },
    {
      "code" : "U0480",
      "display" : "DEVICES FOR PERCUTANEOUS URINARY DRAINAGE - ACCESSORIES"
    },
    {
      "code" : "U0499",
      "display" : "DEVICES FOR PERCUTANEOUS URINARY DRAINAGE - OTHER"
    }]
  },
  {
    "code" : "U05",
    "display" : "URODYNAMICS DEVICES",
    "concept" : [{
      "code" : "U0501",
      "display" : "CYSTOMANOMETRY AND URETHROMANOMETRY CATHETERS",
      "concept" : [{
        "code" : "U050101",
        "display" : "CYSTOMANOMETRY CATHETERS, WITHOUT BALLOON",
        "concept" : [{
          "code" : "U05010101",
          "display" : "CYSTOMANOMETRY CATHETERS, WITHOUT BALLOON, 2-WAY"
        },
        {
          "code" : "U05010102",
          "display" : "CYSTOMANOMETRY CATHETERS, WITHOUT BALLOON, 3-WAY"
        }]
      },
      {
        "code" : "U050199",
        "display" : "CYSTOMANOMETRY AND URETHROMANOMETRY CATHETERS - OTHER"
      }]
    },
    {
      "code" : "U0502",
      "display" : "URINARY PRESSURE-FLOW STUDY CATHETERS",
      "concept" : [{
        "code" : "U050201",
        "display" : "FILLING CATHETERS FOR URINARY PRESSURE-FLOW STUDY"
      },
      {
        "code" : "U050202",
        "display" : "BLADDER PRESSURE-FLOW STUDY CATHETERS"
      },
      {
        "code" : "U050299",
        "display" : "URINARY PRESSURE-FLOW STUDY CATHETERS - OTHER"
      }]
    },
    {
      "code" : "U0503",
      "display" : "URETHRAL PRESSURE PROFILE CATHETERS",
      "concept" : [{
        "code" : "U050301",
        "display" : "URETHRAL PRESSURE PROFILE CATHETERS WITHOUT BALLOON",
        "concept" : [{
          "code" : "U05030101",
          "display" : "URETHRAL PRESSURE PROFILE CATHETERS WITHOUT BALLOON, 1-WAY"
        },
        {
          "code" : "U05030102",
          "display" : "URETHRAL PRESSURE PROFILE CATHETERS WITHOUT BALLOON, 2-WAY"
        }]
      },
      {
        "code" : "U050399",
        "display" : "URETHRAL PRESSURE PROFILE CATHETERS - OTHER"
      }]
    },
    {
      "code" : "U0504",
      "display" : "INTRA-ABDOMINAL PRESSURE MEASUREMENT CATHETERS",
      "concept" : [{
        "code" : "U050401",
        "display" : "INTRA-ABDOMINAL PRESSURE MEASUREMENT CATHETERS, WITHOUT BALLOON"
      },
      {
        "code" : "U050402",
        "display" : "INTRA-ABDOMINAL PRESSURE MEASUREMENT CATHETERS, WITH BALLOON"
      }]
    },
    {
      "code" : "U0505",
      "display" : "CAVERNOSOMETRY AND CAVERNOSOGRAPHY PROBES"
    },
    {
      "code" : "U0580",
      "display" : "URODYNAMICS DEVICES - ACCESSORIES"
    },
    {
      "code" : "U0599",
      "display" : "URODYNAMICS DEVICES - OTHER"
    }]
  },
  {
    "code" : "U06",
    "display" : "UROLOGICAL GUIDEWIRES",
    "concept" : [{
      "code" : "U0601",
      "display" : "UROLOGICAL GUIDEWIRES, HYDROPHILIC"
    },
    {
      "code" : "U0602",
      "display" : "UROLOGICAL GUIDEWIRES, NOT HYDROPHILIC"
    },
    {
      "code" : "U0699",
      "display" : "UROLOGICAL GUIDEWIRES - OTHER"
    }]
  },
  {
    "code" : "U07",
    "display" : "DEVICES FOR THE TREATMENT OF INCONTINENCE",
    "concept" : [{
      "code" : "U0701",
      "display" : "INTERNAL SYSTEMS FOR THE TREATMENT OF INCONTINENCE",
      "concept" : [{
        "code" : "U070101",
        "display" : "SLING SYSTEMS FOR THE TREATMENT OF INCONTINENCE"
      },
      {
        "code" : "U070199",
        "display" : "INTERNAL SYSTEMS FOR THE TREATMENT OF INCONTINENCE - OTHER"
      }]
    },
    {
      "code" : "U0702",
      "display" : "EXTERNAL DEVICES FOR THE TREATMENT OF INCONTINENCE",
      "concept" : [{
        "code" : "U070201",
        "display" : "SHEATH CATHETER FOR THE TREATMENT OF INCONTINENCE"
      },
      {
        "code" : "U070299",
        "display" : "EXTERNAL DEVICES FOR THE TREATMENT OF INCONTINENCE - OTHER"
      }]
    },
    {
      "code" : "U0703",
      "display" : "PELVIC FLOOR REHABILITATION DEVICES",
      "concept" : [{
        "code" : "U070301",
        "display" : "PELVIC FLOOR REHABILITATION DEVICES, BIOFEEDBACK, SINGLE-USE"
      },
      {
        "code" : "U070302",
        "display" : "PELVIC FLOOR REHABILITATION DEVICES, FUNCTIONAL ELECTROSTIMULATION, SINGLE-USE"
      },
      {
        "code" : "U070399",
        "display" : "PELVIC FLOOR REHABILITATION DEVICES - OTHER"
      }]
    },
    {
      "code" : "U0780",
      "display" : "DEVICES FOR THE TREATMENT OF INCONTINENCE - ACCESSORIES"
    },
    {
      "code" : "U0799",
      "display" : "DEVICES FOR THE TREATMENT OF INCONTINENCE - OTHER"
    }]
  },
  {
    "code" : "U08",
    "display" : "GYNAECOLOGICAL DEVICES",
    "concept" : [{
      "code" : "U0801",
      "display" : "GYNAECOLOGICAL CATHETERS",
      "concept" : [{
        "code" : "U080101",
        "display" : "CATHETERS FOR ENDOMETRIAL ABLATION"
      },
      {
        "code" : "U080102",
        "display" : "CATHETERS FOR HYSTEROSALPINGOGRAPHY"
      },
      {
        "code" : "U080103",
        "display" : "CATHETERS FOR HYSTEROSCOPY"
      },
      {
        "code" : "U080199",
        "display" : "GYNAECOLOGICAL CATHETERS - OTHER"
      }]
    },
    {
      "code" : "U0802",
      "display" : "DEVICES FOR ASSISTED REPRODUCTION",
      "concept" : [{
        "code" : "U080201",
        "display" : "CATHETERS FOR ASSISTED REPRODUCTION",
        "concept" : [{
          "code" : "U08020101",
          "display" : "CATHETERS FOR INSEMINATION"
        },
        {
          "code" : "U08020102",
          "display" : "CATHETERS FOR EMBRYO TRANSFER"
        },
        {
          "code" : "U08020180",
          "display" : "ASSISTED REPRODUCTION CATHETERS - ACCESSORIES"
        },
        {
          "code" : "U08020199",
          "display" : "ASSISTED REPRODUCTION CATHETERS - OTHER"
        }]
      },
      {
        "code" : "U080202",
        "display" : "NEEDLES AND SETS FOR OOCYTE RETRIEVAL FOR ASSISTED REPRODUCTION",
        "concept" : [{
          "code" : "U08020201",
          "display" : "SINGLE LUMEN NEEDLES AND SETS/SYSTEMS FOR OOCYTE RETRIEVAL"
        },
        {
          "code" : "U08020202",
          "display" : "DOUBLE LUMEN NEEDLES AND SETS/SYSTEMS FOR OOCYTE RETRIEVAL"
        }]
      },
      {
        "code" : "U080203",
        "display" : "DEVICES FOR MICROMANIPULATION OF BIOLOGICAL MATERIAL FOR ASSISTED REPRODUCTION",
        "concept" : [{
          "code" : "U08020301",
          "display" : "PIPETTES FOR ASSISTED REPRODUCTION",
          "concept" : [{
            "code" : "U0802030101",
            "display" : "BIOPSY PIPETTES FOR ASSISTED REPRODUCTION"
          },
          {
            "code" : "U0802030102",
            "display" : "DENUDING PIPETTES"
          },
          {
            "code" : "U0802030103",
            "display" : "HANDLING PIPETTES"
          },
          {
            "code" : "U0802030104",
            "display" : "HATCHING/DRILLING PIPETTES"
          },
          {
            "code" : "U0802030105",
            "display" : "HOLDING PIPETTES"
          },
          {
            "code" : "U0802030106",
            "display" : "ICSI PIPETTES"
          },
          {
            "code" : "U0802030107",
            "display" : "PASTEUR PIPETTES FOR ASSISTED REPRODUCTION"
          },
          {
            "code" : "U0802030108",
            "display" : "PZD PIPETTES"
          },
          {
            "code" : "U0802030199",
            "display" : "PIPETTES FOR ASSISTED REPRODUCTION - OTHER"
          }]
        },
        {
          "code" : "U08020302",
          "display" : "SYSTEMS FOR MICROMANIPULATION OF BIOLOGICAL MATERIAL FOR ASSISTED REPRODUCTION",
          "concept" : [{
            "code" : "U0802030201",
            "display" : "TIPS FOR ASSISTED REPRODUCTION"
          },
          {
            "code" : "U0802030202",
            "display" : "HANDPIECES FOR TIPS FOR ASSISTED REPRODUCTION"
          }]
        },
        {
          "code" : "U08020380",
          "display" : "DEVICES FOR MICROMANIPULATION OF BIOLOGICAL MATERIAL FOR ASSISTED REPRODUCTION - ACCESSORIES"
        },
        {
          "code" : "U08020399",
          "display" : "DEVICES FOR MICROMANIPULATION OF BIOLOGICAL MATERIAL FOR ASSISTED REPRODUCTION - OTHER"
        }]
      },
      {
        "code" : "U080204",
        "display" : "CRYOPRESERVATION CONTAINERS/SETS FOR ASSISTED REPRODUCTION",
        "concept" : [{
          "code" : "U08020401",
          "display" : "CRYOPRESERVATION CONTAINERS/STRAWS/VIALS FOR ASSISTED REPRODUCTION"
        }]
      },
      {
        "code" : "U080205",
        "display" : "SUBSTRATES FOR STORING/HANDLING BIOLOGICAL MATERIAL FOR ASSISTED REPRODUCTION",
        "concept" : [{
          "code" : "U08020501",
          "display" : "MATERIALS/SOLUTIONS FOR FREEZING/THAWING FOR ASSISTED REPRODUCTION"
        },
        {
          "code" : "U08020502",
          "display" : "MATERIALS/SOLUTIONS FOR PREPARATION/HANDLING FOR ASSISTED REPRODUCTION"
        },
        {
          "code" : "U08020503",
          "display" : "MATERIALS/CULTURE MEDIA FOR ASSISTED REPRODUCTION"
        },
        {
          "code" : "U08020599",
          "display" : "SUBSTRATES FOR STORING/HANDLING BIOLOGICAL MATERIAL FOR ASSISTED REPRODUCTION - OTHER"
        }]
      },
      {
        "code" : "U080206",
        "display" : "CULTURE PLATES FOR ASSISTED REPRODUCTION"
      },
      {
        "code" : "U080207",
        "display" : "CONTAINERS FOR PREPARATION OF BIOLOGICAL MATERIAL FOR ASSISTED REPRODUCTION"
      },
      {
        "code" : "U080299",
        "display" : "DEVICES FOR ASSISTED REPRODUCTION - OTHER"
      }]
    },
    {
      "code" : "U0803",
      "display" : "VAGINAL DEVICES IN THE FORM OF SOLUTIONS/CREAMS/OVA/TABLETS"
    },
    {
      "code" : "U0890",
      "display" : "DEVICES FOR GYNECOLOGY - VARIOUS",
      "concept" : [{
        "code" : "U089002",
        "display" : "DEVICES FOR GYNAECOLOGICAL CYTOLOGY"
      },
      {
        "code" : "U089003",
        "display" : "HYSTEROMETERS, SINGLE-USE"
      },
      {
        "code" : "U089005",
        "display" : "PESSARIANS"
      },
      {
        "code" : "U089006",
        "display" : "VAGINAL SPECULUM, SINGLE-USE"
      },
      {
        "code" : "U089009",
        "display" : "VAGINAL APPLICATORS, SINGLE-USE"
      },
      {
        "code" : "U089010",
        "display" : "UTERINE CURETTES, SINGLE-USE"
      }]
    },
    {
      "code" : "U0899",
      "display" : "GYNAECOLOGICAL DEVICES - OTHER"
    }]
  },
  {
    "code" : "U09",
    "display" : "UROGENITAL ENDOSCOPIC DEVICES",
    "concept" : [{
      "code" : "U0901",
      "display" : "URINARY STONE RETRIEVAL DEVICES",
      "concept" : [{
        "code" : "U090101",
        "display" : "URINARY STONE RETRIEVAL BASKETS"
      },
      {
        "code" : "U090102",
        "display" : "URINARY STONE RETRIEVAL BALLOON CATHETERS"
      },
      {
        "code" : "U090199",
        "display" : "URINARY STONE RETRIEVAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "U0902",
      "display" : "UROGENITAL ENDOSCOPIC RESECTION INSTRUMENTS",
      "concept" : [{
        "code" : "U090201",
        "display" : "UROGENITAL THERMOABLATION, NEEDLES AND KITS"
      },
      {
        "code" : "U090202",
        "display" : "PROSTATECTOMY LOOPS"
      },
      {
        "code" : "U090203",
        "display" : "GYNAECOLOGY LOOPS"
      },
      {
        "code" : "U090204",
        "display" : "BLADDER EVACUATORS"
      },
      {
        "code" : "U090299",
        "display" : "UROGENITAL ENDOSCOPIC RESECTION INSTRUMENTS - OTHER"
      }]
    },
    {
      "code" : "U0903",
      "display" : "SINGLE-USE INSTRUMENTS FOR UROGENITAL ENDOSCOPY",
      "concept" : [{
        "code" : "U090301",
        "display" : "FORCEPS FOR UROGENITAL ENDOSCOPY, SINGLE-USE",
        "concept" : [{
          "code" : "U09030101",
          "display" : "BIOPSY FORCEPS FOR UROGENITAL ENDOSCOPY, SINGLE-USE",
          "concept" : [{
            "code" : "U0903010101",
            "display" : "COLD BIOPSY FORCEPS FOR UROGENITAL ENDOSCOPY, SINGLE-USE"
          },
          {
            "code" : "U0903010102",
            "display" : "HOT BIOPSY FORCEPS FOR UROGENITAL ENDOSCOPY, SINGLE-USE"
          }]
        },
        {
          "code" : "U09030102",
          "display" : "EXTRACTION FORCEPS FOR UROGENITAL ENDOSCOPY, SINGLE-USE"
        },
        {
          "code" : "U09030199",
          "display" : "FORCEPS FOR UROGENITAL ENDOSCOPY, SINGLE-USE - OTHER"
        }]
      },
      {
        "code" : "U090303",
        "display" : "UROGENITAL ENDOSCOPY BRUSHES",
        "concept" : [{
          "code" : "U09030301",
          "display" : "UROGENITAL CYTOLOGY BRUSHES"
        }]
      },
      {
        "code" : "U090399",
        "display" : "SINGLE-USE INSTRUMENTS FOR UROGENITAL ENDOSCOPY - OTHER"
      }]
    },
    {
      "code" : "U0999",
      "display" : "UROGENITAL ENDOSCOPIC DEVICES - OTHER"
    }]
  },
  {
    "code" : "U10",
    "display" : "OBSTETRICS DEVICES",
    "concept" : [{
      "code" : "U1001",
      "display" : "OBSTETRICS CATHETERS",
      "concept" : [{
        "code" : "U100101",
        "display" : "CATHETERS FOR VOLUNTARY TERMINATION OF PREGNANCY"
      },
      {
        "code" : "U100102",
        "display" : "POSTPARTUM INTRAUTERINE CATHETERS"
      },
      {
        "code" : "U100199",
        "display" : "OBSTETRICAL CATHETERS - OTHER"
      }]
    },
    {
      "code" : "U1002",
      "display" : "FETAL STUDY DEVICES",
      "concept" : [{
        "code" : "U100201",
        "display" : "FOETAL SCALP ELECTRODES"
      },
      {
        "code" : "U100299",
        "display" : "FOETAL STUDY DEVICES - OTHER"
      }]
    },
    {
      "code" : "U1003",
      "display" : "PUERPERIUM DEVICES"
    },
    {
      "code" : "U1004",
      "display" : "MANUAL OBSTETRICAL EXTRACTORS, SINGLE-USE"
    },
    {
      "code" : "U1005",
      "display" : "AMNIOTIC MEMBRANE PERFORATORS"
    },
    {
      "code" : "U1006",
      "display" : "SINGLE-USE RIGID AMNIOSCOPES"
    },
    {
      "code" : "U1007",
      "display" : "UTERINE CERCLAGE DEVICES"
    },
    {
      "code" : "U1080",
      "display" : "OBSTETRICS DEVICES - ACCESSORIES"
    },
    {
      "code" : "U1099",
      "display" : "OBSTETRICS DEVICES - OTHER"
    }]
  },
  {
    "code" : "U11",
    "display" : "CONTRACEPTIVE DEVICES",
    "concept" : [{
      "code" : "U1101",
      "display" : "MALE CONTRACEPTIVE DEVICES",
      "concept" : [{
        "code" : "U110101",
        "display" : "CONDOMS"
      },
      {
        "code" : "U110102",
        "display" : "DEVICES FOR LIGATION OF THE VASA DEFERENTIA"
      },
      {
        "code" : "U110199",
        "display" : "DEVICES FOR MALE CONTRACEPTION - OTHER"
      }]
    },
    {
      "code" : "U1102",
      "display" : "DEVICES FOR FEMALE CONTRACEPTION",
      "concept" : [{
        "code" : "U110201",
        "display" : "INTRAUTERINE COILS"
      },
      {
        "code" : "U110202",
        "display" : "VAGINAL DIAPHRAGMS"
      },
      {
        "code" : "U110203",
        "display" : "FEMALE CONDOMS"
      },
      {
        "code" : "U110299",
        "display" : "DEVICES FOR FEMALE CONTRACEPTION - OTHER"
      }]
    }]
  },
  {
    "code" : "U12",
    "display" : "SINGLE-USE INSTRUMENTATION FOR UROGENITAL SYSTEM (NON-ENDOSCOPIC)",
    "concept" : [{
      "code" : "U1201",
      "display" : "NON-ENDOSCOPIC SINGLE-USE FORCEPS FOR UROGENITAL SYSTEM"
    },
    {
      "code" : "U1202",
      "display" : "SINGLE-USE NON-ENDOSCOPIC UROGENITAL SCISSORS"
    },
    {
      "code" : "U1299",
      "display" : "SINGLE-USE UROGENITAL INSTRUMENTATION (NON-ENDOSCOPIC) - OTHER"
    }]
  },
  {
    "code" : "U13",
    "display" : "SOLUTIONS AND KITS FOR BLADDER WASHING AND INSTILLATION",
    "concept" : [{
      "code" : "U1301",
      "display" : "SOLUTIONS FOR BLADDER WASHING AND INSTILLATION"
    },
    {
      "code" : "U1302",
      "display" : "KITS FOR BLADDER WASHING AND INSTILLATION"
    }]
  },
  {
    "code" : "U99",
    "display" : "DEVICES FOR UROGENITAL SYSTEM - OTHER"
  },
  {
    "code" : "V",
    "display" : "VARIOUS MEDICAL DEVICES"
  },
  {
    "code" : "V01",
    "display" : "CUTTING DEVICES, SINGLE-USE",
    "concept" : [{
      "code" : "V0101",
      "display" : "SCALPELS, SINGLE-USE",
      "concept" : [{
        "code" : "V010101",
        "display" : "SCALPELS WITH SAFETY SYSTEMS, SINGLE-USE"
      },
      {
        "code" : "V010102",
        "display" : "SCALPELS WITHOUT SAFETY SYSTEMS, SINGLE-USE"
      }]
    },
    {
      "code" : "V0102",
      "display" : "STAPLE REMOVER KNIVES, SINGLE-USE"
    },
    {
      "code" : "V0103",
      "display" : "BLADES, SINGLE-USE - NOT INCLUDED IN OTHER CLASSES",
      "concept" : [{
        "code" : "V010301",
        "display" : "BLADES WITH SAFETY SYSTEMS, SINGLE-USE - NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "V010302",
        "display" : "BLADES WITHOUT SAFETY SYSTEMS, SINGLE-USE - NOT INCLUDED IN OTHER CLASSES"
      }]
    },
    {
      "code" : "V0104",
      "display" : "LANCETS, SINGLE-USE",
      "concept" : [{
        "code" : "V010401",
        "display" : "LANCETS WITH SAFETY SYSTEMS, SINGLE-USE"
      },
      {
        "code" : "V010402",
        "display" : "LANCETS WITHOUT SAFETY SYSTEMS, SINGLE-USE"
      }]
    },
    {
      "code" : "V0199",
      "display" : "CUTTING DEVICES, SINGLE-USE - OTHER"
    }]
  },
  {
    "code" : "V02",
    "display" : "NEONATOLOGY AND PAEDIATRIC DEVICES",
    "concept" : [{
      "code" : "V0201",
      "display" : "PHOTOTHERAPY MASKS"
    },
    {
      "code" : "V0202",
      "display" : "UMBILICAL CLAMPS AND CLIPPERS, SINGLE-USE"
    },
    {
      "code" : "V0203",
      "display" : "NEWBORN NUTRITION DEVICES",
      "concept" : [{
        "code" : "V020301",
        "display" : "MANUAL BREAST PUMPERS AND KITS"
      },
      {
        "code" : "V020302",
        "display" : "BABY BOTTLES AND KIT"
      },
      {
        "code" : "V020380",
        "display" : "NEWBORN NUTRITION DEVICES - ACCESSORIES"
      },
      {
        "code" : "V020399",
        "display" : "NEWBORN NUTRITION DEVICES - OTHER"
      }]
    },
    {
      "code" : "V0280",
      "display" : "NEONATOLOGY AND PEDIATRICS DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES",
      "concept" : [{
        "code" : "V028002",
        "display" : "NEONATOLOGY CARE KITS"
      },
      {
        "code" : "V028099",
        "display" : "NEONATOLOGY AND PEDIATRICS DEVICES - ACCESSORIES NOT INCLUDED IN OTHER CLASSES - OTHER"
      }]
    },
    {
      "code" : "V0299",
      "display" : "NEONATOLOGY AND PAEDIATRIC DEVICES - OTHER"
    }]
  },
  {
    "code" : "V03",
    "display" : "MEASUREMENT DEVICES",
    "concept" : [{
      "code" : "V0301",
      "display" : "BODY TEMPERATURE MEASUREMENT DEVICES",
      "concept" : [{
        "code" : "V030101",
        "display" : "THERMOMETERS",
        "concept" : [{
          "code" : "V03010102",
          "display" : "DIGITAL THERMOMETERS",
          "concept" : [{
            "code" : "V0301010201",
            "display" : "CONTACT DIGITAL THERMOMETERS"
          },
          {
            "code" : "V0301010202",
            "display" : "NON-CONTACT DIGITAL THERMOMETERS"
          },
          {
            "code" : "V0301010299",
            "display" : "DIGITAL THERMOMETERS - OTHER"
          }]
        },
        {
          "code" : "V03010104",
          "display" : "LIQUID EXPANSION THERMOMETERS"
        },
        {
          "code" : "V03010199",
          "display" : "THERMOMETERS - OTHER"
        }]
      },
      {
        "code" : "V030102",
        "display" : "BODY TEMPERATURE MONITORING PROBES",
        "concept" : [{
          "code" : "V03010201",
          "display" : "TEMPERATURE MONITORING CUTANEOUS PROBES"
        },
        {
          "code" : "V03010299",
          "display" : "BODY TEMPERATURE MONITORING PROBES - OTHER"
        }]
      },
      {
        "code" : "V030180",
        "display" : "BODY TEMPERATURE MEASURING DEVICES - ACCESSORIES"
      },
      {
        "code" : "V030199",
        "display" : "BODY TEMPERATURE MEASURING DEVICES - OTHER"
      }]
    },
    {
      "code" : "V0302",
      "display" : "CLINICAL DIMENSIONAL PARAMETERS MEASURING DEVICES",
      "concept" : [{
        "code" : "V030201",
        "display" : "CALIPERS"
      },
      {
        "code" : "V030202",
        "display" : "GONIOMETERS"
      },
      {
        "code" : "V030203",
        "display" : "OPHTHALMOLOGY MEASUREMENT DEVICES NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "V030204",
        "display" : "IMPLANT MEASUREMENT DEVICES NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "V030205",
        "display" : "OBSTETRICS AND GYNECOLOGY MEASUREMENT DEVICES NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "V030206",
        "display" : "UROLOGY MEASUREMENT DEVICES NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "V030207",
        "display" : "SENSITIVITY MEASUREMENTS DEVICES NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "V030208",
        "display" : "ENT MEASUREMENT DEVICES NOT INCLUDED IN OTHER CLASSES"
      },
      {
        "code" : "V030209",
        "display" : "CLINICAL ALTIMETERS"
      },
      {
        "code" : "V030210",
        "display" : "WEIGHING SCALES (EXCLUDING THOSE FOR NEONATOLOGY)"
      },
      {
        "code" : "V030211",
        "display" : "MULTIDIMENSIONAL MEASUREMENTS STATIONS",
        "concept" : [{
          "code" : "V03021101",
          "display" : "CLINICAL ALTIMETERS WITH WEIGHING SCALE"
        },
        {
          "code" : "V03021199",
          "display" : "MULTIDIMENSIONAL MEASUREMENTS STATIONS - OTHER"
        }]
      },
      {
        "code" : "V030299",
        "display" : "DIMENSIONAL CLINICAL PARAMETERS MEASURING DEVICES - OTHER"
      }]
    },
    {
      "code" : "V0380",
      "display" : "DEVICES WITH MEASURING FUNCTIONS - ACCESSORIES"
    },
    {
      "code" : "V0399",
      "display" : "MEASUREMENT DEVICES - OTHER"
    }]
  },
  {
    "code" : "V04",
    "display" : "CLINICAL USE CONTAINERS (NON-IVD)",
    "concept" : [{
      "code" : "V0401",
      "display" : "CLINICAL USE BOTTLES"
    },
    {
      "code" : "V0402",
      "display" : "CLINICAL USE TRAYS AND BOWLS"
    },
    {
      "code" : "V0480",
      "display" : "CLINICAL USE CONTAINERS (NON-IVD) - ACCESSORIES"
    },
    {
      "code" : "V0499",
      "display" : "CLINICAL USE CONTAINERS (NON-IVD) - OTHER"
    }]
  },
  {
    "code" : "V05",
    "display" : "CLINICAL PROCEDURES KITS NOT INCLUDED IN OTHER CLASSES",
    "concept" : [{
      "code" : "V0501",
      "display" : "CLINICAL EMERGENCY KITS"
    },
    {
      "code" : "V0502",
      "display" : "CLINICAL ADMINISTRATION KITS NOT INCLUDED IN OTHER CLASSES"
    },
    {
      "code" : "V0599",
      "display" : "CLINICAL PROCEDURES KITS NOT INCLUDED IN OTHER CLASSES - OTHER"
    }]
  },
  {
    "code" : "V06",
    "display" : "CLINICAL PROCEDURE SIMULATION DEVICES",
    "concept" : [{
      "code" : "V0601",
      "display" : "ORTHOPAEDIC AND TRAUMATOLOGY PROCEDURES SIMULATION DEVICES",
      "concept" : [{
        "code" : "V060101",
        "display" : "ORTHOPAEDIC PROSTHESES TESTING DEVICES",
        "concept" : [{
          "code" : "V06010101",
          "display" : "HIP PROSTHESES TESTING DEVICES"
        },
        {
          "code" : "V06010102",
          "display" : "KNEE PROSTHESES TESTING DEVICES"
        },
        {
          "code" : "V06010103",
          "display" : "SHOULDER PROSTHESES TESTING DEVICES"
        },
        {
          "code" : "V06010199",
          "display" : "ORTHOPAEDIC PROSTHESES TESTING DEVICES - OTHER"
        }]
      },
      {
        "code" : "V060102",
        "display" : "SPINAL SURGERY TESTING DEVICES"
      }]
    },
    {
      "code" : "V0602",
      "display" : "VASCULAR PROCEDURES SIMULATION DEVICES"
    },
    {
      "code" : "V0603",
      "display" : "DENTAL PROCEDURES SIMULATION DEVICES"
    },
    {
      "code" : "V0604",
      "display" : "GENERAL SURGICAL PROCEDURES SIMULATION DEVICES"
    },
    {
      "code" : "V0605",
      "display" : "OPHTHALMOLOGICAL PROCEDURES SIMULATION DEVICES"
    },
    {
      "code" : "V0606",
      "display" : "BREAST SURGERY TESTING DEVICES"
    },
    {
      "code" : "V0607",
      "display" : "OSTEOSYNTHESIS IMPLANTS TESTING DEVICES"
    },
    {
      "code" : "V0680",
      "display" : "CLINICAL PROCEDURES SIMULATION DEVICES - ACCESSORIES"
    },
    {
      "code" : "V0699",
      "display" : "CLINICAL PROCEDURES SIMULATION DEVICES - OTHER"
    }]
  },
  {
    "code" : "V07",
    "display" : "MEDICAL DEVICE CLEANING DEVICES, NOT OTHERWISE CLASSIFIED",
    "concept" : [{
      "code" : "V0701",
      "display" : "CLEANING BRUSHES",
      "concept" : [{
        "code" : "V070101",
        "display" : "ENDOSCOPES CLEANING BRUSHES - FOR GENERIC USE"
      },
      {
        "code" : "V070102",
        "display" : "DIGESTIVE ENDOSCOPY ENDOSCOPES CLEANING BRUSHES"
      },
      {
        "code" : "V070103",
        "display" : "NEPHRO-CISTOSCOPIC OPTICS CLEANING BRUSHES"
      },
      {
        "code" : "V070104",
        "display" : "BRONCHOSCOPIC OPTICS CLEANING BRUSHES"
      },
      {
        "code" : "V070105",
        "display" : "INSTRUMENTS CLEANING BRUSHES"
      }]
    },
    {
      "code" : "V0702",
      "display" : "CANNULATED INSTRUMENTS AND DEVICES CLEANING BRUSHES"
    },
    {
      "code" : "V0703",
      "display" : "ELECTRODES CLEANING SPONGES"
    },
    {
      "code" : "V0704",
      "display" : "CANNULATED INSTRUMENTS AND DEVICES CLEANING STYLETS"
    },
    {
      "code" : "V0799",
      "display" : "PRODUCTS FOR CLEANING MEDICAL DEVICES NOT INCLUDED IN OTHER CLASSES - OTHER"
    }]
  },
  {
    "code" : "V08",
    "display" : "HEALTHCARE ACTIVITIES SUPPORTIVE EQUIPMENT AND AIDS",
    "concept" : [{
      "code" : "V0802",
      "display" : "MEDICAL CHAIRS",
      "concept" : [{
        "code" : "V080201",
        "display" : "ELECTRIC MEDICAL CHAIRS",
        "concept" : [{
          "code" : "V08020101",
          "display" : "GENERIC USE ELECTRIC MEDICAL CHAIRS"
        },
        {
          "code" : "V08020102",
          "display" : "ELECTRIC MEDICAL CHAIRS WITH WEIGHING SYSTEM"
        },
        {
          "code" : "V08020199",
          "display" : "ELECTRIC MEDICAL CHAIRS - OTHER"
        }]
      },
      {
        "code" : "V080202",
        "display" : "MANUAL MEDICAL CHAIRS"
      },
      {
        "code" : "V080280",
        "display" : "MEDICAL CHAIRS - ACCESSORIES"
      },
      {
        "code" : "V080299",
        "display" : "MEDICAL CHAIRS - OTHER"
      }]
    },
    {
      "code" : "V0803",
      "display" : "MEDICAL CUSHIONS",
      "concept" : [{
        "code" : "V080301",
        "display" : "ANTI-DECUBITUS MEDICAL CUSHIONS",
        "concept" : [{
          "code" : "V08030101",
          "display" : "ACTIVE ANTI-DECUBITUS MEDICAL CUSHIONS"
        },
        {
          "code" : "V08030102",
          "display" : "NON-ACTIVE ANTI-DECUBITUS MEDICAL CUSHIONS"
        }]
      },
      {
        "code" : "V080302",
        "display" : "PATIENT POSITIONING MEDICAL CUSHIONS"
      },
      {
        "code" : "V080399",
        "display" : "MEDICAL CUSHIONS - OTHER"
      }]
    },
    {
      "code" : "V0804",
      "display" : "PATIENT IMMOBILISERS (in diagnostic or therapeutic procedures)"
    },
    {
      "code" : "V0805",
      "display" : "PATIENT TRANSFER EQUIPMENT",
      "concept" : [{
        "code" : "V080501",
        "display" : "PATIENT TRANSFER STRETCHERS",
        "concept" : [{
          "code" : "V08050101",
          "display" : "GENERIC USE STRETCHERS"
        },
        {
          "code" : "V08050102",
          "display" : "SELF-LOADING STRETCHERS"
        },
        {
          "code" : "V08050103",
          "display" : "EMERGENCY AND TRAUMATOLOGY STRETCHERS"
        },
        {
          "code" : "V08050104",
          "display" : "BIO-CONTAINMENT STRETCHERS"
        },
        {
          "code" : "V08050199",
          "display" : "PATIENT TRANSFER STRETCHERS - OTHER"
        }]
      },
      {
        "code" : "V080502",
        "display" : "PATIENT TRANSFER CHAIRS"
      },
      {
        "code" : "V080503",
        "display" : "PATIENT TRANSFER LIFTS",
        "concept" : [{
          "code" : "V08050301",
          "display" : "MOBILE LIFTS",
          "concept" : [{
            "code" : "V0805030101",
            "display" : "MANUAL MOBILE LIFTS"
          },
          {
            "code" : "V0805030102",
            "display" : "ELECTRIC MOBILE LIFTS"
          }]
        },
        {
          "code" : "V08050302",
          "display" : "ELECTRIC FIXED LIFTS"
        },
        {
          "code" : "V08050303",
          "display" : "BATH LIFTS"
        },
        {
          "code" : "V08050380",
          "display" : "PATIENT TRANSFER LIFTS - ACCESSORIES",
          "concept" : [{
            "code" : "V0805038001",
            "display" : "RIGID SUPPORTS FOR LIFTS (STRETCHERS)"
          },
          {
            "code" : "V0805038002",
            "display" : "NON-RIGID SUPPORTS FOR LIFTS (HARNESSES)"
          }]
        },
        {
          "code" : "V08050399",
          "display" : "PATIENT TRANSFER LIFTS - OTHER"
        }]
      },
      {
        "code" : "V080504",
        "display" : "PATIENT TRANSFER BOARDS AND TABLES"
      }]
    },
    {
      "code" : "V0806",
      "display" : "MEDICAL BEDS",
      "concept" : [{
        "code" : "V080601",
        "display" : "ELECTRIC MEDICAL BEDS",
        "concept" : [{
          "code" : "V08060101",
          "display" : "HOSPITAL/HOME CARE ELECTRIC MEDICAL BEDS"
        },
        {
          "code" : "V08060102",
          "display" : "INTENSIVE CARE OR RESUSCITATION ELECTRIC MEDICAL BEDS"
        },
        {
          "code" : "V08060103",
          "display" : "SEMI-INTENSIVE THERAPY OR CARDIAC INTENSIVE CARE UNITS (CICU) ELECTRIC MEDICAL BEDS"
        },
        {
          "code" : "V08060104",
          "display" : "BURN PATIENT ELECTRIC MEDICAL BEDS"
        },
        {
          "code" : "V08060105",
          "display" : "ELECTRIC MEDICAL BEDS WITH WEIGHING SYSTEM"
        },
        {
          "code" : "V08060106",
          "display" : "BARIATRIC ELECTRIC MEDICAL BEDS"
        },
        {
          "code" : "V08060107",
          "display" : "PEDIATRIC ELECTRIC MEDICAL BEDS",
          "concept" : [{
            "code" : "V0806010701",
            "display" : "HOSPITAL/HOME CARE PEDIATRIC ELECTRIC MEDICAL BEDS"
          },
          {
            "code" : "V0806010702",
            "display" : "INTENSIVE CARE PEDIATRIC ELECTRIC MEDICAL BEDS"
          }]
        },
        {
          "code" : "V08060199",
          "display" : "ELECTRIC MEDICAL BEDS - OTHER"
        }]
      },
      {
        "code" : "V080602",
        "display" : "MANUAL MEDICAL BEDS"
      },
      {
        "code" : "V080603",
        "display" : "TREATMENT, DIAGNOSIS AND MONITORING MEDICAL BEDS"
      },
      {
        "code" : "V080680",
        "display" : "MEDICAL BEDS - ACCESSORIES",
        "concept" : [{
          "code" : "V08068001",
          "display" : "BED RAILS"
        },
        {
          "code" : "V08068002",
          "display" : "BED SUPPORTS"
        },
        {
          "code" : "V08068099",
          "display" : "MEDICAL BEDS - OTHER ACCESSORIES"
        }]
      },
      {
        "code" : "V080699",
        "display" : "MEDICAL BEDS - OTHER"
      }]
    },
    {
      "code" : "V0807",
      "display" : "ANTI-DECUBITUS MEDICAL MATTRESSES",
      "concept" : [{
        "code" : "V080701",
        "display" : "ACTIVE ANTI-DECUBITUS MEDICAL MATTRESSES"
      },
      {
        "code" : "V080702",
        "display" : "NON ACTIVE ANTI-DECUBITUS MEDICAL MATTRESSES"
      }]
    },
    {
      "code" : "V0808",
      "display" : "MEDICAL CROSSBARS"
    },
    {
      "code" : "V0809",
      "display" : "MANUAL CLINICAL CRIBS FOR NEWBORNS"
    },
    {
      "code" : "V0810",
      "display" : "NEWBORN POSITIONERS"
    },
    {
      "code" : "V0811",
      "display" : "HEEL, ELBOW AND KNEE ANTI-DECUBITUS PROTECTION AIDS"
    },
    {
      "code" : "V0812",
      "display" : "FECES AND URINE COLLECTION AIDS (BED PANS AND PARROTS)"
    },
    {
      "code" : "V0880",
      "display" : "MEDICAL SUPPORT EQUIPMENT - ACCESSORIES"
    },
    {
      "code" : "V0899",
      "display" : "MEDICAL SUPPORT EQUIPMENT - OTHER"
    }]
  },
  {
    "code" : "V09",
    "display" : "FLUIDS/GASES FOR CLINICAL/THERAPEUTIC USE",
    "concept" : [{
      "code" : "V0901",
      "display" : "CLINICAL/THERAPEUTIC APPLICATIONS CARBON DIOXIDE"
    },
    {
      "code" : "V0902",
      "display" : "CLINICAL/THERAPEUTIC APPLICATIONS LIQUID NITROGEN"
    },
    {
      "code" : "V0903",
      "display" : "CLINICAL/THERAPEUTIC APPLICATIONS GAS MIXTURES"
    },
    {
      "code" : "V0904",
      "display" : "CLINICAL/THERAPEUTIC APPLICATIONS NITROUS OXIDE"
    },
    {
      "code" : "V0905",
      "display" : "CLINICAL/THERAPEUTIC APPLICATIONS ARGON"
    },
    {
      "code" : "V0999",
      "display" : "FLUIDS/GASES FOR CLINICAL/THERAPEUTICAL USE - OTHER"
    }]
  },
  {
    "code" : "V80",
    "display" : "CLINICAL USE ACCESSORIES NOT INCLUDED IN OTHER CLASSES"
  },
  {
    "code" : "V90",
    "display" : "VARIOUS DEVICES NOT INCLUDED IN OTHER CLASSES",
    "concept" : [{
      "code" : "V9001",
      "display" : "TONGUE DEPRESSORS, SINGLE-USE"
    },
    {
      "code" : "V9002",
      "display" : "ENTEROCLYSIS DEVICES"
    },
    {
      "code" : "V9003",
      "display" : "TOURNIQUETS"
    },
    {
      "code" : "V9004",
      "display" : "SKIN MARKING DERMOGRAPHIC PENCILS AND PENS"
    },
    {
      "code" : "V9005",
      "display" : "RUBBER SQUIRTS FOR IRRIGATION"
    },
    {
      "code" : "V9007",
      "display" : "STERILE INSTRUMENT LUBRICANTS"
    },
    {
      "code" : "V9010",
      "display" : "PARASITE ELIMINATION MECHANICAL DEVICES",
      "concept" : [{
        "code" : "V901001",
        "display" : "LICE ELIMINATION MECHANICAL DEVICES"
      },
      {
        "code" : "V901099",
        "display" : "PARASITE ELIMINATION MECHANICAL DEVICES - OTHER"
      }]
    },
    {
      "code" : "V9011",
      "display" : "MULTIFUNCTIONAL TRANSDUCERS"
    },
    {
      "code" : "V9012",
      "display" : "NON-SPECIALIST SURGICAL INSTRUMENTS AND KITS, SINGLE-USE"
    },
    {
      "code" : "V9015",
      "display" : "ELECTRODES AND PROBES CUTANEOUS CONDUCTIVE SUBSTANCES"
    },
    {
      "code" : "V9016",
      "display" : "SPECIALIST SURGICAL INSTRUMENTS AND KITS NOT INCLUDED IN OTHER CLASSES, SINGLE-USE",
      "concept" : [{
        "code" : "V901601",
        "display" : "PLASTIC SURGERY AND NON-AESTHETIC PURPOSES GENERIC USE INSTRUMENTS AND KITS, SINGLE-USE"
      },
      {
        "code" : "V901602",
        "display" : "DERMOSURGERY INSTRUMENTS AND KITS, SINGLE-USE"
      },
      {
        "code" : "V901603",
        "display" : "SUPERFICIAL TREATMENTS INSTRUMENTS AND KITS, SINGLE-USE"
      },
      {
        "code" : "V901699",
        "display" : "SPECIALIST SURGICAL INSTRUMENTS AND KITS NOT INCLUDED IN OTHER CLASSES, SINGLE-USE - OTHER"
      }]
    },
    {
      "code" : "V9017",
      "display" : "ORAL ADMINISTRATION PREPARATIONS NOT INCLUDED IN OTHER CLASSES"
    },
    {
      "code" : "V9018",
      "display" : "TRICHOTOMY MANUAL DEVICES"
    },
    {
      "code" : "V9099",
      "display" : "VARIOUS DEVICES NOT INCLUDED IN OTHER CLASSES - OTHER"
    }]
  },
  {
    "code" : "V92",
    "display" : "MEDICAL DEVICE SOFTWARE - NOT INCLUDED IN OTHER CLASSES"
  },
  {
    "code" : "W",
    "display" : "IN VITRO DIAGNOSTIC MEDICAL DEVICES"
  },
  {
    "code" : "W01",
    "display" : "REAGENTS",
    "concept" : [{
      "code" : "W0101",
      "display" : "CLINICAL CHEMISTRY",
      "concept" : [{
        "code" : "W010101",
        "display" : "ENZYMES",
        "concept" : [{
          "code" : "W01010101",
          "display" : "5'-NUCLEOTIDASE"
        },
        {
          "code" : "W01010102",
          "display" : "ACID PHOSPHATASE (CC)"
        },
        {
          "code" : "W01010103",
          "display" : "ALANINE AMINO-TRANSFERASE"
        },
        {
          "code" : "W01010104",
          "display" : "ALDOLASE"
        },
        {
          "code" : "W01010105",
          "display" : "ALKALINE PHOSPHATASE - TOTAL"
        },
        {
          "code" : "W01010106",
          "display" : "ALKALINE PHOSPHATASE ISOENZYMES (CC)"
        },
        {
          "code" : "W01010107",
          "display" : "AMYLASE - TOTAL"
        },
        {
          "code" : "W01010108",
          "display" : "AMYLASE ISOENZYMES"
        },
        {
          "code" : "W01010109",
          "display" : "ANGIOTENSIN CONVERTING ENZYME (CC)"
        },
        {
          "code" : "W01010110",
          "display" : "ASPARTATE AMINO-TRANSFERASE"
        },
        {
          "code" : "W01010111",
          "display" : "CHOLINESTERASE"
        },
        {
          "code" : "W01010112",
          "display" : "CHYMOTRYPSIN"
        },
        {
          "code" : "W01010113",
          "display" : "CREATINE KINASE - TOTAL"
        },
        {
          "code" : "W01010114",
          "display" : "CREATINE KINASE - MB ACTIVITY (CC)"
        },
        {
          "code" : "W01010115",
          "display" : "CREATINE KINASE ISOENZYMES"
        },
        {
          "code" : "W01010116",
          "display" : "GAMMA GLUTAMYLTRANSFERASE"
        },
        {
          "code" : "W01010117",
          "display" : "GLUTAMATE DEHYDROGENASE"
        },
        {
          "code" : "W01010118",
          "display" : "HYDROXYBUTYRATE DEHYDROGENASE"
        },
        {
          "code" : "W01010119",
          "display" : "LACTATE DEHYDROGENASE L  ( LDH - L --> P )"
        },
        {
          "code" : "W01010120",
          "display" : "LACTATE DEHYDROGENASE P ( LDH - P --> L )"
        },
        {
          "code" : "W01010121",
          "display" : "LACTATE DEHYDROGENASE ISOENZYMES"
        },
        {
          "code" : "W01010122",
          "display" : "LEUCINE AMINOPEPTIDASE"
        },
        {
          "code" : "W01010123",
          "display" : "LIPASE"
        },
        {
          "code" : "W01010124",
          "display" : "LYSOZYME"
        },
        {
          "code" : "W01010125",
          "display" : "MALATE DEHYDROGENASE"
        },
        {
          "code" : "W01010126",
          "display" : "N-ACETYL-B, D-GLUCOSAMINIDASE"
        },
        {
          "code" : "W01010127",
          "display" : "PEPSIN"
        },
        {
          "code" : "W01010128",
          "display" : "PHOSPHO HEXOSE ISOMERASE"
        },
        {
          "code" : "W01010129",
          "display" : "SORBITOL DEHYDROGENASE"
        },
        {
          "code" : "W01010130",
          "display" : "TRYPSIN"
        },
        {
          "code" : "W01010131",
          "display" : "HEXOKINASE ADP"
        },
        {
          "code" : "W01010199",
          "display" : "ENZYMES - OTHER"
        }]
      },
      {
        "code" : "W010102",
        "display" : "SUBSTRATES",
        "concept" : [{
          "code" : "W01010201",
          "display" : "ALBUMIN (CC)"
        },
        {
          "code" : "W01010202",
          "display" : "BILE ACIDS"
        },
        {
          "code" : "W01010203",
          "display" : "BILIRUBIN"
        },
        {
          "code" : "W01010204",
          "display" : "UREA/BLOOD UREA NITROGEN"
        },
        {
          "code" : "W01010205",
          "display" : "CHOLESTEROL"
        },
        {
          "code" : "W01010206",
          "display" : "COPPER"
        },
        {
          "code" : "W01010207",
          "display" : "CREATININE"
        },
        {
          "code" : "W01010208",
          "display" : "D-XYLOSE"
        },
        {
          "code" : "W01010209",
          "display" : "DELTA-AMINOLAEVULINIC ACID"
        },
        {
          "code" : "W01010210",
          "display" : "FRUCTOSAMINE"
        },
        {
          "code" : "W01010211",
          "display" : "FRUCTOSE"
        },
        {
          "code" : "W01010212",
          "display" : "GALACTOSE"
        },
        {
          "code" : "W01010213",
          "display" : "GLUCOSE"
        },
        {
          "code" : "W01010214",
          "display" : "GLYCOSYLATED/GLYCATED HAEMOGLOBIN (CC)"
        },
        {
          "code" : "W01010215",
          "display" : "HIGH DENSITY LIPOPROTEIN CHOLESTEROL"
        },
        {
          "code" : "W01010216",
          "display" : "IRON (CC)"
        },
        {
          "code" : "W01010217",
          "display" : "IRON BINDING CAPACITY - TOTAL (CC)"
        },
        {
          "code" : "W01010218",
          "display" : "LACTATE"
        },
        {
          "code" : "W01010219",
          "display" : "LECITHIN"
        },
        {
          "code" : "W01010220",
          "display" : "LIPOPROTEIN, CHEMICAL DETERMINATION/DETECTION"
        },
        {
          "code" : "W01010221",
          "display" : "LOW DENSITY LIPOPROTEIN CHOLESTEROL INCLUDING SD-LDL"
        },
        {
          "code" : "W01010222",
          "display" : "NON ESTERIFIED FATTY ACIDS"
        },
        {
          "code" : "W01010223",
          "display" : "OXALATE"
        },
        {
          "code" : "W01010224",
          "display" : "PHOSPHOLIPIDS"
        },
        {
          "code" : "W01010225",
          "display" : "PORPHOBILINOGEN"
        },
        {
          "code" : "W01010226",
          "display" : "PYRUVATE"
        },
        {
          "code" : "W01010227",
          "display" : "THYMOL"
        },
        {
          "code" : "W01010228",
          "display" : "TOTAL LIPIDS"
        },
        {
          "code" : "W01010229",
          "display" : "TOTAL PORPHYRINE"
        },
        {
          "code" : "W01010230",
          "display" : "TOTAL PROTEIN"
        },
        {
          "code" : "W01010231",
          "display" : "TRIGLYCERIDES"
        },
        {
          "code" : "W01010232",
          "display" : "URIC ACID"
        },
        {
          "code" : "W01010233",
          "display" : "ZINC"
        },
        {
          "code" : "W01010234",
          "display" : "LIPOPROTEIN ELECTROPORESIS"
        },
        {
          "code" : "W01010235",
          "display" : "PROTEIN ELECTROPORESIS"
        },
        {
          "code" : "W01010236",
          "display" : "PHENYLKETONURIA"
        },
        {
          "code" : "W01010299",
          "display" : "SUBSTRATES - OTHER"
        }]
      },
      {
        "code" : "W010103",
        "display" : "ELECTROLYTES REAGENTS (EXCLUDING ELECTRODES)",
        "concept" : [{
          "code" : "W01010301",
          "display" : "AMMONIA"
        },
        {
          "code" : "W01010302",
          "display" : "BICARBONATE"
        },
        {
          "code" : "W01010303",
          "display" : "CALCIUM"
        },
        {
          "code" : "W01010304",
          "display" : "CHLORIDE"
        },
        {
          "code" : "W01010305",
          "display" : "LITHIUM"
        },
        {
          "code" : "W01010306",
          "display" : "MAGNESIUM"
        },
        {
          "code" : "W01010307",
          "display" : "PHOSPHATE INORGANIC / PHOSPHORUS"
        },
        {
          "code" : "W01010308",
          "display" : "POTASSIUM"
        },
        {
          "code" : "W01010309",
          "display" : "SODIUM"
        },
        {
          "code" : "W01010399",
          "display" : "ELECTROLYTES - OTHER"
        }]
      },
      {
        "code" : "W010104",
        "display" : "MULTIPLE PARAMETERS - CLINICAL CHEMISTRY",
        "concept" : [{
          "code" : "W01010401",
          "display" : "MULTIPLE ENZYMES ONLY - CLIN. CHEM LAB REAGENTS."
        },
        {
          "code" : "W01010402",
          "display" : "MULTIPLE SUBSTRATES ONLY - CLIN. CHEM LAB R."
        },
        {
          "code" : "W01010403",
          "display" : "MULTIPLE ELECTROLYTES ONLY - CLIN. CHEM LAB R."
        },
        {
          "code" : "W01010404",
          "display" : "MULTIPLE PARAMETERS (MIX OF ALL) - CLIN. CHEM LAB R."
        },
        {
          "code" : "W01010499",
          "display" : "MULTIPLE CLIN. CHEM LAB REAGENTS - OTHER"
        }]
      },
      {
        "code" : "W010105",
        "display" : "CONTROLS/STANDARDS/CALIBRATORS CLINICAL CHEMISTRY",
        "concept" : [{
          "code" : "W01010501",
          "display" : "MULTICOMPONENT CONTROLS (CLINICAL CHEMISTRY)",
          "concept" : [{
            "code" : "W0101050101",
            "display" : "ASSAYED MULTICOMPONENT CONTROLS (CC)"
          },
          {
            "code" : "W0101050102",
            "display" : "UNASSAYED MULTICOMPONENT CONTROLS (CC)"
          },
          {
            "code" : "W0101050199",
            "display" : "MULTICOMPONENT CONTROLS (CC) - OTHER"
          }]
        },
        {
          "code" : "W01010502",
          "display" : "SPECIFIC CONTROLS (CLINICAL CHEMISTRY)",
          "concept" : [{
            "code" : "W0101050201",
            "display" : "ENZYME CONTROLS"
          },
          {
            "code" : "W0101050202",
            "display" : "LIPID CONTROLS"
          },
          {
            "code" : "W0101050203",
            "display" : "BILIRUBIN CONTROLS"
          },
          {
            "code" : "W0101050204",
            "display" : "ELECTROLYTE CONTROLS"
          },
          {
            "code" : "W0101050205",
            "display" : "DIABETES CONTROLS"
          },
          {
            "code" : "W0101050207",
            "display" : "URINE CONTROLS"
          },
          {
            "code" : "W0101050208",
            "display" : "CSF CONTROLS"
          },
          {
            "code" : "W0101050299",
            "display" : "SPECIFIC CONTROLS (CC) - OTHER"
          }]
        },
        {
          "code" : "W01010503",
          "display" : "CALIBRATORS AND STANDARDS (CLINICAL CHEMISTRY)",
          "concept" : [{
            "code" : "W0101050301",
            "display" : "CALIBRATORS MULTICOMPONENT (CC)"
          },
          {
            "code" : "W0101050302",
            "display" : "CALIBRATORS SINGLE COMPONENT (CC)"
          },
          {
            "code" : "W0101050303",
            "display" : "AQUEOUS STANDARDS (CC)"
          },
          {
            "code" : "W0101050399",
            "display" : "CALIBRATORS AND STANDARDS (CLINICAL CHEMISTRY) - OTHER"
          }]
        }]
      },
      {
        "code" : "W010106",
        "display" : "CLINICAL CHEMISTRY - RAPID TESTS & POC",
        "concept" : [{
          "code" : "W01010601",
          "display" : "BLOOD TEST STRIPS (CC) - RT & POC",
          "concept" : [{
            "code" : "W0101060101",
            "display" : "GLUCOSE TEST STRIPS"
          },
          {
            "code" : "W0101060102",
            "display" : "CHOLESTEROL TEST STRIPS"
          },
          {
            "code" : "W0101060103",
            "display" : "HDL TEST STRIPS"
          },
          {
            "code" : "W0101060104",
            "display" : "LACTATE TEST STRIPS"
          },
          {
            "code" : "W0101060105",
            "display" : "TRIGLYCERIDE TEST STRIPS"
          },
          {
            "code" : "W0101060106",
            "display" : "UREA TEST STRIPS"
          },
          {
            "code" : "W0101060107",
            "display" : "HBA1C TEST STRIPS"
          },
          {
            "code" : "W0101060108",
            "display" : "CONTROLS/STANDRDS/CALIBRATORS (BLOOD TEST STRIPS)",
            "concept" : [{
              "code" : "W010106010801",
              "display" : "BLOOD TEST STRIPS CONTROLS"
            },
            {
              "code" : "W010106010802",
              "display" : "BLOOD TEST STRIPS CALIBRATORS AND STANDARDS"
            }]
          },
          {
            "code" : "W0101060109",
            "display" : "MULTIPLE PARAMETER BLOOD TEST"
          },
          {
            "code" : "W0101060110",
            "display" : "KETONE TEST STRIPS (Β-HYDROXYBUTYRATE TEST STRIPS)"
          },
          {
            "code" : "W0101060111",
            "display" : "LDL TEST STRIPS"
          },
          {
            "code" : "W0101060112",
            "display" : "CREATININE ANALYSIS TEST STRIPS"
          },
          {
            "code" : "W0101060199",
            "display" : "BLOOD TEST STRIPS (CC) - RAPID TESTS AND 'POINT OF CARE' - OTHER"
          }]
        },
        {
          "code" : "W01010602",
          "display" : "URINE TESTING (CC) - RT & POC",
          "concept" : [{
            "code" : "W0101060201",
            "display" : "URINE SINGLE TEST STRIPS (INCL. TABLETS)"
          },
          {
            "code" : "W0101060203",
            "display" : "URINE SEDIMENTTEST KIT",
            "concept" : [{
              "code" : "W010106020301",
              "display" : "URINE SEDIMENTTEST KIT (MANUAL)"
            },
            {
              "code" : "W010106020302",
              "display" : "URINE SEDIMENT TEST KIT (AUTOMATED)"
            }]
          },
          {
            "code" : "W0101060204",
            "display" : "URINE MULTI-CONSTITUENT TEST STRIPS (MANUAL)"
          },
          {
            "code" : "W0101060205",
            "display" : "URINE MULTI-CONSTITUENT TEST STRIPS (AUTOMATED)"
          },
          {
            "code" : "W0101060206",
            "display" : "URINE TESTING CONTROLS CALIBRATORS AND STANDARDS",
            "concept" : [{
              "code" : "W010106020601",
              "display" : "URINE TESTING CONTROLS"
            },
            {
              "code" : "W010106020602",
              "display" : "URINE TESTING CALIBRATORS AND STANDARDS"
            }]
          },
          {
            "code" : "W0101060299",
            "display" : "URINE TESTING - OTHER"
          }]
        },
        {
          "code" : "W01010603",
          "display" : "FAECES TESTS (CC) - RT & POC",
          "concept" : [{
            "code" : "W0101060301",
            "display" : "GUAIAC-BASED FECAL FAECAL OCCULT BLOOD (CC)"
          },
          {
            "code" : "W0101060302",
            "display" : "ALBUMIN IN STOOL (MECONIUM)"
          },
          {
            "code" : "W0101060303",
            "display" : "PANCREAS-ELASTASE"
          },
          {
            "code" : "W0101060399",
            "display" : "FAECES TESTS - RAPID TESTS AND 'POINT OF CARE' - OTHER"
          }]
        },
        {
          "code" : "W01010604",
          "display" : "MULTIPLE PARAMETERS POC",
          "concept" : [{
            "code" : "W0101060401",
            "display" : "MULTIPLE ENZYMES &/OR SUBSTRATES &/OR ELECTROLYTES"
          },
          {
            "code" : "W0101060402",
            "display" : "MULTIPLE PARAMETERS POC CONTROLS CALIBRATORS AND STANDARDS",
            "concept" : [{
              "code" : "W010106040201",
              "display" : "MULTIPLE PARAMETERS POC CONTROLS"
            },
            {
              "code" : "W010106040202",
              "display" : "MULTIPLE PARAMETERS POC CALIBRATORS AND STANDARDS"
            }]
          },
          {
            "code" : "W0101060499",
            "display" : "MULTIPLE PARAMETERS POC - OTHER"
          }]
        },
        {
          "code" : "W01010606",
          "display" : "ELECTRODES OR CASSETTES FOR BLOOD GAS ANALYSIS INCL. ELECTROLYTES / METABOLITES - POC",
          "concept" : [{
            "code" : "W0101060601",
            "display" : "CARBON DIOXIDE - ELECTRODES (BG)"
          },
          {
            "code" : "W0101060602",
            "display" : "PH - ELECTRODES (BG)"
          },
          {
            "code" : "W0101060603",
            "display" : "OXYGEN - ELECTRODES (BG)"
          },
          {
            "code" : "W0101060604",
            "display" : "PH/PO2/PCO2 - ELECTRODES (BG)"
          },
          {
            "code" : "W0101060605",
            "display" : "BG &/OR ISE &/OR METABOLITES - ELECTRODES (BG)"
          },
          {
            "code" : "W0101060606",
            "display" : "BLOOD GAS BUFFERS AND SOLUTIONS - ELECTRODES OR CASSETTE"
          },
          {
            "code" : "W0101060607",
            "display" : "BLOOD GAS CONTROLS -ELECTRODES OR CASSETTE"
          },
          {
            "code" : "W0101060608",
            "display" : "BLOOD GAS CALIBRATORS AND STANDARDS ELECTRODES OR CASSETTE"
          },
          {
            "code" : "W0101060609",
            "display" : "BLOOD GAS INCL. ELECTROLYTES / METABOLITES - UNITARY USE CASSETTE"
          },
          {
            "code" : "W0101060610",
            "display" : "BLOOD GAS INCL. ELECTROLYTES / METABOLITES - MULTI USE CASSETTE"
          },
          {
            "code" : "W0101060699",
            "display" : "BLOOD GAS ELECTRODES OR CASSETTE POC - OTHER"
          }]
        },
        {
          "code" : "W01010699",
          "display" : "CLIN. CHEM. RT & POC - OTHER"
        }]
      },
      {
        "code" : "W010107",
        "display" : "ELECTRODES AND BIOSENSORS - LABORATORY",
        "concept" : [{
          "code" : "W01010701",
          "display" : "ELECTROLYTE ELECTRODES",
          "concept" : [{
            "code" : "W0101070101",
            "display" : "AMMONIA - ELECTRODES"
          },
          {
            "code" : "W0101070102",
            "display" : "CALCIUM - ELECTRODES"
          },
          {
            "code" : "W0101070103",
            "display" : "CHLORIDE - ELECTRODES"
          },
          {
            "code" : "W0101070104",
            "display" : "LITHIUM - ELECTRODES"
          },
          {
            "code" : "W0101070105",
            "display" : "MAGNESIUM - ELECTRODES"
          },
          {
            "code" : "W0101070106",
            "display" : "POTASSIUM - ELECTRODES"
          },
          {
            "code" : "W0101070107",
            "display" : "SODIUM - ELECTRODES"
          },
          {
            "code" : "W0101070108",
            "display" : "CARBON DIOXIDE (BICARBONATE)   - ELECTRODES (CC)"
          },
          {
            "code" : "W0101070199",
            "display" : "ELECTROLYTE ELECTRODES - OTHER"
          }]
        },
        {
          "code" : "W01010702",
          "display" : "SUBSTRATE ELECTRODES / BIOSENSORS",
          "concept" : [{
            "code" : "W0101070201",
            "display" : "CREATININE - ELECTRODES"
          },
          {
            "code" : "W0101070202",
            "display" : "GLUCOSE - ELECTRODES"
          },
          {
            "code" : "W0101070203",
            "display" : "GLYCATED HAEMOGLOBIN - ELECTRODES"
          },
          {
            "code" : "W0101070204",
            "display" : "LACTATE - ELECTRODES"
          },
          {
            "code" : "W0101070205",
            "display" : "UREA - ELECTRODES"
          },
          {
            "code" : "W0101070206",
            "display" : "BILIRUBIN - ELECTRODES"
          },
          {
            "code" : "W0101070299",
            "display" : "SUBSTRATE - ELECTRODES / BIOSENSORS - OTHER"
          }]
        },
        {
          "code" : "W01010703",
          "display" : "REFERENCE MATERIAL AND BUFFERS (ELECTROLYTES)",
          "concept" : [{
            "code" : "W0101070301",
            "display" : "REFERENCE ELECTRODES"
          },
          {
            "code" : "W0101070302",
            "display" : "ELECTROLYTE ELECTRODE BUFFERS AND SOLUTIONS"
          },
          {
            "code" : "W0101070303",
            "display" : "SUBSTRATE ELECTRODE BUFFERS AND SOLUTIONS"
          },
          {
            "code" : "W0101070304",
            "display" : "COMMON BUFFERS AND SOLUTIONS (ELECTROLYTES)"
          },
          {
            "code" : "W0101070399",
            "display" : "REFERENCE MATERIALS AND BUFFERS (ELECTROLYTES) - OTHER"
          }]
        }]
      },
      {
        "code" : "W010108",
        "display" : "MULTIPLE PARAMETER ELECTRODES/BIOSENSORS",
        "concept" : [{
          "code" : "W01010801",
          "display" : "MULTIPLE ENZYMES ONLY - ELECTRODES/BIOSENSORS"
        },
        {
          "code" : "W01010802",
          "display" : "MULTIPLE SUBSTRATES ONLY - ELECTRODES/BIOSENSORS"
        },
        {
          "code" : "W01010803",
          "display" : "MULTIPLE ELECTROLYTES ONLY - ELECTRODES/BIOSENSORS"
        },
        {
          "code" : "W01010804",
          "display" : "MULTIPLE BLOOD GAS ONLY - ELECTRODES/BIOSENSORS"
        },
        {
          "code" : "W01010805",
          "display" : "MULTIPLE PARAMETERS (MIX OF ALL) - ELECTRODES/BIOSENSORS"
        },
        {
          "code" : "W01010899",
          "display" : "MULTIPLE PARAMETER - ELECTRODES/BIOSENSORS - OTHER"
        }]
      },
      {
        "code" : "W010109",
        "display" : "URINE MULTIPLE PARAMETERS TESTING (CC) - LAB REAGENTS",
        "concept" : [{
          "code" : "W01010901",
          "display" : "URINE MULTI-CONSTITUENT TEST STRIPS / CASSETTES (AUTOMATED)"
        },
        {
          "code" : "W01010902",
          "display" : "URINE SEDIMENT TEST KIT (AUTOMATED)"
        },
        {
          "code" : "W01010999",
          "display" : "MULTIPLE PARAMETERS URINE TESTING - OTHER"
        }]
      },
      {
        "code" : "W010190",
        "display" : "OTHER CLINICAL CHEMISTRY",
        "concept" : [{
          "code" : "W01019001",
          "display" : "BUFFERS (UNASSIGNABLE), SUPPLEM. REAGENTS, ETC (CC)"
        },
        {
          "code" : "W01019002",
          "display" : "ELECTROPHORESIS MEDIA (UNASSIGNABLE)"
        },
        {
          "code" : "W01019099",
          "display" : "CLINICAL CHEMISTRY REAGENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "W0102",
      "display" : "IMMUNOCHEMISTRY (IMMUNOLOGY)",
      "concept" : [{
        "code" : "W010201",
        "display" : "SPECIFIC PROTEINS",
        "concept" : [{
          "code" : "W01020101",
          "display" : "IMMUNOGLOBULINS (EXCEPT IGE)",
          "concept" : [{
            "code" : "W0102010101",
            "display" : "IMMUNOGLOBULIN A"
          },
          {
            "code" : "W0102010102",
            "display" : "IMMUNOGLOBULIN A SUBCLASS REAGENTS"
          },
          {
            "code" : "W0102010103",
            "display" : "IMMUNOGLOBULIN D"
          },
          {
            "code" : "W0102010104",
            "display" : "IMMUNOGLOBULIN D SUBCLASS REAGENTS"
          },
          {
            "code" : "W0102010105",
            "display" : "IMMUNOGLOBULIN G"
          },
          {
            "code" : "W0102010106",
            "display" : "IMMUNOGLOBULIN G SUBCLASS REAGENTS"
          },
          {
            "code" : "W0102010107",
            "display" : "IMMUNOGLOBULIN M"
          },
          {
            "code" : "W0102010108",
            "display" : "IMMUNOGLOBULIN M SUBCLASS REAGENTS"
          },
          {
            "code" : "W0102010109",
            "display" : "KAPPA AND LAMBDA CHAIN"
          },
          {
            "code" : "W0102010110",
            "display" : "IMMUNOELECTROPHORESIS KITS"
          },
          {
            "code" : "W0102010111",
            "display" : "IMMUNOFIXATION KITS"
          },
          {
            "code" : "W0102010112",
            "display" : "ANTI HUMAN IG POLYVALENT ANTISERA"
          },
          {
            "code" : "W0102010113",
            "display" : "HUMAN ANTI-MOUSE ANTIBODY"
          },
          {
            "code" : "W0102010114",
            "display" : "BUFFERS (UNASSIGNABLE), SUPPLEM. REAGENTS, ETC (IG'S)"
          },
          {
            "code" : "W0102010199",
            "display" : "IMMUNOGLOBULINS - OTHER"
          }]
        },
        {
          "code" : "W01020102",
          "display" : "COMPLEMENT COMPONENTS",
          "concept" : [{
            "code" : "W0102010201",
            "display" : "COMPLEMENT COMPONENT C1Q"
          },
          {
            "code" : "W0102010202",
            "display" : "COMPLEMENT COMPONENT C1 INHIBITOR"
          },
          {
            "code" : "W0102010203",
            "display" : "COMPLEMENT COMPONENT C3/C3C"
          },
          {
            "code" : "W0102010204",
            "display" : "COMPLEMENT COMPONENT FOR BB"
          },
          {
            "code" : "W0102010205",
            "display" : "COMPLEMENT COMPONENT C4"
          },
          {
            "code" : "W0102010206",
            "display" : "COMPLEMENT COMPONENT C5A"
          },
          {
            "code" : "W0102010207",
            "display" : "COMPLEMENT COMPONENT C59"
          },
          {
            "code" : "W0102010208",
            "display" : "TOTAL COMPLEMENT ACTIVITY (CH50)"
          },
          {
            "code" : "W0102010299",
            "display" : "COMPLEMENT COMPONENTS - OTHER"
          }]
        },
        {
          "code" : "W01020103",
          "display" : "TRANSPORT PROTEINS",
          "concept" : [{
            "code" : "W0102010301",
            "display" : "CERULOPLASMIN"
          },
          {
            "code" : "W0102010302",
            "display" : "HAPTOGLOBIN"
          },
          {
            "code" : "W0102010303",
            "display" : "HEMOPEXIN"
          },
          {
            "code" : "W0102010304",
            "display" : "LACTOFERRIN"
          },
          {
            "code" : "W0102010305",
            "display" : "PRE-ALBUMIN / TRANSTHYRETIN"
          },
          {
            "code" : "W0102010306",
            "display" : "RETINOL BINDING PROTEIN"
          },
          {
            "code" : "W0102010307",
            "display" : "TRANSFERRIN"
          },
          {
            "code" : "W0102010308",
            "display" : "TRANSCOBALAMIN (S)"
          },
          {
            "code" : "W0102010309",
            "display" : "ALBUMIN (IC) INCL. UALBUMIN"
          },
          {
            "code" : "W0102010399",
            "display" : "TRANSPORT PROTEINS - OTHER"
          }]
        },
        {
          "code" : "W01020104",
          "display" : "LIPOPROTEINS",
          "concept" : [{
            "code" : "W0102010401",
            "display" : "APOLIPOPROTEIN A I"
          },
          {
            "code" : "W0102010402",
            "display" : "APOLIPOPROTEIN A II"
          },
          {
            "code" : "W0102010403",
            "display" : "APOLIPOPROTEIN B"
          },
          {
            "code" : "W0102010404",
            "display" : "APOLIPOPROTEIN E SUB-TYPING"
          },
          {
            "code" : "W0102010405",
            "display" : "LIPOPROTEIN ( A )"
          },
          {
            "code" : "W0102010499",
            "display" : "LIPOPROTEINS - OTHER"
          }]
        },
        {
          "code" : "W01020190",
          "display" : "OTHER SPECIFIC PROTEINS",
          "concept" : [{
            "code" : "W0102019001",
            "display" : "A1-ACID GLYCOPROTEIN (OROSOMUCOID)"
          },
          {
            "code" : "W0102019002",
            "display" : "A1-ANTITRYPSIN (PROTEASE INHIBITOR)"
          },
          {
            "code" : "W0102019003",
            "display" : "A2-MACROGLOBULIN"
          },
          {
            "code" : "W0102019004",
            "display" : "A1-MICROGLOBULIN"
          },
          {
            "code" : "W0102019005",
            "display" : "FIBRONECTIN"
          },
          {
            "code" : "W0102019006",
            "display" : "TRYPSIN-A1-ANTITRYPSIN (ELASTASE)"
          },
          {
            "code" : "W0102019007",
            "display" : "IMMUNO REACTIVE TRYPSIN"
          },
          {
            "code" : "W0102019008",
            "display" : "CYSTATIN C"
          },
          {
            "code" : "W0102019009",
            "display" : "CALPROTECTIN"
          },
          {
            "code" : "W0102019010",
            "display" : "ADENOSINE DEAMINASE"
          },
          {
            "code" : "W0102019011",
            "display" : "ADRENOMEDULLIN"
          },
          {
            "code" : "W0102019012",
            "display" : "AMYLOID BETA-DERIVED DIFFUSIBLE LIGAND (BETA-AMYLOID OLIGOMER)"
          },
          {
            "code" : "W0102019013",
            "display" : "BETA-AMYLOID (1-40)"
          },
          {
            "code" : "W0102019014",
            "display" : "BETA-AMYLOID (1-42)"
          },
          {
            "code" : "W0102019015",
            "display" : "TOTAL TAU"
          },
          {
            "code" : "W0102019016",
            "display" : "HUMAN TAU (HTAU)"
          },
          {
            "code" : "W0102019017",
            "display" : "PHOSPHORYLATED TAU (PTAU)"
          },
          {
            "code" : "W0102019099",
            "display" : "SPECIFIC PROTEINS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010202",
        "display" : "ALLERGY",
        "concept" : [{
          "code" : "W01020201",
          "display" : "IMMUNOGLOBULIN E - TOTAL"
        },
        {
          "code" : "W01020202",
          "display" : "IMMUNOGLOBULIN E - SPECIFIC, MONOTEST/MONORESULT"
        },
        {
          "code" : "W01020203",
          "display" : "IMMUNOGLOBULIN E - MONOTEST/MONORESULT - MULTI AG"
        },
        {
          "code" : "W01020204",
          "display" : "IMMUNOGLOBULIN E - MONOTEST/PLURIRESULT-MULTI AG"
        },
        {
          "code" : "W01020205",
          "display" : "IMMUNOGLOBULIN E - SCREEN"
        },
        {
          "code" : "W01020206",
          "display" : "LEUKOTRIENE STIMULATION TEST"
        },
        {
          "code" : "W01020207",
          "display" : "ALLERGENE SPECIFIC IGA"
        },
        {
          "code" : "W01020208",
          "display" : "ALLERGENE SPECIFIC IGG"
        },
        {
          "code" : "W01020209",
          "display" : "HISTAMINE"
        },
        {
          "code" : "W01020299",
          "display" : "ALLERGY TESTS - OTHER"
        }]
      },
      {
        "code" : "W010203",
        "display" : "TUMOUR MARKERS",
        "concept" : [{
          "code" : "W01020301",
          "display" : "CANCER ANTIGENS",
          "concept" : [{
            "code" : "W0102030101",
            "display" : "BLADDER TUMOUR ANTIGEN"
          },
          {
            "code" : "W0102030102",
            "display" : "CANCER ANTIGEN 15-3"
          },
          {
            "code" : "W0102030103",
            "display" : "CANCER ANTIGEN 19-9"
          },
          {
            "code" : "W0102030104",
            "display" : "CANCER ANTIGEN 50"
          },
          {
            "code" : "W0102030105",
            "display" : "CANCER ANTIGEN 72-4"
          },
          {
            "code" : "W0102030106",
            "display" : "CANCER ANTIGEN 125"
          },
          {
            "code" : "W0102030107",
            "display" : "CANCER ANTIGEN 195"
          },
          {
            "code" : "W0102030108",
            "display" : "CANCER ANTIGEN 242"
          },
          {
            "code" : "W0102030109",
            "display" : "CANCER ANTIGEN 549"
          },
          {
            "code" : "W0102030110",
            "display" : "CANCER ANTIGEN 27.29"
          },
          {
            "code" : "W0102030111",
            "display" : "CYFRA 21-1"
          },
          {
            "code" : "W0102030112",
            "display" : "CARCINOEMBRYONIC ANTIGEN"
          },
          {
            "code" : "W0102030113",
            "display" : "TOTAL PROSTATIC SPECIFIC ANTIGEN"
          },
          {
            "code" : "W0102030114",
            "display" : "FREE PROSTATIC SPECIFIC ANTIGEN"
          },
          {
            "code" : "W0102030115",
            "display" : "COMPLEXED PROSTATIC SPECIFIC ANTIGEN"
          },
          {
            "code" : "W0102030116",
            "display" : "SQUAMOUS CELL CARCINOMA ANTIGEN"
          },
          {
            "code" : "W0102030117",
            "display" : "TUMOR POLYPEPTIDE ANTIGEN (TPA - INCL. TPS)"
          },
          {
            "code" : "W0102030118",
            "display" : "CANCER ASSOCIATED SERUM ANTIGEN"
          },
          {
            "code" : "W0102030119",
            "display" : "HUMAN EPIDIDYMIS PROTEIN 4"
          },
          {
            "code" : "W0102030120",
            "display" : "PROSTATIC ACID PHOSPHATASE (IC)"
          },
          {
            "code" : "W0102030121",
            "display" : "PRO-GASTRIN-RELEASING PEPTIDE"
          },
          {
            "code" : "W0102030122",
            "display" : "EARLY PROSTATE CANCER ANTIGEN - 2"
          },
          {
            "code" : "W0102030123",
            "display" : "NUCLEAR MATRIX PROTEIN 22"
          },
          {
            "code" : "W0102030124",
            "display" : "CANCER ANTIGEN P16"
          },
          {
            "code" : "W0102030125",
            "display" : "CANCER ANTIGEN P63"
          },
          {
            "code" : "W0102030126",
            "display" : "CYTOKERATINS"
          },
          {
            "code" : "W0102030127",
            "display" : "(2)PROPSA"
          },
          {
            "code" : "W0102030199",
            "display" : "CANCER ANTIGENS - OTHER"
          }]
        },
        {
          "code" : "W01020302",
          "display" : "RECEPTOR ASSAYS",
          "concept" : [{
            "code" : "W0102030201",
            "display" : "ESTROGEN RECEPTOR ASSAYS"
          },
          {
            "code" : "W0102030202",
            "display" : "PROGESTERONE RECEPTOR ASSAYS"
          },
          {
            "code" : "W0102030299",
            "display" : "RECEPTOR ASSAYS - OTHER"
          }]
        },
        {
          "code" : "W01020303",
          "display" : "ONCOPROTEINS",
          "concept" : [{
            "code" : "W0102030301",
            "display" : "HER-2/NEU"
          },
          {
            "code" : "W0102030302",
            "display" : "P53"
          },
          {
            "code" : "W0102030399",
            "display" : "OTHER ONCOPROTEINS"
          }]
        },
        {
          "code" : "W01020390",
          "display" : "OTHER TUMOUR MARKERS",
          "concept" : [{
            "code" : "W0102039001",
            "display" : "ALPHAFETOPROTEIN"
          },
          {
            "code" : "W0102039002",
            "display" : "BETA2-MICROGLOBULIN"
          },
          {
            "code" : "W0102039003",
            "display" : "CATHEPSIN-D"
          },
          {
            "code" : "W0102039004",
            "display" : "5 HIAA"
          },
          {
            "code" : "W0102039005",
            "display" : "HUMAN PLACENTA LIKE ALKALINE PHOSPHATASE"
          },
          {
            "code" : "W0102039006",
            "display" : "LAMININ"
          },
          {
            "code" : "W0102039007",
            "display" : "NEURON SPECIFIC ENOLASE"
          },
          {
            "code" : "W0102039008",
            "display" : "THYMIDINE KINASE"
          },
          {
            "code" : "W0102039009",
            "display" : "TISSUE ASSOCIATED PROTEIN"
          },
          {
            "code" : "W0102039010",
            "display" : "MATRIX-METALLOPROTEINASES"
          },
          {
            "code" : "W0102039011",
            "display" : "SEROTONINE"
          },
          {
            "code" : "W0102039013",
            "display" : "FECAL OCCULT BLOOD (IC)"
          },
          {
            "code" : "W0102039014",
            "display" : "CHROMOGRANIN A"
          },
          {
            "code" : "W0102039015",
            "display" : "ALPHA SUBUNIT"
          },
          {
            "code" : "W0102039017",
            "display" : "PROTEIN INDUCED BY VITAMIN K ABSENCE OR ANTAGONIST-II (PIVKA-II)"
          },
          {
            "code" : "W0102039018",
            "display" : "ALPHA-FUCOSIDASE"
          },
          {
            "code" : "W0102039019",
            "display" : "SOLUBLE MESOTHELIN-RELATED PEPTIDES"
          },
          {
            "code" : "W0102039099",
            "display" : "TUMOUR MARKERS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010204",
        "display" : "THYROID FUNCTION HORMONES",
        "concept" : [{
          "code" : "W01020401",
          "display" : "FREE TRIIODOTHYRONINE"
        },
        {
          "code" : "W01020402",
          "display" : "FREE THYROXINE"
        },
        {
          "code" : "W01020403",
          "display" : "NEONATAL THYROID STIMULATING HORMONE"
        },
        {
          "code" : "W01020404",
          "display" : "REVERSE TRIIODOTHYRONINE"
        },
        {
          "code" : "W01020405",
          "display" : "TRIIODOTHYRONINE"
        },
        {
          "code" : "W01020406",
          "display" : "T- UPTAKE"
        },
        {
          "code" : "W01020407",
          "display" : "THYROXINE"
        },
        {
          "code" : "W01020408",
          "display" : "THYROGLOBULIN"
        },
        {
          "code" : "W01020409",
          "display" : "THYROID BINDING GLOBULIN"
        },
        {
          "code" : "W01020410",
          "display" : "THYROID STIMULATING HORMONE"
        },
        {
          "code" : "W01020411",
          "display" : "NEONATAL THYROXINE"
        },
        {
          "code" : "W01020499",
          "display" : "THYROID HORMONES - OTHER"
        }]
      },
      {
        "code" : "W010205",
        "display" : "FERTILITY / PREGNANCY HORMONES / PROTEINS",
        "concept" : [{
          "code" : "W01020501",
          "display" : "FERTILITY FUNCTION HORMONES / PROTEINS",
          "concept" : [{
            "code" : "W0102050101",
            "display" : "ANDROSTENEDIONE"
          },
          {
            "code" : "W0102050102",
            "display" : "DEHYDRO-EPIANDROSTERONE SULPHATE (INCL. DHEA)"
          },
          {
            "code" : "W0102050103",
            "display" : "ESTRADIOL"
          },
          {
            "code" : "W0102050104",
            "display" : "FOLLICLE STIMULATING HORMONE"
          },
          {
            "code" : "W0102050105",
            "display" : "LUTEINISING HORMONE"
          },
          {
            "code" : "W0102050106",
            "display" : "PROGESTERONE"
          },
          {
            "code" : "W0102050107",
            "display" : "17 OH PROGESTERONE"
          },
          {
            "code" : "W0102050108",
            "display" : "PROLACTIN"
          },
          {
            "code" : "W0102050109",
            "display" : "SEX HORMONE BINDING GLOBULIN"
          },
          {
            "code" : "W0102050110",
            "display" : "TESTOSTERONE (WITH DEHYDRO AND FREE TESTOSTERONE)"
          },
          {
            "code" : "W0102050111",
            "display" : "ANDROSTERONE"
          },
          {
            "code" : "W0102050112",
            "display" : "ANDROSTANEDIOL-GLUCURONIDE"
          },
          {
            "code" : "W0102050114",
            "display" : "11-DESOXYCORTISOL"
          },
          {
            "code" : "W0102050115",
            "display" : "CORTICOSTERON (R/M)"
          },
          {
            "code" : "W0102050199",
            "display" : "FERTILITY FUNCTION HORMONES - OTHER"
          }]
        },
        {
          "code" : "W01020502",
          "display" : "PREGNANCY TESTING HORMONES / PROTEINS",
          "concept" : [{
            "code" : "W0102050201",
            "display" : "ALPHA2-PREGNANCY ASSOCIATED GLYCOPROTEIN"
          },
          {
            "code" : "W0102050202",
            "display" : "ESTRIOL"
          },
          {
            "code" : "W0102050203",
            "display" : "UNCONJUGATED (FREE) ESTRIOL"
          },
          {
            "code" : "W0102050204",
            "display" : "ESTRONE"
          },
          {
            "code" : "W0102050205",
            "display" : "TOTAL HUMAN CHORIONIC GONADOTROPIN"
          },
          {
            "code" : "W0102050206",
            "display" : "B- HUMAN CHORIONIC GONADOTROPIN (INCL. SUBUNIT)"
          },
          {
            "code" : "W0102050207",
            "display" : "HUMAN PLACENTAL LACTOGEN"
          },
          {
            "code" : "W0102050208",
            "display" : "PREGNANCY SPECIFIC B1 -GLYCOPROTEIN"
          },
          {
            "code" : "W0102050209",
            "display" : "GLYCOPROTEIN A SUBUNIT"
          },
          {
            "code" : "W0102050210",
            "display" : "PREGNANCY ASSOCIATED PLASMA PROTEIN - A (DOWNS)"
          },
          {
            "code" : "W0102050211",
            "display" : "PLACENTAL GROWTH FACTOR (PRE-ECLAMPSIA)"
          },
          {
            "code" : "W0102050212",
            "display" : "SOLUBLE FMS-LIKE TYROSINE KINASE-1"
          },
          {
            "code" : "W0102050213",
            "display" : "FREE BETA HCG (PRENATAL SCREENING)"
          },
          {
            "code" : "W0102050214",
            "display" : "INHIBIN A/B (PRENATAL SCREENING)"
          },
          {
            "code" : "W0102050215",
            "display" : "ANTI-MÛLLERIAN HORMONE"
          },
          {
            "code" : "W0102050299",
            "display" : "PREGNANCY TESTING HORMONES - OTHER"
          }]
        }]
      },
      {
        "code" : "W010206",
        "display" : "INDIVIDUAL AND SPECIFIC HORMONES / PROTEINS",
        "concept" : [{
          "code" : "W01020601",
          "display" : "DIABETES ASSAYS (HORMONES)",
          "concept" : [{
            "code" : "W0102060101",
            "display" : "C-PEPTIDE"
          },
          {
            "code" : "W0102060102",
            "display" : "GLUCAGON"
          },
          {
            "code" : "W0102060103",
            "display" : "INSULIN"
          },
          {
            "code" : "W0102060104",
            "display" : "INSULIN ANTIBODY"
          },
          {
            "code" : "W0102060105",
            "display" : "GAD II ANTIBODIES AND OTHER ICA"
          },
          {
            "code" : "W0102060106",
            "display" : "THYROSIN PHOSPHATASE IA2 ANTIBODIES"
          },
          {
            "code" : "W0102060107",
            "display" : "PROINSULIN"
          },
          {
            "code" : "W0102060108",
            "display" : "ISLET CELL AB"
          },
          {
            "code" : "W0102060109",
            "display" : "GLYCOSYLATED/GLYCATED HAEMOGLOBIN (IC)"
          },
          {
            "code" : "W0102060199",
            "display" : "DIABETES ASSAYS - OTHER"
          }]
        },
        {
          "code" : "W01020602",
          "display" : "RENAL METABOLISM ASSAYS",
          "concept" : [{
            "code" : "W0102060201",
            "display" : "ALDOSTERONE"
          },
          {
            "code" : "W0102060202",
            "display" : "ANGIOTENSIN I / II"
          },
          {
            "code" : "W0102060203",
            "display" : "CORTISOL"
          },
          {
            "code" : "W0102060204",
            "display" : "RENINE (PLASMA RENINE ACTIVITY)"
          },
          {
            "code" : "W0102060205",
            "display" : "ANGIOTENSIN CONVERTING ENZYME (IC)"
          },
          {
            "code" : "W0102060206",
            "display" : "RENINE DIRECT"
          },
          {
            "code" : "W0102060207",
            "display" : "NEUTROPHIL GELATINASE ASSOCIATED LIPOCALIN (LIPOCALIN 2)"
          },
          {
            "code" : "W0102060208",
            "display" : "TISSUE INHIBITOR OF METALLOPROTEINASE-2 / INSULINE-LIKE GROWTH FACTOR - BINDING PROTEIN-7"
          },
          {
            "code" : "W0102060299",
            "display" : "RENAL METABOLISM TESTS - OTHER"
          }]
        },
        {
          "code" : "W01020603",
          "display" : "BONE AND MINERAL METABOLISM ASSAYS",
          "concept" : [{
            "code" : "W0102060301",
            "display" : "CALCITONIN"
          },
          {
            "code" : "W0102060302",
            "display" : "COLLAGEN TYPE I C-TERMINAL PROPEPTIDE"
          },
          {
            "code" : "W0102060303",
            "display" : "COLLAGEN TYPE III C-TERMINAL PROPEPTIDE"
          },
          {
            "code" : "W0102060304",
            "display" : "CROSS-LINKED C-TELOPEPTIDES"
          },
          {
            "code" : "W0102060305",
            "display" : "CROSS-LINKED N-TELOPEPTIDES"
          },
          {
            "code" : "W0102060306",
            "display" : "CYCLIC ADENOSIN MONOPHOSPHATE"
          },
          {
            "code" : "W0102060307",
            "display" : "DEOXYPYRIDINOLINE"
          },
          {
            "code" : "W0102060308",
            "display" : "1.25-DIHYDROXYVITAMIN D"
          },
          {
            "code" : "W0102060309",
            "display" : "25-HYDROXYVITAMIN D"
          },
          {
            "code" : "W0102060310",
            "display" : "HYDROXYPROLINE"
          },
          {
            "code" : "W0102060311",
            "display" : "OSTEOCALCINE"
          },
          {
            "code" : "W0102060312",
            "display" : "PARATHYROID HORMONE INTACT"
          },
          {
            "code" : "W0102060313",
            "display" : "PARATHYROID HORMONE (C-/N-TERMINAL, M-REGIONAL)"
          },
          {
            "code" : "W0102060314",
            "display" : "PARATHYROID HORMONE RELATED PEPTIDE"
          },
          {
            "code" : "W0102060315",
            "display" : "PYRIDINOLINE"
          },
          {
            "code" : "W0102060316",
            "display" : "TARTRATE-RESISTANT ACID PHOSPHATASE 5B"
          },
          {
            "code" : "W0102060317",
            "display" : "PROCOLLAGEN TYPE I N TERMINAL PROPEPTIDE"
          },
          {
            "code" : "W0102060318",
            "display" : "BONE ALKALINE PHOSPHATASE (IC)"
          },
          {
            "code" : "W0102060399",
            "display" : "BONE METABOLISM TESTS - OTHER"
          }]
        },
        {
          "code" : "W01020604",
          "display" : "ENDOCRINE HORMONES AND PEPTIDES",
          "concept" : [{
            "code" : "W0102060401",
            "display" : "ADRENOCORTIOTROPIC HORMONE"
          },
          {
            "code" : "W0102060402",
            "display" : "HUMAN GROWTH HORMONE"
          },
          {
            "code" : "W0102060403",
            "display" : "INSULIN-LIKE GROWTH FACTOR I (SOMATOMEDIN C)"
          },
          {
            "code" : "W0102060404",
            "display" : "INSULIN-LIKE GROWTH FACTOR II"
          },
          {
            "code" : "W0102060405",
            "display" : "INSULIN-LIKE GROWTH FACTOR BINDING PROTEIN 1"
          },
          {
            "code" : "W0102060406",
            "display" : "INSULIN-LIKE GROWTH FACTOR BINDING PROTEIN 3"
          },
          {
            "code" : "W0102060407",
            "display" : "VASOINTESTINAL PEPTIDE"
          },
          {
            "code" : "W0102060408",
            "display" : "VASOPRESSIN"
          },
          {
            "code" : "W0102060499",
            "display" : "ENDOCRINE HORMONES (GROWTH FACTORS) - OTHER"
          }]
        },
        {
          "code" : "W01020605",
          "display" : "NEUROENDOCRINE FUNCTION ASSAYS",
          "concept" : [{
            "code" : "W0102060501",
            "display" : "BOMBESIN"
          },
          {
            "code" : "W0102060502",
            "display" : "B-ENDORPHIN"
          },
          {
            "code" : "W0102060503",
            "display" : "17-HYDROXY-KETOSTERONE"
          },
          {
            "code" : "W0102060504",
            "display" : "17-KETOGENIC STEROIDS"
          },
          {
            "code" : "W0102060505",
            "display" : "17-KETOSTEROIDS"
          },
          {
            "code" : "W0102060506",
            "display" : "A-MELANOCITE STIMULATING HORMONES"
          },
          {
            "code" : "W0102060507",
            "display" : "NEUROTENSIN"
          },
          {
            "code" : "W0102060508",
            "display" : "SOMATOSTATIN"
          },
          {
            "code" : "W0102060509",
            "display" : "SUBSTANCE P"
          },
          {
            "code" : "W0102060599",
            "display" : "NEOENDOCRINE FUNCTION ASSAYS - OTHER"
          }]
        },
        {
          "code" : "W01020606",
          "display" : "MULTIPLE HORMONES - INDIVIDUAL AND SPECIFIC",
          "concept" : [{
            "code" : "W0102060601",
            "display" : "ADRENALIN / NORADRENALINE / DOPAMINE"
          },
          {
            "code" : "W0102060699",
            "display" : "MULTIPLE INDIVIDUAL HORMONES - OTHER"
          }]
        },
        {
          "code" : "W01020690",
          "display" : "VARIOUS INDIVIDUAL AND SPECIFIC HORMONES",
          "concept" : [{
            "code" : "W0102069001",
            "display" : "GASTRIN"
          },
          {
            "code" : "W0102069002",
            "display" : "GONADOTROPIN-RELEASING HORMONE"
          },
          {
            "code" : "W0102069003",
            "display" : "MELATONINE"
          },
          {
            "code" : "W0102069004",
            "display" : "NEOPTERINE"
          },
          {
            "code" : "W0102069005",
            "display" : "OXYTOCIN"
          },
          {
            "code" : "W0102069006",
            "display" : "PEPSINOGEN"
          },
          {
            "code" : "W0102069007",
            "display" : "PROSTAGLANDIN"
          },
          {
            "code" : "W0102069008",
            "display" : "SEROTONIN-UPTAKE (PLATELETS)"
          },
          {
            "code" : "W0102069009",
            "display" : "ELASTASE (PANCREATIC POLYPEPTIDE)"
          },
          {
            "code" : "W0102069010",
            "display" : "ADRENALIN"
          },
          {
            "code" : "W0102069011",
            "display" : "NORADRENALIN"
          },
          {
            "code" : "W0102069012",
            "display" : "DOPAMINE"
          },
          {
            "code" : "W0102069013",
            "display" : "PROCALCITONIN"
          },
          {
            "code" : "W0102069014",
            "display" : "LEPTIN"
          },
          {
            "code" : "W0102069015",
            "display" : "MOTILIN"
          },
          {
            "code" : "W0102069016",
            "display" : "CYCLIC GUANOSINE MONOPHOSPHATE"
          },
          {
            "code" : "W0102069017",
            "display" : "MID-REGIONAL PROADRENOMEDULLIN (MR-PROADM)"
          },
          {
            "code" : "W0102069099",
            "display" : "INDIVIDUAL AND SPECIFIC HORMONES - OTHER"
          }]
        }]
      },
      {
        "code" : "W010207",
        "display" : "ANEMIA RELATED / VITAMIN TESTS",
        "concept" : [{
          "code" : "W01020701",
          "display" : "ANEMIA",
          "concept" : [{
            "code" : "W0102070101",
            "display" : "ERYTHROPOIETIN"
          },
          {
            "code" : "W0102070102",
            "display" : "FERRITIN"
          },
          {
            "code" : "W0102070103",
            "display" : "FOLATE"
          },
          {
            "code" : "W0102070104",
            "display" : "SOLUBLE TRANSFERRIN RECEPTOR"
          },
          {
            "code" : "W0102070105",
            "display" : "RETICULOCYTE HAEMOGLOBIN CONTENT"
          },
          {
            "code" : "W0102070106",
            "display" : "IRON (IC)"
          },
          {
            "code" : "W0102070107",
            "display" : "IRON BINDING CAPACITY - TOTAL (IC)"
          },
          {
            "code" : "W0102070199",
            "display" : "ANEMIA - OTHER"
          }]
        },
        {
          "code" : "W01020702",
          "display" : "VITAMINES",
          "concept" : [{
            "code" : "W0102070201",
            "display" : "VITAMIN B1"
          },
          {
            "code" : "W0102070202",
            "display" : "VITAMIN B2"
          },
          {
            "code" : "W0102070203",
            "display" : "VITAMIN B6"
          },
          {
            "code" : "W0102070204",
            "display" : "VITAMIN B12"
          },
          {
            "code" : "W0102070205",
            "display" : "INTRINSIC FACTOR (BLOCKING ANTIBODY)"
          },
          {
            "code" : "W0102070206",
            "display" : "VITAMIN D (CHOLECALCIFEROL)"
          },
          {
            "code" : "W0102070299",
            "display" : "VITAMIN TESTS - OTHER"
          }]
        },
        {
          "code" : "W01020703",
          "display" : "MULTIPLE - ANEMIA RELATED / VITAMIN TESTS",
          "concept" : [{
            "code" : "W0102070301",
            "display" : "VITAMIN B 12 / FOLATE"
          },
          {
            "code" : "W0102070399",
            "display" : "MULTIPLE ANEMIA / VITAMIN TESTS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010208",
        "display" : "THERAPEUTIC DRUG MONITORING",
        "concept" : [{
          "code" : "W01020801",
          "display" : "CARDIOVASCULAR TDM",
          "concept" : [{
            "code" : "W0102080101",
            "display" : "DIGOXIN"
          },
          {
            "code" : "W0102080102",
            "display" : "DIGITOXIN"
          },
          {
            "code" : "W0102080103",
            "display" : "DISOPYRAMIDE"
          },
          {
            "code" : "W0102080104",
            "display" : "FLECAINIDE"
          },
          {
            "code" : "W0102080105",
            "display" : "LIDOCAINE"
          },
          {
            "code" : "W0102080106",
            "display" : "N-ACETYLPROCAINAMIDE"
          },
          {
            "code" : "W0102080107",
            "display" : "PROCAINAMIDE"
          },
          {
            "code" : "W0102080108",
            "display" : "PROPRANOLOL"
          },
          {
            "code" : "W0102080109",
            "display" : "QUINIDINE"
          },
          {
            "code" : "W0102080199",
            "display" : "CARDIOVASCULAR TDM - OTHER"
          }]
        },
        {
          "code" : "W01020802",
          "display" : "CENTRAL NERVOUS SYSTEMS TDM",
          "concept" : [{
            "code" : "W0102080201",
            "display" : "CARBAMAZEPINE"
          },
          {
            "code" : "W0102080202",
            "display" : "ETHOSUXIMIDE"
          },
          {
            "code" : "W0102080203",
            "display" : "FREE CARBAMAZEPINE"
          },
          {
            "code" : "W0102080204",
            "display" : "FREE PHENYTOIN"
          },
          {
            "code" : "W0102080205",
            "display" : "FREE PRIMIDONE"
          },
          {
            "code" : "W0102080206",
            "display" : "FREE VALPROIC ACID"
          },
          {
            "code" : "W0102080207",
            "display" : "PHENOBARBITAL"
          },
          {
            "code" : "W0102080208",
            "display" : "PHENYTOIN"
          },
          {
            "code" : "W0102080209",
            "display" : "PRIMIDONE"
          },
          {
            "code" : "W0102080210",
            "display" : "VALPROIC ACID"
          },
          {
            "code" : "W0102080211",
            "display" : "GABAPENTIN"
          },
          {
            "code" : "W0102080212",
            "display" : "LAMOTRIGINE"
          },
          {
            "code" : "W0102080213",
            "display" : "TOPIRAMATE"
          },
          {
            "code" : "W0102080214",
            "display" : "ZONISAMIDE"
          },
          {
            "code" : "W0102080215",
            "display" : "LEVETIRACETAM"
          },
          {
            "code" : "W0102080299",
            "display" : "CENTRAL NERVOUS SYSTEM TDM - OTHER"
          }]
        },
        {
          "code" : "W01020803",
          "display" : "ANTIBIOTIC TDM / ANTIVIRUS TDM",
          "concept" : [{
            "code" : "W0102080301",
            "display" : "AMIKACIN"
          },
          {
            "code" : "W0102080303",
            "display" : "CHLORAMPHENICOL"
          },
          {
            "code" : "W0102080305",
            "display" : "DIBEKACIN"
          },
          {
            "code" : "W0102080307",
            "display" : "GENTAMICIN"
          },
          {
            "code" : "W0102080309",
            "display" : "KANAMYCIN"
          },
          {
            "code" : "W0102080311",
            "display" : "NETILMYCIN"
          },
          {
            "code" : "W0102080313",
            "display" : "SISOMYCIN"
          },
          {
            "code" : "W0102080315",
            "display" : "STREPTOMYCIN"
          },
          {
            "code" : "W0102080317",
            "display" : "TOBRAMYCIN"
          },
          {
            "code" : "W0102080319",
            "display" : "VANCOMYCIN"
          },
          {
            "code" : "W0102080321",
            "display" : "TEICOPLANINE"
          },
          {
            "code" : "W0102080399",
            "display" : "ANTIBIOTICS TDM - OTHER"
          }]
        },
        {
          "code" : "W01020804",
          "display" : "ANTI-ASTHMA TDM",
          "concept" : [{
            "code" : "W0102080401",
            "display" : "CAFFEINE"
          },
          {
            "code" : "W0102080402",
            "display" : "THEOPHYLLINE"
          },
          {
            "code" : "W0102080499",
            "display" : "ANTI-ASTHMA TDM - OTHER"
          }]
        },
        {
          "code" : "W01020805",
          "display" : "ANTI-NEOPLASTIC TDM",
          "concept" : [{
            "code" : "W0102080501",
            "display" : "METHOTREXATE"
          },
          {
            "code" : "W0102080599",
            "display" : "ANTI-NEOPLASTIC TDM - OTHER"
          }]
        },
        {
          "code" : "W01020806",
          "display" : "IMMUNOSUPPRESSANT TDM",
          "concept" : [{
            "code" : "W0102080601",
            "display" : "CYCLOSPORINE TOTAL"
          },
          {
            "code" : "W0102080602",
            "display" : "CYCLOSPORINE SPECIFIC"
          },
          {
            "code" : "W0102080603",
            "display" : "TACROLIMUS"
          },
          {
            "code" : "W0102080604",
            "display" : "RAPAMYCIN (SIROLIMUS)"
          },
          {
            "code" : "W0102080605",
            "display" : "MYCOPHENOLATE"
          },
          {
            "code" : "W0102080606",
            "display" : "EVEROLIMUS"
          },
          {
            "code" : "W0102080699",
            "display" : "IMMUNOSUPPRESSANT TDM - OTHER"
          }]
        },
        {
          "code" : "W01020807",
          "display" : "AUTOIMMUNE DISEASE TDM",
          "concept" : [{
            "code" : "W0102080701",
            "display" : "INFLIXIMAB"
          },
          {
            "code" : "W0102080702",
            "display" : "ADALIMUMAB"
          },
          {
            "code" : "W0102080703",
            "display" : "ETANERCEP"
          },
          {
            "code" : "W0102080704",
            "display" : "RITUXIMAB"
          },
          {
            "code" : "W0102080799",
            "display" : "AUTOIMMUNE DISEASE TDM - OTHER"
          }]
        },
        {
          "code" : "W01020899",
          "display" : "THERAPEUTIC DRUG MONITORING - OTHER"
        }]
      },
      {
        "code" : "W010209",
        "display" : "DRUGS OF ABUSE / TOXICOLOGY",
        "concept" : [{
          "code" : "W01020901",
          "display" : "DRUGS OF ABUSE",
          "concept" : [{
            "code" : "W0102090101",
            "display" : "AMPHETAMINES GROUP"
          },
          {
            "code" : "W0102090102",
            "display" : "AMPHETAMINE/METHAMPHETAMINE SPECIFIC"
          },
          {
            "code" : "W0102090103",
            "display" : "BARBITURATES"
          },
          {
            "code" : "W0102090104",
            "display" : "BENZODIAZEPINES"
          },
          {
            "code" : "W0102090105",
            "display" : "CANNABINOIDS"
          },
          {
            "code" : "W0102090106",
            "display" : "COCAINE + COCAINE METABOLITES"
          },
          {
            "code" : "W0102090107",
            "display" : "CODEINE"
          },
          {
            "code" : "W0102090108",
            "display" : "COTININE"
          },
          {
            "code" : "W0102090109",
            "display" : "LYSERGIC ACID DIETHYLAMIDE"
          },
          {
            "code" : "W0102090110",
            "display" : "METHADONE"
          },
          {
            "code" : "W0102090111",
            "display" : "METHAQUALONE"
          },
          {
            "code" : "W0102090112",
            "display" : "MORPHINES"
          },
          {
            "code" : "W0102090113",
            "display" : "OPIATES"
          },
          {
            "code" : "W0102090114",
            "display" : "PHENCYCLIDINE"
          },
          {
            "code" : "W0102090115",
            "display" : "PROPOXYPHENE"
          },
          {
            "code" : "W0102090116",
            "display" : "6-ACETHYLMORPHIUM"
          },
          {
            "code" : "W0102090117",
            "display" : "BUPRENORPHINE"
          },
          {
            "code" : "W0102090118",
            "display" : "DEXTROMETHORPHAN"
          },
          {
            "code" : "W0102090119",
            "display" : "MDMA (ECSTASY)"
          },
          {
            "code" : "W0102090120",
            "display" : "EDDP SPECIFIC (METHADONE METABOLITES)"
          },
          {
            "code" : "W0102090121",
            "display" : "TRAMADOL"
          },
          {
            "code" : "W0102090122",
            "display" : "FENTANYL"
          },
          {
            "code" : "W0102090123",
            "display" : "OXYCODINE"
          },
          {
            "code" : "W0102090199",
            "display" : "DRUGS OF ABUSE - OTHER"
          }]
        },
        {
          "code" : "W01020902",
          "display" : "TOXICOLOGY",
          "concept" : [{
            "code" : "W0102090201",
            "display" : "ACETAMINOPHENE (PARACETAMOL)"
          },
          {
            "code" : "W0102090202",
            "display" : "5-AMINOLEVULINATE DEHYDRATASE"
          },
          {
            "code" : "W0102090203",
            "display" : "AMITRIPTYLINE"
          },
          {
            "code" : "W0102090204",
            "display" : "CATECHOLAMINES"
          },
          {
            "code" : "W0102090205",
            "display" : "DESIPRAMINE"
          },
          {
            "code" : "W0102090206",
            "display" : "DOXEPIN PLUS METABOLITES"
          },
          {
            "code" : "W0102090207",
            "display" : "ETHANOL (ALCOHOL)"
          },
          {
            "code" : "W0102090208",
            "display" : "HIPPURIC ACID"
          },
          {
            "code" : "W0102090209",
            "display" : "IMIPRAMINE"
          },
          {
            "code" : "W0102090210",
            "display" : "NORTRIPTYLINE"
          },
          {
            "code" : "W0102090211",
            "display" : "PHENOLS"
          },
          {
            "code" : "W0102090212",
            "display" : "PROTOPORPHYRIN IX"
          },
          {
            "code" : "W0102090213",
            "display" : "SALICYLATE"
          },
          {
            "code" : "W0102090214",
            "display" : "TRICHLOROACETIC ACID"
          },
          {
            "code" : "W0102090215",
            "display" : "TRICYCLIC ANTIDEPRESSANTS (TOTAL)"
          },
          {
            "code" : "W0102090216",
            "display" : "URO/COPROPORPHYRINS"
          },
          {
            "code" : "W0102090217",
            "display" : "VANILLYLMANDELIC ACID"
          },
          {
            "code" : "W0102090218",
            "display" : "HOMOVANILLIC ACID"
          },
          {
            "code" : "W0102090220",
            "display" : "ETHYL GLUCURONIDE"
          },
          {
            "code" : "W0102090299",
            "display" : "TOXICOLOGY - OTHER"
          }]
        }]
      },
      {
        "code" : "W010210",
        "display" : "MARKERS FOR AUTO-IMMUNE DISEASES",
        "concept" : [{
          "code" : "W01021001",
          "display" : "AUTOIMMUNE CONNECTIVE TISSUE DISEASES",
          "concept" : [{
            "code" : "W0102100101",
            "display" : "ANA SCREENING"
          },
          {
            "code" : "W0102100102",
            "display" : "ENA SCREENING"
          },
          {
            "code" : "W0102100105",
            "display" : "DS DNA - ANTIBODIES"
          },
          {
            "code" : "W0102100106",
            "display" : "SS DNA - ANTIBODIES"
          },
          {
            "code" : "W0102100107",
            "display" : "HISTONES (H1, H2A, H3, H4,…HN)"
          },
          {
            "code" : "W0102100108",
            "display" : "JO-1"
          },
          {
            "code" : "W0102100109",
            "display" : "PM-SCL - ANTIBODIES"
          },
          {
            "code" : "W0102100110",
            "display" : "SCL-70"
          },
          {
            "code" : "W0102100111",
            "display" : "SM"
          },
          {
            "code" : "W0102100112",
            "display" : "SS-A"
          },
          {
            "code" : "W0102100113",
            "display" : "SS-B"
          },
          {
            "code" : "W0102100114",
            "display" : "U1-SNRNP - ANTIBODIES"
          },
          {
            "code" : "W0102100115",
            "display" : "ANTI-CENTROMERE ANTIBODIES"
          },
          {
            "code" : "W0102100117",
            "display" : "NUCLEOSOME ANTIBODIES"
          },
          {
            "code" : "W0102100118",
            "display" : "RIBOSOMAL PHOSPHOPROTEIN ANTIBODIES"
          },
          {
            "code" : "W0102100199",
            "display" : "AUTOIMMUNE CONNECTIVE TISSUE DISEASES TESTING - OTHER"
          }]
        },
        {
          "code" : "W01021002",
          "display" : "NEURO-AUTO-IMMUNE DISEASE",
          "concept" : [{
            "code" : "W0102100201",
            "display" : "ANTI-GANGLIOSIDE-ANTIBODIES TOTAL"
          },
          {
            "code" : "W0102100202",
            "display" : "ANTI-GM1"
          },
          {
            "code" : "W0102100203",
            "display" : "ASIALO-GM1"
          },
          {
            "code" : "W0102100204",
            "display" : "ANTI-GD1B"
          },
          {
            "code" : "W0102100205",
            "display" : "GAL (ß1-3)"
          },
          {
            "code" : "W0102100206",
            "display" : "GALNAC"
          },
          {
            "code" : "W0102100207",
            "display" : "ANTI-MAG (MYELIN ASSOCIATED GLYCOPROTEIN)"
          },
          {
            "code" : "W0102100208",
            "display" : "ANTI-CAR (CANCER ASSOCIATED RETINOPATHY)"
          },
          {
            "code" : "W0102100209",
            "display" : "ANTI-HU ANTIBODY"
          },
          {
            "code" : "W0102100210",
            "display" : "ANTI-YO ANTIBODY"
          },
          {
            "code" : "W0102100211",
            "display" : "ANTI-RI ANTIBODY"
          },
          {
            "code" : "W0102100212",
            "display" : "ANTI-GQ1B"
          },
          {
            "code" : "W0102100299",
            "display" : "NEURO-AUTO-IMMUNE DISEASE - OTHER"
          }]
        },
        {
          "code" : "W01021003",
          "display" : "THYROID-AUTO-IMMUNE DISEASE",
          "concept" : [{
            "code" : "W0102100301",
            "display" : "THYROID PEROXIDASE (INCL. MICROSOMAL) ANTIBODIES"
          },
          {
            "code" : "W0102100302",
            "display" : "TSH RECEPTOR ANTIBODIES"
          },
          {
            "code" : "W0102100303",
            "display" : "THYROGLOBULIN AUTOANTIBODY"
          },
          {
            "code" : "W0102100304",
            "display" : "THYROID STIMULATING IMMUNOGLOBULIN"
          },
          {
            "code" : "W0102100399",
            "display" : "THYROID-AUTO-IMMUNE DISEASE - OTHER"
          }]
        },
        {
          "code" : "W01021004",
          "display" : "VASCULITIS",
          "concept" : [{
            "code" : "W0102100401",
            "display" : "ANCA SCREENING"
          },
          {
            "code" : "W0102100402",
            "display" : "MPO ANCA"
          },
          {
            "code" : "W0102100403",
            "display" : "PR3 ANCA"
          },
          {
            "code" : "W0102100499",
            "display" : "VASCULITIS - OTHER"
          }]
        },
        {
          "code" : "W01021005",
          "display" : "ANTI-PHOSPHOLIPID SYNDROM",
          "concept" : [{
            "code" : "W0102100501",
            "display" : "ANTI-CARDIOLIPIN ANTIBODIES"
          },
          {
            "code" : "W0102100502",
            "display" : "ANTI-PHOSPHATIDYLSERIN ANTIBODIES"
          },
          {
            "code" : "W0102100503",
            "display" : "ANTI-B2-GLYCOPROTEIN I ANTIBODIES"
          },
          {
            "code" : "W0102100504",
            "display" : "APLS SCREENING (OR ANTI-CARDIOLIPIN / ANTI-B2-GLYCOPROTEIN COMBITEST)"
          },
          {
            "code" : "W0102100599",
            "display" : "ANTI-PHOSPHOLIP SYNDROME - OTHER"
          }]
        },
        {
          "code" : "W01021006",
          "display" : "CELIAC DISEASE",
          "concept" : [{
            "code" : "W0102100601",
            "display" : "TISSUE TRANSGLUTAMINASE ANTIBODIES"
          },
          {
            "code" : "W0102100602",
            "display" : "TISSUE TRANSGLUTAMINASE/ GLIADIN ANTIBODIES COMBITEST"
          },
          {
            "code" : "W0102100603",
            "display" : "ANTIBODIES TO ENDOMYSIAL AUTOANTIGENES"
          },
          {
            "code" : "W0102100604",
            "display" : "GLIADIN ANTIBODIES"
          },
          {
            "code" : "W0102100699",
            "display" : "CELIAC DISEASE - OTHER"
          }]
        },
        {
          "code" : "W01021007",
          "display" : "AUTOIMMUNE HEPATITIS",
          "concept" : [{
            "code" : "W0102100701",
            "display" : "HEPATITIS AUTOANTIBODY SCREENING"
          },
          {
            "code" : "W0102100702",
            "display" : "ANTI-MITOCHONDRIAL ANTIBODIES"
          },
          {
            "code" : "W0102100703",
            "display" : "LKM1 AND RELATED PROTEINS ANTIBODIES"
          },
          {
            "code" : "W0102100704",
            "display" : "ANTI-ACTIN ANTIBODIES"
          },
          {
            "code" : "W0102100705",
            "display" : "PARIETAL CELL ANTIBODIES"
          },
          {
            "code" : "W0102100706",
            "display" : "SP 100 ANTIBODIES"
          },
          {
            "code" : "W0102100707",
            "display" : "ANTIBODIES TO SOLUBLE LIVERANTIGENES"
          },
          {
            "code" : "W0102100799",
            "display" : "AUTOIMMUNE HEPATITIS - OTHER"
          }]
        },
        {
          "code" : "W01021008",
          "display" : "INFLAMATORY BOWEL DISEASE (IBD)",
          "concept" : [{
            "code" : "W0102100801",
            "display" : "SACCHAROMYCES CEREVISIAE ANTIBODIES"
          },
          {
            "code" : "W0102100802",
            "display" : "PERINUCLEAR ANTI-NEUTROPHIL CYTOPLASMIC ANTIBODIES"
          },
          {
            "code" : "W0102100899",
            "display" : "OTHERS INFLAMATORY BOWEL DISEASE"
          }]
        },
        {
          "code" : "W01021090",
          "display" : "VARIOUS AUTO-IMMUNE DISEASE",
          "concept" : [{
            "code" : "W0102109005",
            "display" : "COMPLEMENT ACTIVATION"
          },
          {
            "code" : "W0102109007",
            "display" : "GOODPASTURE ANTIBODIES"
          },
          {
            "code" : "W0102109013",
            "display" : "SPERM ANTIBODIES"
          },
          {
            "code" : "W0102109014",
            "display" : "ANTIBODIES TO GLOMERULAR BASAL MEMBRANE"
          },
          {
            "code" : "W0102109022",
            "display" : "ACETYLCHOLIN RECEPTOR ANTIBODIES"
          },
          {
            "code" : "W0102109023",
            "display" : "LDL ANTIBODIES"
          },
          {
            "code" : "W0102109099",
            "display" : "AUTO-IMMUNE DISEASE TESTS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010211",
        "display" : "RHEUMATOID - INFLAMMATORY DISEASES MARKERS",
        "concept" : [{
          "code" : "W01021101",
          "display" : "ANTI-STREPTOCOCCAL DEOXYRIBONUCLEASE B (ANTI-DNAASE B)"
        },
        {
          "code" : "W01021102",
          "display" : "ANTI-STREPTOCOCCAL HYALURONIDASE"
        },
        {
          "code" : "W01021103",
          "display" : "ANTI-STREPTOKINASE"
        },
        {
          "code" : "W01021104",
          "display" : "ANTI-STREPTOLYSIN O (QUANTITATIVE)"
        },
        {
          "code" : "W01021105",
          "display" : "ANTI-STREPTOLYSIN O REACTION TIME / TITRE (QUALITATIVE)"
        },
        {
          "code" : "W01021106",
          "display" : "ANTI-STAPHYLOLYSIN (QUANTITATIVE)"
        },
        {
          "code" : "W01021107",
          "display" : "ANTI-STAPHYLOLYSIN REACTION TIME / TITRE (QUALITATIVE)"
        },
        {
          "code" : "W01021108",
          "display" : "CIRCULATING IMMUNE COMPLEXES"
        },
        {
          "code" : "W01021109",
          "display" : "C-REACTIVE PROTEIN"
        },
        {
          "code" : "W01021110",
          "display" : "RHEUMATOID FACTORS"
        },
        {
          "code" : "W01021111",
          "display" : "ANTI-STREPTOCOCCAL SCREENING"
        },
        {
          "code" : "W01021112",
          "display" : "ANTI-CYCLIC CITRULLINATED PEPTIDE"
        },
        {
          "code" : "W01021199",
          "display" : "RHEUMATOID / INFLAMMATORY DISEASE MARKERS - OTHER"
        }]
      },
      {
        "code" : "W010212",
        "display" : "SPECIFIC ORGAN FUNCTION ASSAYS",
        "concept" : [{
          "code" : "W01021201",
          "display" : "LIVER FUNCTION    (IMMUNOCHEMISTRY)",
          "concept" : [{
            "code" : "W0102120101",
            "display" : "MEGX"
          },
          {
            "code" : "W0102120102",
            "display" : "CARBO HYDRATE DEFICIENT TRANSFERRIN"
          },
          {
            "code" : "W0102120103",
            "display" : "HYALURONIC ACID"
          },
          {
            "code" : "W0102120104",
            "display" : "PROCOLLAGEN III AMINO TERMINAL PEPTIDE"
          },
          {
            "code" : "W0102120105",
            "display" : "TISSUE INHIBITOR OF METALLOPROTEINASE 1"
          },
          {
            "code" : "W0102120199",
            "display" : "LIVER FUNCTION - OTHER"
          }]
        },
        {
          "code" : "W01021299",
          "display" : "ORGAN FUNCTION ASSAYS - OTHER"
        }]
      },
      {
        "code" : "W010213",
        "display" : "CARDIAC MARKERS",
        "concept" : [{
          "code" : "W01021301",
          "display" : "BNP / PROBNP (INCLUDING OTHER NATRIURIC PEPTIDES)"
        },
        {
          "code" : "W01021302",
          "display" : "HEART-TYPE FATTY ACID BINDING PROTEIN"
        },
        {
          "code" : "W01021303",
          "display" : "GLYCOGEN PHOSPHORYLASE BB"
        },
        {
          "code" : "W01021304",
          "display" : "MYOGLOBIN"
        },
        {
          "code" : "W01021305",
          "display" : "MYOSIN LIGHT CHAIN"
        },
        {
          "code" : "W01021306",
          "display" : "TROPONIN I/T"
        },
        {
          "code" : "W01021307",
          "display" : "HOMOCYSTEINE"
        },
        {
          "code" : "W01021308",
          "display" : "HIGH-SENSITIVITY C-.REACTIVE PROTEIN"
        },
        {
          "code" : "W01021309",
          "display" : "ISCHEMIA MODIFIED ALBUMIN"
        },
        {
          "code" : "W01021310",
          "display" : "MYELOPEROXIDASE"
        },
        {
          "code" : "W01021311",
          "display" : "CREATINE KINASE - MB MASS (IC)"
        },
        {
          "code" : "W01021312",
          "display" : "LIPOPROTEIN-ASSOCIATED PHOSPHOLIPASE A2"
        },
        {
          "code" : "W01021313",
          "display" : "GALECTIN-3"
        },
        {
          "code" : "W01021314",
          "display" : "ST2"
        },
        {
          "code" : "W01021315",
          "display" : "COPEPTIN"
        },
        {
          "code" : "W01021316",
          "display" : "MID-REGIONAL PRO ATRIAL NATRIURETIC PEPTIDE (MR-PROANP)"
        },
        {
          "code" : "W01021399",
          "display" : "CARDIAC MARKERS - OTHER"
        }]
      },
      {
        "code" : "W010214",
        "display" : "MULTIPLE PARAMETERS -  IMMUNOCHEMISTRY",
        "concept" : [{
          "code" : "W01021499",
          "display" : "MULTIPLE IMMUNOCHEMISTRY REAGENTS - OTHER"
        }]
      },
      {
        "code" : "W010215",
        "display" : "IMMUNOCHEMISTRY CONTROLS/STANDARDS/CALIBRATORS",
        "concept" : [{
          "code" : "W01021520",
          "display" : "CONTROLS - IMMUNOCHEMISTRY",
          "concept" : [{
            "code" : "W0102152001",
            "display" : "TDM/DRUG CONTROLS"
          },
          {
            "code" : "W0102152002",
            "display" : "HORMONE CONTROLS"
          },
          {
            "code" : "W0102152003",
            "display" : "SPECIFIC PROTEIN CONTROLS"
          },
          {
            "code" : "W0102152004",
            "display" : "CARDIAC MARKER CONTROLS"
          },
          {
            "code" : "W0102152005",
            "display" : "TUMOUR MARKER CONTROLS"
          },
          {
            "code" : "W0102152006",
            "display" : "ANAEMIA RELATED/VITAMIN CONTROLS"
          },
          {
            "code" : "W0102152008",
            "display" : "CONTROLS FOR INDIVIDUAL AND SPECIFIC HORMONES"
          },
          {
            "code" : "W0102152009",
            "display" : "CONTROLS FOR NARCOTICS / TOXICOLOGY"
          },
          {
            "code" : "W0102152010",
            "display" : "CONTROLS FOR RHEUMATOLOGY"
          },
          {
            "code" : "W0102152011",
            "display" : "CONTROLS FOR AUTOIMMUNITY"
          },
          {
            "code" : "W0102152099",
            "display" : "CONTROLS- IMMUNOCHEMISTRY - OTHER"
          }]
        },
        {
          "code" : "W01021521",
          "display" : "MULTICOMPONENT IMMUNOCHEMISTRY CONTROLS"
        },
        {
          "code" : "W01021522",
          "display" : "STANDARDS AND CALIBRATORS IMMUNOCHEMISTRY",
          "concept" : [{
            "code" : "W0102152201",
            "display" : "TDM/DRUG STANDARDS AND CALIBRATORS"
          },
          {
            "code" : "W0102152202",
            "display" : "HORMONE STANDARDS AND CALIBRATORS"
          },
          {
            "code" : "W0102152203",
            "display" : "SPECIFIC PROTEIN STANDARDS AND CALIBRATORS"
          },
          {
            "code" : "W0102152204",
            "display" : "CARDIAC MARKER STANDARDS AND CALIBRATORS"
          },
          {
            "code" : "W0102152205",
            "display" : "TUMOUR MARKER STANDARDS AND CALIBRATORS"
          },
          {
            "code" : "W0102152206",
            "display" : "ANAEMIA RELATED/VITAMIN STANDARDS AND CALIBRATORS"
          },
          {
            "code" : "W0102152208",
            "display" : "STANDARDS AND CALIBRATORS FOR INDIVIDUAL AND SPECIFIC HORMONES /PROTEINS"
          },
          {
            "code" : "W0102152209",
            "display" : "DRUGS OF ABUSE / TOXICOLOGY STANDARDS AND CALIBRATORS"
          },
          {
            "code" : "W0102152210",
            "display" : "STANDARDS AND CALIBRATORS FOR RHEUMATOLOGY"
          },
          {
            "code" : "W0102152211",
            "display" : "STANDARDS AND CALIBRATORS FOR AUTOIMMUNITY"
          },
          {
            "code" : "W0102152299",
            "display" : "STANDARDS AND CALIBRATORS - IMMUNOCHEMISTRY - OTHER"
          }]
        }]
      },
      {
        "code" : "W010216",
        "display" : "IMMUNOCHEMISTRY - RAPID TESTS & POINT OF CARE",
        "concept" : [{
          "code" : "W01021601",
          "display" : "SPECIFIC PROTEINS RT & POC",
          "concept" : [{
            "code" : "W0102160101",
            "display" : "ALBUMIN INCL. UALBUMIN RT & POC"
          },
          {
            "code" : "W0102160102",
            "display" : "GLYCOSYLATED/GLYCATED HAEMOGLOBIN (IC) RT & POC"
          },
          {
            "code" : "W0102160199",
            "display" : "SPECIFIC PROTEINS RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01021602",
          "display" : "TUMOUR MARKERS RT & POC",
          "concept" : [{
            "code" : "W0102160201",
            "display" : "BTA - RT & POC"
          },
          {
            "code" : "W0102160202",
            "display" : "PSA - RT & POC"
          },
          {
            "code" : "W0102160203",
            "display" : "FECAL OCCULT BLOOD - RT & POC"
          },
          {
            "code" : "W0102160299",
            "display" : "TUMOUR MARKER RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01021603",
          "display" : "FERTILITY / PREGNANCY RT & POC",
          "concept" : [{
            "code" : "W0102160301",
            "display" : "FSH - RT & POC"
          },
          {
            "code" : "W0102160302",
            "display" : "HCG - RT & POC"
          },
          {
            "code" : "W0102160303",
            "display" : "HPL - RT & POC"
          },
          {
            "code" : "W0102160304",
            "display" : "LH - RT & POC"
          },
          {
            "code" : "W0102160399",
            "display" : "FERTILITY/PREGNANCY RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01021604",
          "display" : "THERAPEUTIC DRUG MONITORING (TDM) RT & POC",
          "concept" : [{
            "code" : "W0102160401",
            "display" : "THEOPHYLLINE - RT & POC"
          },
          {
            "code" : "W0102160499",
            "display" : "TDM RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01021605",
          "display" : "DRUGS OF ABUSE/TOXICOLOGY RT & POC",
          "concept" : [{
            "code" : "W0102160501",
            "display" : "AMPHETAMINES - RT & POC"
          },
          {
            "code" : "W0102160502",
            "display" : "AMPHETAMINE/METHAMPHETAMINE SPECIFIC (+ECSTASY) - RT & POC"
          },
          {
            "code" : "W0102160503",
            "display" : "BARBITURATES - RT & POC"
          },
          {
            "code" : "W0102160504",
            "display" : "BENZODIAZEPINES - RT & POC"
          },
          {
            "code" : "W0102160505",
            "display" : "CANNABINOIDS - RT & POC"
          },
          {
            "code" : "W0102160506",
            "display" : "COCAINE + COCAINE METABOLITES - RT & POC"
          },
          {
            "code" : "W0102160507",
            "display" : "METHADONE INCL. EDDP - RT & POC"
          },
          {
            "code" : "W0102160508",
            "display" : "OPIATES - RT & POC"
          },
          {
            "code" : "W0102160509",
            "display" : "PHENCYCLIDINE - RT & POC"
          },
          {
            "code" : "W0102160510",
            "display" : "TRICYCLIC ANTIDEPRESSANTS - RT & POC"
          },
          {
            "code" : "W0102160511",
            "display" : "MULTIPLE DRUGS OF ABUSE/TOXICOLOGY RT & POC"
          },
          {
            "code" : "W0102160599",
            "display" : "DRUGS OF ABUSE/TOXICOLOGY RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01021606",
          "display" : "RHEUMATOID / INFLAMMATORY DISEASE RT & POC",
          "concept" : [{
            "code" : "W0102160601",
            "display" : "C-REACTIVE PROTEIN - RT & POC"
          },
          {
            "code" : "W0102160699",
            "display" : "RHEUMATOID / INFLAMMATORY DISEASE RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01021607",
          "display" : "CARDIAC MARKERS - RT & POC",
          "concept" : [{
            "code" : "W0102160701",
            "display" : "CREATINE KINASE - MB MASS - RT & POC"
          },
          {
            "code" : "W0102160702",
            "display" : "MYOGLOBIN - RT & POC"
          },
          {
            "code" : "W0102160703",
            "display" : "TROPONIN I/T - RT & POC"
          },
          {
            "code" : "W0102160704",
            "display" : "BNP / PROBNP - RT & POC (INCLUDING OTHER NATRIURIC PEPTIDES)"
          },
          {
            "code" : "W0102160705",
            "display" : "HEART-TYPE FATTY ACID-BINDING PROTEIN - RT & POC"
          },
          {
            "code" : "W0102160706",
            "display" : "MULTIPLE CARDIAC MARKERS - RT & POC"
          },
          {
            "code" : "W0102160799",
            "display" : "CARDIAC MARKERS - RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01021608",
          "display" : "CONTROLS / STANDARDS / CALIBRATORS IMMUNOCHEM - RT & POC",
          "concept" : [{
            "code" : "W0102160801",
            "display" : "CONTROLS IMMUNOCHEM - RT & POC"
          },
          {
            "code" : "W0102160802",
            "display" : "STANDARDS AND CALIBRATORS IMMUNOCHEM - RT & POC"
          }]
        },
        {
          "code" : "W01021609",
          "display" : "INDIVIDUAL AND SPECIFIC HORMONES/PROTEINS RT & POC",
          "concept" : [{
            "code" : "W0102160901",
            "display" : "LIPOCALIN-2 GRANULOCYTE GELATINASE ASSOCIATED - RT & POC"
          },
          {
            "code" : "W0102160902",
            "display" : "PARATHYROID HORMONE - RT & POC"
          },
          {
            "code" : "W0102160903",
            "display" : "THYROID-STIMULATING HORMONE - RT & POC"
          },
          {
            "code" : "W0102160999",
            "display" : "INDIVIDUAL AND SPECIFIC HORMONES/PROTEINS RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01021699",
          "display" : "RAPID TESTS & POINT OF CARE - IMMUNOCHEMISTRY - OTHER"
        }]
      },
      {
        "code" : "W010217",
        "display" : "TRAUMATIC BRAIN INJURY",
        "concept" : [{
          "code" : "W01021701",
          "display" : "GLIAL FIBRILLARY ACIDIC PROTEIN / UBIQUITIN C-TERMINAL HYDROLASE-L1"
        },
        {
          "code" : "W01021702",
          "display" : "PROTEIN S-100 B"
        },
        {
          "code" : "W01021799",
          "display" : "OTHER TRAUMATIC BRAIN INJURY MARKERS"
        }]
      },
      {
        "code" : "W010290",
        "display" : "OTHER IMMUNOCHEMISTRY",
        "concept" : [{
          "code" : "W01029001",
          "display" : "ANTISERA (MONOVALENT AND POLYVALENT)"
        },
        {
          "code" : "W01029002",
          "display" : "AMANITIN ( ORGANIC POISONS )"
        },
        {
          "code" : "W01029003",
          "display" : "BUFFERS (UNASSIGNABLE), SUPPLEM. REAGENTS, ETC (IC)"
        },
        {
          "code" : "W01029004",
          "display" : "COATED TUBES AND BEADS (UNASSIGNABLE) (IC)"
        },
        {
          "code" : "W01029099",
          "display" : "IMMUNOCHEMISTRY REAGENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "W0103",
      "display" : "HAEMATOLOGY / HAEMOSTASIS / IMMUNOHAEMATOLOGY / HISTOLOGY / CYTOLOGY",
      "concept" : [{
        "code" : "W010301",
        "display" : "HAEMATOLOGY REAGENTS",
        "concept" : [{
          "code" : "W01030101",
          "display" : "REAGENTS FOR (AUTOMATED) HAEMATOLOGY ANALYZER",
          "concept" : [{
            "code" : "W0103010102",
            "display" : "SPECIFIC RETICULOCYTE REAGENTS"
          },
          {
            "code" : "W0103010103",
            "display" : "COMPLETE CELL COUNT"
          },
          {
            "code" : "W0103010104",
            "display" : "SMALL CELL COUNT"
          },
          {
            "code" : "W0103010105",
            "display" : "CBC-REAGENTS (CLEANING-/DILUTING-/LYSING-/SHEAT-FLUIDS)"
          },
          {
            "code" : "W0103010199",
            "display" : "REAGENTS FOR (AUTOMATED) HAEMATOLOGY ANALYZER - OTHER"
          }]
        },
        {
          "code" : "W01030102",
          "display" : "HAEMOGLOBIN (TYPES) TESTING",
          "concept" : [{
            "code" : "W0103010201",
            "display" : "HAEMOGLOBIN DETERMINATIONS (TOTAL HB)"
          },
          {
            "code" : "W0103010202",
            "display" : "HAEMOGLOBIN SUBTYPES HBA2, HBC, HBF, HBS, ETC.(EXCL. HBA1)"
          },
          {
            "code" : "W0103010299",
            "display" : "OTHER HAEMOGLOBIN (TYPES) TESTING - OTHER"
          }]
        },
        {
          "code" : "W01030103",
          "display" : "CELLULAR STAINS FOR MICROSCOPY",
          "concept" : [{
            "code" : "W0103010301",
            "display" : "HISTO / CYTO STAINS"
          },
          {
            "code" : "W0103010302",
            "display" : "ROMANOWSKY STAINS"
          },
          {
            "code" : "W0103010399",
            "display" : "HAEMATOLOGY STAINS FOR MICROSCOPY - OTHER"
          }]
        },
        {
          "code" : "W01030105",
          "display" : "HAEMATOLOGY CONTROLS AND CALIBRATORS",
          "concept" : [{
            "code" : "W0103010501",
            "display" : "NORMAL BLOOD CONTROLS"
          },
          {
            "code" : "W0103010502",
            "display" : "ABNORMAL BLOOD CONTROLS"
          },
          {
            "code" : "W0103010503",
            "display" : "MULTILEVEL BLOOD CONTROLS"
          },
          {
            "code" : "W0103010504",
            "display" : "HAEMOGLOBIN CONTROLS"
          },
          {
            "code" : "W0103010505",
            "display" : "PLATELET CONTROLS"
          },
          {
            "code" : "W0103010506",
            "display" : "RETICULOCYTE CONTROLS"
          },
          {
            "code" : "W0103010507",
            "display" : "WHOLE BLOOD CALIBRATORS"
          },
          {
            "code" : "W0103010599",
            "display" : "HAEMATOLOGY CONTROLS - OTHER"
          }]
        },
        {
          "code" : "W01030106",
          "display" : "HAEMATOLOGY TESTS - RT & POC",
          "concept" : [{
            "code" : "W0103010601",
            "display" : "HAEMOGLOBIN (HB)"
          },
          {
            "code" : "W0103010602",
            "display" : "ERYTHROCYTES (ERY)"
          },
          {
            "code" : "W0103010603",
            "display" : "HAEMATOCRIT (HCT)"
          },
          {
            "code" : "W0103010604",
            "display" : "WHITE BLOOD CELLS (WBC)"
          },
          {
            "code" : "W0103010605",
            "display" : "PLATELETS"
          },
          {
            "code" : "W0103010606",
            "display" : "HAEMATOLOGY CONTROLS - RT & POC"
          },
          {
            "code" : "W0103010607",
            "display" : "HAEMATOLOGY STANDARDS AND CALIBRATORS - RT & POC"
          },
          {
            "code" : "W0103010699",
            "display" : "HAEMATOLOGY RAPID TESTS & POINT OF CARE - OTHER"
          }]
        },
        {
          "code" : "W01030107",
          "display" : "ERYTHROCYTE SEDIMENTATION RATE (ESR) TEST"
        },
        {
          "code" : "W01030190",
          "display" : "OTHER HAEMATOLOGY REAGENTS",
          "concept" : [{
            "code" : "W0103019001",
            "display" : "CELLULAR ENZYME DETERMINATION REAGENTS (G-6-PDH, PYUVATE KINASE)"
          }]
        },
        {
          "code" : "W01030199",
          "display" : "HAEMATOLOGY REAGENTS - OTHER"
        }]
      },
      {
        "code" : "W010302",
        "display" : "HAEMOSTASIS REAGENTS (COAGULATION)",
        "concept" : [{
          "code" : "W01030201",
          "display" : "GENERAL COAGULATION TESTS",
          "concept" : [{
            "code" : "W0103020101",
            "display" : "PROTHROMBIN TIME ( QUICK TEST )"
          },
          {
            "code" : "W0103020102",
            "display" : "ACTIVATED PARTIAL THROMBOPLASTIN TIME"
          },
          {
            "code" : "W0103020103",
            "display" : "THROMBIN TIME / REPTILASE / BATROXBIN TIME"
          },
          {
            "code" : "W0103020104",
            "display" : "ACTIVATED CLOTTING TIME"
          },
          {
            "code" : "W0103020199",
            "display" : "GENERAL COAGULATION TESTS - OTHER"
          }]
        },
        {
          "code" : "W01030202",
          "display" : "COAGULATION FACTORS",
          "concept" : [{
            "code" : "W0103020201",
            "display" : "FIBRINOGEN ASSAYS (FACTOR I)"
          },
          {
            "code" : "W0103020202",
            "display" : "COAGULATION FACTOR II ( PROTHROMBIN )"
          },
          {
            "code" : "W0103020203",
            "display" : "COAGULATION FACTOR II A ( THROMBIN )"
          },
          {
            "code" : "W0103020204",
            "display" : "COAGULATION FACTOR V"
          },
          {
            "code" : "W0103020205",
            "display" : "COAGULATION FACTOR VII"
          },
          {
            "code" : "W0103020206",
            "display" : "COAGULATION FACTOR VII A"
          },
          {
            "code" : "W0103020207",
            "display" : "COAGULATION FACTOR VIII"
          },
          {
            "code" : "W0103020208",
            "display" : "COAGULATION FACTOR IX"
          },
          {
            "code" : "W0103020209",
            "display" : "COAGULATION FACTOR X"
          },
          {
            "code" : "W0103020210",
            "display" : "COAGULATION FACTOR XI"
          },
          {
            "code" : "W0103020211",
            "display" : "COAGULATION FACTOR XII"
          },
          {
            "code" : "W0103020212",
            "display" : "COAGULATION FACTOR XII A"
          },
          {
            "code" : "W0103020213",
            "display" : "COAGULATION FACTOR XIII"
          },
          {
            "code" : "W0103020214",
            "display" : "COAGULATION FACTOR HMW-KININOGEN (FITZGERALD)"
          },
          {
            "code" : "W0103020215",
            "display" : "COAGULATION FACTOR VON WILLEBRAND (AG)"
          },
          {
            "code" : "W0103020216",
            "display" : "PREKALLIKREIN / KALLIKREIN (FLETCHER FACTOR)"
          },
          {
            "code" : "W0103020217",
            "display" : "COAGULATION FACTOR VON WILLEBRAND ACTIVITY / RISTOCETIN COFACTOR ACTIVITY (RCO)"
          },
          {
            "code" : "W0103020218",
            "display" : "COAGULATION FACTOR VON WILLEBRAND COLLAGEN BINDING ASSAY (CBA)"
          },
          {
            "code" : "W0103020299",
            "display" : "COAGULATION FACTORS - OTHER"
          }]
        },
        {
          "code" : "W01030203",
          "display" : "SPECIAL COAGULATION TESTS",
          "concept" : [{
            "code" : "W0103020301",
            "display" : "FIBRIN SENSITIVITY MONOMER"
          },
          {
            "code" : "W0103020302",
            "display" : "FIBRINOPEPTIDE A"
          },
          {
            "code" : "W0103020303",
            "display" : "STANDARD HEPARIN"
          },
          {
            "code" : "W0103020304",
            "display" : "HIRUDIN TEST"
          },
          {
            "code" : "W0103020305",
            "display" : "PLASMIN - A2 - ANTIPLASMIN COMPLEX"
          },
          {
            "code" : "W0103020306",
            "display" : "PROTHROMBIN FRAGMENT 1 + 2"
          },
          {
            "code" : "W0103020307",
            "display" : "THROMBIN-ANTITHROMBIN III-COMPLEX"
          },
          {
            "code" : "W0103020308",
            "display" : "LOW MOLECULAR WEIGHT HEPARIN"
          },
          {
            "code" : "W0103020309",
            "display" : "ANTI XA ACTIVITY FOR HEPARIN AND DOAC"
          },
          {
            "code" : "W0103020310",
            "display" : "ANTI IIA ACTIVITY FOT DOAC"
          },
          {
            "code" : "W0103020311",
            "display" : "ADAMTS13 (ACTIVITY, AG, AB, INHIBITOR) SPECIFIC VON WILLEBRAND FACTOR (VWF) - CLEAVING PROTEASE"
          },
          {
            "code" : "W0103020399",
            "display" : "SPECIAL COAGULATION TESTS - OTHER"
          }]
        },
        {
          "code" : "W01030204",
          "display" : "PLATELET FACTORS",
          "concept" : [{
            "code" : "W0103020401",
            "display" : "AGGREGATION REAGENTS"
          },
          {
            "code" : "W0103020402",
            "display" : "PLATELET FACTOR 4"
          },
          {
            "code" : "W0103020403",
            "display" : "PROSTACYCLIN"
          },
          {
            "code" : "W0103020404",
            "display" : "THROMBOXANE"
          },
          {
            "code" : "W0103020405",
            "display" : "ß-THROMBOGLOBULIN"
          },
          {
            "code" : "W0103020406",
            "display" : "SCREENING FOR PRIMARY HEMOSTASIS"
          },
          {
            "code" : "W0103020407",
            "display" : "P2Y12 RECEPTOR"
          },
          {
            "code" : "W0103020499",
            "display" : "PRIMARY HEMOSTASIS/PLATELET FACTORS - OTHER"
          }]
        },
        {
          "code" : "W01030205",
          "display" : "FIBRINOLYSIS",
          "concept" : [{
            "code" : "W0103020501",
            "display" : "A2-ANTIPLASMIN"
          },
          {
            "code" : "W0103020502",
            "display" : "FIBRINOGEN DEGRADATION PRODUCTS"
          },
          {
            "code" : "W0103020503",
            "display" : "D-DIMER"
          },
          {
            "code" : "W0103020504",
            "display" : "PLASMIN"
          },
          {
            "code" : "W0103020505",
            "display" : "PLASMINOGEN"
          },
          {
            "code" : "W0103020506",
            "display" : "PLASMINOGEN ACTIVATOR-INHIBITORS"
          },
          {
            "code" : "W0103020507",
            "display" : "TISSUE PLASMINOGEN ACTIVATOR"
          },
          {
            "code" : "W0103020508",
            "display" : "UROKINASE PLASMINOGEN ACTIVATOR"
          },
          {
            "code" : "W0103020509",
            "display" : "THROMBIN ACTIVATING FIBRINOLYSIS INHIBITOR"
          },
          {
            "code" : "W0103020599",
            "display" : "FIBRINOLYSIS TESTS - OTHER"
          }]
        },
        {
          "code" : "W01030206",
          "display" : "COAGULATION INHIBITORS/THROMBOPHILIA MARKERS",
          "concept" : [{
            "code" : "W0103020601",
            "display" : "ANTI-PHOSPHOLIPID ANTIBODIES"
          },
          {
            "code" : "W0103020602",
            "display" : "ANTITHROMBIN"
          },
          {
            "code" : "W0103020603",
            "display" : "COAGULATION FACTOR VIII INHIBITOR"
          },
          {
            "code" : "W0103020604",
            "display" : "COAGULATION FACTOR IX INHIBITOR"
          },
          {
            "code" : "W0103020605",
            "display" : "COAGULATION FACTOR X INHIBITOR"
          },
          {
            "code" : "W0103020606",
            "display" : "LUPUS ANTICOAGULANT"
          },
          {
            "code" : "W0103020607",
            "display" : "PROTEIN C"
          },
          {
            "code" : "W0103020608",
            "display" : "PROTEIN S ACTIVITY"
          },
          {
            "code" : "W0103020609",
            "display" : "HEPARIN COFACTOR II - TISSUE FACTOR PATHWAY INHIBITOR"
          },
          {
            "code" : "W0103020610",
            "display" : "APC RESISTANCE"
          },
          {
            "code" : "W0103020611",
            "display" : "PRO C GLOBAL"
          },
          {
            "code" : "W0103020612",
            "display" : "FREE PROTEIN S ANTIGEN"
          },
          {
            "code" : "W0103020613",
            "display" : "TOTAL PROTEIN S ANTIGEN"
          },
          {
            "code" : "W0103020614",
            "display" : "HOMOCYSTEINE"
          },
          {
            "code" : "W0103020615",
            "display" : "COAGULATION INHIBITORS/THROMBOPHILIA MARKERS FOR HEPARIN INDUCED THROMBOCYTOPENIA TEST (HIT)"
          },
          {
            "code" : "W0103020699",
            "display" : "COAGULATION INHIBITORS - OTHER"
          }]
        },
        {
          "code" : "W01030207",
          "display" : "HAEMOSTASIS CALIBRATORS/CONTROLS",
          "concept" : [{
            "code" : "W0103020701",
            "display" : "CALIBRATION PLASMA FOR HAEMOSTASIS"
          },
          {
            "code" : "W0103020702",
            "display" : "CONTROL PLASMA FOR HAEMOSTASIS"
          },
          {
            "code" : "W0103020799",
            "display" : "HAEMOSTASIS CONTROLS - OTHER"
          }]
        },
        {
          "code" : "W01030208",
          "display" : "HAEMOSTASIS RAPID TESTS - RT & POC",
          "concept" : [{
            "code" : "W0103020801",
            "display" : "PROTHROMBIN TIME RT & POC"
          },
          {
            "code" : "W0103020802",
            "display" : "ACTIVATED PARTIAL THROMBOPLASTIN TIME - RT & POC"
          },
          {
            "code" : "W0103020803",
            "display" : "D-DIMER - RT & POC"
          },
          {
            "code" : "W0103020804",
            "display" : "ACTIVATED CLOTTING TIME RT & POC"
          },
          {
            "code" : "W0103020805",
            "display" : "CONTROLS/ STANDARDS / CALIBRATORS FOR RT & POC",
            "concept" : [{
              "code" : "W010302080501",
              "display" : "HEMOSTASIS CONTROLS RT & POC"
            },
            {
              "code" : "W010302080502",
              "display" : "HAEMOSTASIS STANDARDS AND CALIBRATORS RT & POC"
            }]
          },
          {
            "code" : "W0103020806",
            "display" : "HEPARIN INDUCED THROMBOCYTOPENIA TEST (HIT) RT & POC"
          },
          {
            "code" : "W0103020899",
            "display" : "HAEMOSTASIS RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01030209",
          "display" : "AUXILIARY REAGENTS AND SUPPLEMENTS (HAEMOSTASIS)",
          "concept" : [{
            "code" : "W0103020901",
            "display" : "CALCIUM CHLORIDE"
          },
          {
            "code" : "W0103020902",
            "display" : "CITRATE"
          },
          {
            "code" : "W0103020903",
            "display" : "BUFFERS (HAEMOSTASIS)"
          },
          {
            "code" : "W0103020904",
            "display" : "COATED TUBES (CITRATE, HEPARIN ETC.)"
          },
          {
            "code" : "W0103020999",
            "display" : "AUXILIARY REAGENTS (HAEMOSTASIS) - OTHER"
          }]
        },
        {
          "code" : "W01030299",
          "display" : "HAEMOSTASIS REAGENTS - OTHER"
        }]
      },
      {
        "code" : "W010303",
        "display" : "IMMUNOHAEMATOLOGY (BLOOD GROUPING)",
        "concept" : [{
          "code" : "W01030301",
          "display" : "ABO TYPING",
          "concept" : [{
            "code" : "W0103030101",
            "display" : "ABO GROUPING CELLS"
          },
          {
            "code" : "W0103030102",
            "display" : "ABO SERA"
          },
          {
            "code" : "W0103030199",
            "display" : "ABO TYPING TESTS - OTHER"
          }]
        },
        {
          "code" : "W01030302",
          "display" : "RHESUS TYPING",
          "concept" : [{
            "code" : "W0103030201",
            "display" : "RHESUS D"
          },
          {
            "code" : "W0103030202",
            "display" : "RHESUS PHENOTYPES"
          },
          {
            "code" : "W0103030299",
            "display" : "RHESUS TYPING ASSAYS OTHER"
          }]
        },
        {
          "code" : "W01030303",
          "display" : "ANTIBODY DETECTION (IMMUNOHAEMATOLOGY)",
          "concept" : [{
            "code" : "W0103030301",
            "display" : "ANTOBODY 1 CELL SCREENING"
          },
          {
            "code" : "W0103030302",
            "display" : "ANTIBODY 2 CELL SCREENING"
          },
          {
            "code" : "W0103030303",
            "display" : "ANTIBODY IDENTIFICATION CELL PANELS"
          },
          {
            "code" : "W0103030304",
            "display" : "POLYSPECIFIC ANTIHUMAN SERUM"
          },
          {
            "code" : "W0103030305",
            "display" : "MONOSPECIFIC ANTIHUMAN SERUM"
          },
          {
            "code" : "W0103030306",
            "display" : "ENHANCEMENT MEDIA (E.G. BOVINE ALBUMIN, LISS, PEG)"
          },
          {
            "code" : "W0103030307",
            "display" : "ENZYMES (E.G. BROMELIN / PAPAIN, ETC.)"
          },
          {
            "code" : "W0103030308",
            "display" : "ANTIBODY 3 CELL SCREENING"
          },
          {
            "code" : "W0103030399",
            "display" : "ANTIBODY DETECTION (IMMUNOHAEMATOLOGY) - OTHER"
          }]
        },
        {
          "code" : "W01030304",
          "display" : "IMMUNOHAEMATOLOGY CONTROLS",
          "concept" : [{
            "code" : "W0103030401",
            "display" : "COOMBS CONTROL CELLS"
          },
          {
            "code" : "W0103030402",
            "display" : "CONTROL KITS  (IMMUNOHAEMATOLOGY)"
          },
          {
            "code" : "W0103030499",
            "display" : "IMMUNOHAEMATOLOGY CONTROLS - OTHER"
          }]
        },
        {
          "code" : "W01030305",
          "display" : "OTHER ANTIGEN TYPING",
          "concept" : [{
            "code" : "W0103030501",
            "display" : "OTHER ANTIGEN TYPING REAGENTS"
          }]
        },
        {
          "code" : "W01030309",
          "display" : "COMBINED ABO TYPING + RHESUS TYPING",
          "concept" : [{
            "code" : "W0103030901",
            "display" : "COMBINED ABO TYPING + RHESUS D"
          },
          {
            "code" : "W0103030902",
            "display" : "COMBINED ABO TYPING + RHESUS PHENOTYPES"
          },
          {
            "code" : "W0103030999",
            "display" : "COMBINED ABO TYPING + RHESUS TYPING TEST - OTHER"
          }]
        },
        {
          "code" : "W01030399",
          "display" : "IMMUNOHAEMATOLOGY  (BLOOD GROUPING) TESTS - OTHER"
        }]
      },
      {
        "code" : "W010304",
        "display" : "TISSUE TYPING REAGENTS",
        "concept" : [{
          "code" : "W01030401",
          "display" : "COMPLEMENT FOR HLA TESTING"
        },
        {
          "code" : "W01030402",
          "display" : "HLA ANTIBODY SCREENING"
        },
        {
          "code" : "W01030403",
          "display" : "HLA ANTIGEN TYPING"
        },
        {
          "code" : "W01030404",
          "display" : "HLA CONTROL CELLS"
        },
        {
          "code" : "W01030405",
          "display" : "LYMPHOCYTE SEPARATION MEDIA"
        },
        {
          "code" : "W01030406",
          "display" : "LYMPHOCYTE STABILIZING MEDIA"
        },
        {
          "code" : "W01030499",
          "display" : "TISSUE TYPING REAGENTS - OTHER"
        }]
      },
      {
        "code" : "W010306",
        "display" : "CYTOKINES (LYMPHOKINES) / IMMUNMODULATORS",
        "concept" : [{
          "code" : "W01030601",
          "display" : "INTERFERONS (α, β, ɣ…)"
        },
        {
          "code" : "W01030602",
          "display" : "SOLUBLE ANTIGENS / RECEPTORS"
        },
        {
          "code" : "W01030603",
          "display" : "TUMOUR NECROSIS FACTORS (TNFα,TNFβ, ...)"
        },
        {
          "code" : "W01030604",
          "display" : "TUMOUR NECROSIS FACTORS RECEPTORS (TNF-R I,TNF-R II)"
        },
        {
          "code" : "W01030605",
          "display" : "COLONY STIMULATING FACTORS (G-CSF,M-CSF,GM-CSF)"
        },
        {
          "code" : "W01030606",
          "display" : "OTHER INTERLEUKINS (EXCEPT FOR IL-6)"
        },
        {
          "code" : "W01030607",
          "display" : "INTERLEUKINS RECEPTORS (IL-2R,IL6R ...)"
        },
        {
          "code" : "W01030608",
          "display" : "CYTOKINES CALIBRATORS/CONTROLS"
        },
        {
          "code" : "W01030609",
          "display" : "INTERLEUKIN 6 (IL-6)"
        },
        {
          "code" : "W01030699",
          "display" : "LYMPHOKINES /IMMUNMODULATORS - OTHER"
        }]
      },
      {
        "code" : "W010307",
        "display" : "HISTOLOGY/CYTOLOGY REAGENTS",
        "concept" : [{
          "code" : "W01030701",
          "display" : "CHROMOSOME CULTURE KITS / REAGENTS"
        },
        {
          "code" : "W01030702",
          "display" : "CYTOCHEMICAL STAINING REAGENTS"
        },
        {
          "code" : "W01030703",
          "display" : "DNA IN SITU HYBRIDISATION REAGENTS"
        },
        {
          "code" : "W01030704",
          "display" : "EMBEDDING MEDIA (HISTOLOGY/CYTOLOGY)"
        },
        {
          "code" : "W01030705",
          "display" : "FIXING REAGENTS (HISTOLOGY/CYTOLOGY)"
        },
        {
          "code" : "W01030706",
          "display" : "MOUNTING MEDIA (HISTOLOGY/CYTOLOGY)"
        },
        {
          "code" : "W01030707",
          "display" : "STAIN POWDERS (HISTOLOGY/CYTOLOGY)"
        },
        {
          "code" : "W01030708",
          "display" : "STAIN SOLUTIONS (HISTOLOGY/CYTOLOGY)"
        },
        {
          "code" : "W01030709",
          "display" : "PRIMARY ANTISERA FOR IMMUNOHISTOLOGY"
        },
        {
          "code" : "W01030710",
          "display" : "SECONDARY ANTISERA FOR IMMUNOHISTOLOGY"
        },
        {
          "code" : "W01030711",
          "display" : "IMMUNOHISTOLOGY KITS"
        },
        {
          "code" : "W01030799",
          "display" : "HISTOLOGY / CYTOLOGY REAGENTS - OTHER"
        }]
      },
      {
        "code" : "W010308",
        "display" : "MONOCLONAL ANTIBODIES / FLOW CYTOMETRY",
        "concept" : [{
          "code" : "W01030801",
          "display" : "MONOCLONAL ANTIBODIES FOR CELL SURFACE ANTIGENS",
          "concept" : [{
            "code" : "W0103080101",
            "display" : "ANTIBODIES FOR B AND T-CELL SUBTYPING"
          },
          {
            "code" : "W0103080102",
            "display" : "ANTIBODIES FOR HLA CLASS II DETERMINANTS"
          },
          {
            "code" : "W0103080103",
            "display" : "ANTIBODIES FOR LYMPHOMA TYPING (EXCEPT B-&T-CELL TYPING)"
          },
          {
            "code" : "W0103080104",
            "display" : "ANTIBODIES FOR RECOGNIZING CELL SURFACE RECEPTORS"
          },
          {
            "code" : "W0103080105",
            "display" : "ANTIBODIES FOR SUBTYPING OF LEUKEMIA (EXCEPT B-&T-CELL TYPING)"
          },
          {
            "code" : "W0103080106",
            "display" : "ANTIBODIES FOR LYMPHOCYTE SUBTYPING"
          },
          {
            "code" : "W0103080199",
            "display" : "MONOCLONAL ANTIBODIES FOR CELL SURFACE ANTIGENS - OTHER"
          }]
        },
        {
          "code" : "W01030802",
          "display" : "MONOCLONAL ANTIBODIES FOR CYTOPLASMATIC ANTIGENS",
          "concept" : [{
            "code" : "W0103080201",
            "display" : "MONOCLONAL ANTIBODIES FOR RECOGNIZING ENZYMES"
          },
          {
            "code" : "W0103080202",
            "display" : "IGA, IGD, IGM, IGG, IGE"
          },
          {
            "code" : "W0103080203",
            "display" : "MONOCLONAL ANTIBODIES FOR DETECTING CELLS EXSPRESSING KAPPA OR LAMBDA LIGHT CHAINS"
          },
          {
            "code" : "W0103080204",
            "display" : "PROLIFERATION MARKERS"
          },
          {
            "code" : "W0103080299",
            "display" : "MONOCLONAL ANTIBODIES FOR CYTOPLASMATIC ANTIGENS - OTHER"
          }]
        },
        {
          "code" : "W01030803",
          "display" : "STEM CELL ENUMERATION REAGENTS"
        },
        {
          "code" : "W01030804",
          "display" : "FLOW CYTOMETRY CONTROLS",
          "concept" : [{
            "code" : "W0103080401",
            "display" : "SETUP BEADS"
          },
          {
            "code" : "W0103080402",
            "display" : "LEUCOCYTE CONTROLS"
          },
          {
            "code" : "W0103080403",
            "display" : "LYMPHOCYTE SUBTYPING CONTROLS"
          },
          {
            "code" : "W0103080404",
            "display" : "STEM CELL ENUMERATION CONTROLS"
          },
          {
            "code" : "W0103080499",
            "display" : "FLOW CYTOMETRY CONTROLS - OTHER"
          }]
        },
        {
          "code" : "W01030805",
          "display" : "AUXILIARY & SUPPLEMENTAL REAGENTS FOR FLOW CYTOMETRY",
          "concept" : [{
            "code" : "W0103080501",
            "display" : "CELL STAINING REAGENTS FOR CELL NUCLEAR STAINING"
          },
          {
            "code" : "W0103080502",
            "display" : "CELL STAINING REAGENTS FOR DETECTING RETICULOCYTES"
          },
          {
            "code" : "W0103080599",
            "display" : "AUXILIARY & SUPPLEMENTAL REAGENTS FOR FLOW CYTOMETRY - OTHER"
          }]
        },
        {
          "code" : "W01030806",
          "display" : "OTHER REAGENTS FOR FLOW CYTOMETRY",
          "concept" : [{
            "code" : "W0103080699",
            "display" : "REAGENTS FOR FLOW CYTOMETRY - OTHER"
          }]
        }]
      },
      {
        "code" : "W010399",
        "display" : "HAEMATOLOGY / HAEMOSTASIS / IMMUNOHAEMATOLOGY / HISTOLOGY / CYSTOLOGY REAGENTS - OTHER"
      }]
    },
    {
      "code" : "W0104",
      "display" : "MICROBIOLOGY (CULTURE)",
      "concept" : [{
        "code" : "W010401",
        "display" : "BACTERIOLOGY - CULTURE MEDIA",
        "concept" : [{
          "code" : "W01040101",
          "display" : "DEHYDRATED CULTURE MEDIA (DCM - BACTERIOLOGY))",
          "concept" : [{
            "code" : "W0104010101",
            "display" : "DEHYDRATED CULTURE MEDIA (DCM)"
          },
          {
            "code" : "W0104010103",
            "display" : "RAW MATERIALS (AGAR, PEPTONES, …)"
          },
          {
            "code" : "W0104010104",
            "display" : "ADDITIVES FOR DCM (GROWTH SUPPLEMENTS, SELECTIVE AGENTS, ...)"
          },
          {
            "code" : "W0104010199",
            "display" : "DCM - OTHER"
          }]
        },
        {
          "code" : "W01040102",
          "display" : "PREPARED MEDIA IN TUBES (BACTERIOLOGY)",
          "concept" : [{
            "code" : "W0104010203",
            "display" : "TRANSPORT MEDIA"
          },
          {
            "code" : "W0104010204",
            "display" : "SAMPLE TRANSPORT FOR NA TESTING"
          },
          {
            "code" : "W0104010206",
            "display" : "MEDIA IN TUBES (SOLID & LIQUID)"
          },
          {
            "code" : "W0104010299",
            "display" : "MEDIA IN TUBES - OTHER"
          }]
        },
        {
          "code" : "W01040103",
          "display" : "PREPARED MEDIA IN BOTTLES (BACTERIOLOGY)",
          "concept" : [{
            "code" : "W0104010306",
            "display" : "CULTURE MEDIA IN BOTTLES"
          }]
        },
        {
          "code" : "W01040104",
          "display" : "PREPARED MEDIA IN PLATES (BACTERIOLOGY)",
          "concept" : [{
            "code" : "W0104010402",
            "display" : "CHROMOGENIC ID MEDIA (PLATES)"
          },
          {
            "code" : "W0104010403",
            "display" : "SUSCEPTIBILITY TEST MEDIA (PLATES)"
          },
          {
            "code" : "W0104010404",
            "display" : "CHROMOGENIC RESISTANCE MARKER MEDIA (PLATES) - MRSA, VRE, ESBL …"
          },
          {
            "code" : "W0104010405",
            "display" : "NON-CHROMOGENIC MEDIA (PLATES)"
          },
          {
            "code" : "W0104010407",
            "display" : "BI-PLATES - INCLUDING NON-CHROMOGENIC & CHROMOGENIC MEDIA COMBINATION"
          },
          {
            "code" : "W0104010499",
            "display" : "PREPARED MEDIA IN PLATES - OTHER"
          }]
        },
        {
          "code" : "W01040105",
          "display" : "BLOOD CULTURE - MANUAL & AUTOMATED",
          "concept" : [{
            "code" : "W0104010501",
            "display" : "BOTTLES FOR MANUAL BLOOD CULTURE"
          },
          {
            "code" : "W0104010504",
            "display" : "BOTTLES FOR AUTOMATED BLOOD CULTURE"
          },
          {
            "code" : "W0104010599",
            "display" : "MANUAL BLOOD CULTURES - (CONCENTRATORS, ANTIBOTIC INACTIVATORS,ETC.) - OTHER"
          }]
        },
        {
          "code" : "W01040106",
          "display" : "MYCOBACTERIA CULTURE (MANUAL & AUTOMATED)",
          "concept" : [{
            "code" : "W0104010603",
            "display" : "AUTOMATED MYCOBACTERIA MEDIA (BOTTLES)"
          },
          {
            "code" : "W0104010604",
            "display" : "MANUAL MYCOBACTERIA MEDIA (TUBES & BOTTLES)"
          },
          {
            "code" : "W0104010699",
            "display" : "MEDIA FOR MYCOBACTERIA CULTURES - MANUAL & AUTOMATED (FOR AST DRUGS, SUPPLEMENTS) - OTHER"
          }]
        },
        {
          "code" : "W01040107",
          "display" : "URINE SCREENING (BACTERIOLOGY)",
          "concept" : [{
            "code" : "W0104010701",
            "display" : "URINE SCREENING REAGENTS - AUTOMATED"
          },
          {
            "code" : "W0104010702",
            "display" : "URINE SCREENING MANUAL - STRIPS, ETC.)"
          },
          {
            "code" : "W0104010703",
            "display" : "URINE SCREENING MANUAL (DIPSLIDES ETC.)"
          },
          {
            "code" : "W0104010799",
            "display" : "URINE SCREENING (BACTERIOLOGY) - OTHER"
          }]
        },
        {
          "code" : "W01040108",
          "display" : "STAINS, BUFFERS (BACTERIOLOGY)",
          "concept" : [{
            "code" : "W0104010804",
            "display" : "STAINS"
          },
          {
            "code" : "W0104010805",
            "display" : "BUFFERS"
          },
          {
            "code" : "W0104010899",
            "display" : "BUFFERS, STAINS - OTHER"
          }]
        },
        {
          "code" : "W01040109",
          "display" : "ENVIRONMENTAL GENERATING SYSTEMS",
          "concept" : [{
            "code" : "W0104010901",
            "display" : "GAS GENERATING KITS"
          },
          {
            "code" : "W0104010999",
            "display" : "ENVIRONMENTAL GENERATING SYSTEMS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010403",
        "display" : "MYCOLOGY",
        "concept" : [{
          "code" : "W01040301",
          "display" : "DEHYDRATED CULTURE MEDIA   (MYCOLOGY)",
          "concept" : [{
            "code" : "W0104030101",
            "display" : "DCM FOR YEASTS AND FUNGI"
          },
          {
            "code" : "W0104030199",
            "display" : "DCM (MYCOLOGY) - OTHER"
          }]
        },
        {
          "code" : "W01040302",
          "display" : "PREPARED MEDIA IN PLATES   (MYCOLOGY)",
          "concept" : [{
            "code" : "W0104030201",
            "display" : "PPM FOR YEASTS AND FUNGI"
          },
          {
            "code" : "W0104030202",
            "display" : "CHROMOGENIC MEDIA FOR YEASTS AND FUNGI"
          },
          {
            "code" : "W0104030299",
            "display" : "PREPARED MEDIA IN PLATES - OTHER"
          }]
        },
        {
          "code" : "W01040303",
          "display" : "TUBES AND BOTTLED MEDIA FOR YEASTS AND FUNGI",
          "concept" : [{
            "code" : "W0104030301",
            "display" : "TUBES FOR YEASTS AND FUNGI"
          },
          {
            "code" : "W0104030302",
            "display" : "DIP SLIDES (MYCOLOGY)"
          },
          {
            "code" : "W0104030303",
            "display" : "BOTTLED MEDIA FOR YEASTS AND FUNGI"
          },
          {
            "code" : "W0104030399",
            "display" : "TUBES MEDIA FOR YEASTS AND FUNGI - OTHER"
          }]
        },
        {
          "code" : "W01040304",
          "display" : "IDENTIFICATION   (MYCOLOGY)",
          "concept" : [{
            "code" : "W0104030403",
            "display" : "IDENTIFICATION SYSTEMS FOR YEASTS AND FUNGI - AUTOMATED"
          },
          {
            "code" : "W0104030404",
            "display" : "IDENTIFICATION SYSTEMS FOR YEASTS AND FUNGI / NA REAGENTS"
          },
          {
            "code" : "W0104030405",
            "display" : "IDENTIFICATION SYSTEMS FOR YEASTS AND FUNGI - MANUAL"
          },
          {
            "code" : "W0104030499",
            "display" : "IDENTIFICATION SYSTEMS FOR YEAST AND FUNGI - OTHER"
          }]
        },
        {
          "code" : "W01040305",
          "display" : "SEROLOGICAL IDENTIFICATION   (MYCOLOGY)",
          "concept" : [{
            "code" : "W0104030501",
            "display" : "SEROLOGICAL IDENTIFICATION OF YEASTS AND FUNGI"
          },
          {
            "code" : "W0104030599",
            "display" : "SEROLOGICAL IDENTIFICATION SYSTEMS OF YEAST AND FUNGI - OTHER"
          }]
        },
        {
          "code" : "W01040306",
          "display" : "SUSCEPTIBILITY TESTING   (MYCOLOGY)",
          "concept" : [{
            "code" : "W0104030601",
            "display" : "SUSCEPTIBILITY TESTING SYSTEMS FOR YEASTS AND FUNGI",
            "concept" : [{
              "code" : "W010403060101",
              "display" : "SUSCEPTIBILITY TESTING SYSTEMS FOR YEASTS AND FUNGI - MANUAL"
            },
            {
              "code" : "W010403060102",
              "display" : "SUSCEPTIBILITY TESTING SYSTEMS FOR YEASTS AND FUNGI - AUTOMATED"
            },
            {
              "code" : "W010403060199",
              "display" : "SUSCEPTIBILITY TESTING SYSTEMS FOR YEASTS AND FUNGI - OTHER"
            }]
          }]
        }]
      },
      {
        "code" : "W010404",
        "display" : "TISSUE CULTURE FOR VIROLOGY",
        "concept" : [{
          "code" : "W01040401",
          "display" : "CELLS FOR TISSUE CULTURE"
        },
        {
          "code" : "W01040402",
          "display" : "MEDIA FOR TISSUE CULTURE"
        },
        {
          "code" : "W01040403",
          "display" : "SERUM FOR TISSUE CULTURE"
        },
        {
          "code" : "W01040404",
          "display" : "OTHER TISSUE CULTURE ADDITIVES AND SOLUTIONS"
        },
        {
          "code" : "W01040499",
          "display" : "VIRAL CULTURE REAGENTS - OTHER"
        }]
      },
      {
        "code" : "W010405",
        "display" : "PARASITOLOGY ( MICROBIOLOGY )",
        "concept" : [{
          "code" : "W01040501",
          "display" : "PARASITOLOGY REAGENTS",
          "concept" : [{
            "code" : "W0104050101",
            "display" : "PARASITOLOGY EXTRACTION REAGENTS"
          },
          {
            "code" : "W0104050102",
            "display" : "PARASITOLOGY STAINS"
          },
          {
            "code" : "W0104050199",
            "display" : "PARASITOLOGY REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01040502",
          "display" : "DETECTION AND IDENTIFICATION (PARASITOLOGY)",
          "concept" : [{
            "code" : "W0104050201",
            "display" : "PNEUMOCYSTIS JIROVECII (PNEUMOCYSTIS CARINII)"
          },
          {
            "code" : "W0104050202",
            "display" : "PLASMODIUM FALCIPARUM"
          },
          {
            "code" : "W0104050203",
            "display" : "CRYPTOSPORIDIUM"
          },
          {
            "code" : "W0104050299",
            "display" : "DETECTION AND IDENTIFICATION (PARASITOLOGY) - OTHER"
          }]
        }]
      },
      {
        "code" : "W010406",
        "display" : "CONTROLS/STANDARDS/CALIBRATORS - MICROBIOLOGY",
        "concept" : [{
          "code" : "W01040601",
          "display" : "QC STRAINS BACTERIOLOGY"
        },
        {
          "code" : "W01040699",
          "display" : "CONTROLS, STANDARDS, CALIBRATORS, MICROBIOLOGY - OTHER"
        }]
      },
      {
        "code" : "W010407",
        "display" : "MICROBIOLOGY RT & POC"
      },
      {
        "code" : "W010408",
        "display" : "BACTERIOLOGY - IDENTIFICATION AND SUSCEPTIBILITY TESTING",
        "concept" : [{
          "code" : "W01040801",
          "display" : "BIOCHEMICAL IDENTIFICATION AND SUSCEPTIBILITY TESTING - AUTOMATED",
          "concept" : [{
            "code" : "W0104080101",
            "display" : "GRAM NEGATIVE IDENTIFICATION - AUTOMATED"
          },
          {
            "code" : "W0104080103",
            "display" : "GRAM POSITIVE IDENTIFICATION - AUTOMATED"
          },
          {
            "code" : "W0104080105",
            "display" : "ANAEROBIC AND OTHER PATHOGENIC GERMS IDENTIFICATION - AUTOMATED"
          },
          {
            "code" : "W0104080107",
            "display" : "GRAM NEGATIVE SUSCEPTIBILITY TESTING - AUTOMATED"
          },
          {
            "code" : "W0104080108",
            "display" : "GRAM POSITIVE SUSCEPTIBILITY TESTING - AUTOMATED"
          },
          {
            "code" : "W0104080109",
            "display" : "COMBINED SUSCEPTIBILITY AND IDENTIFICATION SYSTEMS GRAM NEGATIVES - AUTOMATED"
          },
          {
            "code" : "W0104080110",
            "display" : "COMBINED SUSCEPTIBILITY AND IDENTIFICATION SYSTEMS GRAM POSITIVES - AUTOMATED"
          },
          {
            "code" : "W0104080111",
            "display" : "ANAEROBES AND FASTIDIOUS SUSCEPT TESTING - AUTOMATED"
          },
          {
            "code" : "W0104080112",
            "display" : "OTHER AUTOMATED IDENTIFICATION TESTING (INCL. CONSUMABLES...)"
          },
          {
            "code" : "W0104080113",
            "display" : "OTHER AUTOMATED SUSCEPTIBILITY TESTING (INCL CONSUMABLES...)"
          }]
        },
        {
          "code" : "W01040802",
          "display" : "BIOCHEMICAL IDENTIFICATION - MANUAL",
          "concept" : [{
            "code" : "W0104080201",
            "display" : "GRAM NEGATIVE - MANUAL IDENTIFICATION"
          },
          {
            "code" : "W0104080203",
            "display" : "GRAM POSITIVE - MANUAL IDENTIFICATION"
          },
          {
            "code" : "W0104080207",
            "display" : "MYCOPLASMA / UREAPLASMA - (INCL. COMBINED ID-AST)"
          },
          {
            "code" : "W0104080208",
            "display" : "SINGLE TESTS (DISCS, STRIPS, DROPPERS...)"
          },
          {
            "code" : "W0104080209",
            "display" : "MANUAL IDENTIFICATION KITS - ANAEROBES, PATHOGENS - OTHER"
          },
          {
            "code" : "W0104080299",
            "display" : "MANUAL IDENTIFICATION - OTHER"
          }]
        },
        {
          "code" : "W01040803",
          "display" : "IMMUNOLOGICAL IDENTIFICATION BY CULTURE",
          "concept" : [{
            "code" : "W0104080301",
            "display" : "SEROTYPING (E.COLI, SALMONELLA, SHIGELLA, ETC)"
          },
          {
            "code" : "W0104080302",
            "display" : "STREPTOCOCCI GROUPING SLIDE TESTS"
          },
          {
            "code" : "W0104080303",
            "display" : "STAPHYLOCOCCI SLIDE TESTS"
          },
          {
            "code" : "W0104080304",
            "display" : "MENINGITIS SLIDE TESTS"
          },
          {
            "code" : "W0104080399",
            "display" : "IMMUNOLOGICAL IDENTIFICATION - OTHER"
          }]
        },
        {
          "code" : "W01040805",
          "display" : "MANUAL SUSCEPTIBILITY TESTING",
          "concept" : [{
            "code" : "W0104080501",
            "display" : "MIC SYSTEMS - DILUTION METHODS (INCL. E-TEST)"
          },
          {
            "code" : "W0104080502",
            "display" : "IMPREGNATED DISKS, MULTI-DISKS & TABLETS"
          },
          {
            "code" : "W0104080503",
            "display" : "MANUAL ANTIMICROBIAL SUCEPTIBILITY TESTING (AST)-  STRIPS / CASSETTES/GALLERIES"
          },
          {
            "code" : "W0104080504",
            "display" : "TARGETED RESISTANCE TESTS - MRSA"
          },
          {
            "code" : "W0104080505",
            "display" : "TARGETED RESISTANCE TESTS - ESBL"
          },
          {
            "code" : "W0104080506",
            "display" : "TARGETED RESISTANCE TESTS - CARBAPENEMASE"
          },
          {
            "code" : "W0104080590",
            "display" : "TARGETED RESISTANCE TESTS - OTHER"
          },
          {
            "code" : "W0104080599",
            "display" : "MANUAL SUSCEPTIBILITY TESTING - OTHER"
          }]
        },
        {
          "code" : "W01040806",
          "display" : "NUCLEIC ACID IDENTIFICATION (BACTERIOLOGY)",
          "concept" : [{
            "code" : "W0104080601",
            "display" : "NUCLEIC ACID IDENTIFICATION - MANUAL / AUTOMATED BACTERIA SPP / SSPP"
          },
          {
            "code" : "W0104080602",
            "display" : "NUCLEIC ACID IDENTIFICATION - MANUAL / AUTOMATED MRSA AND/OR MSSA"
          },
          {
            "code" : "W0104080604",
            "display" : "NUCLEIC ACID IDENTIFICATION - MANUAL / AUTOMATED VRE"
          },
          {
            "code" : "W0104080605",
            "display" : "NUCLEIC ACID IDENTIFICATION - MANUAL / AUTOMATED ESBL"
          },
          {
            "code" : "W0104080606",
            "display" : "NUCLEIC ACID IDENTIFICATION - MANUAL / AUTOMATED CARBAPENEMASE"
          },
          {
            "code" : "W0104080607",
            "display" : "NUCLEIC ACID IDENTIFICATION - MANUAL / AUTOMATED OTHER RESISTANCE MARKERS"
          },
          {
            "code" : "W0104080608",
            "display" : "NUCLEIC ACID IDENTIFICATION - MANUAL / AUTOMATED ESBL / CARBAPENEMASE COMBINED"
          },
          {
            "code" : "W0104080699",
            "display" : "NUCLEIC ACID IDENTIFICATION (BACTERIOLOGY) MANUAL / AUTOMATED - OTHER"
          }]
        }]
      },
      {
        "code" : "W010499",
        "display" : "MICROBIOLOGY TESTS - OTHER"
      }]
    },
    {
      "code" : "W0105",
      "display" : "INFECTIOUS DISEASES",
      "concept" : [{
        "code" : "W010501",
        "display" : "BACTERIOLOGY (INFECT. IMMUNOLOGY/NAT)",
        "concept" : [{
          "code" : "W01050101",
          "display" : "CHLAMYDIA",
          "concept" : [{
            "code" : "W0105010107",
            "display" : "CHLAMYDIA TRACHOMATIS ANTIGEN DETECTION"
          },
          {
            "code" : "W0105010108",
            "display" : "CHLAMYDIA TRACHOMATIS ANTIBODY ASSAYS TOTAL"
          },
          {
            "code" : "W0105010109",
            "display" : "CHLAMYDIA TRACHOMATIS ANTIBODY IGA"
          },
          {
            "code" : "W0105010110",
            "display" : "CHLAMYDIA TRACHOMATIS ANTIBODY IGG"
          },
          {
            "code" : "W0105010111",
            "display" : "CHLAMYDIA TRACHOMATIS ANTIBODY IGM"
          },
          {
            "code" : "W0105010112",
            "display" : "CHLAMYDIA PNEUMONIAE ANTIGEN DETECTION"
          },
          {
            "code" : "W0105010113",
            "display" : "CHLAMYDIA PNEUMONIAE ANTIBODY ASSAYS TOTAL"
          },
          {
            "code" : "W0105010114",
            "display" : "CHLAMYDIA PNEUMONIAE ANTIBODY IGA"
          },
          {
            "code" : "W0105010115",
            "display" : "CHLAMYDIA PNEUMONAIE ANTIBODY IGG"
          },
          {
            "code" : "W0105010116",
            "display" : "CHLAMYDIA PNEUMONIAE ANTIBODY IGM"
          },
          {
            "code" : "W0105010117",
            "display" : "CHLAMYDIA TRACHOMATIS DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010118",
            "display" : "CHLAMYDIA PNEUMONIAE DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010199",
            "display" : "CHLAMYDIA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050102",
          "display" : "GONOCOCCI (NEISSERIA GONORRHOEAE)",
          "concept" : [{
            "code" : "W0105010201",
            "display" : "GONOCOCCAL ANTIGEN DETECTION"
          },
          {
            "code" : "W0105010202",
            "display" : "GONOCOCCAL ANTIBODY ASSAYS TOTAL"
          },
          {
            "code" : "W0105010203",
            "display" : "GONOCOCCAL DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010299",
            "display" : "GONOCOCCI REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050103",
          "display" : "SYPHILIS (TREPONEMA PALLIDUM)",
          "concept" : [{
            "code" : "W0105010301",
            "display" : "SYPHILIS ANTIGEN DETECTION"
          },
          {
            "code" : "W0105010302",
            "display" : "SYPHILIS ANTIBODY ASSAYS TOTAL"
          },
          {
            "code" : "W0105010303",
            "display" : "SYPHILIS ANTIBODY IGG"
          },
          {
            "code" : "W0105010304",
            "display" : "SYPHILIS ANTIBODY IGM"
          },
          {
            "code" : "W0105010305",
            "display" : "SYPHILIS DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010399",
            "display" : "SYPHILIS REAGENTS OTHER"
          }]
        },
        {
          "code" : "W01050104",
          "display" : "HELICOBACTER PYLORI",
          "concept" : [{
            "code" : "W0105010401",
            "display" : "H. PYLORI ANTIGEN DETECTION"
          },
          {
            "code" : "W0105010402",
            "display" : "H. PYLORI ANTIBODY ASSAYS"
          },
          {
            "code" : "W0105010403",
            "display" : "H. PYLORI DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010499",
            "display" : "H. PYLORI REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050105",
          "display" : "LEGIONELLA",
          "concept" : [{
            "code" : "W0105010501",
            "display" : "LEGIONELLA ANTIGEN DETECTION"
          },
          {
            "code" : "W0105010502",
            "display" : "LEGIONELLA ANTIBODY ASSAYS"
          },
          {
            "code" : "W0105010503",
            "display" : "LEGIONELLA DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010599",
            "display" : "LEGIONELLA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050106",
          "display" : "LYME BORRELIOSIS",
          "concept" : [{
            "code" : "W0105010601",
            "display" : "LYME ANTIGEN DETECTION"
          },
          {
            "code" : "W0105010602",
            "display" : "LYME ANTIBODY TOTAL"
          },
          {
            "code" : "W0105010603",
            "display" : "LYME ANTIBODY IGG"
          },
          {
            "code" : "W0105010604",
            "display" : "LYME ANTIBODY IGM"
          },
          {
            "code" : "W0105010605",
            "display" : "LYME DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010699",
            "display" : "LYME BORRELIOSIS REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050107",
          "display" : "MYCOBACTERIA GENUS + SPECIES",
          "concept" : [{
            "code" : "W0105010701",
            "display" : "MYCOBACTERIAL ANTIGEN DETECTION"
          },
          {
            "code" : "W0105010702",
            "display" : "MYCOBACTERIAL ANTIBODY ASSAYS"
          },
          {
            "code" : "W0105010703",
            "display" : "MYCOBACTERIAL DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010704",
            "display" : "TB-IGRA (INTERFERON-‐GAMMA-‐RELEASE ASSAY)"
          },
          {
            "code" : "W0105010799",
            "display" : "MYCOBACTERIA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050108",
          "display" : "MYCOPLASMA",
          "concept" : [{
            "code" : "W0105010801",
            "display" : "MYCOPLASMA ANTIGEN DETECTION"
          },
          {
            "code" : "W0105010802",
            "display" : "MYCOPLASMA ANTIBODY ASSAYS"
          },
          {
            "code" : "W0105010803",
            "display" : "MYCOPLASMA DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010899",
            "display" : "MYCOPLASMA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050109",
          "display" : "PSEUDOMONAS AERUGINOSA",
          "concept" : [{
            "code" : "W0105010901",
            "display" : "PSEUDOMONAS AERUGINOSA ANTIBODY IGG"
          },
          {
            "code" : "W0105010902",
            "display" : "PSEUDOMONAS DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105010999",
            "display" : "PSEUDOMONAS AERUGINOSA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050110",
          "display" : "SALMONELLA",
          "concept" : [{
            "code" : "W0105011001",
            "display" : "SALMONELLA ANTIGEN DETECTION"
          },
          {
            "code" : "W0105011002",
            "display" : "SALMONELLA ANTIBODY ASSAYS"
          },
          {
            "code" : "W0105011003",
            "display" : "SALMONELLA DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105011099",
            "display" : "SALMONELLA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050111",
          "display" : "STREPTOCOCCI",
          "concept" : [{
            "code" : "W0105011101",
            "display" : "STREPTOCOCCAL DIRECT ANTIGEN DETECTION"
          },
          {
            "code" : "W0105011102",
            "display" : "STREPTOCOCCAL  DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105011103",
            "display" : "STREP. A DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105011104",
            "display" : "STREP. B DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105011105",
            "display" : "STREP. PNEUMONIAE DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105011199",
            "display" : "STREPTOCOCCAL REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050112",
          "display" : "STAPHYLOCOCCI",
          "concept" : [{
            "code" : "W0105011201",
            "display" : "STAPHYLOCOCCAL DIRECT ANTIGEN DETECTION"
          },
          {
            "code" : "W0105011202",
            "display" : "STAPHYLOTOXIN"
          },
          {
            "code" : "W0105011203",
            "display" : "SAPHYLOCOCCAL DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105011299",
            "display" : "STAPHYLOCOCCI REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050113",
          "display" : "LISTERIA",
          "concept" : [{
            "code" : "W0105011301",
            "display" : "LISTERIA ANTIGEN DETECTION"
          },
          {
            "code" : "W0105011302",
            "display" : "LISTERIA ANTIBODY ASSAYS"
          },
          {
            "code" : "W0105011303",
            "display" : "LISTERIA MONOCYTOGENES DIRECT ANTIGEN DETECTION"
          },
          {
            "code" : "W0105011304",
            "display" : "LISTERIA MONOCYTOGENES ANTIBODY ASSAYS"
          },
          {
            "code" : "W0105011305",
            "display" : "LISTERIA DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105011399",
            "display" : "LISTERIA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050114",
          "display" : "CAMPYLOBACTER",
          "concept" : [{
            "code" : "W0105011401",
            "display" : "CAMPYLOBACTER DIRECT ANTIGEN DETECTION"
          },
          {
            "code" : "W0105011402",
            "display" : "CAMPYLOBACTER DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105011499",
            "display" : "CAMPYLOBACTER REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050115",
          "display" : "ESCHERICHIA COLI",
          "concept" : [{
            "code" : "W0105011501",
            "display" : "E. COLI DIRECT ANTIGEN DETECTION"
          },
          {
            "code" : "W0105011502",
            "display" : "E. COLI TOXIN"
          },
          {
            "code" : "W0105011503",
            "display" : "E. COLI DETECTION BY NA REAGENTS"
          },
          {
            "code" : "W0105011599",
            "display" : "E. COLI REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050116",
          "display" : "OTHER BACTERIOLOGY - NA REAGENTS",
          "concept" : [{
            "code" : "W0105011601",
            "display" : "BRUCELLA - NA REAGENTS"
          },
          {
            "code" : "W0105011603",
            "display" : "COXIELLA BURNETII (Q FEVER) - NA REAGENTS"
          },
          {
            "code" : "W0105011604",
            "display" : "LEPTOSPIRA - NA REAGENTS"
          },
          {
            "code" : "W0105011605",
            "display" : "RICKETTSIA - NA REAGENTS"
          },
          {
            "code" : "W0105011606",
            "display" : "YERSINIA - NA REAGENTS"
          },
          {
            "code" : "W0105011607",
            "display" : "BORDETELLA PERTUSSIS / PARAPERTUSSIS - NA REAGENTS"
          },
          {
            "code" : "W0105011608",
            "display" : "DIPHTERIA (CORYNEBACTERIUM D.) - NA REAGENTS"
          },
          {
            "code" : "W0105011609",
            "display" : "TETANUS (CLOSTRIDIUM T.) - NA REAGENTS"
          },
          {
            "code" : "W0105011610",
            "display" : "HAEMOPHILUS INFLUENZAE - NA REAGENTS"
          },
          {
            "code" : "W0105011611",
            "display" : "NEISSERIA MENINGITIDIS - NA REAGENTS"
          },
          {
            "code" : "W0105011612",
            "display" : "PROTEUS - NA REAGENTS"
          },
          {
            "code" : "W0105011613",
            "display" : "PSEUDOMONAS - NA REAGENTS"
          },
          {
            "code" : "W0105011614",
            "display" : "SHIGELLA - NA REAGENTS"
          },
          {
            "code" : "W0105011699",
            "display" : "BACTERIOLOGY - NA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050117",
          "display" : "OTHER BACTERIOLOGY IMMUNOASSAYS",
          "concept" : [{
            "code" : "W0105011701",
            "display" : "BRUCELLA"
          },
          {
            "code" : "W0105011703",
            "display" : "COXIELLA BURNETII (Q FEVER)"
          },
          {
            "code" : "W0105011704",
            "display" : "LEPTOSPIRA"
          },
          {
            "code" : "W0105011705",
            "display" : "RICKETTSIA"
          },
          {
            "code" : "W0105011706",
            "display" : "YERSINIA"
          },
          {
            "code" : "W0105011707",
            "display" : "BORDETELLA PERTUSSIS / PARAPERTUSSIS"
          },
          {
            "code" : "W0105011708",
            "display" : "DIPHTERIA (CORYNEBACTERIUM D.)"
          },
          {
            "code" : "W0105011709",
            "display" : "TETANUS (CLOSTRIDIUM T.)"
          },
          {
            "code" : "W0105011710",
            "display" : "HAEMOPHILUS INFLUENZAE"
          },
          {
            "code" : "W0105011711",
            "display" : "NEISSERIA MENINGITIDIS"
          },
          {
            "code" : "W0105011712",
            "display" : "PROTEUS"
          },
          {
            "code" : "W0105011713",
            "display" : "PSEUDOMONAS"
          },
          {
            "code" : "W0105011714",
            "display" : "SHIGELLA"
          },
          {
            "code" : "W0105011799",
            "display" : "BACTERIOLOGY IMMUNOASSAY - OTHER"
          }]
        },
        {
          "code" : "W01050118",
          "display" : "CLOSTRIDIUM DIFFICILE",
          "concept" : [{
            "code" : "W0105011801",
            "display" : "C.DIFFICILE GDH DETECTION"
          },
          {
            "code" : "W0105011802",
            "display" : "C.DIFFICILE TOXIN A/B DETECTION"
          },
          {
            "code" : "W0105011803",
            "display" : "C.DIFFICILE GDH AND TOXIN A/B COMBINED DETECTION"
          },
          {
            "code" : "W0105011804",
            "display" : "C.DIFFICILE BY NA REAGENTS"
          },
          {
            "code" : "W0105011899",
            "display" : "C.DIFFICILE REAGENTS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010502",
        "display" : "HEPATITIS VIRUSES (INFECT. IMMUNOLOGY/NAT)",
        "concept" : [{
          "code" : "W01050201",
          "display" : "HEPATITIS A VIRUS",
          "concept" : [{
            "code" : "W0105020101",
            "display" : "HAV ANTIGEN CONFIRMATORY"
          },
          {
            "code" : "W0105020102",
            "display" : "HAV ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105020103",
            "display" : "HAV ANTIBODY IGG"
          },
          {
            "code" : "W0105020104",
            "display" : "HAV ANTIBODY IGM"
          },
          {
            "code" : "W0105020105",
            "display" : "HEPATITIS A VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105020199",
            "display" : "HAV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050202",
          "display" : "HEPATITIS B VIRUS",
          "concept" : [{
            "code" : "W0105020201",
            "display" : "HEPATITIS B SURFACE ANTIGEN"
          },
          {
            "code" : "W0105020202",
            "display" : "HEPATITIS B SURFACE ANTIGEN - CONFIRMATORY"
          },
          {
            "code" : "W0105020203",
            "display" : "HEPATITIS B SURFACE ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105020204",
            "display" : "HEPATITIS B SURFACE ANTIBODY IGG"
          },
          {
            "code" : "W0105020205",
            "display" : "HEPATITIS B SURFACE ANTIBODY IGM"
          },
          {
            "code" : "W0105020206",
            "display" : "HEPATITIS B CORE ANTIGEN"
          },
          {
            "code" : "W0105020207",
            "display" : "HEPATITIS B CORE ANTIGEN - CONFIRMATORY"
          },
          {
            "code" : "W0105020208",
            "display" : "HEPATITIS B CORE ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105020209",
            "display" : "HEPATITIS B CORE ANTIBODY IGG"
          },
          {
            "code" : "W0105020210",
            "display" : "HEPATITIS B CORE ANTIBODY IGM"
          },
          {
            "code" : "W0105020211",
            "display" : "HEPATITIS B ANTIGEN"
          },
          {
            "code" : "W0105020212",
            "display" : "HEPATITIS B ANTIGEN - CONFIRMATORY"
          },
          {
            "code" : "W0105020213",
            "display" : "HEPATITIS B ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105020214",
            "display" : "HEPATITIS B ANTIBODY IGG"
          },
          {
            "code" : "W0105020215",
            "display" : "HEPATITIS B ANTIBODY IGM"
          },
          {
            "code" : "W0105020216",
            "display" : "HEPATITIS B VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105020217",
            "display" : "HEPATITIS B SURFACE ANTIGEN - QUANTITATIVE"
          },
          {
            "code" : "W0105020218",
            "display" : "HEPATITIS B VIRUS - GENOTYPING - NA REAGENTS"
          },
          {
            "code" : "W0105020299",
            "display" : "HBV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050203",
          "display" : "HEPATITIS C VIRUS",
          "concept" : [{
            "code" : "W0105020301",
            "display" : "HCV ANTIGEN"
          },
          {
            "code" : "W0105020302",
            "display" : "HCV ANTIGEN - CONFIRMATORY"
          },
          {
            "code" : "W0105020303",
            "display" : "HCV ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105020304",
            "display" : "HCV ANTIBODY IGG"
          },
          {
            "code" : "W0105020305",
            "display" : "HCV ANTIBODY IGM"
          },
          {
            "code" : "W0105020306",
            "display" : "HCV ANTIBODY - CONFIRMATORY"
          },
          {
            "code" : "W0105020307",
            "display" : "HEPATITIS C VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105020308",
            "display" : "HEPATITIS C VIRUS (HCV) ANTIGEN/ANTIBODY COMBO TEST"
          },
          {
            "code" : "W0105020309",
            "display" : "HEPATITIS C VIRUS (HCV) GENOTYPING - NA REAGENTS"
          },
          {
            "code" : "W0105020399",
            "display" : "HCV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050204",
          "display" : "HEPATITIS DELTA VIRUS",
          "concept" : [{
            "code" : "W0105020401",
            "display" : "HEPATITIS DELTA ANTIGEN"
          },
          {
            "code" : "W0105020402",
            "display" : "HEPATITIS DELTA ANTIGEN - CONFIRMATORY"
          },
          {
            "code" : "W0105020403",
            "display" : "HEPATITIS DELTA ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105020404",
            "display" : "HEPATITIS DELTA ANTIBODY IGG"
          },
          {
            "code" : "W0105020405",
            "display" : "HEPATITIS DELTA ANTIBODY IGM"
          },
          {
            "code" : "W0105020406",
            "display" : "HEPATITIS DELTA VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105020499",
            "display" : "HDV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050205",
          "display" : "HEPATITIS E VIRUS",
          "concept" : [{
            "code" : "W0105020501",
            "display" : "HEV ANTIGEN"
          },
          {
            "code" : "W0105020502",
            "display" : "HEV ANTIGEN - CONFIRMATORY"
          },
          {
            "code" : "W0105020503",
            "display" : "HEV ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105020504",
            "display" : "HEV ANTIBODY IGG"
          },
          {
            "code" : "W0105020505",
            "display" : "HEV ANTIBODY IGM"
          },
          {
            "code" : "W0105020506",
            "display" : "HEV ANTIBODY - CONFIRMATORY"
          },
          {
            "code" : "W0105020507",
            "display" : "HEPATITIS E VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105020599",
            "display" : "HEV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050206",
          "display" : "HEPATITIS G VIRUS",
          "concept" : [{
            "code" : "W0105020601",
            "display" : "HGV ANTIGEN"
          },
          {
            "code" : "W0105020602",
            "display" : "HGV ANTIGEN - CONFIRMATORY"
          },
          {
            "code" : "W0105020603",
            "display" : "HGV ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105020604",
            "display" : "HGV ANTIBODY IGG"
          },
          {
            "code" : "W0105020605",
            "display" : "HGV ANTIBODY IGM"
          },
          {
            "code" : "W0105020606",
            "display" : "HEPATITIS G VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105020699",
            "display" : "HGV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050207",
          "display" : "HEPATITIS X VIRUS",
          "concept" : [{
            "code" : "W0105020701",
            "display" : "HXV ANTIGEN"
          },
          {
            "code" : "W0105020702",
            "display" : "HXV ANTIGEN - CONFIRMATORY"
          },
          {
            "code" : "W0105020703",
            "display" : "HXV ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105020704",
            "display" : "HXV ANTIBODY IGG"
          },
          {
            "code" : "W0105020705",
            "display" : "HXV ANTIBODY IGM"
          },
          {
            "code" : "W0105020706",
            "display" : "HEPATITIS X VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105020799",
            "display" : "HXV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050290",
          "display" : "OTHER HEPATITIS VIRUSES",
          "concept" : [{
            "code" : "W0105029099",
            "display" : "HEPATITIS VIRUSES REAGENTS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010503",
        "display" : "RETROVIRUSES (INFECT. IMMUNOLOGY/NAT)",
        "concept" : [{
          "code" : "W01050301",
          "display" : "HIV 1",
          "concept" : [{
            "code" : "W0105030101",
            "display" : "HIV 1 ANTIGEN"
          },
          {
            "code" : "W0105030102",
            "display" : "HIV 1 ANTIGEN - CONFIRMATORY"
          },
          {
            "code" : "W0105030103",
            "display" : "HIV 1 ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105030104",
            "display" : "HIV 1 ANTIBODY IGG"
          },
          {
            "code" : "W0105030105",
            "display" : "HIV 1 ANTIBODY IGM"
          },
          {
            "code" : "W0105030106",
            "display" : "HIV 1 ANTIBODY - CONFIRMATORY"
          },
          {
            "code" : "W0105030107",
            "display" : "HIV 1 - NA REAGENTS"
          },
          {
            "code" : "W0105030108",
            "display" : "HIV 1 GENOTYPING - NA REAGENTS"
          },
          {
            "code" : "W0105030199",
            "display" : "HIV 1 REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050302",
          "display" : "HIV 2",
          "concept" : [{
            "code" : "W0105030201",
            "display" : "HIV 2 ANTIGEN"
          },
          {
            "code" : "W0105030202",
            "display" : "HIV 2 ANTIBODY"
          },
          {
            "code" : "W0105030203",
            "display" : "HIV 2 ANTIBODY - CONFIRMATORY"
          },
          {
            "code" : "W0105030204",
            "display" : "HIV 2 - NA REAGENTS"
          },
          {
            "code" : "W0105030205",
            "display" : "HIV 2 GENOTYPING - NA REAGENTS"
          },
          {
            "code" : "W0105030299",
            "display" : "HIV 2 REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050303",
          "display" : "HIV P24",
          "concept" : [{
            "code" : "W0105030301",
            "display" : "HIV P24 ANTIGEN"
          },
          {
            "code" : "W0105030302",
            "display" : "HIV P24 ANTIBODY"
          },
          {
            "code" : "W0105030303",
            "display" : "HIV P24 - NA REAGENTS"
          },
          {
            "code" : "W0105030399",
            "display" : "HIV P24 REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050304",
          "display" : "HIV - MULTIPLE ( 1 / 2 )",
          "concept" : [{
            "code" : "W0105030401",
            "display" : "HIV MULTIPLE ANTIGEN"
          },
          {
            "code" : "W0105030402",
            "display" : "HIV MULTIPLE ANTIBODY"
          },
          {
            "code" : "W0105030403",
            "display" : "HIV MULTIPLE ANTIBODY - CONFIRMATORY"
          },
          {
            "code" : "W0105030404",
            "display" : "HIV MULTIPLE AG/AB COMBI TEST"
          },
          {
            "code" : "W0105030405",
            "display" : "HIV MULTIPLE - NA REAGENTS"
          },
          {
            "code" : "W0105030499",
            "display" : "HIV MULTIPLE (1/2) REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050305",
          "display" : "HTLV I",
          "concept" : [{
            "code" : "W0105030501",
            "display" : "HTLV I ANTIGEN"
          },
          {
            "code" : "W0105030502",
            "display" : "HTLV I ANTIBODY"
          },
          {
            "code" : "W0105030503",
            "display" : "HTLV I ANTIBODY - CONFIRMATORY"
          },
          {
            "code" : "W0105030504",
            "display" : "HTLV I - NA REAGENTS"
          },
          {
            "code" : "W0105030599",
            "display" : "HTLV I REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050306",
          "display" : "HTLV II",
          "concept" : [{
            "code" : "W0105030601",
            "display" : "HTLV II ANTIGEN"
          },
          {
            "code" : "W0105030602",
            "display" : "HTLV II ANTIBODY"
          },
          {
            "code" : "W0105030603",
            "display" : "HTLV II ANTIBODY - CONFIRMATORY"
          },
          {
            "code" : "W0105030604",
            "display" : "HTLV II - NA REAGENTS"
          },
          {
            "code" : "W0105030699",
            "display" : "HTLV II REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050307",
          "display" : "HTLV MULTIPLE",
          "concept" : [{
            "code" : "W0105030701",
            "display" : "HTLV MULTIPLE ANTIGEN"
          },
          {
            "code" : "W0105030702",
            "display" : "HTLV MULTIPLE ANTIBODY"
          },
          {
            "code" : "W0105030703",
            "display" : "HTLV MULTIPLE ANTIBODY - CONFIRMATORY"
          },
          {
            "code" : "W0105030704",
            "display" : "HTLV MULTIPLE - NA REAGENTS"
          },
          {
            "code" : "W0105030799",
            "display" : "HTLV MULTIPLE REAGENTS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010504",
        "display" : "OTHER VIROLOGY TESTS (INFECT. IMMUNOLOGY/NAT)",
        "concept" : [{
          "code" : "W01050401",
          "display" : "RUBELLA VIRUS",
          "concept" : [{
            "code" : "W0105040101",
            "display" : "RUBELLA VIRUS ANTIBODIES - TOTAL"
          },
          {
            "code" : "W0105040102",
            "display" : "RUBELLA VIRUS IGG"
          },
          {
            "code" : "W0105040103",
            "display" : "RUBELLA VIRUS IGM"
          },
          {
            "code" : "W0105040104",
            "display" : "RUBELLA - NA REAGENTS"
          },
          {
            "code" : "W0105040199",
            "display" : "RUBELLA VIRUS REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050402",
          "display" : "CYTOMEGALOVIRUS",
          "concept" : [{
            "code" : "W0105040201",
            "display" : "CMV ANTIGEN"
          },
          {
            "code" : "W0105040202",
            "display" : "CMV ANTIBODIES - TOTAL"
          },
          {
            "code" : "W0105040203",
            "display" : "CMV IGG"
          },
          {
            "code" : "W0105040204",
            "display" : "CMV IGM"
          },
          {
            "code" : "W0105040205",
            "display" : "CMV - NA REAGENTS"
          },
          {
            "code" : "W0105040206",
            "display" : "CMV IGG - AVIDITY"
          },
          {
            "code" : "W0105040299",
            "display" : "CMV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050403",
          "display" : "HERPES SIMPLEX VIRUS",
          "concept" : [{
            "code" : "W0105040301",
            "display" : "HSV ANTIGEN"
          },
          {
            "code" : "W0105040302",
            "display" : "HSV 1+2 ANTIBODIES - TOTAL"
          },
          {
            "code" : "W0105040303",
            "display" : "HSV 1+2 IGG"
          },
          {
            "code" : "W0105040304",
            "display" : "HSV 1+2 IGM"
          },
          {
            "code" : "W0105040305",
            "display" : "HSV 1 ANTIBODIES - TOTAL"
          },
          {
            "code" : "W0105040306",
            "display" : "HSV 1 IGG"
          },
          {
            "code" : "W0105040307",
            "display" : "HSV 1 IGM"
          },
          {
            "code" : "W0105040308",
            "display" : "HSV 2 ANTIBODIES - TOTAL"
          },
          {
            "code" : "W0105040309",
            "display" : "HSV 2 IGG"
          },
          {
            "code" : "W0105040310",
            "display" : "HSV 2 IGM"
          },
          {
            "code" : "W0105040311",
            "display" : "HSV - NA REAGENTS"
          },
          {
            "code" : "W0105040399",
            "display" : "HSV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050404",
          "display" : "EPSTEIN BARR VIRUS",
          "concept" : [{
            "code" : "W0105040401",
            "display" : "EBV ANTIBODIES",
            "concept" : [{
              "code" : "W010504040101",
              "display" : "EBV ANTIBODIES - TOTAL"
            },
            {
              "code" : "W010504040102",
              "display" : "EBV IGG - TOTAL"
            },
            {
              "code" : "W010504040103",
              "display" : "EBV IGM - TOTAL"
            },
            {
              "code" : "W010504040104",
              "display" : "EBV VCA IGM"
            },
            {
              "code" : "W010504040105",
              "display" : "EBV VCA IGG"
            },
            {
              "code" : "W010504040106",
              "display" : "EBV EBNA IGG"
            },
            {
              "code" : "W010504040107",
              "display" : "EBV EA IGM"
            },
            {
              "code" : "W010504040108",
              "display" : "EBV EA IGG"
            },
            {
              "code" : "W010504040199",
              "display" : "EBV ANTIBODIES - OTHER"
            }]
          },
          {
            "code" : "W0105040403",
            "display" : "EBV - NA REAGENTS"
          },
          {
            "code" : "W0105040499",
            "display" : "EBV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050405",
          "display" : "OTHER VIROLOGY - NA REAGENTS",
          "concept" : [{
            "code" : "W0105040501",
            "display" : "ADENOVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040502",
            "display" : "ENTEROVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040504",
            "display" : "INFLUENZA & PARA INFLUENZA - NA REAGENTS"
          },
          {
            "code" : "W0105040505",
            "display" : "RESPIRATORY SYNCYTIAL VIRUS (RSV) - NA REAGENTS"
          },
          {
            "code" : "W0105040506",
            "display" : "ROTAVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040509",
            "display" : "PARVOVIRUS B 19 - NA REAGENTS"
          },
          {
            "code" : "W0105040511",
            "display" : "DENGUE VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040512",
            "display" : "FSME VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040513",
            "display" : "LCM VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040514",
            "display" : "HANTAVIRUS / BUNYAVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040515",
            "display" : "AVIAN INFLUENZA - NA REAGENTS"
          },
          {
            "code" : "W0105040516",
            "display" : "NOROVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040517",
            "display" : "HUMAN METAPNEUMOVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040518",
            "display" : "BOCAVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040520",
            "display" : "RHINOVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040521",
            "display" : "PARECHOVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040522",
            "display" : "BK VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040523",
            "display" : "JC VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040524",
            "display" : "HHV-6,7,8 - NA REAGENTS"
          },
          {
            "code" : "W0105040525",
            "display" : "CHIKUNGUNYA VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040526",
            "display" : "WEST NILE VIRUS - NA REAGENT"
          },
          {
            "code" : "W0105040528",
            "display" : "EBOLA (FILOVIRUS) - NA REAGENTS"
          },
          {
            "code" : "W0105040529",
            "display" : "CRIMEAN–CONGO HEMORRHAGIC FEVER (CCHF) - NA REAGENTS"
          },
          {
            "code" : "W0105040530",
            "display" : "ASTROVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040531",
            "display" : "ZIKA VIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105040532",
            "display" : "MONKEYPOX VIRUS / MPOX - NA REAGENT"
          },
          {
            "code" : "W0105040599",
            "display" : "VIROLOGY - NA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050406",
          "display" : "OTHER VIROLOGY ANTIGEN/ANTIBODY DETECTION",
          "concept" : [{
            "code" : "W0105040601",
            "display" : "ADENOVIRUS"
          },
          {
            "code" : "W0105040602",
            "display" : "ENTEROVIRUS"
          },
          {
            "code" : "W0105040604",
            "display" : "INFLUENZA & PARA INFLUENZA"
          },
          {
            "code" : "W0105040605",
            "display" : "RESPIRATORY SYNCYTIAL VIRUS (RSV)"
          },
          {
            "code" : "W0105040606",
            "display" : "ROTAVIRUS"
          },
          {
            "code" : "W0105040609",
            "display" : "PARVOVIRUS B 19"
          },
          {
            "code" : "W0105040611",
            "display" : "DENGUE VIRUS"
          },
          {
            "code" : "W0105040612",
            "display" : "FSME VIRUS"
          },
          {
            "code" : "W0105040613",
            "display" : "LCM VIRUS"
          },
          {
            "code" : "W0105040614",
            "display" : "HANTAVIRUS / BUNYAVIRUS"
          },
          {
            "code" : "W0105040615",
            "display" : "AVIAN INFLUENZA"
          },
          {
            "code" : "W0105040616",
            "display" : "NOROVIRUS"
          },
          {
            "code" : "W0105040617",
            "display" : "HUMAN METAPNEUMOVIRUS"
          },
          {
            "code" : "W0105040618",
            "display" : "BOCAVIRUS"
          },
          {
            "code" : "W0105040620",
            "display" : "RHINOVIRUS"
          },
          {
            "code" : "W0105040621",
            "display" : "PARECHOVIRUS"
          },
          {
            "code" : "W0105040622",
            "display" : "BK VIRUS"
          },
          {
            "code" : "W0105040623",
            "display" : "JC VIRUS"
          },
          {
            "code" : "W0105040624",
            "display" : "HHV-6,7,8"
          },
          {
            "code" : "W0105040625",
            "display" : "CHIKUNGUNYA VIRUS"
          },
          {
            "code" : "W0105040626",
            "display" : "WEST NILE VIRUS"
          },
          {
            "code" : "W0105040627",
            "display" : "EBOLA (FILOVIRUS)"
          },
          {
            "code" : "W0105040628",
            "display" : "CRIMEAN–CONGO HEMORRHAGIC FEVER (CCHF)"
          },
          {
            "code" : "W0105040629",
            "display" : "ASTROVIRUS"
          },
          {
            "code" : "W0105040630",
            "display" : "ZIKA VIRUS"
          },
          {
            "code" : "W0105040699",
            "display" : "VIRAL ANTIGEN/ANTIBODY DETECTION - OTHER"
          }]
        },
        {
          "code" : "W01050407",
          "display" : "MEASLES VIRUS",
          "concept" : [{
            "code" : "W0105040701",
            "display" : "MEASLES VIRUS ANTIBODIES - TOTAL"
          },
          {
            "code" : "W0105040702",
            "display" : "MEASLES VIRUS IGG"
          },
          {
            "code" : "W0105040703",
            "display" : "MEASLES VIRUS IGM"
          },
          {
            "code" : "W0105040704",
            "display" : "MEASLES - NA REAGENTS"
          },
          {
            "code" : "W0105040799",
            "display" : "MEASLES VIRUS REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050408",
          "display" : "MUMPS / PAROTITIS VIRUS",
          "concept" : [{
            "code" : "W0105040801",
            "display" : "MUMPS / PAROTITIS VIRUS ANTIBODIES - TOTAL"
          },
          {
            "code" : "W0105040802",
            "display" : "MUMPS / PAROTITIS VIRUS IGG"
          },
          {
            "code" : "W0105040803",
            "display" : "MUMPS / PAROTITIS VIRUS IGM"
          },
          {
            "code" : "W0105040804",
            "display" : "MUMPS / PAROTITIS - NA REAGENTS"
          },
          {
            "code" : "W0105040899",
            "display" : "MUMPS / PAROTITIS VIRUS REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050409",
          "display" : "VARICELLA ZOSTER VIRUS",
          "concept" : [{
            "code" : "W0105040901",
            "display" : "VARICELLA ZOSTER VIRUS ANTIBODIES - TOTAL"
          },
          {
            "code" : "W0105040902",
            "display" : "VARICELLA ZOSTER VIRUS IGG"
          },
          {
            "code" : "W0105040903",
            "display" : "VARICELLA ZOSTER VIRUS IGM"
          },
          {
            "code" : "W0105040904",
            "display" : "VARICELLA ZOSTER  - NA REAGENTS"
          },
          {
            "code" : "W0105040999",
            "display" : "VARICELLA ZOSTER VIRUS REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050410",
          "display" : "HUMAN PAPILLOMA VIRUS",
          "concept" : [{
            "code" : "W0105041001",
            "display" : "HPV ANTIGEN / ANTIBODIES"
          },
          {
            "code" : "W0105041002",
            "display" : "SCREENING HIGH-RISK HPV - NA REAGENTS"
          },
          {
            "code" : "W0105041003",
            "display" : "PARTIAL GENOTYPING HIGH-RISK HPV - NA REAGENTS"
          },
          {
            "code" : "W0105041004",
            "display" : "FULL GENOTYPING HIGH-RISK + LOW-RISK HPV - NA REAGENTS"
          },
          {
            "code" : "W0105041005",
            "display" : "OTHER HPV - NA REAGENTS"
          },
          {
            "code" : "W0105041099",
            "display" : "HPV REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050411",
          "display" : "CORONAVIRUS",
          "concept" : [{
            "code" : "W0105041101",
            "display" : "CORONAVIRUS AG"
          },
          {
            "code" : "W0105041102",
            "display" : "CORONAVIRUS ANTIBODIES - TOTAL"
          },
          {
            "code" : "W0105041103",
            "display" : "CORONAVIRUS IGG"
          },
          {
            "code" : "W0105041104",
            "display" : "CORONAVIRUS IGM"
          },
          {
            "code" : "W0105041105",
            "display" : "CORONAVIRUS IGA"
          },
          {
            "code" : "W0105041106",
            "display" : "CORONAVIRUS - NA REAGENTS"
          },
          {
            "code" : "W0105041199",
            "display" : "OTHER CORONAVIRUS REAGENTS"
          }]
        },
        {
          "code" : "W01050499",
          "display" : "VIROLOGY REAGENTS - OTHER"
        }]
      },
      {
        "code" : "W010505",
        "display" : "PARASITOLOGY (INFECT. IMMUNOLOGY/NAT)",
        "concept" : [{
          "code" : "W01050501",
          "display" : "TOXOPLASMA",
          "concept" : [{
            "code" : "W0105050101",
            "display" : "TOXOPLASMA ANTIBODY (TOTAL)"
          },
          {
            "code" : "W0105050102",
            "display" : "TOXOPLASMA ANTIBODY IGG"
          },
          {
            "code" : "W0105050103",
            "display" : "TOXOPLASMA ANTIBODY IGM"
          },
          {
            "code" : "W0105050104",
            "display" : "TOXOPLASMA ANTIBODY IGG - AVIDITY"
          },
          {
            "code" : "W0105050105",
            "display" : "TOXOPLASMA - NA REAGENTS"
          },
          {
            "code" : "W0105050199",
            "display" : "TOXOPLASMA REAGENTS - OTHER"
          }]
        },
        {
          "code" : "W01050502",
          "display" : "MISCELLANEOUS PARASITOLOGY IMMUNOASSAY",
          "concept" : [{
            "code" : "W0105050201",
            "display" : "ENTAMOEBA HISTOLYTICA"
          },
          {
            "code" : "W0105050202",
            "display" : "CHAGAS"
          },
          {
            "code" : "W0105050203",
            "display" : "DISTOMATOSIS"
          },
          {
            "code" : "W0105050204",
            "display" : "ECHINOCOCCUS"
          },
          {
            "code" : "W0105050205",
            "display" : "LEISHMANIA"
          },
          {
            "code" : "W0105050206",
            "display" : "SCHISTOSOMA"
          },
          {
            "code" : "W0105050207",
            "display" : "CRYPTOSPORIDIUM"
          },
          {
            "code" : "W0105050208",
            "display" : "GIARDIA LAMBLIA"
          },
          {
            "code" : "W0105050209",
            "display" : "PLASMODIUM (MALARIA)"
          },
          {
            "code" : "W0105050210",
            "display" : "TRICHOMONAS"
          },
          {
            "code" : "W0105050299",
            "display" : "PARASITOLOGY - OTHER"
          }]
        },
        {
          "code" : "W01050503",
          "display" : "MISCELLANEOUS PARASITOLOGY - NA REAGENTS",
          "concept" : [{
            "code" : "W0105050301",
            "display" : "ENTAMOEBA HISTOLYTICA - NA REAGENTS"
          },
          {
            "code" : "W0105050302",
            "display" : "CHAGAS - NA REAGENTS"
          },
          {
            "code" : "W0105050303",
            "display" : "DISTOMATOSIS - NA REAGENTS"
          },
          {
            "code" : "W0105050304",
            "display" : "ECHINOCOCCUS - NA REAGENTS"
          },
          {
            "code" : "W0105050305",
            "display" : "LEISHMANIA - NA REAGENTS"
          },
          {
            "code" : "W0105050306",
            "display" : "SCHISTOSOMA - NA REAGENTS"
          },
          {
            "code" : "W0105050307",
            "display" : "CRYPTOSPORIDIUM - NA REAGENTS"
          },
          {
            "code" : "W0105050308",
            "display" : "GIARDIA LAMBLIA - NA REAGENTS"
          },
          {
            "code" : "W0105050309",
            "display" : "PLASMODIUM (MALARIA) - NA REAGENTS"
          },
          {
            "code" : "W0105050310",
            "display" : "TRICHOMONAS - NA REAGENTS"
          },
          {
            "code" : "W0105050399",
            "display" : "OTHER PARASITOLOGY - NA REAGENTS"
          }]
        }]
      },
      {
        "code" : "W010506",
        "display" : "MYCOLOGY (INFECT. IMMUNOLOGY/NAT)",
        "concept" : [{
          "code" : "W01050603",
          "display" : "MYCOLOGY IMMUNOASSAYS",
          "concept" : [{
            "code" : "W0105060301",
            "display" : "ASPERGILLUS"
          },
          {
            "code" : "W0105060302",
            "display" : "CANDIDA ALBICANS"
          },
          {
            "code" : "W0105060303",
            "display" : "CRYPTOCOCCUS"
          },
          {
            "code" : "W0105060399",
            "display" : "MYCOLOGY IMMUNOASSAYS - OTHER"
          }]
        },
        {
          "code" : "W01050604",
          "display" : "MYCOLOGY - NA REAGENTS",
          "concept" : [{
            "code" : "W0105060401",
            "display" : "ASPERGILLUS - NA REAGENTS"
          },
          {
            "code" : "W0105060402",
            "display" : "CANDIDA ALBICANS - NA REAGENTS"
          },
          {
            "code" : "W0105060403",
            "display" : "CRYPTOCOCCUS - NA REAGENTS"
          },
          {
            "code" : "W0105060404",
            "display" : "CANDIDA AURIS - NA REAGENTS"
          },
          {
            "code" : "W0105060405",
            "display" : "PNEUMOCYSTIS - NA REAGENTS"
          },
          {
            "code" : "W0105060499",
            "display" : "MYCOLOGY NA REAGENTS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010507",
        "display" : "MULTIPLE PARAMETERS - (INFECT. IMMUNOLOGY/NAT)",
        "concept" : [{
          "code" : "W01050702",
          "display" : "MULTIPLE BACTERIA / FUNGI PANELS",
          "concept" : [{
            "code" : "W0105070201",
            "display" : "GRAM+ - GRAM- - FUNGI - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070202",
            "display" : "SEPSIS (BACTERIA & FUNGI) - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070203",
            "display" : "GRAM+ - GRAM- - FUNGI - MULTIPLEX ASSAYS"
          }]
        },
        {
          "code" : "W01050703",
          "display" : "MULTIPLE VIRUSES PANELS",
          "concept" : [{
            "code" : "W0105070301",
            "display" : "HBV / HCV / HIV COMBINATION - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070302",
            "display" : "OTHER VIRUS COMBINATIONS - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070303",
            "display" : "IMMUNOSUPPRESSED / TRANSPLANTATION MONITORING - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070304",
            "display" : "INFLUENZA & PARA INFLUENZA / RESPIRATORY SYNCYTIAL VIRUS (RSV) / SARS-COV - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070399",
            "display" : "MULTIPLE VIRUSES - MULTIPLEX ASSAYS - OTHER"
          }]
        },
        {
          "code" : "W01050704",
          "display" : "MULTIPLE PARASITES PANELS"
        },
        {
          "code" : "W01050705",
          "display" : "MULTIPLE PANELS FOR INFECTIONS - VARIOUS",
          "concept" : [{
            "code" : "W0105070501",
            "display" : "STIS / STDS (C.TRACHOMATIS, N.GONORRHOEAE ,M.GENITALIUM, T.VAGINALIS, UREAPLASMA SPP….) COMBINATION - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070502",
            "display" : "OTHER MULTIPLE INFECTIOUS - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070503",
            "display" : "RESPIRATORY TRACT INFECTIONS - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070504",
            "display" : "GASTROINTESTINAL INFECTIONS - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070505",
            "display" : "MENINGITIS / ENCEPHALITIS INFECTIONS - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070506",
            "display" : "TROPICAL FEVER - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070507",
            "display" : "TICK BORNE DISEASES - MULTIPLEX NA REAGENTS"
          },
          {
            "code" : "W0105070599",
            "display" : "MULTIPLE INFECTIOUS - MULTIPLEX ASSAYS - OTHER"
          }]
        },
        {
          "code" : "W01050799",
          "display" : "MULTIPLE VIRUSES - OTHER"
        }]
      },
      {
        "code" : "W010508",
        "display" : "CONTROLS/STANDARDS/CALIBRATORS - (INFECT. IMMUNOLOGY/NAT)",
        "concept" : [{
          "code" : "W01050808",
          "display" : "CONTROLS - INFECT. IMMUNOLOGY",
          "concept" : [{
            "code" : "W0105080801",
            "display" : "BACTERIOLOGY CONTROLS - INF.IMM."
          },
          {
            "code" : "W0105080802",
            "display" : "HEPATITIS VIRUS CONTROLS - INF.IMM."
          },
          {
            "code" : "W0105080803",
            "display" : "RETROVIRUS CONTROLS - INF.IMM."
          },
          {
            "code" : "W0105080804",
            "display" : "OTHER VIROLOGY CONTROLS - INF.IMM."
          },
          {
            "code" : "W0105080805",
            "display" : "PARASITOLOGY CONTROLS - INF.IMM."
          },
          {
            "code" : "W0105080806",
            "display" : "MYCOLOGY CONTROLS - INF.IMM."
          },
          {
            "code" : "W0105080807",
            "display" : "MULTICONSTITUENT CONTROLS - INF.IMM."
          },
          {
            "code" : "W0105080808",
            "display" : "ALL INFECTIOUS DISEASES CONTROLS - NAT"
          },
          {
            "code" : "W0105080899",
            "display" : "CONTROLS - INF. IMMUNOLOGY - OTHER"
          }]
        },
        {
          "code" : "W01050809",
          "display" : "STANDARDS AND CALIBRATORS - INFECT. IMMUNOLOGY/NAT",
          "concept" : [{
            "code" : "W0105080901",
            "display" : "BACTERIOLOGY STANDARDS AND CALIBRATORS - INF.IMM."
          },
          {
            "code" : "W0105080902",
            "display" : "HEPATITIS VIRUS STANDARDS AND CALIBRATORS - INF.IMM."
          },
          {
            "code" : "W0105080903",
            "display" : "RETROVIRUS STANDARDS AND CALIBRATORS - INF.IMM."
          },
          {
            "code" : "W0105080904",
            "display" : "OTHER VIROLOGY STANDARDS AND CALIBRATORS - INF.IMM."
          },
          {
            "code" : "W0105080905",
            "display" : "PARASITOLOGY STANDARDS AND CALIBRATORS - INF.IMM."
          },
          {
            "code" : "W0105080906",
            "display" : "MYCOLOGY STANDARDS AND CALIBRATORS - INF.IMM."
          },
          {
            "code" : "W0105080907",
            "display" : "MULTICONSTITUENT STANDARDS AND CALIBRATORS - INF.IMM."
          },
          {
            "code" : "W0105080908",
            "display" : "STANDARDS AND CALIBRATORS FOR ALL INFECTIONS/ NAT"
          },
          {
            "code" : "W0105080999",
            "display" : "STANDARDS AND CALIBRATORS - INF. IMMUNOLOGY - OTHER"
          }]
        }]
      },
      {
        "code" : "W010509",
        "display" : "INFECTIOUS IMMUNOLOGY - RAPID TESTS & POINT OF CARE",
        "concept" : [{
          "code" : "W01050901",
          "display" : "BACTERIOLOGY - RT & POC",
          "concept" : [{
            "code" : "W0105090101",
            "display" : "CHLAMYDIA AG - RT & POC"
          },
          {
            "code" : "W0105090102",
            "display" : "H. PYLORI - RT & POC"
          },
          {
            "code" : "W0105090103",
            "display" : "STREP. A - RT & POC"
          },
          {
            "code" : "W0105090104",
            "display" : "STREP. B - RT & POC"
          },
          {
            "code" : "W0105090105",
            "display" : "SYPHILIS - RT & POC"
          },
          {
            "code" : "W0105090106",
            "display" : "CLOST. DIFF. INCL GDH AND/OR TOXIN A AND B - RT & POC"
          },
          {
            "code" : "W0105090107",
            "display" : "MENINGITIS CAUSITIVE AGENTS - RT & POC"
          },
          {
            "code" : "W0105090108",
            "display" : "LEGIONELLA - RT & POC"
          },
          {
            "code" : "W0105090109",
            "display" : "STREP. PNEUMONIAE - RT & POC"
          },
          {
            "code" : "W0105090199",
            "display" : "BACTERIOLOGY - RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01050902",
          "display" : "HEPATITIS VIRUSES - RT & POC",
          "concept" : [{
            "code" : "W0105090201",
            "display" : "HBSAG - RT & POC"
          },
          {
            "code" : "W0105090202",
            "display" : "HCV ANTIBODY -RT & POC"
          },
          {
            "code" : "W0105090299",
            "display" : "HEPATITIS VIRUSES - RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01050903",
          "display" : "RETROVIRUSES RT & POC",
          "concept" : [{
            "code" : "W0105090301",
            "display" : "HIV 1 - RT & POC"
          },
          {
            "code" : "W0105090302",
            "display" : "HIV 1 / 2 - RT & POC"
          },
          {
            "code" : "W0105090303",
            "display" : "HIV AG/AB COMBI - RT & POC"
          },
          {
            "code" : "W0105090399",
            "display" : "RETROVIRUSES - RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01050904",
          "display" : "PARASITOLOGY RT & POC",
          "concept" : [{
            "code" : "W0105090401",
            "display" : "PLASMODIUM (MALARIA) - RT & POC"
          },
          {
            "code" : "W0105090499",
            "display" : "PARASITES - RT & POC - OTHER"
          }]
        },
        {
          "code" : "W01050905",
          "display" : "CORONAVIRUS RT & POC",
          "concept" : [{
            "code" : "W0105090501",
            "display" : "CORONAVIRUS ANTIGEN (AG) - RT & POC"
          },
          {
            "code" : "W0105090502",
            "display" : "CORONAVIRUS ANTIBODY (AB) - RT & POC"
          },
          {
            "code" : "W0105090599",
            "display" : "OTHER CORONAVIRUS - RT & POC"
          }]
        },
        {
          "code" : "W01050906",
          "display" : "MULTIPLE PATHOGENS - RT & POC",
          "concept" : [{
            "code" : "W0105090601",
            "display" : "CORONAVIRUS / INFLUENZA - RT & POC"
          },
          {
            "code" : "W0105090699",
            "display" : "OTHER MULTIPLE PATHOGENS - RT & POC"
          }]
        },
        {
          "code" : "W01050940",
          "display" : "CONTROLS, STANDARDS AND CALIBRATORS INFECTIOUS IMMUNOLOGY/NAT - RT & POC",
          "concept" : [{
            "code" : "W0105094001",
            "display" : "CONTROLS INFECTIOUS IMMUNOLOGY/NAT - RT & POC"
          },
          {
            "code" : "W0105094002",
            "display" : "STANDARDS AND CALIBRATORS INFECTIOUS IMMUNOLOGY/NAT - RT & POC"
          }]
        },
        {
          "code" : "W01050990",
          "display" : "OTHER VIROLOGY RT & POC",
          "concept" : [{
            "code" : "W0105099001",
            "display" : "CMV - RT & POC"
          },
          {
            "code" : "W0105099002",
            "display" : "RSV - RT & POC"
          },
          {
            "code" : "W0105099003",
            "display" : "MONONUCLEOSIS (EBV) - RT & POC"
          },
          {
            "code" : "W0105099004",
            "display" : "INFLUENZA A AND /OR B - RT & POC"
          },
          {
            "code" : "W0105099006",
            "display" : "VZV - RT & POC"
          },
          {
            "code" : "W0105099007",
            "display" : "DENGUE - RT & POC"
          },
          {
            "code" : "W0105099008",
            "display" : "MONKEYPOX VIRUS / MPOX RT & POC"
          },
          {
            "code" : "W0105099099",
            "display" : "VIROLOGY - RT & POC - OTHER"
          }]
        }]
      },
      {
        "code" : "W010590",
        "display" : "OTHER INFECTIOUS IMMUNOLOGY/NAT",
        "concept" : [{
          "code" : "W01059001",
          "display" : "INFECTIOUS IMMUNOLOGY",
          "concept" : [{
            "code" : "W0105900101",
            "display" : "REAGENTS FOR DNA AND/OR RNA EXTRACTION AND PREPARATION: BACTERIA AND/OR VIRUS"
          },
          {
            "code" : "W0105900102",
            "display" : "REAGENTS FOR DNA AND/OR RNA AMPLIFICATION AND/OR DETECTION: BACTERIA AND/OR VIRUS"
          },
          {
            "code" : "W0105900103",
            "display" : "SUPPLEMENTAL NA REAGENTS"
          }]
        },
        {
          "code" : "W01059002",
          "display" : "OTHER INFECTIOUS IMMUNOLOGY REAGENTS",
          "concept" : [{
            "code" : "W0105900201",
            "display" : "BUFFERS (UNASSIGNABLE ), SUPPLEM. REAGENTS, ETC"
          },
          {
            "code" : "W0105900299",
            "display" : "INFECTIOUS IMMUNOLOGY - OTHER"
          }]
        }]
      }]
    },
    {
      "code" : "W0106",
      "display" : "GENETIC TESTING",
      "concept" : [{
        "code" : "W010601",
        "display" : "INBORN GENE OR CHROMOSOME ALTERATIONS",
        "concept" : [{
          "code" : "W01060101",
          "display" : "MONOGENETIC DISORDERS",
          "concept" : [{
            "code" : "W0106010101",
            "display" : "CYSTIC FIBROSIS"
          },
          {
            "code" : "W0106010102",
            "display" : "DUCHENNE MUSCULAR DYSTROPHY"
          },
          {
            "code" : "W0106010103",
            "display" : "FACTOR V LEIDEN"
          },
          {
            "code" : "W0106010104",
            "display" : "FRAGILE X SYNDROME"
          },
          {
            "code" : "W0106010105",
            "display" : "HAEMOCHROMATOSIS"
          },
          {
            "code" : "W0106010106",
            "display" : "HAEMOPHILIA"
          },
          {
            "code" : "W0106010107",
            "display" : "HUNTINGTON CHOREA"
          },
          {
            "code" : "W0106010108",
            "display" : "POLYCYSTIC KIDNEY DISEASE"
          },
          {
            "code" : "W0106010109",
            "display" : "SICKLE CELL ANEMIA"
          },
          {
            "code" : "W0106010110",
            "display" : "TAY SACHS DISEASE"
          },
          {
            "code" : "W0106010111",
            "display" : "THALASSAEMIA"
          },
          {
            "code" : "W0106010112",
            "display" : "FRIEDREICH'S ATAXIA"
          },
          {
            "code" : "W0106010113",
            "display" : "SPIHOCEREBELLAR ATAXINS TYPE 1,2,3,6,7,8"
          },
          {
            "code" : "W0106010114",
            "display" : "PROTHROMBIN MUTATION"
          },
          {
            "code" : "W0106010115",
            "display" : "COMBINED FACTOR II / FACTOR V LEIDEN"
          },
          {
            "code" : "W0106010116",
            "display" : "OTHER THROMBOPHILIA MUTATIONS (PROC, PROS1, MTHFR, SERPINC1, SEPINE1, F11, F12, F13, OTHER F2/F5)"
          },
          {
            "code" : "W0106010117",
            "display" : "OTHER HEMOPHILIA MUTATIONS (VWF, F8, F9)"
          },
          {
            "code" : "W0106010199",
            "display" : "MONOGENETIC DISORDERS TESTS - OTHER"
          }]
        },
        {
          "code" : "W01060102",
          "display" : "POLYGENETIC DISORDERS",
          "concept" : [{
            "code" : "W0106010201",
            "display" : "ALZHEIMER'S DISEASE"
          },
          {
            "code" : "W0106010202",
            "display" : "ASTHMA"
          },
          {
            "code" : "W0106010203",
            "display" : "ATHEROSCLEROSIS"
          },
          {
            "code" : "W0106010204",
            "display" : "DIABETES"
          },
          {
            "code" : "W0106010205",
            "display" : "HYPERTENSION"
          },
          {
            "code" : "W0106010206",
            "display" : "MULTIPLE SCLEROSIS"
          },
          {
            "code" : "W0106010207",
            "display" : "OSTEOPOROSIS"
          },
          {
            "code" : "W0106010299",
            "display" : "POLYGENETIC DISORDERS TESTS - OTHER"
          }]
        },
        {
          "code" : "W01060103",
          "display" : "CHROMOSOMAL DISORDERS",
          "concept" : [{
            "code" : "W0106010301",
            "display" : "DOWN'S SYNDROME"
          },
          {
            "code" : "W0106010302",
            "display" : "EDWARDS SYNDROME"
          },
          {
            "code" : "W0106010303",
            "display" : "KLINEFELTER SYNDROME"
          },
          {
            "code" : "W0106010304",
            "display" : "PÄTAU SYNDROME"
          },
          {
            "code" : "W0106010305",
            "display" : "TURNER SYNDROME"
          },
          {
            "code" : "W0106010399",
            "display" : "CHROMOSOMAL DISORDERS TESTS - OTHER"
          }]
        },
        {
          "code" : "W01060104",
          "display" : "POLYMORPHISMS",
          "concept" : [{
            "code" : "W0106010401",
            "display" : "HLA-TYPING"
          },
          {
            "code" : "W0106010499",
            "display" : "POLYMORPHISM TESTS - OTHER"
          }]
        }]
      },
      {
        "code" : "W010602",
        "display" : "ACQUIRED GENE OR CHROMOSOME ALTERATIONS",
        "concept" : [{
          "code" : "W01060201",
          "display" : "P53"
        },
        {
          "code" : "W01060202",
          "display" : "K-RAS"
        },
        {
          "code" : "W01060203",
          "display" : "BRCA 1+2"
        },
        {
          "code" : "W01060204",
          "display" : "RET"
        },
        {
          "code" : "W01060205",
          "display" : "C-MYC"
        },
        {
          "code" : "W01060206",
          "display" : "HNPCC"
        },
        {
          "code" : "W01060207",
          "display" : "APC"
        },
        {
          "code" : "W01060208",
          "display" : "T (9;22)"
        },
        {
          "code" : "W01060209",
          "display" : "T (8;14)"
        },
        {
          "code" : "W01060210",
          "display" : "T (14;18)"
        },
        {
          "code" : "W01060211",
          "display" : "INV (16)"
        },
        {
          "code" : "W01060212",
          "display" : "TELOMERASE"
        },
        {
          "code" : "W01060213",
          "display" : "HER-2/NEU (BREAST CANCER)"
        },
        {
          "code" : "W01060214",
          "display" : "COLORECTAL CANCER (MSI-H / DMMR)"
        },
        {
          "code" : "W01060215",
          "display" : "BLADDER CANCER DETECTION / MONITORING"
        },
        {
          "code" : "W01060299",
          "display" : "TESTS FOR ACQUIRED GENETIC OR CHROMOSOMAL ALTERATIONS - OTHER"
        }]
      },
      {
        "code" : "W010603",
        "display" : "MULTIPLE PARAMETERS - GENETIC TESTING",
        "concept" : [{
          "code" : "W01060301",
          "display" : "PHARMACOGENOMICS",
          "concept" : [{
            "code" : "W0106030101",
            "display" : "CYP 450 - INDIVIDUAL TEST"
          },
          {
            "code" : "W0106030102",
            "display" : "CYP 450 - MULTIPLE TESTS ON MICRO-ARRAYS"
          },
          {
            "code" : "W0106030103",
            "display" : "CYP2C9"
          },
          {
            "code" : "W0106030104",
            "display" : "CYP2C19"
          },
          {
            "code" : "W0106030105",
            "display" : "VKORC1"
          }]
        }]
      },
      {
        "code" : "W010699",
        "display" : "GENETIC TESTS - OTHER"
      }]
    }]
  },
  {
    "code" : "W02",
    "display" : "IVD INSTRUMENTS",
    "concept" : [{
      "code" : "W0201",
      "display" : "CHEMISTRY / IMMUNOCHEMISTRY INSTRUMENTS",
      "concept" : [{
        "code" : "W020101",
        "display" : "CHEMISTRY INSTRUMENTS",
        "concept" : [{
          "code" : "W02010101",
          "display" : "CHEMISTRY ANALYSERS",
          "concept" : [{
            "code" : "W0201010101",
            "display" : "CHEMISTRY ANALYSERS - LOW ROUTINE (Random access without ISE mode test/h <= 400)"
          },
          {
            "code" : "W0201010102",
            "display" : "CHEMISTRY ANALYSERS - MODERATE ROUTINE (Random access without ISE mode test/h > 400 and <= 800)"
          },
          {
            "code" : "W0201010103",
            "display" : "CHEMISTRY ANALYSERS - MODERATE TO HIGH ROUTINE (Random access without ISE mode test/h > 800 and <= 1.200)"
          },
          {
            "code" : "W0201010104",
            "display" : "CHEMISTRY ANALYSERS - HIGH ROUTINE (Random access without ISE mode test/h > 1.200)"
          },
          {
            "code" : "W0201010105",
            "display" : "CHEMISTRY ANALYSERS - LOW ROUTINE (with ISE mode test/h <= 400)"
          },
          {
            "code" : "W0201010106",
            "display" : "CHEMISTRY ANALYSERS - MODERATE ROUTINE (with ISE mode test/h > 400 and <= 800)"
          },
          {
            "code" : "W0201010107",
            "display" : "CHEMISTRY ANALYSERS - MODERATE TO HIGH ROUTINE (with ISE mode test/h > 800 and <= 1.200)"
          },
          {
            "code" : "W0201010108",
            "display" : "CHEMISTRY ANALYSERS - HIGH ROUTINE (with ISE mode test/h > 1.200)"
          },
          {
            "code" : "W0201010180",
            "display" : "CHEMISTRY ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0201010182",
            "display" : "CHEMISTRY ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0201010185",
            "display" : "CHEMISTRY ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0201010192",
            "display" : "CHEMISTRY ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02010102",
          "display" : "LIMITED PANEL CHEMISTRY ANALYSERS",
          "concept" : [{
            "code" : "W0201010201",
            "display" : "URINE ANALYSERS",
            "concept" : [{
              "code" : "W020101020101",
              "display" : "URINE STRIP READERS"
            },
            {
              "code" : "W020101020102",
              "display" : "SEMI-AUTOMATED URINE ANALYSERS"
            },
            {
              "code" : "W020101020103",
              "display" : "AUTOMATED URINE ANALYSERS"
            },
            {
              "code" : "W020101020180",
              "display" : "AUTOMATED URINE ANALYSERS - HARDWARE ACCESSORIES"
            },
            {
              "code" : "W020101020182",
              "display" : "AUTOMATED URINE ANALYSERS - SOFTWARE ACCESSORIES"
            },
            {
              "code" : "W020101020185",
              "display" : "AUTOMATED URINE ANALYSERS - CONSUMABLES"
            },
            {
              "code" : "W020101020192",
              "display" : "AUTOMATED URINE ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
            }]
          },
          {
            "code" : "W0201010202",
            "display" : "URINARY SEDIMENT DEVICES"
          },
          {
            "code" : "W0201010203",
            "display" : "BLOOD-AMMONIA CHECKERS"
          },
          {
            "code" : "W0201010280",
            "display" : "LIMITED PANEL CHEMISTRY ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0201010282",
            "display" : "LIMITED PANEL CHEMISTRY ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0201010285",
            "display" : "LIMITED PANEL CHEMISTRY ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0201010292",
            "display" : "LIMITED PANEL CHEMISTRY ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "W0201010299",
            "display" : "LIMITED PANEL CHEMISTRY ANALYSERS - OTHER"
          }]
        },
        {
          "code" : "W02010199",
          "display" : "CHEMISTRY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "W020102",
        "display" : "IMMUNOCHEMISTRY INSTRUMENTS",
        "concept" : [{
          "code" : "W02010201",
          "display" : "AUTOMATED IMMUNOCHEMISTRY ANALYSERS",
          "concept" : [{
            "code" : "W0201020101",
            "display" : "AUTOMATED IMMUNOCHEMISTRY ANALYSERS - LOW ROUTINE (Throughput <= 100 test/h)"
          },
          {
            "code" : "W0201020102",
            "display" : "AUTOMATED IMMUNOCHEMISTRY ANALYSERS - MODERATE ROUTINE (Throughput > 100 and <= 250 test/h)"
          },
          {
            "code" : "W0201020103",
            "display" : "AUTOMATED IMMUNOCHEMISTRY ANALYSERS - MODERATE TO HIGH ROUTINE (Throughput > 250 and <= 700 test/h)"
          },
          {
            "code" : "W0201020104",
            "display" : "AUTOMATED IMMUNOCHEMISTRY ANALYSERS - HIGH ROUTINE (Throughput > 700 test/h)"
          },
          {
            "code" : "W0201020180",
            "display" : "AUTOMATED IMMUNOCHEMISTRY ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0201020182",
            "display" : "AUTOMATED IMMUNOCHEMISTRY ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0201020185",
            "display" : "AUTOMATED IMMUNOCHEMISTRY ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0201020192",
            "display" : "AUTOMATED IMMUNOCHEMISTRY ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02010202",
          "display" : "LIMITED PANEL IMMUNOCHEMISTRY ANALYSERS",
          "concept" : [{
            "code" : "W0201020201",
            "display" : "IMMUNOCHEMISTRY READERS"
          },
          {
            "code" : "W0201020202",
            "display" : "BETA PARTICLES COUNTERS"
          },
          {
            "code" : "W0201020203",
            "display" : "GAMMA COUNTERS"
          },
          {
            "code" : "W0201020204",
            "display" : "NEPHELOMETERS"
          },
          {
            "code" : "W0201020205",
            "display" : "TURBIDIMETERS"
          },
          {
            "code" : "W0201020280",
            "display" : "LIMITED PANEL IMMUNOCHEMISTRY ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0201020282",
            "display" : "LIMITED PANEL IMMUNOCHEMISTRY ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0201020285",
            "display" : "LIMITED PANEL IMMUNOCHEMISTRY ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0201020292",
            "display" : "LIMITED PANEL IMMUNOCHEMISTRY ANALYSERS - IVD MEDICAL DEVICE SOFTWAE"
          },
          {
            "code" : "W0201020299",
            "display" : "LIMITED PANEL IMMUNOCHEMISTRY ANALYSERS - OTHER"
          }]
        },
        {
          "code" : "W02010299",
          "display" : "IMMUNOCHEMISTRY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "W020103",
        "display" : "INTEGRATED / MODULAR CHEMISTRY / IMMUNOCHEMISTRY INSTRUMENTS",
        "concept" : [{
          "code" : "W02010301",
          "display" : "MIXED PANEL MULTIPARAMETER ANALYSERS",
          "concept" : [{
            "code" : "W0201030101",
            "display" : "MIXED PANEL MULTIPARAMETER ANALYSERS - LOW ROUTINE (Throughput <= 800 test/h)"
          },
          {
            "code" : "W0201030102",
            "display" : "MIXED PANEL MULTIPARAMETER ANALYSERS - MODERATE ROUTINE (Throughput > 800 and <= 2000 test/h)"
          },
          {
            "code" : "W0201030103",
            "display" : "MIXED PANEL MULTIPARAMETER ANALYSERS - HIGH ROUTINE (Throughput > 2000 test/h)"
          },
          {
            "code" : "W0201030180",
            "display" : "MIXED PANEL MULTIPARAMETER ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0201030182",
            "display" : "MIXED PANEL MULTIPARAMETER ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0201030185",
            "display" : "MIXED PANEL MULTIPARAMETER ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0201030192",
            "display" : "MIXED PANEL MULTIPARAMETER ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02010399",
          "display" : "INTEGRATED / MODULAR CHEMISTRY / IMMUNOCHEMISTRY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "W020104",
        "display" : "BLOOD GAS ANALYSIS / ELECTROLYTE INSTRUMENTS",
        "concept" : [{
          "code" : "W02010401",
          "display" : "BLOOD GAS ANALYSERS",
          "concept" : [{
            "code" : "W0201040101",
            "display" : "BLOOD GAS ANALYSERS - WITH CLASSIC PROFILE (pH, pO2, pCO2, HCT + electrolytes)"
          },
          {
            "code" : "W0201040102",
            "display" : "BLOOD GAS ANALYSERS - WITH ADDITIONAL PARAMETERS (pH, pO2, pCO2, Hct + metabolites + electrolytes, CO-oximeter parameters and coagulation parameters)"
          },
          {
            "code" : "W0201040180",
            "display" : "BLOOD GAS ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0201040182",
            "display" : "BLOOD GAS ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0201040185",
            "display" : "BLOOD GAS ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0201040192",
            "display" : "BLOOD GAS ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02010402",
          "display" : "LIMITED PANEL ANALYSERS FOR BLOOD GAS ANALYSIS / ELECTROLYTES",
          "concept" : [{
            "code" : "W0201040201",
            "display" : "ION SELECTIVE ELECTROLYTE ANALYSERS"
          },
          {
            "code" : "W0201040202",
            "display" : "FLAME PHOTOMETERS"
          },
          {
            "code" : "W0201040203",
            "display" : "CHLORIDE ANALYSERS"
          },
          {
            "code" : "W0201040280",
            "display" : "LIMITED PANEL ANALYSERS FOR BLOOD GAS ANALYSIS / ELECTROLYTE - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0201040282",
            "display" : "LIMITED PANEL ANALYSERS FOR BLOOD GAS ANALYSIS / ELECTROLYTES - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0201040285",
            "display" : "LIMITED PANEL ANALYSERS FOR BLOOD GAS ANALYSIS / ELECTROLYTES - CONSUMABLES"
          },
          {
            "code" : "W0201040292",
            "display" : "LIMITED PANEL ANALYSERS FOR BLOOD GAS ANALYSIS / ELECTROLYTES - IVD MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "W0201040299",
            "display" : "LIMITED PANEL ANALYSERS FOR BLOOD GAS ANALYSIS / ELECTROLYTES - OTHER"
          }]
        },
        {
          "code" : "W02010499",
          "display" : "BLOOD GAS ANALYSIS / ELECTROLYTE INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "W020105",
        "display" : "ELECTROPHORESIS / CHROMATOGRAPHY INSTRUMENTS",
        "concept" : [{
          "code" : "W02010501",
          "display" : "ELECTROPHORESIS INSTRUMENTS",
          "concept" : [{
            "code" : "W0201050101",
            "display" : "AUTOMATED ELECTROPHORESIS SYSTEMS"
          },
          {
            "code" : "W0201050102",
            "display" : "LIMITED PANEL ELECTROPHORESIS ANALYSERS",
            "concept" : [{
              "code" : "W020105010201",
              "display" : "SEMI-.AUTOMATED ELECTROPHORESIS SYSTEMS"
            },
            {
              "code" : "W020105010202",
              "display" : "CAPILLARY ELECTROPHORESIS SYSTEMS"
            },
            {
              "code" : "W020105010203",
              "display" : "DENSITOMETERS"
            },
            {
              "code" : "W020105010280",
              "display" : "LIMITED PANEL ELECTROPHORESIS ANALYSERS - HARDWARE ACCESSORIES"
            },
            {
              "code" : "W020105010282",
              "display" : "LIMITED PANEL ELECTROPHORESIS ANALYSERS - SOFTWARE ACCESSORIES"
            },
            {
              "code" : "W020105010285",
              "display" : "LIMITED PANEL ELECTROPHORESIS ANALYSERS - CONSUMABLES"
            },
            {
              "code" : "W020105010292",
              "display" : "LIMITED PANEL ELECTROPHORESIS ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
            },
            {
              "code" : "W020105010299",
              "display" : "LIMITED PANEL ELECTROPHORESIS ANALYSERS - OTHER"
            }]
          },
          {
            "code" : "W0201050190",
            "display" : "VARIOUS ELECTROPHORESIS INTRUMENTS",
            "concept" : [{
              "code" : "W020105019001",
              "display" : "ELECTROPHORETIC GEL PROCESSORS"
            },
            {
              "code" : "W020105019002",
              "display" : "GEL DOCUMENTATION SYSTEMS"
            },
            {
              "code" : "W020105019080",
              "display" : "VARIOUS ELECTROPHORESIS INTRUMENTS - HARDWARE ACCESSORIES"
            },
            {
              "code" : "W020105019082",
              "display" : "VARIOUS ELECTROPHORESIS INTRUMENTS - SOFTWARE ACCESSORIES"
            },
            {
              "code" : "W020105019085",
              "display" : "VARIOUS ELECTROPHORESIS INTRUMENTS - CONSUMABLES"
            },
            {
              "code" : "W020105019092",
              "display" : "VARIOUS ELECTROPHORESIS INTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
            },
            {
              "code" : "W020105019099",
              "display" : "VARIOUS ELECTROPHORESIS INTRUMENTS - OTHER"
            }]
          }]
        },
        {
          "code" : "W02010502",
          "display" : "CHROMATOGRAPHY INSTRUMENTS (HPLC)",
          "concept" : [{
            "code" : "W0201050201",
            "display" : "HIGH PERFORMANCE LIQUID CHROMATOGRAPHY SYSTEMS"
          },
          {
            "code" : "W0201050280",
            "display" : "HIGH PERFORMANCE LIQUID CHROMATOGRAPHY SYSTEMS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0201050282",
            "display" : "HIGH PERFORMANCE LIQUID CHROMATOGRAPHY SYSTEMS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0201050285",
            "display" : "HIGH PERFORMANCE LIQUID CHROMATOGRAPHY SYSTEMS - CONSUMABLES"
          },
          {
            "code" : "W0201050292",
            "display" : "HIGH PERFORMANCE LIQUID CHROMATOGRAPHY SYSTEMS - IVD MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "W0201050299",
            "display" : "HIGH PERFORMANCE LIQUID CHROMATOGRAPHY SYSTEMS - OTHER"
          }]
        }]
      },
      {
        "code" : "W020106",
        "display" : "CHEMISTRY / IMMUNOCHEMISTRY RAPID TESTS + POC TESTS",
        "concept" : [{
          "code" : "W02010601",
          "display" : "DIABETES MONITORING",
          "concept" : [{
            "code" : "W0201060101",
            "display" : "GLYCOSILATED HEMOGLOBIN DEVICEs"
          },
          {
            "code" : "W0201060102",
            "display" : "BLOOD GLUCOSE METERS"
          },
          {
            "code" : "W0201060190",
            "display" : "VARIOUS DIABETES MONITORING INSTRUMENTS",
            "concept" : [{
              "code" : "W020106019080",
              "display" : "VARIOUS DIABETES MONITORING INSTRUMENTS - HARDWARE ACCESSORIES"
            },
            {
              "code" : "W020106019082",
              "display" : "VARIOUS DIABETES MONITORING INSTRUMENTS - SOFTWARE ACCESSORIES"
            },
            {
              "code" : "W020106019085",
              "display" : "VARIOUS DIABETES MONITORING INSTRUMENTS - CONSUMABLES"
            },
            {
              "code" : "W020106019092",
              "display" : "VARIOUS DIABETES MONITORING INSTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
            },
            {
              "code" : "W020106019099",
              "display" : "VARIOUS DIABETES MONITORING INSTRUMENTS - OTHER"
            }]
          }]
        },
        {
          "code" : "W02010690",
          "display" : "VARIOUS RAPID TEST CHEMISTRY / IMMUNOCHEMISTRY INSTRUMENTS ('POINT OF CARE' AND/OR EMERGENCY)",
          "concept" : [{
            "code" : "W0201069001",
            "display" : "CARDIAC MARKER PORTABLE ANALYSERS"
          },
          {
            "code" : "W0201069002",
            "display" : "BLOOD GAS PORTABLE ANALYSERS"
          },
          {
            "code" : "W0201069003",
            "display" : "ALCOHOL ANALYSERS"
          },
          {
            "code" : "W0201069004",
            "display" : "BILIRUBINOMETERS"
          },
          {
            "code" : "W0201069005",
            "display" : "HEMOXIMETERS"
          },
          {
            "code" : "W0201069080",
            "display" : "VARIOUS RAPID TEST CHEMISTRY / IMMUNOCHEMISTRY INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0201069082",
            "display" : "VARIOUS RAPID TEST CHEMISTRY / IMMUNOCHEMISTRY INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0201069085",
            "display" : "VARIOUS RAPID TEST CHEMISTRY / IMMUNOCHEMISTRY INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "W0201069092",
            "display" : "VARIOUS RAPID TEST CHEMISTRY / IMMUNOCHEMISTRY INSTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "W0201069099",
            "display" : "VARIOUS RAPID TEST CHEMISTRY / IMMUNOCHEMISTRY INSTRUMENTS - OTHER"
          }]
        }]
      },
      {
        "code" : "W020107",
        "display" : "URINALYSIS (UR) - LABORATORY ANALYSERS",
        "concept" : [{
          "code" : "W02010701",
          "display" : "URINALYSIS (UR) - LABORATORY ANALYSERS- INSTRUMENTS"
        },
        {
          "code" : "W02010780",
          "display" : "URINALYSIS (UR) - LABORATORY ANALYSERS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02010782",
          "display" : "URINALYSIS (UR) - LABORATORY ANALYSERS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02010785",
          "display" : "URINALYSIS (UR) - LABORATORY ANALYSERS - CONSUMABLES"
        },
        {
          "code" : "W02010792",
          "display" : "URINALYSIS (UR) - LABORATORY ANALYSERS- IVD MEDICAL DEVICE SOFTWARE"
        }]
      }]
    },
    {
      "code" : "W0202",
      "display" : "HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS",
      "concept" : [{
        "code" : "W020201",
        "display" : "HAEMATOLOGY / CELL COUNTING",
        "concept" : [{
          "code" : "W02020101",
          "display" : "AUTOMATED 5 PART DIFFERENTIAL HEMATOLOGY ANALYSERS",
          "concept" : [{
            "code" : "W0202010101",
            "display" : "AUTOMATED WHOLE BLOOD HEMATOLOGY ANALYSERS - LOW ROUTINE (Throughput <= 100 samples/hr)"
          },
          {
            "code" : "W0202010102",
            "display" : "AUTOMATED WHOLE BLOOD HEMATOLOGY ANALYSERS - MODERATE ROUTINE (Throughput > 100 and <= 120 samples/hr)"
          },
          {
            "code" : "W0202010103",
            "display" : "AUTOMATED WHOLE BLOOD HEMATOLOGY ANALYSERS - HIGH ROUTINE (Throughput > 120 samples/hr)"
          },
          {
            "code" : "W0202010180",
            "display" : "AUTOMATED WHOLE BLOOD HEMATOLOGY ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0202010182",
            "display" : "AUTOMATED WHOLE BLOOD HEMATOLOGY ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0202010185",
            "display" : "AUTOMATED WHOLE BLOOD HEMATOLOGY ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0202010192",
            "display" : "AUTOMATED WHOLE BLOOD HEMATOLOGY ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02020102",
          "display" : "LIMITED PANEL CELL COUNTING ANALYSERS",
          "concept" : [{
            "code" : "W0202010201",
            "display" : "AUTOMATED 3 PART HEMATOLOGY ANALYSERS"
          },
          {
            "code" : "W0202010202",
            "display" : "SEMI-AUTOMATED HEMATOLOGY ANALYSERS"
          },
          {
            "code" : "W0202010280",
            "display" : "LIMITED PANEL CELL COUNTING ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0202010282",
            "display" : "LIMITED PANEL CELL COUNTING ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0202010285",
            "display" : "LIMITED PANEL CELL COUNTING ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0202010292",
            "display" : "LIMITED PANEL CELL COUNTING ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "W0202010299",
            "display" : "LIMITED PANEL CELL COUNTING ANALYSERS - OTHER"
          }]
        },
        {
          "code" : "W02020199",
          "display" : "CELL COUNTING INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "W020202",
        "display" : "HEMOSTASIS",
        "concept" : [{
          "code" : "W02020201",
          "display" : "COAGULOMETERS",
          "concept" : [{
            "code" : "W0202020101",
            "display" : "SEMI-AUTOMATED COAGULOMETERS"
          },
          {
            "code" : "W0202020102",
            "display" : "AUTOMATED COAGULOMETERS"
          },
          {
            "code" : "W0202020180",
            "display" : "COAGULOMETERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0202020182",
            "display" : "COAGULOMETERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0202020185",
            "display" : "COAGULOMETERS - CONSUMABLES"
          },
          {
            "code" : "W0202020192",
            "display" : "COAGULOMETERS - IVD MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02020290",
          "display" : "VARIOUS HEMOSTASIS INSTRUMENTS",
          "concept" : [{
            "code" : "W0202029001",
            "display" : "THROMBELASTOGRAPHS"
          },
          {
            "code" : "W0202029080",
            "display" : "VARIOUS HEMOSTASIS INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0202029082",
            "display" : "VARIOUS HEMOSTASIS INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0202029085",
            "display" : "VARIOUS HEMOSTASIS INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "W0202029092",
            "display" : "VARIOUS HEMOSTASIS INSTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "W0202029099",
            "display" : "VARIOUS HEMOSTASIS INSTRUMENTS - OTHER"
          }]
        }]
      },
      {
        "code" : "W020203",
        "display" : "BLOOD GROUPING INSTRUMENTS",
        "concept" : [{
          "code" : "W02020301",
          "display" : "BLOOD GROUPING ANALYSERS",
          "concept" : [{
            "code" : "W0202030101",
            "display" : "BLOOD GROUPING ANALYSERS - MANUAL OR SEMI-AUTOMATED"
          },
          {
            "code" : "W0202030102",
            "display" : "AUTOMATED BLOOD GROUPING ANALYSERS"
          },
          {
            "code" : "W0202030180",
            "display" : "BLOOD GROUPING ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0202030182",
            "display" : "BLOOD GROUPING ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0202030185",
            "display" : "BLOOD GROUPING ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0202030192",
            "display" : "BLOOD GROUPING ANALYSERS - MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02020302",
          "display" : "LIMITED PANEL BLOOD GROUPING ANALYSERS",
          "concept" : [{
            "code" : "W0202030201",
            "display" : "IMMUNOHEMATOLOGY READERS"
          },
          {
            "code" : "W0202030202",
            "display" : "TRANSILLUMINATORS"
          },
          {
            "code" : "W0202030203",
            "display" : "LIMITED PANEL BLOOD GROUPING ANALYSERS - OTHER"
          },
          {
            "code" : "W0202030280",
            "display" : "LIMITED PANEL BLOOD GROUPING ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0202030282",
            "display" : "LIMITED PANEL BLOOD GROUPING ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0202030285",
            "display" : "LIMITED PANEL BLOOD GROUPING ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0202030292",
            "display" : "LIMITED PANEL BLOOD GROUPING ANALYSERS - IVD MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02020399",
          "display" : "BLOOD GROUPING INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "W020204",
        "display" : "FLOW CYTOMETRY INSTRUMENTS",
        "concept" : [{
          "code" : "W02020401",
          "display" : "CYTOFLOWMETERS",
          "concept" : [{
            "code" : "W0202040101",
            "display" : "CYTOFLOWMETERS - LOW ROUTINE"
          },
          {
            "code" : "W0202040102",
            "display" : "CYTOFLOWMETERS - MODERATE ROUTINE"
          },
          {
            "code" : "W0202040103",
            "display" : "CYTOFLOWMETERS - HIGH ROUTINE"
          },
          {
            "code" : "W0202040180",
            "display" : "CYTOFLOWMETERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0202040182",
            "display" : "CYTOFLOWMETERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0202040185",
            "display" : "CYTOFLOWMETERS - CONSUMABLES"
          },
          {
            "code" : "W0202040192",
            "display" : "CYTOFLOWMETERS - IVD MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02020499",
          "display" : "FLOW CYTOMETRY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "W020205",
        "display" : "HISTOLOGY / CYTOLOGY",
        "concept" : [{
          "code" : "W02020501",
          "display" : "HISTOLOGICAL SAMPLES ANALYSERS"
        },
        {
          "code" : "W02020502",
          "display" : "CERVICAL SCREENING SYSTEMS"
        },
        {
          "code" : "W02020503",
          "display" : "LABORATORY INSTRUMENTS FOR MICROSCOPIC INVESTIGATIONS",
          "concept" : [{
            "code" : "W0202050301",
            "display" : "ELECTRON MICROSCOPES"
          },
          {
            "code" : "W0202050302",
            "display" : "LASER SCANNING MICROSCOPES"
          },
          {
            "code" : "W0202050303",
            "display" : "OPTICAL LABORATORY MICROSCOPES"
          },
          {
            "code" : "W0202050304",
            "display" : "DIGITAL LABORATORY MICROSCOPES"
          },
          {
            "code" : "W0202050380",
            "display" : "LABORATORY INSTRUMENTS FOR MICROSCOPIC INVESTIGATIONS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0202050382",
            "display" : "LABORATORY INSTRUMENTS FOR MICROSCOPIC INVESTIGATIONS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0202050385",
            "display" : "LABORATORY INSTRUMENTS FOR MICROSCOPIC INVESTIGATIONS - CONSUMABLES"
          },
          {
            "code" : "W0202050392",
            "display" : "LABORATORY INSTRUMENTS FOR MICROSCOPIC INVESTIGATIONS - IVD MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02020590",
          "display" : "VARIOUS PROCESSING INSTRUMENTS FOR HYSTOLOGY / CYTOLOGY",
          "concept" : [{
            "code" : "W0202059001",
            "display" : "IMMUNOHISTOCHEMISTRY PROCESSORS"
          },
          {
            "code" : "W0202059002",
            "display" : "AUTOMATED SLIDE STAINERS"
          },
          {
            "code" : "W0202059003",
            "display" : "CRYOSTAT MICROTOMES"
          },
          {
            "code" : "W0202059004",
            "display" : "TISSUE EMBEDDING PROCESSORS"
          },
          {
            "code" : "W0202059005",
            "display" : "MICROTOMES"
          },
          {
            "code" : "W0202059006",
            "display" : "LASER MICRODISSECTION SYSTEMS"
          },
          {
            "code" : "W0202059007",
            "display" : "MICROMANIPULATORS"
          },
          {
            "code" : "W0202059008",
            "display" : "AUTOMATED COVERSLIPPERS"
          },
          {
            "code" : "W0202059009",
            "display" : "PARAFFIN DISPENSERS"
          },
          {
            "code" : "W0202059010",
            "display" : "TISSUE PROCESSORS"
          },
          {
            "code" : "W0202059011",
            "display" : "SAMPLE PREPARATION UNITS FOR CHROMOSOMIC ANALYSIS"
          },
          {
            "code" : "W0202059012",
            "display" : "COOLING PARAFFIN PLATES"
          },
          {
            "code" : "W0202059013",
            "display" : "HEATED FORCEPS"
          },
          {
            "code" : "W0202059014",
            "display" : "SOLVENT DISTILLERS"
          },
          {
            "code" : "W0202059015",
            "display" : "CUTTING STATION FOR HISTOLOGICAL SAMPLES"
          },
          {
            "code" : "W0202059016",
            "display" : "AUTOMATED DEWAXING SYSTEMS"
          },
          {
            "code" : "W0202059017",
            "display" : "CASSETTE / SLIDE PRINTERS"
          },
          {
            "code" : "W0202059080",
            "display" : "VARIOUS PROCESSING INSTRUMENTS FOR HYSTOLOGY / CYTOLOGY - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0202059082",
            "display" : "VARIOUS PROCESSING INSTRUMENTS FOR HYSTOLOGY / CYTOLOGY - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0202059085",
            "display" : "VARIOUS PROCESSING INSTRUMENTS FOR HYSTOLOGY / CYTOLOGY - CONSUMABLES"
          },
          {
            "code" : "W0202059092",
            "display" : "VARIOUS PROCESSING INSTRUMENTS FOR HYSTOLOGY / CYTOLOGY - IVD MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "W0202059099",
            "display" : "VARIOUS PROCESSING INSTRUMENTS FOR HYSTOLOGY / CYTOLOGY - OTHER"
          }]
        }]
      },
      {
        "code" : "W020206",
        "display" : "RAPID TEST HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS",
        "concept" : [{
          "code" : "W02020601",
          "display" : "RAPID TEST CELL COUNT INSTRUMENTS"
        },
        {
          "code" : "W02020602",
          "display" : "RAPID TEST HEMOSTASIS INSTRUMENTS"
        },
        {
          "code" : "W02020680",
          "display" : "RAPID TEST HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02020682",
          "display" : "RAPID TEST HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02020685",
          "display" : "RAPID TEST HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "W02020692",
          "display" : "RAPID TEST HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02020699",
          "display" : "RAPID TEST HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "W020290",
        "display" : "VARIOUS HEMATOLOGY / HISTOLOGY /CYTOLOGY INSTRUMENTS",
        "concept" : [{
          "code" : "W02029001",
          "display" : "ERYTHROCYTE SEDIMENTATION RATE DEVICES"
        },
        {
          "code" : "W02029002",
          "display" : "BLOOD PHOTODYNAMIC TREATMENT UNITS"
        },
        {
          "code" : "W02029003",
          "display" : "AUTOMATED BLOOD COMPONENT EXTRACTORS"
        },
        {
          "code" : "W02029005",
          "display" : "CYTOFLUOROMETRIC PREPARATION UNITS"
        },
        {
          "code" : "W02029006",
          "display" : "APHERESIS UNITS"
        },
        {
          "code" : "W02029007",
          "display" : "IMMUNOMAGNETIC CELLULAR SEPARATION SYSTEMS"
        },
        {
          "code" : "W02029008",
          "display" : "TUBING WELDERS"
        },
        {
          "code" : "W02029009",
          "display" : "BLOOD BAG PRESSES"
        },
        {
          "code" : "W02029010",
          "display" : "BAG SEALERS"
        },
        {
          "code" : "W02029080",
          "display" : "VARIOUS HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02029082",
          "display" : "VARIOUS HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02029085",
          "display" : "VARIOUS HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "W02029092",
          "display" : "VARIOUS HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02029099",
          "display" : "VARIOUS HEMATOLOGY / HISTOLOGY / CYTOLOGY INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "W0203",
      "display" : "MICROBIOLOGY INSTRUMENTS (CULTURES)",
      "concept" : [{
        "code" : "W020301",
        "display" : "MICROBIOLOGY SUSCEPTIBILITY / IDENTIFICATION",
        "concept" : [{
          "code" : "W02030101",
          "display" : "ANTIBIOTIC SUSCEPTIBILITY ANALYSERS",
          "concept" : [{
            "code" : "W0203010180",
            "display" : "ANTIBIOTIC SUSCEPTIBILITY ANALYSERS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "W0203010182",
            "display" : "ANTIBIOTIC SUSCEPTIBILITY ANALYSERS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "W0203010185",
            "display" : "ANTIBIOTIC SUSCEPTIBILITY ANALYSERS - CONSUMABLES"
          },
          {
            "code" : "W0203010192",
            "display" : "ANTIBIOTIC SUSCEPTIBILITY ANALYSERS - MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "W02030199",
          "display" : "ANTIBIOTIC SUSCEPTIBILITY ANALYSERS - OTHER"
        }]
      },
      {
        "code" : "W020302",
        "display" : "BLOOD CULTURES AND MYCOBACTERIA",
        "concept" : [{
          "code" : "W02030201",
          "display" : "AUTOMATED BLOOD CULTURE ANALYSERS"
        },
        {
          "code" : "W02030299",
          "display" : "INSTRUMENTS FOR BLOOD CULTURES AND MYCOBACTERIA - OTHER"
        }]
      },
      {
        "code" : "W020303",
        "display" : "MASS - SPECTROMETRY SYSTEM"
      },
      {
        "code" : "W020304",
        "display" : "MICROBIOLOGY GRAM STAINER"
      },
      {
        "code" : "W020305",
        "display" : "PLATES STREAKER"
      },
      {
        "code" : "W020306",
        "display" : "URINARY SCREENING SYSTEM"
      },
      {
        "code" : "W020390",
        "display" : "VARIOUS MICROBIOLOGY INSTRUMENTS",
        "concept" : [{
          "code" : "W02039001",
          "display" : "COLONY COUNTERS"
        },
        {
          "code" : "W02039002",
          "display" : "CARBON DIOXIDE INCUBATORS"
        },
        {
          "code" : "W02039003",
          "display" : "PETRI DISH FILLERS"
        },
        {
          "code" : "W02039004",
          "display" : "AUTOMATED SLIDE PREPARATION UNITS"
        },
        {
          "code" : "W02039005",
          "display" : "CULTURE MEDIUM PREPARATION UNITS"
        },
        {
          "code" : "W02039006",
          "display" : "DNA THERMAL CYCLERS"
        },
        {
          "code" : "W02039080",
          "display" : "VARIOUS MICROBIOLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02039082",
          "display" : "VARIOUS MICROBIOLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02039085",
          "display" : "VARIOUS MICROBIOLOGY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "W02039092",
          "display" : "VARIOUS MICROBIOLOGY INSTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02039099",
          "display" : "VARIOUS MICROBIOLOGY INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "W0204",
      "display" : "INFECTIOUS IMMUNOLOGY INSTRUMENTS"
    },
    {
      "code" : "W0205",
      "display" : "NUCLEIC ACID TESTING INSTRUMENTS",
      "concept" : [{
        "code" : "W020501",
        "display" : "NUCLEIC ACID TESTING INSTRUMENTS EXCEPT MICRO-ARRAYS",
        "concept" : [{
          "code" : "W02050101",
          "display" : "NUCLEIC ACID HYBRIDIZATION UNITS"
        },
        {
          "code" : "W02050102",
          "display" : "EUKARYOTIC CELL BIOREACTORS"
        },
        {
          "code" : "W02050103",
          "display" : "BLOTTING SYSTEMS"
        },
        {
          "code" : "W02050104",
          "display" : "KARYOTYPE PROCESSING AUTOMATED SYSTEMS"
        },
        {
          "code" : "W02050105",
          "display" : "ELECTROPORATION DEVICES"
        },
        {
          "code" : "W02050106",
          "display" : "DNA GENOMIC PREPARATION DEVICES"
        },
        {
          "code" : "W02050107",
          "display" : "MICRO-ARRAY SCANNERS"
        },
        {
          "code" : "W02050108",
          "display" : "GENETIC SYSTEM READERS"
        },
        {
          "code" : "W02050109",
          "display" : "CELL WASHERS"
        },
        {
          "code" : "W02050110",
          "display" : "MICROINJECTORS"
        },
        {
          "code" : "W02050111",
          "display" : "EPITHELIAL VOLTOHMMETERS"
        },
        {
          "code" : "W02050112",
          "display" : "GENIC EXPRESSION MONITORING SYSTEMS"
        },
        {
          "code" : "W02050113",
          "display" : "PEPTIDE SYNTHESIZERS"
        },
        {
          "code" : "W02050114",
          "display" : "MOLECULAR BIOLOGY SCANNERS"
        },
        {
          "code" : "W02050115",
          "display" : "DNA SYNTHESIZERS"
        },
        {
          "code" : "W02050116",
          "display" : "NUCLEIC ACID TESTING INTEGRETED EXTRATION /AMPLIFICATION /DETECTION SYSTEMS"
        },
        {
          "code" : "W02050180",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS EXCEPT MICRO-ARRAYS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02050182",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS EXCEPT MICRO-ARRAYS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02050185",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS EXCEPT MICRO-ARRAYS - CONSUMABLES"
        },
        {
          "code" : "W02050192",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS EXCEPT MICRO-ARRAYS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02050199",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS EXCEPT MICRO-ARRAYS - OTHER"
        }]
      },
      {
        "code" : "W020502",
        "display" : "MICRO-ARRAY INSTRUMENTS",
        "concept" : [{
          "code" : "W02050201",
          "display" : "MICRO-ARRAY ANALYSERS"
        },
        {
          "code" : "W02050202",
          "display" : "MICRO-ARRAYS PREPARATION UNITS"
        },
        {
          "code" : "W02050280",
          "display" : "MICRO-ARRAY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02050282",
          "display" : "MICRO-ARRAY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02050285",
          "display" : "MICRO-ARRAY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "W02050292",
          "display" : "MICRO-ARRAY INSTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02050299",
          "display" : "MICRO-ARRAY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "W020503",
        "display" : "NUCLEIC ACID TESTING INSTRUMENTS - RAPID AND POINT OF CARE TESTS",
        "concept" : [{
          "code" : "W02050301",
          "display" : "NUCLEIC ACID TESTING APPARATUSES - RAPID AND POINT OF CARE TESTS"
        },
        {
          "code" : "W02050380",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS - RAPID AND POINT OF CARE TESTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02050382",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS- RAPID AND POINT OF CARE TESTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02050385",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS - RAPID AND POINT OF CARE TESTS - CONSUMABLES"
        },
        {
          "code" : "W02050392",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS - RAPID AND POINT OF CARE TESTS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02050399",
          "display" : "NUCLEIC ACID TESTING INSTRUMENTS - RAPID AND POINT OF CARE TESTS - OTHER"
        }]
      }]
    },
    {
      "code" : "W0206",
      "display" : "SAMPLE PROCESSING SYSTEMS",
      "concept" : [{
        "code" : "W020601",
        "display" : "ROBOTIC SAMPLE PROCESSING SYSTEMS",
        "concept" : [{
          "code" : "W02060101",
          "display" : "AUTOMATED SYSTEMS FOR THE MANAGEMENT OF PRE AND POST-ANALYSIS"
        },
        {
          "code" : "W02060102",
          "display" : "AUTOMATED SAMPLE TRANSPORT SYSTEMS"
        },
        {
          "code" : "W02060180",
          "display" : "ROBOTIC SAMPLE PROCESSING SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02060182",
          "display" : "ROBOTIC SAMPLE PROCESSING SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02060185",
          "display" : "ROBOTIC SAMPLE PROCESSING SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "W02060192",
          "display" : "ROBOTIC SAMPLE PROCESSING SYSTEMS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02060199",
          "display" : "ROBOTIC SAMPLE PROCESSING SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "W020602",
        "display" : "POST-ANALYSIS SAMPLE ARCHIVING SYSTEMS",
        "concept" : [{
          "code" : "W02060201",
          "display" : "POST-ANALYSIS SAMPLE ARCHIVING SYSTEMS - INSTRUMENTS"
        },
        {
          "code" : "W02060280",
          "display" : "POST-ANALYSIS SAMPLE ARCHIVING SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02060282",
          "display" : "POST-ANALYSIS SAMPLE ARCHIVING SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02060285",
          "display" : "POST-ANALYSIS SAMPLE ARCHIVING SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "W02060292",
          "display" : "POST-ANALYSIS SAMPLE ARCHIVING SYSTEMS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02060299",
          "display" : "POST-ANALYSIS SAMPLE ARCHIVING SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "W020690",
        "display" : "VARIOUS SAMPLE PROCESSING INSTRUMENTS",
        "concept" : [{
          "code" : "W02069001",
          "display" : "AUTOSAMPLERS"
        },
        {
          "code" : "W02069002",
          "display" : "TEST TUBE APPARATUSES"
        },
        {
          "code" : "W02069003",
          "display" : "CENTRIFUGES"
        },
        {
          "code" : "W02069004",
          "display" : "CYTOCENTRIFUGES"
        },
        {
          "code" : "W02069005",
          "display" : "REFRIGERATED CENTRIFUGES"
        },
        {
          "code" : "W02069006",
          "display" : "ULTRACENTRIFUGES"
        },
        {
          "code" : "W02069080",
          "display" : "VARIOUS SAMPLE PROCESSING INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02069082",
          "display" : "VARIOUS SAMPLE PROCESSING INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02069085",
          "display" : "VARIOUS SAMPLE PROCESSING INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "W02069092",
          "display" : "VARIOUS SAMPLE PROCESSING INSTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02069099",
          "display" : "VARIOUS SAMPLE PROCESSING INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "W0207",
      "display" : "GENERAL PURPOSE IVD INSTRUMENTS",
      "concept" : [{
        "code" : "W020701",
        "display" : "SCALES",
        "concept" : [{
          "code" : "W02070101",
          "display" : "ANALYTICAL SCALES"
        },
        {
          "code" : "W02070102",
          "display" : "TECHNICAL SCALES"
        },
        {
          "code" : "W02070103",
          "display" : "BLOOD SCALES"
        }]
      },
      {
        "code" : "W020702",
        "display" : "CRYOGENICS / FROZEN"
      },
      {
        "code" : "W020703",
        "display" : "BIOLOGICAL HOODS AND CABINETS",
        "concept" : [{
          "code" : "W02070301",
          "display" : "BIOLOGICAL HOODS"
        },
        {
          "code" : "W02070302",
          "display" : "FUME HOODS"
        },
        {
          "code" : "W02070303",
          "display" : "LAMINAR AIRFLOW HOODS"
        },
        {
          "code" : "W02070304",
          "display" : "CHEMICAL FILTRATION AIR CLOSETS"
        }]
      },
      {
        "code" : "W020704",
        "display" : "SHAKERS AND HOMOGENIZERS",
        "concept" : [{
          "code" : "W02070401",
          "display" : "LABORATORY SHAKERS"
        },
        {
          "code" : "W02070402",
          "display" : "GRINDING MILLS"
        },
        {
          "code" : "W02070403",
          "display" : "HOMOGENIZERS"
        },
        {
          "code" : "W02070404",
          "display" : "BLOOD BAG MIXERS"
        }]
      },
      {
        "code" : "W020790",
        "display" : "VARIOUS GENERAL PURPOSE IVD INSTRUMENTS",
        "concept" : [{
          "code" : "W02079001",
          "display" : "THERMOSTATIC WATER BATHS"
        },
        {
          "code" : "W02079002",
          "display" : "DILUTERS"
        },
        {
          "code" : "W02079003",
          "display" : "DISPENSERS"
        },
        {
          "code" : "W02079004",
          "display" : "EVAPORATORS"
        },
        {
          "code" : "W02079006",
          "display" : "BUNSEN BURNERS"
        },
        {
          "code" : "W02079007",
          "display" : "FREEZE DRYERS"
        },
        {
          "code" : "W02079008",
          "display" : "HEATING MANTLES"
        },
        {
          "code" : "W02079009",
          "display" : "PH METERS"
        },
        {
          "code" : "W02079011",
          "display" : "MELTING POINT DEVICES"
        },
        {
          "code" : "W02079012",
          "display" : "LABORATORY HOTPLATES"
        },
        {
          "code" : "W02079013",
          "display" : "LABORATORY REFRACTOMETERS"
        },
        {
          "code" : "W02079014",
          "display" : "LABWARE DRYERS"
        },
        {
          "code" : "W02079015",
          "display" : "LABORATORY TITRATORS"
        },
        {
          "code" : "W02079016",
          "display" : "VISCOSIMETERS"
        },
        {
          "code" : "W02079017",
          "display" : "OSMOMETERS"
        },
        {
          "code" : "W02079080",
          "display" : "VARIOUS GENERAL PURPOSE IVD INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "W02079082",
          "display" : "VARIOUS GENERAL PURPOSE IVD INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "W02079085",
          "display" : "VARIOUS GENERAL PURPOSE IVD INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "W02079092",
          "display" : "VARIOUS GENERAL PURPOSE IVD INSTRUMENTS - IVD MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "W02079099",
          "display" : "VARIOUS GENERAL PURPOSE IVD INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "W0299",
      "display" : "IVD INSTRUMENTS - OTHER"
    }]
  },
  {
    "code" : "W05",
    "display" : "IVD GENERIC USE CONSUMABLES",
    "concept" : [{
      "code" : "W0501",
      "display" : "SAMPLES COLLECTION DEVICES",
      "concept" : [{
        "code" : "W050101",
        "display" : "BLOOD COLLECTION DEVICES",
        "concept" : [{
          "code" : "W05010101",
          "display" : "VENOUS OR ARTERIOUS BLOOD COLLECTION DEVICES",
          "concept" : [{
            "code" : "W0501010101",
            "display" : "BLOOD COLLECTION, CLOSED SYRINGES",
            "concept" : [{
              "code" : "W050101010101",
              "display" : "BLOOD COLLECTION, CLOSED SYRINGES WITH ADDITIVES"
            },
            {
              "code" : "W050101010102",
              "display" : "BLOOD COLLECTION, CLOSED SYRINGES WITHOUT ADDITIVES"
            }]
          },
          {
            "code" : "W0501010102",
            "display" : "BLOOD COLLECTION, TUBES",
            "concept" : [{
              "code" : "W050101010201",
              "display" : "BLOOD COLLECTION, TUBES WITH ADDITIVES OR SERUM SEPARATOR"
            },
            {
              "code" : "W050101010202",
              "display" : "BLOOD COLLECTION, TUBES WITHOUT ADDITIVES OR SERUM SEPARATOR"
            }]
          },
          {
            "code" : "W0501010103",
            "display" : "BLOOD GAS SAMPLES COLLECTION, SYRINGES WITHOUT NEEDLE"
          },
          {
            "code" : "W0501010180",
            "display" : "VENOUS OR ARTERIOUS BLOOD COLLECTION DEVICES - ACCESSORIES"
          },
          {
            "code" : "W0501010199",
            "display" : "VENOUS OR ARTERIOUS BLOOD COLLECTION DEVICES - OTHER"
          }]
        },
        {
          "code" : "W05010102",
          "display" : "CAPILLARY BLOOD COLLECTION DEVICES",
          "concept" : [{
            "code" : "W0501010201",
            "display" : "CAPILLARY BLOOD COLLECTION SYSTEMS"
          },
          {
            "code" : "W0501010202",
            "display" : "CAPILLARY AND VENOUS BLOOD COLLECTION, INTEGRATED SYSTEMS"
          },
          {
            "code" : "W0501010203",
            "display" : "BLOOD COLLECTION, CAPILLARY TUBES"
          },
          {
            "code" : "W0501010280",
            "display" : "CAPILLARY BLOOD COLLECTION DEVICES - ACCESSORIES"
          },
          {
            "code" : "W0501010299",
            "display" : "CAPILLARY BLOOD COLLECTION DEVICES - OTHER"
          }]
        }]
      },
      {
        "code" : "W050102",
        "display" : "URINE COLLECTION DEVICES",
        "concept" : [{
          "code" : "W05010201",
          "display" : "URINE COLLECTION, SYRINGES",
          "concept" : [{
            "code" : "W0501020101",
            "display" : "URINE COLLECTION, SYRINGES WITH STABILIZER"
          },
          {
            "code" : "W0501020102",
            "display" : "URINE COLLECTION, SYRINGES WITHOUT STABILIZER"
          }]
        },
        {
          "code" : "W05010202",
          "display" : "URINE COLLECTION, TUBES"
        },
        {
          "code" : "W05010203",
          "display" : "URINE COLLECTION, CONTAINERS"
        },
        {
          "code" : "W05010280",
          "display" : "URINE COLLECTION DEVICES - ACCESSORIES"
        },
        {
          "code" : "W05010299",
          "display" : "URINE COLLECTION DEVICES - OTHER"
        }]
      },
      {
        "code" : "W050180",
        "display" : "SAMPLES COLLECTION DEVICES - OTHER ACCESSORIES"
      },
      {
        "code" : "W050190",
        "display" : "SAMPLES COLLECTION DEVICES - VARIOUS",
        "concept" : [{
          "code" : "W05019001",
          "display" : "FAECES COLLECTION DEVICES"
        },
        {
          "code" : "W05019002",
          "display" : "SALIVA COLLECTION DEVICES"
        },
        {
          "code" : "W05019003",
          "display" : "SPUTUM COLLECTION DEVICES"
        },
        {
          "code" : "W05019005",
          "display" : "BIOPTICAL COLLECTION, FILTERS"
        },
        {
          "code" : "W05019099",
          "display" : "SAMPLES COLLECTION DEVICES - OTHER"
        }]
      }]
    },
    {
      "code" : "W0502",
      "display" : "DEVICES FOR SAMPLES TRANSPORT (non-generic laboratory products)",
      "concept" : [{
        "code" : "W050201",
        "display" : "SAMPLES TRANSPORT, CONTAINERS",
        "concept" : [{
          "code" : "W05020101",
          "display" : "SAMPLES TRANSPORT, POUCHES"
        },
        {
          "code" : "W05020102",
          "display" : "SAMPLES TRANSPORT, BOXES"
        },
        {
          "code" : "W05020103",
          "display" : "SAMPLES TRANSPORT, BOTTLES"
        },
        {
          "code" : "W05020104",
          "display" : "SAMPLES TRANSPORT, VASES"
        },
        {
          "code" : "W05020105",
          "display" : "SAMPLES TRANSPORT, BAGS"
        },
        {
          "code" : "W05020106",
          "display" : "BIOPSY CARTRIDGES"
        },
        {
          "code" : "W05020180",
          "display" : "SAMPLES TRANSPORT, CONTAINERS - ACCESSORIES"
        },
        {
          "code" : "W05020199",
          "display" : "SAMPLES TRANSPORT, CONTAINERS - OTHER"
        }]
      },
      {
        "code" : "W050280",
        "display" : "DEVICES FOR SAMPLES TRANSPORT - OTHER ACCESSORIES"
      },
      {
        "code" : "W050299",
        "display" : "DEVICES FOR SAMPLES TRANSPORT - OTHER"
      }]
    },
    {
      "code" : "W0503",
      "display" : "DEVICES FOR SAMPLES ANALYSES (no laboratory generic products)",
      "concept" : [{
        "code" : "W050301",
        "display" : "ANALYSIS CONTAINERS",
        "concept" : [{
          "code" : "W05030101",
          "display" : "SAMPLES ANALYSES, GLASS CONTAINERS",
          "concept" : [{
            "code" : "W0503010101",
            "display" : "SAMPLES ANALYSES, GLASS TUBES"
          },
          {
            "code" : "W0503010102",
            "display" : "SAMPLES ANALYSES, GLASS CUVETTES"
          },
          {
            "code" : "W0503010103",
            "display" : "SAMPLES ANALYSES, GLASSES"
          },
          {
            "code" : "W0503010104",
            "display" : "SAMPLES ANALYSES, GLASS BOTTLES"
          },
          {
            "code" : "W0503010105",
            "display" : "SAMPLES ANALYSES, GLASS TUBING"
          },
          {
            "code" : "W0503010106",
            "display" : "SAMPLES ANALYSES, GLASS TRAYS"
          },
          {
            "code" : "W0503010180",
            "display" : "SAMPLES ANALYSES, GLASS CONTAINERS - ACCESSORIES"
          },
          {
            "code" : "W0503010199",
            "display" : "SAMPLES ANALYSES, GLASS CONTAINERS - OTHER"
          }]
        },
        {
          "code" : "W05030102",
          "display" : "SAMPLES ANALYSES, PLASTIC CONTAINERS",
          "concept" : [{
            "code" : "W0503010201",
            "display" : "SAMPLES ANALYSES, PLASTIC TUBES",
            "concept" : [{
              "code" : "W050301020101",
              "display" : "SAMPLES ANALYSES, PLASTIC TUBES WITH ADDITIVES"
            },
            {
              "code" : "W050301020102",
              "display" : "SAMPLES ANALYSES, PLASTIC TUBES WITHOUT ADDITIVES"
            },
            {
              "code" : "W050301020180",
              "display" : "SAMPLES ANALYSES, PLASTIC TUBES - ACCESSORIES"
            }]
          },
          {
            "code" : "W0503010202",
            "display" : "SAMPLES ANALYSES, PLASTIC MICROTUBES",
            "concept" : [{
              "code" : "W050301020201",
              "display" : "SAMPLES ANALYSES, PLASTIC MICROTUBES WITH ADDITIVES"
            },
            {
              "code" : "W050301020202",
              "display" : "SAMPLES ANALYSES, PLASTIC MICROTUBES WITHOUT ADDITIVES"
            },
            {
              "code" : "W050301020280",
              "display" : "SAMPLES ANALYSES, PLASTIC MICROTUBES - ACCESSORIES"
            }]
          },
          {
            "code" : "W0503010203",
            "display" : "SAMPLES ANALYSES, PLASTIC CUVETTES"
          },
          {
            "code" : "W0503010204",
            "display" : "SAMPLES ANALYSES, PLASTIC DISHES FOR MICROTECHNIQUES"
          },
          {
            "code" : "W0503010205",
            "display" : "SAMPLES ANALYSES, PLASTIC VASES"
          },
          {
            "code" : "W0503010206",
            "display" : "SAMPLES ANALYSES, PLASTIC GLASSES"
          },
          {
            "code" : "W0503010207",
            "display" : "SAMPLES ANALYSES, PLASTIC BOTTLES"
          },
          {
            "code" : "W0503010208",
            "display" : "SAMPLES ANALYSES, PLASTIC TUBING"
          },
          {
            "code" : "W0503010209",
            "display" : "SAMPLES ANALYSES, PLASTIC TRAYS"
          },
          {
            "code" : "W0503010280",
            "display" : "SAMPLES ANALYSES, PLASTIC CONTAINERS - OTHER ACCESSORIES"
          },
          {
            "code" : "W0503010290",
            "display" : "SAMPLES ANALYSES, PLASTIC CONTAINERS - VARIOUS",
            "concept" : [{
              "code" : "W050301029001",
              "display" : "BLOOD COMPONENTS SEPARATORS, PLASTIC"
            },
            {
              "code" : "W050301029099",
              "display" : "SAMPLES ANALYSES, PLASTIC CONTAINERS - OTHER"
            }]
          }]
        },
        {
          "code" : "W05030199",
          "display" : "SAMPLES ANALYSES, CONTAINERS - OTHER"
        }]
      },
      {
        "code" : "W050302",
        "display" : "PIPETTES AND TIPS",
        "concept" : [{
          "code" : "W05030201",
          "display" : "PIPETTES",
          "concept" : [{
            "code" : "W0503020101",
            "display" : "SEROLOGICAL AND DILUTION PIPETTES",
            "concept" : [{
              "code" : "W050302010101",
              "display" : "SEROLOGICAL AND DILUTION PIPETTES, GLASS"
            },
            {
              "code" : "W050302010102",
              "display" : "SEROLOGICAL AND DILUTION PIPETTES, PLASTIC"
            }]
          },
          {
            "code" : "W0503020180",
            "display" : "PIPETTES - ACCESSORIES"
          },
          {
            "code" : "W0503020199",
            "display" : "PIPETTES - OTHER"
          }]
        },
        {
          "code" : "W05030202",
          "display" : "PIPETTE TIPS",
          "concept" : [{
            "code" : "W0503020201",
            "display" : "PIPETTE TIPS WITH FILTER"
          },
          {
            "code" : "W0503020202",
            "display" : "PIPETTES, TIPS WITHOUT FILTER"
          },
          {
            "code" : "W0503020280",
            "display" : "PIPETTES, TIPS - ACCESSORIES"
          }]
        }]
      },
      {
        "code" : "W050303",
        "display" : "MICROBIOLOGY DEVICES",
        "concept" : [{
          "code" : "W05030301",
          "display" : "MICROBIOLOGICAL CULTURE DEVICES",
          "concept" : [{
            "code" : "W0503030101",
            "display" : "PETRI DISHES"
          },
          {
            "code" : "W0503030199",
            "display" : "MICROBIOLOGICAL CULTURE DEVICES - OTHER"
          }]
        },
        {
          "code" : "W05030302",
          "display" : "MICROBIOLOGICAL CULTURE, LOOPS"
        },
        {
          "code" : "W05030380",
          "display" : "MICROBIOLOGY DEVICES - ACCESSORIES"
        },
        {
          "code" : "W05030399",
          "display" : "MICROBIOLOGY DEVICES - OTHER"
        }]
      },
      {
        "code" : "W050304",
        "display" : "CELL AND TISSUE CULTURES DEVICES",
        "concept" : [{
          "code" : "W05030401",
          "display" : "CELL AND TISSUE CULTURES, CONTAINERS",
          "concept" : [{
            "code" : "W0503040101",
            "display" : "CELL AND TISSUE CULTURES, FLASKS"
          },
          {
            "code" : "W0503040102",
            "display" : "CELL AND TISSUE CULTURES, DISHES"
          },
          {
            "code" : "W0503040103",
            "display" : "CELL AND TISSUE CULTURES, BOTTLES"
          },
          {
            "code" : "W0503040104",
            "display" : "CELL AND TISSUE CULTURES, TUBES"
          },
          {
            "code" : "W0503040105",
            "display" : "CELL AND TISSUE CULTURES, DISKS"
          },
          {
            "code" : "W0503040180",
            "display" : "CELL AND TISSUE CULTURES, CONTAINERS - ACCESSORIES"
          },
          {
            "code" : "W0503040199",
            "display" : "CELL AND TISSUE CULTURES, CONTAINERS - OTHER"
          }]
        },
        {
          "code" : "W05030402",
          "display" : "CELL AND TISSUE CULTURES, FILTERS"
        },
        {
          "code" : "W05030480",
          "display" : "CELL AND TISSUE CULTURES DEVICES - OTHER ACCESSORIES"
        },
        {
          "code" : "W05030499",
          "display" : "CELL AND TISSUE CULTURES DEVICES - OTHER"
        }]
      },
      {
        "code" : "W050305",
        "display" : "DEVICES FOR PATHOLOGY TESTS",
        "concept" : [{
          "code" : "W05030501",
          "display" : "INCLUSION DEVICES, CASSETTES"
        },
        {
          "code" : "W05030502",
          "display" : "INCLUSION DEVICES, RINGS"
        },
        {
          "code" : "W05030580",
          "display" : "DEVICES FOR PATOLOGY TESTS - ACCESSORIES"
        },
        {
          "code" : "W05030599",
          "display" : "DEVICES FOR PATOLOGY TESTS - OTHER"
        }]
      },
      {
        "code" : "W050390",
        "display" : "DEVICES FOR SAMPLES ANALYSES - VARIOUS",
        "concept" : [{
          "code" : "W05039001",
          "display" : "AGITATION DEVICES",
          "concept" : [{
            "code" : "W0503900101",
            "display" : "AGITATION RODS"
          },
          {
            "code" : "W0503900102",
            "display" : "AGITATION ANCHORS"
          },
          {
            "code" : "W0503900199",
            "display" : "AGITATION DEVICES - OTHER"
          }]
        },
        {
          "code" : "W05039002",
          "display" : "SLIDES FOR SAMPLES ANALYSIS",
          "concept" : [{
            "code" : "W0503900201",
            "display" : "MICROSCOPE SLIDES"
          },
          {
            "code" : "W0503900202",
            "display" : "MICROSCOPE SLIDES COVERSLIP"
          }]
        },
        {
          "code" : "W05039080",
          "display" : "DEVICES FOR SAMPLES ANALYSES - OTHER ACCESSORIES"
        },
        {
          "code" : "W05039099",
          "display" : "DEVICES FOR SAMPLES ANALYSES - OTHER"
        }]
      }]
    },
    {
      "code" : "W0580",
      "display" : "IVD GENERAL USE CONSUMABLES DEVICES - OTHER ACCESSORIES"
    },
    {
      "code" : "W0599",
      "display" : "IVD GENERAL USE CONSUMABLE DEVICES - OTHER"
    }]
  },
  {
    "code" : "X",
    "display" : "PRODUCTS WITHOUT AN INTENDED MEDICAL PURPOSE (Annex XVI)"
  },
  {
    "code" : "X01",
    "display" : "CONTACT LENSES OR OTHER ITEMS INTENDED TO BE INTRODUCED INTO OR ONTO THE EYE WITHOUT AN INTENDED MEDICAL PURPOSE",
    "concept" : [{
      "code" : "X0101",
      "display" : "CONTACT LENSES WITHOUT AN INTENDED MEDICAL PURPOSE – HYDROGEL",
      "concept" : [{
        "code" : "X010101",
        "display" : "CONTACT LENSES WITHOUT AN INTENDED MEDICAL PURPOSE – HYDROGEL, SINGLE-USE",
        "concept" : [{
          "code" : "X01010101",
          "display" : "CONTACT LENSES WITHOUT AN INTENDED MEDICAL PURPOSE – HYDROGEL, DAILY SINGLE-USE"
        },
        {
          "code" : "X01010102",
          "display" : "CONTACT LENSES WITHOUT AN INTENDED MEDICAL PURPOSE – HYDROGEL, EXTENDED WEAR SINGLE-USE"
        }]
      },
      {
        "code" : "X010102",
        "display" : "CONTACT LENSES WITHOUT AN INTENDED MEDICAL PURPOSE – HYDROGEL, REUSABLE"
      }]
    },
    {
      "code" : "X0102",
      "display" : "CONTACT LENSES WITHOUT AN INTENDED MEDICAL PURPOSE – NON HYDROGEL"
    }]
  },
  {
    "code" : "X02",
    "display" : "PRODUCTS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE TOTALLY OR PARTIALLY INTRODUCED INTO THE HUMAN BODY THROUGH SURGICALLY INVASIVE MEANS FOR THE PURPOSE OF MODIFYING THE ANATOMY OR FIXATION OF BODY PARTS WITH THE EXCEPTION OF TATTOOING PRODUCTS AND PIERCINGS",
    "concept" : [{
      "code" : "X0201",
      "display" : "PRODUCTS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE TOTALLY INTRODUCED INTO THE HUMAN BODY THROUGH SURGICALLY INVASIVE MEANS FOR THE PURPOSE OF MODIFYING THE ANATOMY OF BODY PARTS WITH THE EXCEPTION OF TATTOOING PRODUCTS AND PIERCINGS",
      "concept" : [{
        "code" : "X020101",
        "display" : "PRODUCTS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE TOTALLY INTRODUCED INTO THE HUMAN BODY THROUGH SURGICALLY INVASIVE MEANS FOR THE PURPOSE OF MODIFYING THE ANATOMY OF BODY PARTS WITH THE EXCEPTION OF TATTOOING PRODUCTS AND PIERCINGS – RESORBABLE"
      },
      {
        "code" : "X020102",
        "display" : "PRODUCTS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE TOTALLY INTRODUCED INTO THE HUMAN BODY THROUGH SURGICALLY INVASIVE MEANS FOR THE PURPOSE OF MODIFYING THE ANATOMY OF BODY PARTS WITH THE EXCEPTION OF TATTOOING PRODUCTS AND PIERCINGS – NON RESORBABLE"
      }]
    },
    {
      "code" : "X0202",
      "display" : "PRODUCTS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE PARTIALLY INTRODUCED INTO THE HUMAN BODY THROUGH SURGICALLY INVASIVE MEANS FOR THE PURPOSE OF MODIFYING THE ANATOMY OF BODY PARTS WITH THE EXCEPTION OF TATTOOING PRODUCTS AND PIERCINGS",
      "concept" : [{
        "code" : "X020201",
        "display" : "PRODUCTS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE PARTIALLY INTRODUCED INTO THE HUMAN BODY THROUGH SURGICALLY INVASIVE MEANS FOR THE PURPOSE OF MODIFYING THE ANATOMY OF BODY PARTS WITH THE EXCEPTION OF TATTOOING PRODUCTS AND PIERCINGS – RESORBABLE"
      },
      {
        "code" : "X020202",
        "display" : "PRODUCTS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE PARTIALLY INTRODUCED INTO THE HUMAN BODY THROUGH SURGICALLY INVASIVE MEANS FOR THE PURPOSE OF MODIFYING THE ANATOMY OF BODY PARTS WITH THE EXCEPTION OF TATTOOING PRODUCTS AND PIERCINGS – NON RESORBABLE"
      }]
    }]
  },
  {
    "code" : "X03",
    "display" : "SUBSTANCES, COMBINATIONS OF SUBSTANCES, OR ITEMS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE USED FOR FACIAL OR OTHER DERMAL OR MUCOUS MEMBRANE FILLING BY SUBCUTANEOUS, SUBMUCOUS OR INTRADERMAL INJECTION OR OTHER INTRODUCTION, EXCLUDING THOSE FOR TATTOOING",
    "concept" : [{
      "code" : "X0301",
      "display" : "SUBSTANCES, COMBINATIONS OF SUBSTANCES, OR ITEMS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE USED FOR FACIAL OR OTHER DERMAL OR MUCOUS MEMBRANE FILLING BY SUBCUTANEOUS, SUBMUCOUS OR INTRADERMAL INJECTION OR OTHER INTRODUCTION, EXCLUDING THOSE FOR TATTOOING – RESORBABLE"
    },
    {
      "code" : "X0302",
      "display" : "SUBSTANCES, COMBINATIONS OF SUBSTANCES, OR ITEMS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE USED FOR FACIAL OR OTHER DERMAL OR MUCOUS MEMBRANE FILLING BY SUBCUTANEOUS, SUBMUCOUS OR INTRADERMAL INJECTION OR OTHER INTRODUCTION, EXCLUDING THOSE FOR TATTOOING – NON RESORBABLE"
    },
    {
      "code" : "X0303",
      "display" : "SUBSTANCES, COMBINATIONS OF SUBSTANCES, OR ITEMS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE USED FOR FACIAL OR OTHER DERMAL OR MUCOUS MEMBRANE FILLING BY SUBCUTANEOUS, SUBMUCOUS OR INTRADERMAL INJECTION OR OTHER INTRODUCTION, BY A PREFILLED MEANS FOR INTRODUCTION, EXCLUDING THOSE FOR TATTOOING – RESORBABLE"
    },
    {
      "code" : "X0304",
      "display" : "SUBSTANCES, COMBINATIONS OF SUBSTANCES, OR ITEMS WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE USED FOR FACIAL OR OTHER DERMAL OR MUCOUS MEMBRANE FILLING BY SUBCUTANEOUS, SUBMUCOUS OR INTRADERMAL INJECTION OR OTHER INTRODUCTION, BY A PREFILLED MEANS FOR INTRODUCTION, EXCLUDING THOSE FOR TATTOOING – NON RESORBABLE"
    }]
  },
  {
    "code" : "X04",
    "display" : "EQUIPMENT WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED TO BE USED TO REDUCE, REMOVE OR DESTROY ADIPOSE TISSUE",
    "concept" : [{
      "code" : "X0401",
      "display" : "EQUIPMENT WITHOUT AN INTENDED MEDICAL PURPOSE FOR LIPOSUCTION"
    },
    {
      "code" : "X0402",
      "display" : "EQUIPMENT WITHOUT AN INTENDED MEDICAL PURPOSE FOR LIPOLYSIS"
    },
    {
      "code" : "X0403",
      "display" : "EQUIPMENT WITHOUT AN INTENDED MEDICAL PURPOSE FOR LIPOPLASTY, OTHER THAN LIPOSUCTION OR LIPOLYSIS"
    }]
  },
  {
    "code" : "X05",
    "display" : "HIGH INTENSITY ELECTROMAGNETIC RADIATION EMITTING EQUIPMENT WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED FOR USE ON THE HUMAN BODY FOR SKIN RESURFACING, TATTOO OR HAIR REMOVAL OR OTHER SKIN TREATMENT",
    "concept" : [{
      "code" : "X0501",
      "display" : "HIGH INTENSITY ELECTROMAGNETIC RADIATION EMITTING EQUIPMENT WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED FOR USE ON THE HUMAN BODY, FOR SKIN RESURFACING, TATTOO OR HAIR REMOVAL OR OTHER SKIN TREATMENT – LASER"
    },
    {
      "code" : "X0502",
      "display" : "HIGH INTENSITY ELECTROMAGNETIC RADIATION EMITTING EQUIPMENT WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED FOR USE ON THE HUMAN BODY, FOR SKIN RESURFACING, TATTOO OR HAIR REMOVAL OR OTHER SKIN TREATMENT – INTENSE PULSED LIGHT"
    },
    {
      "code" : "X0599",
      "display" : "HIGH INTENSITY ELECTROMAGNETIC RADIATION EMITTING EQUIPMENT WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED FOR USE ON THE HUMAN BODY, FOR SKIN RESURFACING, TATTOO OR HAIR REMOVAL OR OTHER SKIN TREATMENT – OTHER"
    }]
  },
  {
    "code" : "X06",
    "display" : "EQUIPMENT WITHOUT AN INTENDED MEDICAL PURPOSE INTENDED FOR BRAIN STIMULATION THAT APPLY ELECTRICAL CURRENTS OR MAGNETIC OR ELECTROMAGNETIC FIELDS THAT PENETRATE THE CRANIUM TO MODIFY NEURONAL ACTIVITY IN THE BRAIN"
  },
  {
    "code" : "Y",
    "display" : "DEVICES FOR PERSONS WITH DISABILITIES NOT INCLUDED IN OTHER CATEGORIES"
  },
  {
    "code" : "Y05",
    "display" : "ABILITIES LEARNING AND TRAINING DEVICES",
    "concept" : [{
      "code" : "Y0501",
      "display" : "CONTINENCE TRAINING DEVICES (INCLUDING INCONTINENCE ALARM SYSTEMS)"
    },
    {
      "code" : "Y0502",
      "display" : "GAIT TRAINERS",
      "concept" : [{
        "code" : "Y050201",
        "display" : "STANDING SUPPORT GAIT TRAINERS"
      },
      {
        "code" : "Y050202",
        "display" : "STANDING FRAMES"
      }]
    },
    {
      "code" : "Y0503",
      "display" : "HANDS AND FINGERS RE-EDUCATION DEVICES"
    },
    {
      "code" : "Y0504",
      "display" : "ARMS, TORSO AND LEGS RE-EDUCATION DEVICES"
    },
    {
      "code" : "Y0580",
      "display" : "LEARNING AND TRAINING DEVICES - ACCESSORIES"
    },
    {
      "code" : "Y0599",
      "display" : "LEARNING AND TRAINING DEVICES - OTHER"
    }]
  },
  {
    "code" : "Y06",
    "display" : "EXTERNAL PROSTHESES AND ORTHOSES",
    "concept" : [{
      "code" : "Y0603",
      "display" : "SPINE ORTHOSES",
      "concept" : [{
        "code" : "Y060303",
        "display" : "SACROILIAC SPINE ORTHOSES"
      },
      {
        "code" : "Y060306",
        "display" : "THORACOLUMBAR ORTHOSES"
      },
      {
        "code" : "Y060307",
        "display" : "THORACIC ORTHOSES"
      },
      {
        "code" : "Y060308",
        "display" : "LUMBOSACRAL SPINE ORTHOSES"
      },
      {
        "code" : "Y060309",
        "display" : "THORACOLUMBOSACRAL SPINE ORTHOSES"
      },
      {
        "code" : "Y060312",
        "display" : "CERVICAL SPINE ORTHOSES"
      },
      {
        "code" : "Y060315",
        "display" : "CERVICOTHORACIC SPINE ORTHOSES"
      },
      {
        "code" : "Y060318",
        "display" : "CERVICOTHORACOLUMBOSACRAL SPINE ORTHOSES"
      },
      {
        "code" : "Y060380",
        "display" : "SPINAL ORTHOSES - ACCESSORIES"
      },
      {
        "code" : "Y060399",
        "display" : "SPINE ORTHOSES - OTHER"
      }]
    },
    {
      "code" : "Y0604",
      "display" : "ABDOMINAL ORTHOSES",
      "concept" : [{
        "code" : "Y060403",
        "display" : "ABDOMINAL MUSCLES SUPPORTS"
      },
      {
        "code" : "Y060406",
        "display" : "ABDOMINAL HERNIA SUPPORTS"
      },
      {
        "code" : "Y060499",
        "display" : "ABDOMINAL ORTHOSES - OTHER"
      }]
    },
    {
      "code" : "Y0606",
      "display" : "UPPER EXTREMITY ORTHOSES (SPLINTS AND BRACES)",
      "concept" : [{
        "code" : "Y060603",
        "display" : "FINGERS ORTHOSES"
      },
      {
        "code" : "Y060606",
        "display" : "HAND ORTHOSES"
      },
      {
        "code" : "Y060609",
        "display" : "WRIST (FOREARM) ORTHOSES"
      },
      {
        "code" : "Y060612",
        "display" : "WRIST-HAND ORTHOSES"
      },
      {
        "code" : "Y060613",
        "display" : "WRIST-HAND-FINGERS ORTHOSES"
      },
      {
        "code" : "Y060615",
        "display" : "ELBOW ORTHOSES"
      },
      {
        "code" : "Y060618",
        "display" : "ELBOW-WRIST ORTHOSES"
      },
      {
        "code" : "Y060619",
        "display" : "ELBOW-WRIST-HAND ORTHOSES"
      },
      {
        "code" : "Y060621",
        "display" : "SHOULDER ORTHOSES"
      },
      {
        "code" : "Y060624",
        "display" : "SHOULDER-ELBOW ORTHOSES"
      },
      {
        "code" : "Y060627",
        "display" : "SHOULDER-ELBOW - WRIST ORTHOSES"
      },
      {
        "code" : "Y060630",
        "display" : "SHOULDER-ELBOW-WRIST- HAND ORTHOSES"
      },
      {
        "code" : "Y060680",
        "display" : "UPPER LIMB ORTHOSES - ACCESSORIES"
      },
      {
        "code" : "Y060699",
        "display" : "ORTHOSES, UPPER EXTREMITY - OTHER"
      }]
    },
    {
      "code" : "Y0612",
      "display" : "ORTHOSIS, LOWER EXTREMITY (INSOLES, LIFTS, SPLINTS, BRACES, CLAMPS)",
      "concept" : [{
        "code" : "Y061203",
        "display" : "ORTHOSES, FOOT (INCLUDING INSOLES AND INSERTS)"
      },
      {
        "code" : "Y061206",
        "display" : "ANKLE-FOOT ORTHOSES",
        "concept" : [{
          "code" : "Y06120601",
          "display" : "PASSIVE ANKLE-FOOT ORTHOSES"
        },
        {
          "code" : "Y06120602",
          "display" : "ENERGY RETURN ANKLE-FOOT ORTHOSES"
        }]
      },
      {
        "code" : "Y061209",
        "display" : "KNEE ORTHOSES"
      },
      {
        "code" : "Y061212",
        "display" : "KNEE-ANKLE-FOOT ORTHOSES",
        "concept" : [{
          "code" : "Y06121201",
          "display" : "PASSIVE KNEE-ANKLE-FOOT ORTHOSES"
        },
        {
          "code" : "Y06121202",
          "display" : "ENERGY RETURN ORTHOSES FOR KNEE-ANKLE-FOOT"
        },
        {
          "code" : "Y06121203",
          "display" : "ACTIVE KNEE-ANKLE-FOOT ORTHOSES"
        }]
      },
      {
        "code" : "Y061215",
        "display" : "HIP ORTHOSES (INCLUDING ABDUCTION ORTHOSES)"
      },
      {
        "code" : "Y061216",
        "display" : "HIP-KNEE ORTHOSES"
      },
      {
        "code" : "Y061217",
        "display" : "THIGH ORTHOSES"
      },
      {
        "code" : "Y061218",
        "display" : "HIP-KNEE-ANKLE-FOOT ORTHOSES"
      },
      {
        "code" : "Y061219",
        "display" : "CHEST-LUMB-SACRAL-HIP-KNEE-ANKLE-FOOT ORTHOSES"
      },
      {
        "code" : "Y061280",
        "display" : "LOWER LIMB ORTHOSES - ACCESSORIES"
      },
      {
        "code" : "Y061299",
        "display" : "LOWER EXTREMITY ORTHOSES - OTHER"
      }]
    },
    {
      "code" : "Y0618",
      "display" : "UPPER EXTREMITY PROSTHESES",
      "concept" : [{
        "code" : "Y061803",
        "display" : "PARTIAL HAND PROSTHESES (INCLUDING FINGERS PROSTHESES)"
      },
      {
        "code" : "Y061806",
        "display" : "WRIST DISARTICULATION PROSTHESES"
      },
      {
        "code" : "Y061809",
        "display" : "TRANSRADIAL PROSTHESES (FOR AMPUTATION UNDER ELBOW)"
      },
      {
        "code" : "Y061812",
        "display" : "ELBOW DISARTICULATION PROSTHESES"
      },
      {
        "code" : "Y061815",
        "display" : "TRANSHUMERAL PROSTHESES (FOR AMPUTATION ABOVE ELBOW)"
      },
      {
        "code" : "Y061818",
        "display" : "SHOULDER DISARTICULATION PROSTHESES"
      },
      {
        "code" : "Y061899",
        "display" : "UPPER EXTREMITY PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "Y0624",
      "display" : "LOWER EXTREMITY PROSTHESES",
      "concept" : [{
        "code" : "Y062403",
        "display" : "FOOT PARTIAL PROSTHESES (INCLUDING TOE PROSTHESES)"
      },
      {
        "code" : "Y062409",
        "display" : "TRANSTIBIAL PROSTHESES (FOR AMPUTATION UNDER KNEE)"
      },
      {
        "code" : "Y062412",
        "display" : "KNEE DISARTICULATION PROSTHESES"
      },
      {
        "code" : "Y062415",
        "display" : "TRANSFEMORAL PROSTHESES (FOR AMPUTATION ABOVE KNEE)"
      },
      {
        "code" : "Y062418",
        "display" : "HIP DISARTICULATION PROSTHESES"
      },
      {
        "code" : "Y062499",
        "display" : "LOWER EXTREMITY PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "Y0627",
      "display" : "COSMETIC AND NON-FUNCTIONAL LOWER LIMB PROSTHESES",
      "concept" : [{
        "code" : "Y062703",
        "display" : "AESTHETIC FILLERS, CALF AND THIGH"
      }]
    },
    {
      "code" : "Y0630",
      "display" : "NON-EXTREMITY PROSTHESES",
      "concept" : [{
        "code" : "Y063018",
        "display" : "EXTERNAL BREAST PROSTHESES"
      },
      {
        "code" : "Y063021",
        "display" : "OCULAR PROSTHESES"
      },
      {
        "code" : "Y063099",
        "display" : "NON-EXTREMITY PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "Y0633",
      "display" : "ORTHOTIC SHOES",
      "concept" : [{
        "code" : "Y063303",
        "display" : "READY-MADE ORTHOTIC SHOES"
      }]
    },
    {
      "code" : "Y0699",
      "display" : "EXTERNAL PROSTHESES AND ORTHOSES - OTHER"
    }]
  },
  {
    "code" : "Y09",
    "display" : "PERSONAL CARE AIDS",
    "concept" : [{
      "code" : "Y0903",
      "display" : "CLOTHES, FOOTWEAR AND COVERS FOR PROSTHESES",
      "concept" : [{
        "code" : "Y090312",
        "display" : "GLOVES AND HANDLES FOR PROSTHESES"
      },
      {
        "code" : "Y090327",
        "display" : "SOCKS FOR PROSTHESES"
      },
      {
        "code" : "Y090342",
        "display" : "SHOES AND BOOTS FOR PROSTHESES"
      },
      {
        "code" : "Y090399",
        "display" : "CLOTHES, FOOTWEAR AND COVERS FOR PROSTHESES - OTHER"
      }]
    },
    {
      "code" : "Y0906",
      "display" : "BODY PROTECTION DEVICES",
      "concept" : [{
        "code" : "Y090612",
        "display" : "ARM AND ELBOW PROTECTIONS"
      },
      {
        "code" : "Y090618",
        "display" : "LEG AND KNEE PROTECTIONS (INCLUDING SOCKS FOR AMPUTATED LEGS)"
      },
      {
        "code" : "Y090699",
        "display" : "DEVICES FOR BODY PROTECTION - OTHER"
      }]
    },
    {
      "code" : "Y0912",
      "display" : "DEJECTION DEVICES",
      "concept" : [{
        "code" : "Y091203",
        "display" : "CHAIRS, TOILET AND SHOWER"
      },
      {
        "code" : "Y091209",
        "display" : "TOILET SEATS"
      },
      {
        "code" : "Y091212",
        "display" : "TOILET STOOLS"
      },
      {
        "code" : "Y091215",
        "display" : "TOILET SEATS, RAISED"
      },
      {
        "code" : "Y091299",
        "display" : "DEJECTION DEVICES - OTHER"
      }]
    },
    {
      "code" : "Y0933",
      "display" : "WASHING, BATHING AND SHOWERING DEVICES",
      "concept" : [{
        "code" : "Y093303",
        "display" : "FIXED AND ROTARY CHAIRS FOR BATH AND SHOWER"
      },
      {
        "code" : "Y093312",
        "display" : "SHOWER STRETCHERS"
      },
      {
        "code" : "Y093399",
        "display" : "WASHING, BATHING AND SHOWERING DEVICES - OTHER"
      }]
    },
    {
      "code" : "Y0999",
      "display" : "PERSONAL CARE AIDS - OTHER"
    }]
  },
  {
    "code" : "Y12",
    "display" : "PERSONAL MOBILITY DEVICES",
    "concept" : [{
      "code" : "Y1203",
      "display" : "WALKING DEVICES, ONE-HANDED OPERATION",
      "concept" : [{
        "code" : "Y120303",
        "display" : "WHITE STICKS FOR BLIND PERSONS"
      },
      {
        "code" : "Y120306",
        "display" : "WALKING CRUTCHES",
        "concept" : [{
          "code" : "Y12030601",
          "display" : "ELBOW CRUTCHES"
        },
        {
          "code" : "Y12030602",
          "display" : "CRUTCHES WITH ANTIBRACHIAL SUPPORT"
        },
        {
          "code" : "Y12030603",
          "display" : "CRUTCHES WITH UNDER-AXLE SUPPORT"
        }]
      },
      {
        "code" : "Y120315",
        "display" : "TRIPODS"
      },
      {
        "code" : "Y120318",
        "display" : "QUADRIPODS"
      },
      {
        "code" : "Y120380",
        "display" : "ONE ARM MANIPULATED WALKING AIDS - ACCESSORIES"
      },
      {
        "code" : "Y120399",
        "display" : "WALKING DEVICES, ONE-HANDED OPERATION - OTHER"
      }]
    },
    {
      "code" : "Y1206",
      "display" : "WALKING DEVICES, TWO-HANDED OPERATION",
      "concept" : [{
        "code" : "Y120603",
        "display" : "WALKING FRAMES, 4 TIPS"
      },
      {
        "code" : "Y120606",
        "display" : "WHEELED WALKER"
      },
      {
        "code" : "Y120609",
        "display" : "WALKING FRAMES WITH CHAIR, 4 WHEELS"
      },
      {
        "code" : "Y120612",
        "display" : "WALKING TROLLEYS"
      },
      {
        "code" : "Y120615",
        "display" : "POWER ASSISTED MOBILITY ROLLATORS"
      },
      {
        "code" : "Y120680",
        "display" : "TWO ARMS MANIPULATED WALKING AIDS - ACCESSORIES"
      },
      {
        "code" : "Y120699",
        "display" : "WALKING DEVICES, TWO-HANDED OPERATION - OTHER"
      }]
    },
    {
      "code" : "Y1218",
      "display" : "CYCLES",
      "concept" : [{
        "code" : "Y121801",
        "display" : "BICYCLES"
      },
      {
        "code" : "Y121806",
        "display" : "PEDAL TRICYCLES"
      },
      {
        "code" : "Y121809",
        "display" : "MANUALLY PROPELLED TRICYCLES"
      },
      {
        "code" : "Y121821",
        "display" : "RETRACTORS, BACKRESTS, BRACKETS AND SUPPORTS"
      },
      {
        "code" : "Y121899",
        "display" : "CYCLES - OTHER"
      }]
    },
    {
      "code" : "Y1221",
      "display" : "WHEELCHAIRS",
      "concept" : [{
        "code" : "Y122103",
        "display" : "PUSH WHEELCHAIRS"
      },
      {
        "code" : "Y122106",
        "display" : "REAR SELF-PROPELLED WHEELCHAIRS"
      },
      {
        "code" : "Y122109",
        "display" : "FRONT SELF-PROPELLED WHEELCHAIRS"
      },
      {
        "code" : "Y122124",
        "display" : "ELECTRIC SCOOTERS"
      },
      {
        "code" : "Y122127",
        "display" : "ELECTRIC WHEELCHAIRS"
      },
      {
        "code" : "Y122130",
        "display" : "DISABILITY MOPEDS, 3-WHEELED"
      },
      {
        "code" : "Y122199",
        "display" : "WHEELCHAIRS - OTHER"
      }]
    },
    {
      "code" : "Y1224",
      "display" : "WHEELCHAIR ACCESSORIES",
      "concept" : [{
        "code" : "Y122403",
        "display" : "WHEELCHAIR FOOTRESTS, SUPPORTS AND CONTROLS"
      },
      {
        "code" : "Y122406",
        "display" : "BELTS, SEATS AND ARMRESTS FOR WHEELCHAIRS"
      },
      {
        "code" : "Y122409",
        "display" : "HANDRIMS AND ONE-ARM-DRIVE SYSTEMS"
      },
      {
        "code" : "Y122410",
        "display" : "ELECTRIC PROPULSION UNIT"
      },
      {
        "code" : "Y122411",
        "display" : "WHEELCHAIR UNICYCLE"
      },
      {
        "code" : "Y122412",
        "display" : "WHEELCHAIR LIGHTS"
      },
      {
        "code" : "Y122499",
        "display" : "WHEELCHAIRS ACCESSORIES - OTHER"
      }]
    },
    {
      "code" : "Y1227",
      "display" : "NON-MOTORIZED VEHICLES AND MEANS OF TRANSPORT",
      "concept" : [{
        "code" : "Y122703",
        "display" : "PUSHCHAIRS"
      },
      {
        "code" : "Y122799",
        "display" : "NON-MOTORIZED VEHICLES AND MEANS OF TRANSPORT - OTHER"
      }]
    },
    {
      "code" : "Y1299",
      "display" : "PERSONAL MOBILITY DEVICES - OTHER"
    }]
  },
  {
    "code" : "Y15",
    "display" : "DOMESTIC ACTIVITIES AIDS",
    "concept" : [{
      "code" : "Y1509",
      "display" : "ASSISTIVE EATING AND DRINKING DEVICES",
      "concept" : [{
        "code" : "Y150912",
        "display" : "CUTLERY"
      },
      {
        "code" : "Y150915",
        "display" : "GLASSES AND CUPS"
      },
      {
        "code" : "Y150918",
        "display" : "ADAPTABLE DISHES"
      },
      {
        "code" : "Y150921",
        "display" : "ADAPTABLE CUTTERS AND EDGES FOR DISHES"
      },
      {
        "code" : "Y150999",
        "display" : "ASSISTIVE EATING AND DRINKING DEVICES - OTHER"
      }]
    },
    {
      "code" : "Y1599",
      "display" : "HOUSEHOLD ACTIVITIES AIDS - OTHER"
    }]
  },
  {
    "code" : "Y18",
    "display" : "AIDS, FURNITURE AND HOME AIDS FOR PERSONS WITH DISABILITIES",
    "concept" : [{
      "code" : "Y1803",
      "display" : "ASSISTIVE TABLES"
    },
    {
      "code" : "Y1809",
      "display" : "CHAIRS / POSTURE SYSTEMS / SEAT POSITIONING AIDS",
      "concept" : [{
        "code" : "Y180918",
        "display" : "MULTIFUNCTIONAL CHAIRS"
      },
      {
        "code" : "Y180939",
        "display" : "MODULAR POSTURE SYSTEMS"
      },
      {
        "code" : "Y180980",
        "display" : "SEATING SYSTEMS / POSTURE SYSTEMS / SEATING AIDS - ACCESSORIES"
      },
      {
        "code" : "Y180999",
        "display" : "CHAIRS / POSTURE SYSTEMS / SEAT POSITIONING AIDS - OTHER"
      }]
    },
    {
      "code" : "Y1818",
      "display" : "SUPPORT SYSTEMS",
      "concept" : [{
        "code" : "Y181803",
        "display" : "HANDRAILS"
      },
      {
        "code" : "Y181806",
        "display" : "HANDLES"
      },
      {
        "code" : "Y181809",
        "display" : "ARMRESTS"
      },
      {
        "code" : "Y181899",
        "display" : "SUPPORT SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "Y1830",
      "display" : "LIFTING DEVICES (STAIRLIFTS)",
      "concept" : [{
        "code" : "Y183012",
        "display" : "MOBILE STAIRLIFTS"
      },
      {
        "code" : "Y183015",
        "display" : "PORTABLE RAMPS"
      },
      {
        "code" : "Y183099",
        "display" : "LIFTING DEVICES (STAIRLIFTS) - OTHER"
      }]
    },
    {
      "code" : "Y1899",
      "display" : "AIDS, FURNITURE AND HOME AIDS FOR PERSONS WITH DISABILITIES - OTHER"
    }]
  },
  {
    "code" : "Y21",
    "display" : "COMMUNICATION AND INFORMATION MANAGEMENT AIDS",
    "concept" : [{
      "code" : "Y2103",
      "display" : "OPTICAL AIDS",
      "concept" : [{
        "code" : "Y210306",
        "display" : "PRISMATIC OPHTHALMIC LENSES FOR RAISING AND LOWERING THE EYE WITH PROSTHESES"
      },
      {
        "code" : "Y210321",
        "display" : "FAR SIGHTEDNESS TELESCOPIC SYSTEMS/SPECTACLES"
      },
      {
        "code" : "Y210324",
        "display" : "NEAR SIGHTEDNESS TELESCOPIC SYSTEMS/SPECTACLES"
      },
      {
        "code" : "Y210330",
        "display" : "MAGNIFYING ACHROMATIC DOUBLET LENSES"
      },
      {
        "code" : "Y210333",
        "display" : "PRISMATIC SPECTACLES"
      },
      {
        "code" : "Y210336",
        "display" : "OCCLUSION AND ANTI-RADIATION FILTERS"
      },
      {
        "code" : "Y210399",
        "display" : "OPTICAL AIDS - OTHER"
      }]
    },
    {
      "code" : "Y2106",
      "display" : "OPTICAL ELECTRONIC AIDS",
      "concept" : [{
        "code" : "Y210603",
        "display" : "VIDEO MAGNIFIERS"
      },
      {
        "code" : "Y210606",
        "display" : "OCR SYSTEMS"
      },
      {
        "code" : "Y210609",
        "display" : "MAGNIFIERS FOR PERSONAL COMPUTERS"
      },
      {
        "code" : "Y210699",
        "display" : "ELECTRONIC OPTICAL AIDS - OTHER"
      }]
    },
    {
      "code" : "Y2109",
      "display" : "PERSONAL COMPUTER INPUT AND OUTPUT PERIPHERAL EQUIPMENT",
      "concept" : [{
        "code" : "Y210905",
        "display" : "EXTERNAL SENSOR INTERFACES"
      },
      {
        "code" : "Y210906",
        "display" : "MOUSE AND KEYBOARD EMULATORS"
      },
      {
        "code" : "Y210915",
        "display" : "VOCAL SYNTHESIS DEVICES"
      },
      {
        "code" : "Y210924",
        "display" : "ARM SUPPORTS"
      },
      {
        "code" : "Y210999",
        "display" : "PERSONAL COMPUTER INPUT AND OUTPUT PERIPHERAL EQUIPMENT - OTHER"
      }]
    },
    {
      "code" : "Y2115",
      "display" : "WRITING MACHINES AND TEXT PROCESSING SYSTEMS",
      "concept" : [{
        "code" : "Y211518",
        "display" : "WRITING SOFTWARE"
      },
      {
        "code" : "Y211599",
        "display" : "WRITING MACHINES AND TEXT PROCESSING SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "Y2127",
      "display" : "NON-OPTICAL READING AIDS",
      "concept" : [{
        "code" : "Y212703",
        "display" : "PAGE-TURNERS"
      },
      {
        "code" : "Y212706",
        "display" : "BOOKRESTS"
      }]
    },
    {
      "code" : "Y2136",
      "display" : "TELEPHONES AND TELEPHONING AIDS",
      "concept" : [{
        "code" : "Y213603",
        "display" : "EASY ACCESS TELEPHONES"
      },
      {
        "code" : "Y213609",
        "display" : "TELEPHONE COMMUNICATORS"
      },
      {
        "code" : "Y213624",
        "display" : "TELEPHONE HANDSET REPLACEMENT DEVICES AND CALL SIGNALERS"
      },
      {
        "code" : "Y213699",
        "display" : "TELEPHONES AND TELEPHONING AIDS - OTHER"
      }]
    },
    {
      "code" : "Y2139",
      "display" : "SOUND TRANSMISSION SYSTEMS",
      "concept" : [{
        "code" : "Y213924",
        "display" : "MF RECEIVER-TRANSMITTERS"
      },
      {
        "code" : "Y213999",
        "display" : "SOUND TRANSMISSION SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "Y2142",
      "display" : "INTERPERSONAL COMUNICATION DEVICES",
      "concept" : [{
        "code" : "Y214209",
        "display" : "ALPHABETIC AND SYMBOLIC COMMUNICATORS"
      },
      {
        "code" : "Y214212",
        "display" : "VOICE GENERATORS"
      },
      {
        "code" : "Y214224",
        "display" : "AUGMENTATIVE SOFTWARE"
      },
      {
        "code" : "Y214299",
        "display" : "DEVICES FOR INTERPERSONAL COMUNICATION - OTHER"
      }]
    },
    {
      "code" : "Y2145",
      "display" : "HEARING AIDS",
      "concept" : [{
        "code" : "Y214506",
        "display" : "AIR CONDUCTION HEARING AIDS",
        "concept" : [{
          "code" : "Y21450601",
          "display" : "BEHIND-THE-EAR HEARING AIDS (BTEs)",
          "concept" : [{
            "code" : "Y2145060101",
            "display" : "BEHIND-THE-EAR HEARING AIDS WITH RECEIVER IN THE DEVICE (BTE)"
          },
          {
            "code" : "Y2145060102",
            "display" : "BEHIND-THE-EAR HEARING AIDS WITH RECEIVER IN THE CANAL (RIC, RITE)"
          }]
        },
        {
          "code" : "Y21450602",
          "display" : "IN-THE-EAR HEARING AIDS (ITEs)",
          "concept" : [{
            "code" : "Y2145060201",
            "display" : "HEARING AID IN THE-EAR (ITE)"
          },
          {
            "code" : "Y2145060202",
            "display" : "HEARING AIDS IN-THE-CANAL (ITC)"
          },
          {
            "code" : "Y2145060203",
            "display" : "HEARING AIDS COMPLETELY-IN-THE-CANAL (CIC)"
          },
          {
            "code" : "Y2145060204",
            "display" : "HEARING AIDS INVISIBLE-IN-THE-CANAL (IIC)"
          }]
        },
        {
          "code" : "Y21450603",
          "display" : "BOX HEARING AIDS"
        }]
      },
      {
        "code" : "Y214509",
        "display" : "BONE CONDUCTION HEARING AIDS",
        "concept" : [{
          "code" : "Y21450901",
          "display" : "SPECTACLE HEARING AIDS"
        },
        {
          "code" : "Y21450902",
          "display" : "HEADBAND HEARING AIDS"
        },
        {
          "code" : "Y21450903",
          "display" : "HEARING AIDS WITH ELASTIC BAND"
        },
        {
          "code" : "Y21450904",
          "display" : "HEARING AIDS USING ADHESIVE PATCH"
        }]
      },
      {
        "code" : "Y214580",
        "display" : "HEARING AIDS OR HEARING DEVICES - ACCESSORIES"
      },
      {
        "code" : "Y214599",
        "display" : "HEARING AIDS - OTHER"
      }]
    },
    {
      "code" : "Y2151",
      "display" : "ALARM SYSTEMS + SIGNALLING, INDICATION AND REMINDER AIDS",
      "concept" : [{
        "code" : "Y215112",
        "display" : "CLOCKS FOR PERSONS WITH DISABILITIES"
      },
      {
        "code" : "Y215199",
        "display" : "ALARM SYSTEMS + SIGNALING, INDICATION AND REMINDER AIDS - OTHER"
      }]
    },
    {
      "code" : "Y2199",
      "display" : "COMMUNICATION AND INFORMATION MANAGEMENT AIDS - OTHER"
    }]
  },
  {
    "code" : "Y24",
    "display" : "OBJECT MANIPULATION DEVICES",
    "concept" : [{
      "code" : "Y2409",
      "display" : "CONTROL DEVICES AND SYSTEMS",
      "concept" : [{
        "code" : "Y240918",
        "display" : "CONTROL SENSORS"
      },
      {
        "code" : "Y240999",
        "display" : "CONTROL DEVICES AND SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "Y2412",
      "display" : "AMBIENT CONTROL SYSTEMS",
      "concept" : [{
        "code" : "Y241203",
        "display" : "PROGRAMMABLE REMOTE CONTROLS, HOME AUTOMATION SYSTEMS, CONTROL SATELLITES"
      },
      {
        "code" : "Y241299",
        "display" : "AMBIENT CONTROL SYSTEMS - OTHER"
      }]
    },
    {
      "code" : "Y2418",
      "display" : "ARM, HAND, FINGER FUNCTION AID AND/OR SUBSTITUTION DEVICES",
      "concept" : [{
        "code" : "Y241815",
        "display" : "FUNCTIONAL HELMETS"
      },
      {
        "code" : "Y241899",
        "display" : "ARM, HAND, FINGER FUNCTION AID AND/OR SUBSTITUTION DEVICES - OTHER"
      }]
    },
    {
      "code" : "Y2421",
      "display" : "DEVICES FOR REACHING AND GRASPING OBJECTS",
      "concept" : [{
        "code" : "Y242103",
        "display" : "MANUAL PREHENSILE GRIPPERS"
      },
      {
        "code" : "Y242199",
        "display" : "DEVICES FOR REACHING AND GRASPING OBJECTS - OTHER"
      }]
    },
    {
      "code" : "Y2499",
      "display" : "DEVICES FOR OBJECT MANIPULATION - OTHER"
    }]
  },
  {
    "code" : "Y99",
    "display" : "DEVICES FOR PERSONS WITH DISABILITIES NOT INCLUDED IN OTHER CATEGORIES - OTHER"
  },
  {
    "code" : "Z",
    "display" : "MEDICAL EQUIPMENT AND RELATED ACCESSORIES, SOFTWARE AND CONSUMABLES"
  },
  {
    "code" : "Z11",
    "display" : "BIOIMAGING AND RADIOTHERAPY INSTRUMENTS",
    "concept" : [{
      "code" : "Z1101",
      "display" : "RADIOTHERAPY AND RADIOSURGERY INSTRUMENTS",
      "concept" : [{
        "code" : "Z110101",
        "display" : "LINEAR ACCELERATORS",
        "concept" : [{
          "code" : "Z11010101",
          "display" : "SINGLE ENERGY LINEAR ACCELERATORS"
        },
        {
          "code" : "Z11010102",
          "display" : "MEDIUM AND MULTI ENERGY LINEAR ACCELERATORS"
        },
        {
          "code" : "Z11010103",
          "display" : "MULTI AND HIGH ENERGY LINEAR ACCELERATORS"
        },
        {
          "code" : "Z11010104",
          "display" : "INTRA-OPERATIVE LINEAR ACCELERATORS"
        },
        {
          "code" : "Z11010180",
          "display" : "LINEAR ACCELERATORS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11010182",
          "display" : "LINEAR ACCELERATORS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11010185",
          "display" : "LINEAR ACCELERATORS - CONSUMABLES"
        },
        {
          "code" : "Z11010192",
          "display" : "LINEAR ACCELERATORS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11010199",
          "display" : "LINEAR ACCELERATORS – OTHER"
        }]
      },
      {
        "code" : "Z110102",
        "display" : "RADIOTHERAPY SIMULATION INSTRUMENTS",
        "concept" : [{
          "code" : "Z11010201",
          "display" : "RADIOTHERAPY SIMULATORS"
        },
        {
          "code" : "Z11010202",
          "display" : "COMPUTED TOMOGRAPHY (CT) FOR RADIOTHERAPY SIMULATION"
        },
        {
          "code" : "Z11010280",
          "display" : "INSTRUMENTS FOR RADIOTHERAPY SIMULATION - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11010282",
          "display" : "INSTRUMENTS FOR RADIOTHERAPY SIMULATION - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11010285",
          "display" : "INSTRUMENTS FOR RADIOTHERAPY SIMULATION - CONSUMABLES"
        },
        {
          "code" : "Z11010292",
          "display" : "INSTRUMENTS FOR RADIOTHERAPY SIMULATION - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110103",
        "display" : "BRACHYTHERAPY RADIATION INSTRUMENTS",
        "concept" : [{
          "code" : "Z11010301",
          "display" : "BRACHYTHERAPY RADIATION SYSTEMS"
        },
        {
          "code" : "Z11010380",
          "display" : "BRACHYTHERAPY RADIATION SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11010382",
          "display" : "BRACHYTHERAPY RADIATION SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11010385",
          "display" : "BRACHYTHERAPY RADIATION SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z11010392",
          "display" : "BRACHYTHERAPY RADIATION SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110104",
        "display" : "RADIOTHERAPY TREATMENT PLANNING INSTRUMENTS",
        "concept" : [{
          "code" : "Z11010401",
          "display" : "RADIOTHERAPY TREATMENT PLANNING SYSTEMS"
        },
        {
          "code" : "Z11010480",
          "display" : "RADIOTHERAPY TREATMENT PLANNING INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11010482",
          "display" : "RADIOTHERAPY TREATMENT PLANNING INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11010485",
          "display" : "RADIOTHERAPY TREATMENT PLANNING INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11010492",
          "display" : "RADIOTHERAPY TREATMENT PLANNING INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110105",
        "display" : "INTRAVASCULAR RADIOTHERAPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z11010501",
          "display" : "INTRAVASCULAR RADIOTHERAPY SYSTEMS"
        },
        {
          "code" : "Z11010580",
          "display" : "INTRAVASCULAR RADIOTHERAPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11010582",
          "display" : "INTRAVASCULAR RADIOTHERAPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11010585",
          "display" : "INTRAVASCULAR RADIOTHERAPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11010592",
          "display" : "INTRAVASCULAR RADIOTHERAPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110107",
        "display" : "RADIOSURGERY INSTRUMENTS",
        "concept" : [{
          "code" : "Z11010701",
          "display" : "RADIOSURGERY SYSTEMS"
        },
        {
          "code" : "Z11010780",
          "display" : "RADIOSURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11010782",
          "display" : "RADIOSURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11010785",
          "display" : "RADIOSURGERY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11010792",
          "display" : "RADIOSURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110108",
        "display" : "TOMOTHERAPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z11010801",
          "display" : "TOMOTHERAPY SYSTEMS"
        },
        {
          "code" : "Z11010880",
          "display" : "TOMOTHERAPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11010882",
          "display" : "TOMOTHERAPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11010885",
          "display" : "TOMOTHERAPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11010892",
          "display" : "TOMOTHERAPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110109",
        "display" : "MAGNETIC RESONANCE RADIOTHERAPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z11010901",
          "display" : "INTEGRATED SYSTEMS FOR MAGNETIC RESONANCE RADIOTHERAPY"
        },
        {
          "code" : "Z11010980",
          "display" : "MAGNETIC RESONANCE RADIOTHERAPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11010982",
          "display" : "MAGNETIC RESONANCE RADIOTHERAPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11010985",
          "display" : "MAGNETIC RESONANCE RADIOTHERAPY INSTRUMENTS - SPECIFIC MATERIALS"
        },
        {
          "code" : "Z11010992",
          "display" : "MAGNETIC RESONANCE RADIOTHERAPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110110",
        "display" : "INSTRUMENTS FOR PROTON THERAPY",
        "concept" : [{
          "code" : "Z11011001",
          "display" : "PROTON THERAPY SYSTEMS"
        },
        {
          "code" : "Z11011080",
          "display" : "PROTON THERAPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11011082",
          "display" : "PROTON THERAPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11011085",
          "display" : "PROTON THERAPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11011092",
          "display" : "PROTON THERAPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110190",
        "display" : "VARIOUS RADIOTHERAPY AND RADIOSURGERY INSTRUMENTS",
        "concept" : [{
          "code" : "Z11019001",
          "display" : "CAESIUM THERAPY EQUIPMENT"
        },
        {
          "code" : "Z11019002",
          "display" : "COBALT THERAPY EQUIPMENT"
        },
        {
          "code" : "Z11019004",
          "display" : "AUTOMATIC CURVE TRACERS"
        },
        {
          "code" : "Z11019005",
          "display" : "SHIELDING BLOCK CUTTERS"
        },
        {
          "code" : "Z11019080",
          "display" : "VARIOUS RADIOTHERAPY AND RADIOSURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11019082",
          "display" : "VARIOUS RADIOTHERAPY AND RADIOSURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11019085",
          "display" : "VARIOUS RADIOTHERAPY AND RADIOSURGERY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11019092",
          "display" : "VARIOUS RADIOTHERAPY AND RADIOSURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11019099",
          "display" : "VARIOUS RADIOTHERAPY AND RADIOSURGERY INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1102",
      "display" : "NUCLEAR MEDICINE INSTRUMENTS",
      "concept" : [{
        "code" : "Z110201",
        "display" : "COMPUTERISED GAMMA CAMERAS",
        "concept" : [{
          "code" : "Z11020101",
          "display" : "MOBILE GAMMA CAMERAS"
        },
        {
          "code" : "Z11020102",
          "display" : "FIXED STATION GAMMA CAMERAS WITH SINGLE HEAD - WITHOUT 'TOTAL BODY' ACQUISITION"
        },
        {
          "code" : "Z11020103",
          "display" : "FIXED STATION GAMMA CAMERAS WITH SINGLE HEAD - WITH 'TOTAL BODY' ACQUISITION"
        },
        {
          "code" : "Z11020104",
          "display" : "FIXED STATION GAMMA CAMERAS WITH MULTIPLE HEADS - WITHOUT 'TOTAL BODY' ACQUISITION"
        },
        {
          "code" : "Z11020105",
          "display" : "FIXED STATION GAMMA CAMERAS WITH MULTIPLE HEADS - WITH 'TOTAL BODY' ACQUISITION"
        },
        {
          "code" : "Z11020180",
          "display" : "COMPUTERIZED GAMMA CAMERAS -HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11020182",
          "display" : "COMPUTERIZED GAMMA CAMERAS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11020185",
          "display" : "COMPUTERISED GAMMA CAMERAS -CONSUMABLES"
        },
        {
          "code" : "Z11020192",
          "display" : "COMPUTERISED GAMMA CAMERAS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110202",
        "display" : "INTEGRATED CT/GAMMA CAMERA SYSTEMS",
        "concept" : [{
          "code" : "Z11020201",
          "display" : "CT/GAMMA CAMERA SYSTEMS"
        },
        {
          "code" : "Z11020280",
          "display" : "INTEGRATED CT/GAMMA CAMERA SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11020282",
          "display" : "INTEGRATED CT/GAMMA CAMERA SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11020285",
          "display" : "IINTEGRATED CT/GAMMA CAMERA SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z11020292",
          "display" : "IINTEGRATED CT/GAMMA CAMERA SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110203",
        "display" : "INTEGRATED CT/PET SYSTEMS",
        "concept" : [{
          "code" : "Z11020301",
          "display" : "CT/PET SYSTEMS"
        },
        {
          "code" : "Z11020380",
          "display" : "INTEGRATED CT/PET SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11020382",
          "display" : "INTEGRATED CT/PET SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11020385",
          "display" : "INTEGRATED CT/PET SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z11020392",
          "display" : "INTEGRATED CT/PET SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110204",
        "display" : "POSITRON EMISSION TOMOGRAPHY INSTRUMENTS",
        "concept" : [{
          "code" : "Z11020401",
          "display" : "POSITRON EMISSION TOMOGRAPHS"
        },
        {
          "code" : "Z11020480",
          "display" : "POSITRON EMISSION TOMOGRAPHY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11020482",
          "display" : "POSITRON EMISSION TOMOGRAPHY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11020485",
          "display" : "POSITRON EMISSION TOMOGRAPHY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11020492",
          "display" : "POSITRON EMISSION TOMOGRAPHY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110205",
        "display" : "RADIOISOTOPE SCANNERS"
      },
      {
        "code" : "Z110206",
        "display" : "INTRAOPERATIVE RADIOISOTOPE SCANNERS"
      },
      {
        "code" : "Z110207",
        "display" : "INTEGRATED MRI/PET SYSTEMS",
        "concept" : [{
          "code" : "Z11020701",
          "display" : "MRI/PET SYSTEMS"
        },
        {
          "code" : "Z11020780",
          "display" : "INTEGRATED MRI/PET SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11020782",
          "display" : "INTEGRATED MRI/PET SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11020785",
          "display" : "INTEGRATED MRI/PET SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z11020792",
          "display" : "INTEGRATED MRI/PET SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110290",
        "display" : "VARIOUS INSTRUMENTS FOR NUCLEAR MEDICINE",
        "concept" : [{
          "code" : "Z11029001",
          "display" : "BETA/GAMMA DETECTORS"
        },
        {
          "code" : "Z11029002",
          "display" : "CYCLOTRONS"
        },
        {
          "code" : "Z11029003",
          "display" : "LYMPHOSCINTIGRAPHS"
        },
        {
          "code" : "Z11029004",
          "display" : "RADIOACTIVE GAS PRODUCERS"
        },
        {
          "code" : "Z11029005",
          "display" : "AUTOMATIC DOSE CALIBRATORS"
        },
        {
          "code" : "Z11029080",
          "display" : "VARIOUS INSTRUMENTS FOR NUCLEAR MEDICINE - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11029082",
          "display" : "VARIOUS INSTRUMENTS FOR NUCLEAR MEDICINE - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11029085",
          "display" : "VARIOUS INSTRUMENTS FOR NUCLEAR MEDICINE - CONSUMABLES"
        },
        {
          "code" : "Z11029092",
          "display" : "VARIOUS INSTRUMENTS FOR NUCLEAR MEDICINE - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11029099",
          "display" : "VARIOUS INSTRUMENTS FOR NUCLEAR MEDICINE - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1103",
      "display" : "DIAGNOSTIC AND INTERVENTIONAL RADIOLOGY INSTRUMENTS",
      "concept" : [{
        "code" : "Z110301",
        "display" : "DIGITAL ANGIOGRAPHY SYSTEMS",
        "concept" : [{
          "code" : "Z11030101",
          "display" : "MOBILE ANGIOGRAPHY SYSTEMS FOR ANGIOPLASTY AND CATHETERIZATION"
        },
        {
          "code" : "Z11030102",
          "display" : "STATIONARY ANGIOGRAPHY SYSTEMS FOR ANGIOGRAPHIC AND CARDIOLOGIC STUDIES"
        },
        {
          "code" : "Z11030103",
          "display" : "BIPLANAR ANGIOGRAPHY SYSTEMS"
        },
        {
          "code" : "Z11030180",
          "display" : "DIGITAL ANGIOGRAPHY SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11030182",
          "display" : "DIGITAL ANGIOGRAPHY SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11030185",
          "display" : "DIGITAL ANGIOGRAPHY SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z11030192",
          "display" : "DIGITAL ANGIOGRAPHY SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110302",
        "display" : "MAMMOGRAPHY SYSTEMS",
        "concept" : [{
          "code" : "Z11030201",
          "display" : "CONVENTIONAL MAMMOGRAPHY SYSTEMS"
        },
        {
          "code" : "Z11030202",
          "display" : "DIGITAL MAMMOGRAPHY SYSTEMS"
        },
        {
          "code" : "Z11030280",
          "display" : "MAMMOGRAPHY SYSTEMS - HARDWARE ACCESSORIES",
          "concept" : [{
            "code" : "Z1103028001",
            "display" : "STEREOTACTIC MODULES FOR MAMMOGRAPHY"
          },
          {
            "code" : "Z1103028099",
            "display" : "MAMMOGRAPHY SYSTEMS - HARDWARE - OTHER"
          }]
        },
        {
          "code" : "Z11030282",
          "display" : "MAMMOGRAPHY SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11030285",
          "display" : "MAMMOGRAPHY SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z11030292",
          "display" : "MAMMOGRAPHY SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110303",
        "display" : "INSTRUMENTS FOR ORTHOPANTOMOGRAPHY AND PANORAMIC DENTAL RADIOLOGY",
        "concept" : [{
          "code" : "Z11030301",
          "display" : "EQUIPMENT FOR ORTHOPANTOMOGRAPHY",
          "concept" : [{
            "code" : "Z1103030101",
            "display" : "EQUIPMENT FOR CONVENTIONAL ORTHOPANTOMOGRAPHY"
          },
          {
            "code" : "Z1103030102",
            "display" : "EQUIPMENT FOR DIGITAL ORTHOPANTOMOGRAPHY"
          }]
        },
        {
          "code" : "Z11030302",
          "display" : "EQUIPMENT FOR PANORAMIC DENTAL RADIOLOGY"
        },
        {
          "code" : "Z11030380",
          "display" : "INSTRUMENTS FOR ORTHOPANTOMOGRAPHY AND PANORAMIC DENTAL RADIOLOGY - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11030382",
          "display" : "INSTRUMENTS FOR ORTHOPANTOMOGRAPHY AND PANORAMIC DENTAL RADIOLOGY - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11030385",
          "display" : "INSTRUMENTS FOR ORTHOPANTOMOGRAPHY AND PANORAMIC DENTAL RADIOLOGY - CONSUMABLES"
        },
        {
          "code" : "Z11030392",
          "display" : "INSTRUMENTS FOR ORTHOPANTOMOGRAPHY AND PANORAMIC DENTAL RADIOLOGY - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110304",
        "display" : "INSTRUMENTS FOR ENDORAL RADIOLOGY",
        "concept" : [{
          "code" : "Z11030401",
          "display" : "ENDORAL RADIOLOGY EQUIPMENT",
          "concept" : [{
            "code" : "Z1103040101",
            "display" : "EQUIPMENT FOR CONVENTIONAL ENDORAL RADIOLOGY"
          },
          {
            "code" : "Z1103040102",
            "display" : "EQUIPMENT FOR DIGITAL ENDORAL RADIOLOGY"
          }]
        },
        {
          "code" : "Z11030402",
          "display" : "SYSTEMS FOR INTRAORAL DIGITAL VIDEORADIOGRAPHY"
        },
        {
          "code" : "Z11030480",
          "display" : "INSTRUMENTS FOR ENDORAL RADIOLOGY - CONSUMABLES"
        },
        {
          "code" : "Z11030482",
          "display" : "INSTRUMENTS FOR RADIOLOGICAL SECTION"
        },
        {
          "code" : "Z11030485",
          "display" : "INSTRUMENTS FOR DIGITAL ENDORAL RADIOLOGY - CONSUMABLES"
        },
        {
          "code" : "Z11030492",
          "display" : "INSTRUMENTS FOR DIGITAL ENDORAL RADIOLOGY - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110305",
        "display" : "RADIOLOGY INSTRUMENTS",
        "concept" : [{
          "code" : "Z11030501",
          "display" : "COLUMN STANDS FOR RADIOLOGICAL EQUIPMENT"
        },
        {
          "code" : "Z11030502",
          "display" : "CEILING STANDS FOR RADIOLOGICAL EQUIPMENT"
        },
        {
          "code" : "Z11030503",
          "display" : "PATIENT TABLES FOR RADIOLOGICAL EQUIPMENT"
        },
        {
          "code" : "Z11030504",
          "display" : "TILTING TABLES FOR RADIOLOGY EQUIPMENT"
        },
        {
          "code" : "Z11030505",
          "display" : "TOMOGRAPHY TABLES"
        },
        {
          "code" : "Z11030506",
          "display" : "TELERADIOGRAPHS"
        },
        {
          "code" : "Z11030507",
          "display" : "TOMOGRAPHS"
        },
        {
          "code" : "Z11030580",
          "display" : "RADIOLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11030582",
          "display" : "RADIOLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11030585",
          "display" : "RADIOLOGY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11030592",
          "display" : "RADIOLOGY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11030599",
          "display" : "RADIOLOGY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z110306",
        "display" : "COMPUTED TOMOGRAPHS (CT)",
        "concept" : [{
          "code" : "Z11030601",
          "display" : "COMPUTED TOMOGRAPHS - NOT EXCEEDING 2 LAYERS"
        },
        {
          "code" : "Z11030602",
          "display" : "COMPUTED TOMOGRAPHS - EXCEEDING 2 LAYERS BUT LESS THAN 16 LAYERS"
        },
        {
          "code" : "Z11030603",
          "display" : "COMPUTED TOMOGRAPHS - 16 LAYERS OR MORE BUT LESS THAN 64 LAYERS"
        },
        {
          "code" : "Z11030605",
          "display" : "COMPUTED TOMOGRAPHS - 64 LAYERS OR MORE BUT LESS THAN 128 LAYERS"
        },
        {
          "code" : "Z11030606",
          "display" : "COMPUTED TOMOGRAPHS - 128 LAYERS OR MORE BUT LESS THAN 256 LAYERS"
        },
        {
          "code" : "Z11030607",
          "display" : "COMPUTED TOMOGRAPHS - 256 LAYERS OR MORE"
        },
        {
          "code" : "Z11030680",
          "display" : "COMPUTED TOMOGRAPHS (CT) - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11030682",
          "display" : "COMPUTED TOMOGRAPHS (CT) - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11030685",
          "display" : "COMPUTED TOMOGRAPHS (CT) - CONSUMABLES"
        },
        {
          "code" : "Z11030692",
          "display" : "COMPUTED TOMOGRAPHS (CT) - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11030699",
          "display" : "COMPUTED TOMOGRAPHS (CT) - OTHER"
        }]
      },
      {
        "code" : "Z110307",
        "display" : "REMOTE CONTROL TABLES",
        "concept" : [{
          "code" : "Z11030701",
          "display" : "CONVENTIONAL REMOTE CONTROL TABLES"
        },
        {
          "code" : "Z11030702",
          "display" : "DIGITAL REMOTE CONTROL TABLES"
        },
        {
          "code" : "Z11030703",
          "display" : "REMOTE CONTROL TABLES WITH CONVENTIONAL MULTIFUNCTIONAL ARCH"
        },
        {
          "code" : "Z11030704",
          "display" : "REMOTE CONTROL TABLES WITH DIGITAL MULTIFUNCTIONAL ARCH"
        },
        {
          "code" : "Z11030780",
          "display" : "REMOTE CONTROL TABLES - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11030782",
          "display" : "REMOTE CONTROL TABLES - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11030785",
          "display" : "REMOTE CONTROL TABLES - CONSUMABLES"
        },
        {
          "code" : "Z11030792",
          "display" : "REMOTE CONTROL TABLES - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110310",
        "display" : "MULTIFUNCTIONAL SYSTEMS FOR TRADITIONAL RADIOLOGY"
      },
      {
        "code" : "Z110311",
        "display" : "DIRECT DIGITAL RADIOLOGY (DR) SYSTEMS",
        "concept" : [{
          "code" : "Z11031101",
          "display" : "MULTIFUNCTIONAL SYSTEMS FOR DIRECT DIGITAL RADIOLOGY"
        },
        {
          "code" : "Z11031102",
          "display" : "DIRECT DIGITAL TELERADIOGRAPHS"
        },
        {
          "code" : "Z11031180",
          "display" : "SYSTEMS FOR DIRECT DIGITAL RADIOLOGY (DR) - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11031182",
          "display" : "SYSTEMS FOR DIRECT DIGITAL RADIOLOGY (DR) - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11031192",
          "display" : "SYSTEMS FOR DIRECT DIGITAL RADIOLOGY (DR) - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110390",
        "display" : "VARIOUS INSTRUMENTS FOR RADIODIAGNOSTICS AND INTERVENTIONAL PROCEDURES",
        "concept" : [{
          "code" : "Z11039001",
          "display" : "ANGIOGRAPHS"
        },
        {
          "code" : "Z11039002",
          "display" : "ARTERIOGRAPHS"
        },
        {
          "code" : "Z11039003",
          "display" : "MULTIFORMAT CAMERAS"
        },
        {
          "code" : "Z11039004",
          "display" : "TELEVISION SYSTEMS"
        },
        {
          "code" : "Z11039005",
          "display" : "RADIOGENIC COMPLEXES"
        },
        {
          "code" : "Z11039006",
          "display" : "RADIOLOGY CONTROL UNITS"
        },
        {
          "code" : "Z11039007",
          "display" : "CRANIOSTATS"
        },
        {
          "code" : "Z11039008",
          "display" : "AUTOMATIC EXPOSURE METERS"
        },
        {
          "code" : "Z11039009",
          "display" : "FLUOROSCOPY DEVICES"
        },
        {
          "code" : "Z11039010",
          "display" : "PHOTO CAMERAS"
        },
        {
          "code" : "Z11039011",
          "display" : "HIGH VOLTAGE X-RAY GENERATORS"
        },
        {
          "code" : "Z11039012",
          "display" : "X-RAY TUBE ASSEMBLY"
        },
        {
          "code" : "Z11039013",
          "display" : "ANGIOGRAPHIC INJECTORS"
        },
        {
          "code" : "Z11039014",
          "display" : "MULTIPLE CONTRAST AGENT INJECTORS"
        },
        {
          "code" : "Z11039015",
          "display" : "IMAGE INTENSIFIERS"
        },
        {
          "code" : "Z11039016",
          "display" : "MOBILE RADIOGRAPHIC UNITS"
        },
        {
          "code" : "Z11039017",
          "display" : "MOBILE RADIOSCOPIC UNITS"
        },
        {
          "code" : "Z11039018",
          "display" : "SERIALOGRAPHS"
        },
        {
          "code" : "Z11039019",
          "display" : "ANGIOGRAPHY TUBE SUPPORTS"
        },
        {
          "code" : "Z11039020",
          "display" : "ANGIOGRAPHY TABLES"
        },
        {
          "code" : "Z11039021",
          "display" : "RADIOGRAPHY VIDEO ACQUISITION SYSTEMS"
        },
        {
          "code" : "Z11039080",
          "display" : "VARIOUS RADIODIAGNOSTIC AND INTERVENTIONAL INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11039082",
          "display" : "VARIOUS RADIODIAGNOSTIC AND INTERVENTIONAL INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11039085",
          "display" : "VARIOUS RADIODIAGNOSTIC AND INTERVENTIONAL INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11039092",
          "display" : "VARIOUS RADIODIAGNOSTIC AND INTERVENTIONAL INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11039099",
          "display" : "VARIOUS RADIODIAGNOSTIC AND INTERVENTIONAL INSTRUMENTS – OTHER"
        }]
      }]
    },
    {
      "code" : "Z1104",
      "display" : "ECHOGRAPHY INSTRUMENTS",
      "concept" : [{
        "code" : "Z110401",
        "display" : "ULTRASOUND SCANNERS",
        "concept" : [{
          "code" : "Z11040101",
          "display" : "INTERNAL ULTRASOUND SCANNERS"
        },
        {
          "code" : "Z11040102",
          "display" : "CARDIOLOGY ULTRASOUND SCANNERS"
        },
        {
          "code" : "Z11040103",
          "display" : "PORTABLE ULTRASOUND SCANNERS"
        },
        {
          "code" : "Z11040104",
          "display" : "MULTIDISCIPLINARY ULTRASOUND SCANNERS (INTERNAL AND CARDIOLOGY, ETC.)"
        },
        {
          "code" : "Z11040105",
          "display" : "OBSTETRIC/GYNAECOLOGICAL ULTRASOUND SCANNERS"
        },
        {
          "code" : "Z11040106",
          "display" : "HANDHELD ULTRASOUND SCANNERS"
        },
        {
          "code" : "Z11040107",
          "display" : "ECHOPHTHALMOGRAPHS"
        },
        {
          "code" : "Z11040180",
          "display" : "ULTRASOUND SCANNERS - HARDWARE ACCESSORIES",
          "concept" : [{
            "code" : "Z1104018099",
            "display" : "ULTRASOUND SCANNERS – HARDWARE ACCESSORIES – OTHER"
          }]
        },
        {
          "code" : "Z11040182",
          "display" : "ULTRASOUND SCANNERS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11040185",
          "display" : "ULTRASOUND SCANNERS - CONSUMABLES"
        },
        {
          "code" : "Z11040192",
          "display" : "ULTRASOUND SCANNERS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11040199",
          "display" : "ULTRASOUND SCANNERS - OTHER"
        }]
      },
      {
        "code" : "Z110402",
        "display" : "ULTRASOUND PROBES",
        "concept" : [{
          "code" : "Z11040201",
          "display" : "TRANSCUTANEOUS ULTRASOUND PROBES",
          "concept" : [{
            "code" : "Z1104020101",
            "display" : "LINEAR–ARRAY TRANSCUTANEOUS ULTRASOUND PROBES",
            "concept" : [{
              "code" : "Z110402010101",
              "display" : "TWO–DIMENSIONAL LINEAR–ARRAY TRANSCUTANEOUS ULTRASOUND PROBES"
            },
            {
              "code" : "Z110402010102",
              "display" : "MULTIDIMENSIONAL LINEAR–ARRAY TRANSCUTANEOUS ULTRASOUND PROBES"
            }]
          },
          {
            "code" : "Z1104020102",
            "display" : "CURVILINEAR TRANSCUTANEOUS ULTRASOUND PROBES (CONVEX–ARRAY)",
            "concept" : [{
              "code" : "Z110402010201",
              "display" : "CURVILINEAR TRANSCUTANEOUS TWO–DIMENSIONAL ULTRASOUND PROBES  (CONVEX–ARRAY)"
            },
            {
              "code" : "Z110402010202",
              "display" : "CURVILINEAR TRANSCUTANEOUS MULTIDIMENSIONAL ULTRASOUND PROBES  (CONVEX–ARRAY)"
            }]
          },
          {
            "code" : "Z1104020103",
            "display" : "TRANSCUTANEOUS ULTRASOUND SECTOR PROBES (PHASED ARRAY)",
            "concept" : [{
              "code" : "Z110402010301",
              "display" : "TRANSCUTANEOUS ULTRASOUND SECTOR PROBES (PHASED ARRAY), TWO–DIMENSIONAL"
            },
            {
              "code" : "Z110402010302",
              "display" : "TRANSCUTANEOUS ULTRASOUND SECTOR PROBES (PHASED ARRAY), MULTIDIMENSIONAL"
            }]
          },
          {
            "code" : "Z1104020104",
            "display" : "TRANSCUTANEOUS ULTRASOUND ACTIVE MATRIX PROBES",
            "concept" : [{
              "code" : "Z110402010401",
              "display" : "TRANSCUTANEOUS ULTRASOUND ACTIVE MATRIX PROBES, TWO–DIMENSIONAL"
            },
            {
              "code" : "Z110402010402",
              "display" : "TRANSCUTANEOUS ULTRASOUND ACTIVE MATRIX PROBES, MULTIDIMENSIONAL"
            }]
          },
          {
            "code" : "Z1104020105",
            "display" : "CMUT ARRAY TRANSCUTANEOUS ULTRASOUND PROBES",
            "concept" : [{
              "code" : "Z110402010501",
              "display" : "CMUT ARRAY TRANSCUTANEOUS ULTRASOUND PROBES, TWO–DIMENSIONAL"
            },
            {
              "code" : "Z110402010502",
              "display" : "CMUT ARRAY TRANSCUTANEOUS ULTRASOUND PROBES, MULTIDIMENSIONAL"
            }]
          }]
        },
        {
          "code" : "Z11040202",
          "display" : "ENDOCAVITARY ULTRASOUND PROBES",
          "concept" : [{
            "code" : "Z1104020201",
            "display" : "ENDOCAVITARY ULTRASOUND PROBES, TWO–DIMENSIONAL"
          },
          {
            "code" : "Z1104020202",
            "display" : "ENDOCAVITARY ULTRASOUND PROBES, MULTIDIMENSIONAL"
          }]
        },
        {
          "code" : "Z11040203",
          "display" : "TRANSESOPHAGEAL ULTRASOUND PROBES",
          "concept" : [{
            "code" : "Z1104020301",
            "display" : "TRANSESOPHAGEAL ULTRASOUND PROBES, TWO–DIMENSIONAL"
          },
          {
            "code" : "Z1104020302",
            "display" : "TRANSESOPHAGEAL ULTRASOUND PROBES, MULTIDIMENSIONAL"
          }]
        },
        {
          "code" : "Z11040299",
          "display" : "ULTRASOUND PROBES – OTHER"
        }]
      },
      {
        "code" : "Z110490",
        "display" : "VARIOUS ULTRASOUND INSTRUMENTS",
        "concept" : [{
          "code" : "Z11049080",
          "display" : "VARIOUS ULTRASOUND INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11049082",
          "display" : "VARIOUS ULTRASOUND INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11049085",
          "display" : "VARIOUS ULTRASOUND INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11049092",
          "display" : "VARIOUS ULTRASOUND INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11049099",
          "display" : "VARIOUS ULTRASOUND INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1105",
      "display" : "MAGNETIC RESONANCE IMAGING (MRI) INSTRUMENTS",
      "concept" : [{
        "code" : "Z110501",
        "display" : "MAGNETIC RESONANCE (MR) SYSTEMS",
        "concept" : [{
          "code" : "Z11050101",
          "display" : "SECTORAL TOMOGRAPHS (FOR TOMOGRAPHIC EXAMINATIONS OF THE EXTREMITIES)"
        },
        {
          "code" : "Z11050102",
          "display" : "OPEN MAGNET MRI SCANNERS WITH MAGNETIC FIELD INTENSITY LESS THAN OR EQUAL TO 0.5T"
        },
        {
          "code" : "Z11050103",
          "display" : "OPEN MAGNET MRI SCANNERS WITH MAGNETIC FIELD INTENSITY GREATER THAN 0.5T"
        },
        {
          "code" : "Z11050104",
          "display" : "CLOSED MAGNET MRI SCANNERS WITH MAGNETIC FIELD LESS THAN OR EQUAL TO 2T"
        },
        {
          "code" : "Z11050105",
          "display" : "CLOSED MAGNET MRI SCANNERS WITH MAGNETIC FIELD GREATER THAN 2T AND LESS THAN OR EQUAL TO 4T"
        },
        {
          "code" : "Z11050106",
          "display" : "CLOSED MAGNET MRI SCANNERS WITH MAGNETIC FIELD GREATER THAN 4T"
        },
        {
          "code" : "Z11050180",
          "display" : "MAGNETIC RESONANCE (MR) SYSTEMS - HARDWARE ACCESSORIES",
          "concept" : [{
            "code" : "Z1105018001",
            "display" : "MAGNETIC RESONANCE (MR) RADIOFREQUENCY SURFACE COILS"
          },
          {
            "code" : "Z1105018002",
            "display" : "MAGNETIC RESONANCE (MR) RADIOFREQUENCY VOLUMETRIC COILS"
          },
          {
            "code" : "Z1105018099",
            "display" : "MAGNETIC RESONANCE (MR) SYSTEMS - HARDWARE ACCESSORIES - OTHER"
          }]
        },
        {
          "code" : "Z11050182",
          "display" : "MMAGNETIC RESONANCE (MR) SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11050185",
          "display" : "MAGNETIC RESONANCE (MR) SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z11050192",
          "display" : "MAGNETIC RESONANCE (MR) SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110590",
        "display" : "VARIOUS MAGNETIC RESONANCE IMAGING (MRI) INSTRUMENTS",
        "concept" : [{
          "code" : "Z11059001",
          "display" : "MAGNETIC RESONANCE INJECTORS"
        },
        {
          "code" : "Z11059080",
          "display" : "VARIOUS MAGNETIC RESONANCE IMAGING INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11059082",
          "display" : "VARIOUS MAGNETIC RESONANCE IMAGING INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11059085",
          "display" : "VARIOUS MAGNETIC RESONANCE IMAGING INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11059092",
          "display" : "VARIOUS MAGNETIC RESONANCE IMAGING INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11059099",
          "display" : "VARIOUS MAGNETIC RESONANCE IMAGING INSTRUMENTS – OTHER"
        }]
      }]
    },
    {
      "code" : "Z1106",
      "display" : "DIGITAL BIOIMAGING MANAGEMENT INSTRUMENTS",
      "concept" : [{
        "code" : "Z110601",
        "display" : "LASER IMAGING SCANNER"
      },
      {
        "code" : "Z110602",
        "display" : "DIGITAL COMPUTED RADIOGRAPHY (CR) SYSTEMS",
        "concept" : [{
          "code" : "Z11060201",
          "display" : "SINGLE-INPUT COMPUTED RADIOGRAPHY (CR) SYSTEMS"
        },
        {
          "code" : "Z11060202",
          "display" : "MULTIPLE-INPUT COMPUTED RADIOGRAPHY (CR) SYSTEMS"
        },
        {
          "code" : "Z11060280",
          "display" : "DIGITAL COMPUTED RADIOGRAPHY (CR) SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11060282",
          "display" : "DIGITAL COMPUTED RADIOGRAPHY (CR) SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11060285",
          "display" : "DIGITAL COMPUTED RADIOGRAPHY (CR) SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z11060292",
          "display" : "DIGITAL COMPUTED RADIOGRAPHY (CR) SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z110603",
        "display" : "PICTURE ARCHIVING AND COMMUNICATION SYSTEMS"
      },
      {
        "code" : "Z110690",
        "display" : "VARIOUS DIGITAL BIOIMAGING MANAGEMENT INSTRUMENTS",
        "concept" : [{
          "code" : "Z11069001",
          "display" : "BIOIMAGING PROCESSORS"
        },
        {
          "code" : "Z11069002",
          "display" : "JUKE BOXES FOR OPTICAL DISKS"
        },
        {
          "code" : "Z11069003",
          "display" : "BIOIMAGING SERVERS"
        },
        {
          "code" : "Z11069004",
          "display" : "IDENTIFICATION STATIONS"
        },
        {
          "code" : "Z11069005",
          "display" : "DIAGNOSTIC IMAGING WORKSTATIONS"
        },
        {
          "code" : "Z11069080",
          "display" : "VARIOUS DIGITAL BIOIMAGING MANAGEMENT INSTRUMENTS - HARDWARE"
        },
        {
          "code" : "Z11069082",
          "display" : "VARIOUS DIGITAL BIOIMAGING MANAGEMENT INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11069085",
          "display" : "VARIOUS DIGITAL BIOIMAGING MANAGEMENT INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11069092",
          "display" : "VARIOUS DIGITAL BIOIMAGING MANAGEMENT INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11069099",
          "display" : "VARIOUS DIGITAL BIOIMAGING MANAGEMENT INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1107",
      "display" : "X–RAY FILM IMAGING SUPPORT INSTRUMENTS",
      "concept" : [{
        "code" : "Z110701",
        "display" : "AUTOMATIC FILM LOADING SYSTEMS"
      },
      {
        "code" : "Z110702",
        "display" : "DIAPHANOSCOPE"
      },
      {
        "code" : "Z110703",
        "display" : "X–RAY FILM VIEWER"
      },
      {
        "code" : "Z110704",
        "display" : "X–RAY FILM PLAYERS"
      },
      {
        "code" : "Z110705",
        "display" : "LASER IMAGERS FOR BIOIMAGING"
      },
      {
        "code" : "Z110706",
        "display" : "VIDEO OR DIGITAL BIOIMAGING PLAYERS"
      },
      {
        "code" : "Z110707",
        "display" : "PROCESSORS",
        "concept" : [{
          "code" : "Z11070701",
          "display" : "TRADITIONAL PROCESSORS"
        },
        {
          "code" : "Z11070702",
          "display" : "DAY-LIGHT PROCESSORS"
        },
        {
          "code" : "Z11070780",
          "display" : "PROCESSORS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11070785",
          "display" : "PROCESSORS - CONSUMABLES"
        }]
      },
      {
        "code" : "Z110790",
        "display" : "VARIOUS SUPPORTING INSTRUMENTS FOR X–RAY FILM IMAGING",
        "concept" : [{
          "code" : "Z11079001",
          "display" : "X–RAY FILM DENSITOMETERS"
        },
        {
          "code" : "Z11079002",
          "display" : "SENSITOMETERS AND DENSITOMETERS FOR X–RAY FILMS"
        },
        {
          "code" : "Z11079003",
          "display" : "X–RAY SENSITOMETERS"
        },
        {
          "code" : "Z11079004",
          "display" : "LIQUID MIXERS FOR PROCESSORS"
        },
        {
          "code" : "Z11079005",
          "display" : "PRINTING MACHINES"
        },
        {
          "code" : "Z11079006",
          "display" : "CASSETTES WITH REINFORCEMENT SCREEN FOR X–RAY FILMS"
        },
        {
          "code" : "Z11079007",
          "display" : "CASSETTES FOR X–RAY FILMS"
        },
        {
          "code" : "Z11079008",
          "display" : "REINFORCEMENT SCREENS FOR X–RAY FILM CASSETTES"
        },
        {
          "code" : "Z11079080",
          "display" : "VARIOUS SUPPORTING INSTRUMENTS FOR X-RAY FILM SYSTEM - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11079082",
          "display" : "VARIOUS X-RAY FILM IMAGING SUPPORT INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11079085",
          "display" : "VARIOUS X-RAY FILM IMAGING SUPPORT INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z11079092",
          "display" : "VARIOUS X-RAY FILM IMAGING SUPPORT INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z11079099",
          "display" : "VARIOUS X–RAY FILM IMAGING SUPPORT INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1190",
      "display" : "VARIOUS BIOIMAGING AND RADIOTHERAPY INSTRUMENTS",
      "concept" : [{
        "code" : "Z119001",
        "display" : "BONE DENSITOMETRY SYSTEMS",
        "concept" : [{
          "code" : "Z11900101",
          "display" : "GAMMA–RAY BONE DENSITOMETERS"
        },
        {
          "code" : "Z11900102",
          "display" : "ULTRASOUND BONE DENSITOMETERS"
        },
        {
          "code" : "Z11900103",
          "display" : "X–RAY BONE DENSITOMETERS"
        },
        {
          "code" : "Z11900180",
          "display" : "BONE DENSITOMETRY SYSTEMS - HARDWARE"
        },
        {
          "code" : "Z11900182",
          "display" : "BONE DENSITOMETRY SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z11900185",
          "display" : "BONE DENSITOMETRY SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z11900192",
          "display" : "BONE DENSITOMETRY SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z119002",
        "display" : "DOSIMETERS"
      },
      {
        "code" : "Z119003",
        "display" : "BIOIMAGING PHOTOGRAPHY INSTRUMENTS"
      },
      {
        "code" : "Z119004",
        "display" : "MICROFILM IMAGE READERS"
      },
      {
        "code" : "Z119005",
        "display" : "PERSONAL DOSIMETER READERS"
      },
      {
        "code" : "Z119007",
        "display" : "IMAGE ACQUISITION MODULES"
      },
      {
        "code" : "Z119008",
        "display" : "BIOIMAGING VISUALIZATION AND/OR DIAGNOSTIC REPORT VIEWING MONITORS",
        "concept" : [{
          "code" : "Z11900801",
          "display" : "BIOIMAGING DIAGNOSTIC REPORT VIEWING MONITORS"
        },
        {
          "code" : "Z11900802",
          "display" : "BIOIMAGING VIEWING MONITORS"
        },
        {
          "code" : "Z11900880",
          "display" : "BIOIMAGING VISUALIZATION AND/OR DIAGNOSTIC REPORT VIEWING MONITORS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z11900885",
          "display" : "BIOIMAGING VISUALIZATION AND/OR DIAGNOSTIC REPORT VIEWING MONITORS- CONSUMABLES ACCESSORIES"
        }]
      },
      {
        "code" : "Z119010",
        "display" : "LASER SYSTEMS FOR PATIENT POSITIONING"
      },
      {
        "code" : "Z119011",
        "display" : "MAMMOGRAPHY ECOGRAPHY OR RADIOGRAPHY STEREOTACTIC SYSTEMS"
      },
      {
        "code" : "Z119012",
        "display" : "CLOSED CIRCUIT TELEVISION SYSTEMS"
      },
      {
        "code" : "Z119013",
        "display" : "THERMOGRAPHS"
      },
      {
        "code" : "Z119014",
        "display" : "VIDEO RECORDERS FOR BIOIMAGES"
      },
      {
        "code" : "Z119080",
        "display" : "VARIOUS BIOIMAGING AND RADIOTHERAPY INSTRUMENTS - HARDWARE ACCESSORIES"
      },
      {
        "code" : "Z119082",
        "display" : "VARIOUS BIOIMAGING AND RADIOTHERAPY INSTRUMENTS - SOFTWARE ACCESSORIES"
      },
      {
        "code" : "Z119085",
        "display" : "VARIOUS BIOIMAGING AND RADIOTHERAPY INSTRUMENTS - CONSUMABLES"
      },
      {
        "code" : "Z119092",
        "display" : "VARIOUS BIOIMAGING AND RADIOTHERAPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
      },
      {
        "code" : "Z119099",
        "display" : "VARIOUS BIOIMAGING AND RADIOTHERAPY INSTRUMENTS - OTHER"
      }]
    }]
  },
  {
    "code" : "Z12",
    "display" : "INSTRUMENTS FOR FUNCTIONAL EXPLORATIONS AND THERAPEUTIC INTERVENTIONS",
    "concept" : [{
      "code" : "Z1201",
      "display" : "GENERAL AND MULTIDISCIPLINARY SURGERY INSTRUMENTS",
      "concept" : [{
        "code" : "Z120101",
        "display" : "ARTERIOTOMY ABLATORS"
      },
      {
        "code" : "Z120102",
        "display" : "CRYOSURGERY EQUIPMENT"
      },
      {
        "code" : "Z120103",
        "display" : "DERMOTOMY EQUIPMENT"
      },
      {
        "code" : "Z120104",
        "display" : "SELF–TRANSFUSION EQUIPMENT"
      },
      {
        "code" : "Z120105",
        "display" : "SURGICAL MEDICAL ASPIRATORS"
      },
      {
        "code" : "Z120106",
        "display" : "HYDRODISSECTORS"
      },
      {
        "code" : "Z120107",
        "display" : "SCIALYTIC LAMP LIGHTING SYSTEMS",
        "concept" : [{
          "code" : "Z12010701",
          "display" : "FIXED SCIALYTIC LAMPS"
        },
        {
          "code" : "Z12010702",
          "display" : "MOBILE SCIALYTIC LAMPS"
        },
        {
          "code" : "Z12010780",
          "display" : "SCIALYTIC LAMP LIGHTING SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12010785",
          "display" : "SCIALYTIC LAMP LIGHTING SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z12010799",
          "display" : "SCIALYTIC LAMP LIGHTING SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "Z120108",
        "display" : "INSTRUMENTS FOR ULTRASONIC SURGERY",
        "concept" : [{
          "code" : "Z12010801",
          "display" : "ULTRASONIC SCALPEL"
        },
        {
          "code" : "Z12010880",
          "display" : "INSTRUMENTS FOR ULTRASONIC SURGERY - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12010882",
          "display" : "INSTRUMENTS FOR ULTRASONIC SURGERY - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12010885",
          "display" : "INSTRUMENTS FOR ULTRASONIC SURGERY - CONSUMABLES"
        },
        {
          "code" : "Z12010892",
          "display" : "INSTRUMENTS FOR ULTRASONIC SURGERY - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120109",
        "display" : "ELECTROSURGICAL INSTRUMENTS",
        "concept" : [{
          "code" : "Z12010901",
          "display" : "DIATHERMOCOAGULATORS"
        },
        {
          "code" : "Z12010902",
          "display" : "ELECTROSURGICAL UNITS (ESU) FOR GENERAL USE"
        },
        {
          "code" : "Z12010903",
          "display" : "ARGON ELECTROSURGICAL UNITS (ESU)"
        },
        {
          "code" : "Z12010904",
          "display" : "ENDOSCOPIC ELECTROSURGICAL UNITS (ESU)"
        },
        {
          "code" : "Z12010905",
          "display" : "RADIOSURGICAL UNITS"
        },
        {
          "code" : "Z12010980",
          "display" : "ELECTROSURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12010982",
          "display" : "ELECTROSURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12010985",
          "display" : "ELECTROSURGERY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12010992",
          "display" : "ELECTROSURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12010999",
          "display" : "ELECTROSURGERY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120110",
        "display" : "LASER SURGERY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12011001",
          "display" : "EXCIMER SURGICAL LASER"
        },
        {
          "code" : "Z12011002",
          "display" : "CARBON MONOXIDE SURGICAL LASER"
        },
        {
          "code" : "Z12011003",
          "display" : "HOLMIUM SURGICAL LASER"
        },
        {
          "code" : "Z12011004",
          "display" : "KRYPTON SURGICAL LASER"
        },
        {
          "code" : "Z12011005",
          "display" : "CARBON DIOXIDE SURGICAL LASER"
        },
        {
          "code" : "Z12011006",
          "display" : "DIODE–PUMPED SOLID–STATE (DPSS) SURGICAL LASER"
        },
        {
          "code" : "Z12011007",
          "display" : "DYE SURGICAL LASER"
        },
        {
          "code" : "Z12011008",
          "display" : "HELIUM/NEON SURGICAL LASER"
        },
        {
          "code" : "Z12011009",
          "display" : "COPPER VAPOUR SURGICAL LASER"
        },
        {
          "code" : "Z12011010",
          "display" : "ARGON/KRYPTON SURGICAL LASER"
        },
        {
          "code" : "Z12011011",
          "display" : "KTP SURGICAL LASER"
        },
        {
          "code" : "Z12011012",
          "display" : "DYE/ALEXANDRITE SURGICAL LASER"
        },
        {
          "code" : "Z12011013",
          "display" : "ARGON SURGICAL LASER"
        },
        {
          "code" : "Z12011014",
          "display" : "ERBIUM SURGICAL LASER"
        },
        {
          "code" : "Z12011015",
          "display" : "RUBIDIUM SURGICAL LASER"
        },
        {
          "code" : "Z12011016",
          "display" : "DIODE SURGICAL LASER"
        },
        {
          "code" : "Z12011017",
          "display" : "NEODYMIUM SURGICAL LASER"
        },
        {
          "code" : "Z12011018",
          "display" : "HELIUM/CADMIUM SURGICAL LASER"
        },
        {
          "code" : "Z12011019",
          "display" : "MULTI–PLATFORM LASER"
        },
        {
          "code" : "Z12011080",
          "display" : "LASER SURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12011082",
          "display" : "LASER SURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12011085",
          "display" : "LASER SURGERY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12011092",
          "display" : "LASER SURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12011099",
          "display" : "LASER SURGERY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120111",
        "display" : "INSTRUMENTS FOR OPERATIVE MICROSCOPY",
        "concept" : [{
          "code" : "Z12011101",
          "display" : "OPERATIVE MICROSCOPES"
        },
        {
          "code" : "Z12011180",
          "display" : "INSTRUMENTS FOR OPERATIVE MICROSCOPY - HARDWARE ACCESSORIES",
          "concept" : [{
            "code" : "Z1201118001",
            "display" : "STANDS FOR OPERATIVE MICROSCOPY"
          },
          {
            "code" : "Z1201118099",
            "display" : "INSTRUMENTS FOR OPERATIVE MICROSCOPY - HARDWARE ACCESSORIES - OTHER"
          }]
        },
        {
          "code" : "Z12011182",
          "display" : "INSTRUMENTS FOR OPERATIVE MICROSCOPY - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12011185",
          "display" : "INSTRUMENTS FOR OPERATIVE MICROSCOPY - CONSUMABLES"
        },
        {
          "code" : "Z12011192",
          "display" : "INSTRUMENTS FOR OPERATIVE MICROSCOPY - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12011199",
          "display" : "INSTRUMENTS FOR OPERATIVE MICROSCOPY – OTHER"
        }]
      },
      {
        "code" : "Z120112",
        "display" : "PATIENT POSITIONING INSTRUMENTS",
        "concept" : [{
          "code" : "Z12011201",
          "display" : "OPERATING CHAIRS"
        },
        {
          "code" : "Z12011202",
          "display" : "OPERATING TABLES"
        },
        {
          "code" : "Z12011280",
          "display" : "PATIENT POSITIONING INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12011285",
          "display" : "PATIENT POSITIONING INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12011299",
          "display" : "PATIENT POSITIONING INSTRUMENTS – OTHER"
        }]
      },
      {
        "code" : "Z120113",
        "display" : "CLEANING, DISINFECTION AND STERILISATION INSTRUMENTS",
        "concept" : [{
          "code" : "Z12011301",
          "display" : "CLEANING AND DISINFECTION EQUIPMENT"
        },
        {
          "code" : "Z12011302",
          "display" : "ULTRASONIC CLEANING EQUIPMENT"
        },
        {
          "code" : "Z12011303",
          "display" : "CHEMICAL STERILISATION EQUIPMENT"
        },
        {
          "code" : "Z12011304",
          "display" : "AUTOCLAVES WITH A CHAMBER LARGER THAN OR EQUAL TO 1 STANDARD STERILISATION UNIT"
        },
        {
          "code" : "Z12011305",
          "display" : "SMALL LOAD AUTOCLAVES WITH A CHAMBER SMALLER THAN 1 STANDARD STERILISATION UNIT"
        },
        {
          "code" : "Z12011306",
          "display" : "CLEANING AND DECONTAMINATION SYSTEMS FOR GENERAL AND MULTIDISCIPLINARY SURGERY INSTRUMENTS"
        },
        {
          "code" : "Z12011307",
          "display" : "DRY AIR STERILISERS"
        },
        {
          "code" : "Z12011309",
          "display" : "PLASMA STERILISERS"
        },
        {
          "code" : "Z12011310",
          "display" : "RADIATION STERILISERS",
          "concept" : [{
            "code" : "Z1201131001",
            "display" : "RADIATION STERILISERS, X–RAY"
          },
          {
            "code" : "Z1201131002",
            "display" : "RADIATION STERILISERS, GAMMA–RAY"
          },
          {
            "code" : "Z1201131003",
            "display" : "RADIATION STERILISERS, MICROWAVE"
          },
          {
            "code" : "Z1201131099",
            "display" : "RADIATION STERILISERS - OTHER"
          }]
        },
        {
          "code" : "Z12011311",
          "display" : "ENDOSCOPE WASHERS"
        },
        {
          "code" : "Z12011312",
          "display" : "ENDOSCOPE DRYERS"
        },
        {
          "code" : "Z12011313",
          "display" : "ENDOSCOPE STERILISERS"
        },
        {
          "code" : "Z12011314",
          "display" : "ENDOSCOPE DRYING CABINETS AND STORAGE"
        },
        {
          "code" : "Z12011380",
          "display" : "CLEANING, DISINFECTION AND STERILISATION INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12011382",
          "display" : "CLEANING, DISINFECTION AND STERILISATION INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12011385",
          "display" : "CLEANING, DISINFECTION AND STERILISATION INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12011392",
          "display" : "CLEANING, DISINFECTION AND STERILISATION INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12011399",
          "display" : "CLEANING, DISINFECTION AND STERILISATION INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120114",
        "display" : "SURGICAL NAVIGATION INSTRUMENTS",
        "concept" : [{
          "code" : "Z12011401",
          "display" : "SURGICAL NAVIGATION SYSTEM"
        },
        {
          "code" : "Z12011480",
          "display" : "SURGICAL NAVIGATION INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12011482",
          "display" : "SURGICAL NAVIGATION INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12011485",
          "display" : "SURGICAL NAVIGATION INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12011492",
          "display" : "SURGICAL NAVIGATION INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120190",
        "display" : "VARIOUS INSTRUMENTS FOR GENERAL AND MULTIDISCIPLINARY SURGERY",
        "concept" : [{
          "code" : "Z12019001",
          "display" : "SURGICAL WIRE APPLICATION EQUIPMENT"
        },
        {
          "code" : "Z12019002",
          "display" : "EQUIPMENT FOR THE TRANSPORT OF ORGANIC MATERIAL"
        },
        {
          "code" : "Z12019003",
          "display" : "WOUND TREATMENT EQUIPMENT"
        },
        {
          "code" : "Z12019004",
          "display" : "SURGICAL SMOKE EVACUATION SYSTEMS"
        },
        {
          "code" : "Z12019005",
          "display" : "DERMOGRAPHS"
        },
        {
          "code" : "Z12019006",
          "display" : "PHOTOCOAGULATORS"
        },
        {
          "code" : "Z12019007",
          "display" : "IRRIGATORS"
        },
        {
          "code" : "Z12019008",
          "display" : "BLOOD HEATERS"
        },
        {
          "code" : "Z12019009",
          "display" : "THAWING UNITS"
        },
        {
          "code" : "Z12019010",
          "display" : "PATIENT TRANSFER SYSTEMS"
        },
        {
          "code" : "Z12019080",
          "display" : "VARIOUS INSTRUMENTS FOR GENERAL AND MULTIDISCIPLINARY SURGERY - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12019082",
          "display" : "VARIOUS INSTRUMENTS FOR GENERAL AND MULTIDISCIPLINARY SURGERY - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12019085",
          "display" : "VARIOUS INSTRUMENTS FOR GENERAL AND MULTIDISCIPLINARY SURGERY - CONSUMABLES"
        },
        {
          "code" : "Z12019092",
          "display" : "VARIOUS INSTRUMENTS FOR GENERAL AND MULTIDISCIPLINARY SURGERY - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12019099",
          "display" : "VARIOUS INSTRUMENTS FOR GENERAL AND MULTIDISCIPLINARY SURGERY - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1202",
      "display" : "ENDOSCOPIC AND MINIMALLY INVASIVE SURGERY INSTRUMENTS",
      "concept" : [{
        "code" : "Z120201",
        "display" : "REMOTE CONTROL ROBOTIC ENDOSCOPIC SURGERY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12020101",
          "display" : "ROBOT-ASSISTED ENDOSCOPIC SURGERY SYSTEMS"
        },
        {
          "code" : "Z12020180",
          "display" : "REMOTE CONTROL ROBOT-ASSISTED ENDOSCOPIC SURGERY INSTRUMENTS - HARDWARE ACCESSORIES",
          "concept" : [{
            "code" : "Z1202018001",
            "display" : "ROBOTIC ARMS FOR VIDEOENDOSCOPY"
          },
          {
            "code" : "Z1202018002",
            "display" : "COMMAND CONSOLES FOR ENDOSCOPIC SURGERY"
          },
          {
            "code" : "Z1202018099",
            "display" : "REMOTE CONTROL ROBOT-ASSISTED ENDOSCOPIC SURGERY INSTRUMENTS - HARDWARE ACCESSORIES - OTHER"
          }]
        },
        {
          "code" : "Z12020182",
          "display" : "REMOTE CONTROL ROBOTIC ENDOSCOPIC SURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12020185",
          "display" : "REMOTE CONTROL ROBOT-ASSISTED ENDOSCOPIC SURGERY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12020192",
          "display" : "REMOTE CONTROL ROBOT-ASSISTED ENDOSCOPIC SURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12020199",
          "display" : "REMOTE CONTROL ROBOT-ASSISTED ENDOSCOPIC SURGERY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120202",
        "display" : "MOTORISED INSTRUMENTS FOR ENDOSCOPIC SURGERY",
        "concept" : [{
          "code" : "Z12020201",
          "display" : "MOTORISED SYSTEMS FOR ENDOSCOPIC SURGERY"
        },
        {
          "code" : "Z12020280",
          "display" : "MOTORISED INSTRUMENTS FOR ENDOSCOPIC SURGERY - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12020282",
          "display" : "MOTORISED INSTRUMENTS FOR ENDOSCOPIC SURGERY - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12020285",
          "display" : "MOTORISED INSTRUMENTS FOR ENDOSCOPIC SURGERY - CONSUMABLES"
        },
        {
          "code" : "Z12020292",
          "display" : "MOTORISED INSTRUMENTS FOR ENDOSCOPIC SURGERY - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120203",
        "display" : "ENDOSCOPIC LITHOTRIPSY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12020301",
          "display" : "ELECTROMECHANICAL ENDOSCOPIC LITHOTRIPTERS"
        },
        {
          "code" : "Z12020302",
          "display" : "ULTRASONIC ENDOSCOPIC LITHOTRIPTERS"
        },
        {
          "code" : "Z12020303",
          "display" : "ELECTROHYDRAULIC ENDOSCOPIC LITHOTRIPTERS"
        },
        {
          "code" : "Z12020304",
          "display" : "LASER ENDOSCOPIC LITHOTRIPTERS"
        },
        {
          "code" : "Z12020380",
          "display" : "ENDOSCOPIC LITHOTRIPSY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12020382",
          "display" : "ENDOSCOPIC LITHOTRIPSY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12020385",
          "display" : "ENDOSCOPIC LITHOTRIPSY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12020392",
          "display" : "ENDOSCOPIC LITHOTRIPSY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120204",
        "display" : "INSTRUMENTS FOR THE ACQUISITION AND MANAGEMENT OF ENDOSCOPIC AND MINIMALLY INVASIVE SURGERY IMAGES",
        "concept" : [{
          "code" : "Z12020401",
          "display" : "INTEGRATED SYSTEMS FOR THE ACQUISITION AND MANAGEMENT OF ENDOSCOPIC AND MINIMALLY INVASIVE SURGERY IMAGES"
        },
        {
          "code" : "Z12020402",
          "display" : "LIGHT SOURCES FOR ENDOSCOPY AND MINIMALLY INVASIVE SURGERY"
        },
        {
          "code" : "Z12020403",
          "display" : "MODULES FOR ENDOSCOPIC IMAGING AND MINIMALLY INVASIVE SURGERY"
        },
        {
          "code" : "Z12020404",
          "display" : "REMOTE CONTROL UNITS FOR ENDOSCOPY AND MINIMALLY INVASIVE SURGERY"
        },
        {
          "code" : "Z12020405",
          "display" : "SURGICAL CAMERAS"
        },
        {
          "code" : "Z12020406",
          "display" : "VIDEO PROCESSORS"
        },
        {
          "code" : "Z12020480",
          "display" : "INSTRUMENTS FOR THE ACQUISITION AND MANAGEMENT OF ENDOSCOPIC AND MINIMALLY INVASIVE SURGERY IMAGES - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12020482",
          "display" : "INSTRUMENTS FOR THE ACQUISITION AND MANAGEMENT OF ENDOSCOPIC AND MINIMALLY INVASIVE SURGERY IMAGES - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12020485",
          "display" : "INSTRUMENTS FOR THE ACQUISITION AND MANAGEMENT OF ENDOSCOPIC AND MINIMALLY INVASIVE SURGERY IMAGES - CONSUMABLES"
        },
        {
          "code" : "Z12020492",
          "display" : "INSTRUMENTS FOR THE ACQUISITION AND MANAGEMENT OF ENDOSCOPIC AND MINIMALLY INVASIVE SURGERY IMAGES - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12020499",
          "display" : "INSTRUMENTS FOR THE ACQUISITION AND MANAGEMENT OF ENDOSCOPIC AND MINIMALLY INVASIVE SURGERY IMAGES – OTHER"
        }]
      },
      {
        "code" : "Z120205",
        "display" : "UPPER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12020501",
          "display" : "CHOLEDOCOSCOPES"
        },
        {
          "code" : "Z12020502",
          "display" : "DUODENOSCOPES"
        },
        {
          "code" : "Z12020503",
          "display" : "ECHO–GASTROSCOPES"
        },
        {
          "code" : "Z12020504",
          "display" : "OESOPHAGOSCOPES"
        },
        {
          "code" : "Z12020505",
          "display" : "GASTRODUODENOSCOPES"
        },
        {
          "code" : "Z12020506",
          "display" : "GASTROSCOPES"
        },
        {
          "code" : "Z12020507",
          "display" : "VIDEO CHOLEDOCOSCOPES"
        },
        {
          "code" : "Z12020508",
          "display" : "VIDEO DUODENOSCOPES"
        },
        {
          "code" : "Z12020509",
          "display" : "VIDEO OESOPHAGOSCOPES"
        },
        {
          "code" : "Z12020510",
          "display" : "VIDEO GASTRODUODENOSCOPES"
        },
        {
          "code" : "Z12020511",
          "display" : "VIDEO GASTROSCOPES"
        },
        {
          "code" : "Z12020580",
          "display" : "UPPER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12020582",
          "display" : "UPPER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12020585",
          "display" : "UPPER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12020592",
          "display" : "UPPER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12020599",
          "display" : "UPPER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120206",
        "display" : "LOWER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12020601",
          "display" : "COLONOSCOPES"
        },
        {
          "code" : "Z12020602",
          "display" : "SIGMOIDOSCOPES"
        },
        {
          "code" : "Z12020603",
          "display" : "PROCTOSCOPES"
        },
        {
          "code" : "Z12020604",
          "display" : "ULTRASONIC PROCTOSCOPES"
        },
        {
          "code" : "Z12020605",
          "display" : "RECTOSCOPES"
        },
        {
          "code" : "Z12020606",
          "display" : "VIDEO COLONOSCOPES"
        },
        {
          "code" : "Z12020607",
          "display" : "VIDEO ENTEROSCOPES"
        },
        {
          "code" : "Z12020608",
          "display" : "VIDEO SIGMOIDOSCOPES"
        },
        {
          "code" : "Z12020680",
          "display" : "LOWER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12020682",
          "display" : "LOWER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12020685",
          "display" : "LOWER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12020692",
          "display" : "LOWER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12020699",
          "display" : "LOWER GASTROINTESTINAL TRACT ENDOSCOPY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120207",
        "display" : "GENITOURINARY ENDOSCOPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12020701",
          "display" : "CYSTOSCOPES"
        },
        {
          "code" : "Z12020702",
          "display" : "CYSTOURETHROSCOPES"
        },
        {
          "code" : "Z12020703",
          "display" : "COLPOSCOPES"
        },
        {
          "code" : "Z12020704",
          "display" : "HYSTEROSCOPES"
        },
        {
          "code" : "Z12020705",
          "display" : "NEPHROSCOPES"
        },
        {
          "code" : "Z12020706",
          "display" : "PELVISCOPES"
        },
        {
          "code" : "Z12020707",
          "display" : "RESECTOSCOPES"
        },
        {
          "code" : "Z12020708",
          "display" : "VIDEO COLPOSCOPY INSTRUMENTS",
          "concept" : [{
            "code" : "Z1202070801",
            "display" : "VIDEO COLPOSCOPY SYSTEMS"
          },
          {
            "code" : "Z1202070880",
            "display" : "VIDEO COLPOSCOPY INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1202070882",
            "display" : "VIDEO COLPOSCOPY INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1202070885",
            "display" : "VIDEO COLPOSCOPY INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1202070892",
            "display" : "VIDEO COLPOSCOPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "Z12020709",
          "display" : "UTEROSCOPES"
        },
        {
          "code" : "Z12020710",
          "display" : "VAGINOSCOPES"
        },
        {
          "code" : "Z12020711",
          "display" : "VIDEO CYSTOURETHROSCOPES"
        },
        {
          "code" : "Z12020712",
          "display" : "VIDEO HYSTEROSCOPES"
        },
        {
          "code" : "Z12020713",
          "display" : "URETERORENOSCOPES"
        },
        {
          "code" : "Z12020780",
          "display" : "GENITOURINARY ENDOSCOPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12020782",
          "display" : "GENITOURINARY ENDOSCOPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12020785",
          "display" : "GENITOURINARY ENDOSCOPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12020792",
          "display" : "GENITOURINARY ENDOSCOPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12020799",
          "display" : "GENITOURINARY ENDOSCOPY INSTRUMENTS – OTHER"
        }]
      },
      {
        "code" : "Z120208",
        "display" : "PULMONARY ENDOSCOPIC INSTRUMENTS",
        "concept" : [{
          "code" : "Z12020801",
          "display" : "BRONCHOSCOPES"
        },
        {
          "code" : "Z12020802",
          "display" : "VIDEO BRONCHOSCOPES"
        },
        {
          "code" : "Z12020880",
          "display" : "PULMONARY ENDOSCOPIC INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12020882",
          "display" : "PULMONARY ENDOSCOPIC INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12020885",
          "display" : "PULMONARY ENDOSCOPIC INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12020892",
          "display" : "PULMONARY ENDOSCOPIC INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12020899",
          "display" : "PULMONARY ENDOSCOPIC INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120209",
        "display" : "NEUROENDOSCOPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12020901",
          "display" : "ENCEPHALOSCOPES"
        },
        {
          "code" : "Z12020902",
          "display" : "NEUROSCOPES"
        },
        {
          "code" : "Z12020903",
          "display" : "SPINOSCOPES"
        },
        {
          "code" : "Z12020980",
          "display" : "NEUROENDOSCOPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12020982",
          "display" : "NEUROENDOSCOPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12020985",
          "display" : "NEUROENDOSCOPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12020992",
          "display" : "NEUROENDOSCOPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12020999",
          "display" : "NEUROENDOSCOPY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120210",
        "display" : "ENT ENDOSCOPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12021001",
          "display" : "PHARYNGOSCOPES"
        },
        {
          "code" : "Z12021002",
          "display" : "VIDEO PHARYNGOSCOPES"
        },
        {
          "code" : "Z12021003",
          "display" : "LARYNGOSCOPES"
        },
        {
          "code" : "Z12021004",
          "display" : "VIDEO LARYNGOSCOPES"
        },
        {
          "code" : "Z12021005",
          "display" : "NASAL PHARYNGO/LARYNGOSCOPES"
        },
        {
          "code" : "Z12021006",
          "display" : "VIDEO NASOPHARYNGO/LARYNGOSCOPES"
        },
        {
          "code" : "Z12021007",
          "display" : "MIDDLE EAR OTOSCOPES"
        },
        {
          "code" : "Z12021008",
          "display" : "RHINOSCOPES"
        },
        {
          "code" : "Z12021009",
          "display" : "DIRECT OUTPATIENT VIDEO-OTOSCOPES"
        },
        {
          "code" : "Z12021010",
          "display" : "LARYNGOSTROBOSCOPES"
        },
        {
          "code" : "Z12021011",
          "display" : "MOTORISED RHINOSCOPY SURGERY INSTRUMENTS",
          "concept" : [{
            "code" : "Z1202101101",
            "display" : "MOTORISED RHINOSCOPY SURGERY SYSTEMS"
          },
          {
            "code" : "Z1202101180",
            "display" : "MOTORISED RHINOSCOPY SURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1202101182",
            "display" : "MOTORISED RHINOSCOPY SURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1202101185",
            "display" : "MOTORISED RHINOSCOPY SURGERY INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1202101192",
            "display" : "MOTORISED RHINOSCOPY SURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "Z12021080",
          "display" : "ENT ENDOSCOPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12021082",
          "display" : "ENT ENDOSCOPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12021085",
          "display" : "ENT ENDOSCOPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12021092",
          "display" : "ENT ENDOSCOPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12021099",
          "display" : "ENT ENDOSCOPY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120211",
        "display" : "ORTHOPAEDIC ENDOSCOPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12021101",
          "display" : "ARTHROSCOPES"
        },
        {
          "code" : "Z12021102",
          "display" : "MOTORISED ARTHROSCOPIC SURGERY INSTRUMENTS",
          "concept" : [{
            "code" : "Z1202110201",
            "display" : "MOTORISED ARTHROSCOPIC SURGERY SYSTEMS"
          },
          {
            "code" : "Z1202110280",
            "display" : "MOTORISED ARTHROSCOPIC SURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1202110282",
            "display" : "MOTORISED ARTHROSCOPIC SURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1202110285",
            "display" : "MOTORISED ARTHROSCOPIC SURGERY INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1202110292",
            "display" : "MOTORISED ARTHROSCOPIC SURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "Z12021180",
          "display" : "ORTHOPAEDIC ENDOSCOPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12021182",
          "display" : "ORTHOPAEDIC ENDOSCOPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12021185",
          "display" : "ORTHOPAEDIC ENDOSCOPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12021192",
          "display" : "ORTHOPAEDIC ENDOSCOPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12021199",
          "display" : "ORTHOPAEDIC ENDOSCOPY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120212",
        "display" : "ENDOSCOPIC CAPSULES INSTRUMENTS",
        "concept" : [{
          "code" : "Z12021201",
          "display" : "ENDOSCOPIC CAPSULES"
        },
        {
          "code" : "Z12021202",
          "display" : "ENDOSCOPIC CAPSULE SIGNAL RECEIVERS"
        },
        {
          "code" : "Z12021280",
          "display" : "ENDOSCOPIC CAPSULE SIGNAL RECEIVERS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12021282",
          "display" : "ENDOSCOPIC CAPSULE SIGNAL RECEIVERS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12021285",
          "display" : "ENDOSCOPIC CAPSULE SIGNAL RECEIVERS - CONSUMABLES"
        },
        {
          "code" : "Z12021292",
          "display" : "ENDOSCOPIC CAPSULE SIGNAL RECEIVERS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120290",
        "display" : "VARIOUS INSTRUMENTS FOR ENDOSCOPY AND MINI-INVASIVE SURGERY",
        "concept" : [{
          "code" : "Z12029001",
          "display" : "AMNIOSCOPES"
        },
        {
          "code" : "Z12029002",
          "display" : "ANGIOSCOPES"
        },
        {
          "code" : "Z12029003",
          "display" : "ENDOSCOPE TRANSPORT CARTS"
        },
        {
          "code" : "Z12029004",
          "display" : "LACRIMAL DUCT ENDOSCOPES"
        },
        {
          "code" : "Z12029005",
          "display" : "MAMMARY DUCT ENDOSCOPES"
        },
        {
          "code" : "Z12029006",
          "display" : "FIBROSCOPES FOR INTUBATION"
        },
        {
          "code" : "Z12029007",
          "display" : "INFRA–RED SURGICAL ILLUMINATORS"
        },
        {
          "code" : "Z12029008",
          "display" : "GAS INFLATORS"
        },
        {
          "code" : "Z12029009",
          "display" : "LAPAROSCOPES"
        },
        {
          "code" : "Z12029011",
          "display" : "OPTICAL HEATERS"
        },
        {
          "code" : "Z12029012",
          "display" : "ENDOSCOPIC PHLEBOTOMY SYSTEMS WITH TRANSILLUMINATION"
        },
        {
          "code" : "Z12029014",
          "display" : "GAS PRE–HEATING UNITS"
        },
        {
          "code" : "Z12029015",
          "display" : "LENS CLEANING UNITS"
        },
        {
          "code" : "Z12029016",
          "display" : "VIDEO LAPAROSCOPES"
        },
        {
          "code" : "Z12029017",
          "display" : "THORACOSCOPES"
        },
        {
          "code" : "Z12029080",
          "display" : "VARIOUS INSTRUMENTS FOR ENDOSCOPY AND MINI-INVASIVE SURGERY - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12029082",
          "display" : "VARIOUS INSTRUMENTS FOR ENDOSCOPY AND MINI-INVASIVE SURGERY - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12029085",
          "display" : "VARIOUS INSTRUMENTS FOR ENDOSCOPY AND MINI-INVASIVE SURGERY - CONSUMABLES"
        },
        {
          "code" : "Z12029092",
          "display" : "VARIOUS INSTRUMENTS FOR ENDOSCOPY AND MINI-INVASIVE SURGERY - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12029099",
          "display" : "VARIOUS INSTRUMENTS FOR ENDOSCOPY AND MINI–INVASIVE SURGERY – OTHER"
        }]
      }]
    },
    {
      "code" : "Z1203",
      "display" : "INSTRUMENTS TO SUPPORT AND MONITOR VITAL SIGNS",
      "concept" : [{
        "code" : "Z120301",
        "display" : "ANAESTHESIA AND PULMONARY VENTILATION SUPPORT INSTRUMENTS",
        "concept" : [{
          "code" : "Z12030101",
          "display" : "ANAESTHESIA SYSTEMS",
          "concept" : [{
            "code" : "Z1203010101",
            "display" : "ANAESTHESIA DEVICES"
          },
          {
            "code" : "Z1203010180",
            "display" : "ANAESTHESIA SYSTEMS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1203010182",
            "display" : "ANAESTHESIA SYSTEMS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1203010185",
            "display" : "ANAESTHESIA SYSTEMS - CONSUMABLES"
          },
          {
            "code" : "Z1203010192",
            "display" : "ANAESTHESIA SYSTEMS - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1203010199",
            "display" : "ANAESTHESIA SYSTEMS - OTHER"
          }]
        },
        {
          "code" : "Z12030102",
          "display" : "CONTINUOUS POSITIVE PRESSURE EQUIPMENT"
        },
        {
          "code" : "Z12030103",
          "display" : "PULMONARY VENTILATORS FOR NON–HOSPITAL USE"
        },
        {
          "code" : "Z12030104",
          "display" : "PORTABLE PULMONARY VENTILATORS"
        },
        {
          "code" : "Z12030105",
          "display" : "PULMONARY VENTILATORS FOR HOSPITAL USE",
          "concept" : [{
            "code" : "Z1203010501",
            "display" : "HIGH–FREQUENCY PULMONARY VENTILATORS"
          },
          {
            "code" : "Z1203010502",
            "display" : "ADULT PULMONARY VENTILATORS"
          },
          {
            "code" : "Z1203010503",
            "display" : "NEONATAL/PAEDIATRIC PULMONARY VENTILATORS"
          },
          {
            "code" : "Z1203010504",
            "display" : "ADULT AND PAEDIATRIC/NEONATAL PULMONARY VENTILATORS"
          },
          {
            "code" : "Z1203010580",
            "display" : "PULMONARY VENTILATORS FOR HOSPITAL USE - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1203010582",
            "display" : "PULMONARY VENTILATORS FOR HOSPITAL USE - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1203010585",
            "display" : "PULMONARY VENTILATORS FOR HOSPITAL USE - CONSUMABLES"
          },
          {
            "code" : "Z1203010592",
            "display" : "PULMONARY VENTILATORS FOR HOSPITAL USE - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1203010599",
            "display" : "PULMONARY VENTILATORS FOR HOSPITAL USE - OTHER"
          }]
        },
        {
          "code" : "Z12030190",
          "display" : "VARIOUS INSTRUMENTS FOR ANAESTHESIA AND PULMONARY VENTILATION SUPPORT",
          "concept" : [{
            "code" : "Z1203019001",
            "display" : "NEUROMUSCULAR RELAXATION MONITORING EQUIPMENT"
          },
          {
            "code" : "Z1203019002",
            "display" : "NITRIC OXIDE DISPENSERS"
          },
          {
            "code" : "Z1203019003",
            "display" : "VENTILATION MONITORS"
          },
          {
            "code" : "Z1203019004",
            "display" : "IRON LUNGS"
          },
          {
            "code" : "Z1203019005",
            "display" : "OXYGEN THERAPY TENTS"
          },
          {
            "code" : "Z1203019080",
            "display" : "VARIOUS INSTRUMENTS FOR ANAESTHESIA AND PULMONARY VENTILATION SUPPORT - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1203019082",
            "display" : "VARIOUS INSTRUMENTS FOR ANAESTHESIA AND PULMONARY VENTILATION SUPPORT - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1203019085",
            "display" : "VARIOUS INSTRUMENTS FOR ANAESTHESIA AND PULMONARY VENTILATION SUPPORT - CONSUMABLES"
          },
          {
            "code" : "Z1203019092",
            "display" : "VARIOUS INSTRUMENTS FOR ANAESTHESIA AND PULMONARY VENTILATION SUPPORT - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1203019099",
            "display" : "VARIOUS INSTRUMENTS FOR ANAESTHESIA AND PULMONARY VENTILATION SUPPORT – OTHER"
          }]
        }]
      },
      {
        "code" : "Z120302",
        "display" : "VITAL SIGNS MONITORING INSTRUMENTS",
        "concept" : [{
          "code" : "Z12030201",
          "display" : "CENTRAL INFORMATION COMPUTING SYSTEMS"
        },
        {
          "code" : "Z12030202",
          "display" : "MULTI–PARAMETER PATIENT MONITORS",
          "concept" : [{
            "code" : "Z1203020201",
            "display" : "MULTI–PARAMETER PATIENT BEDSIDE MONITORS"
          },
          {
            "code" : "Z1203020202",
            "display" : "TRANSPORTABLE/PORTABLE MULTI–PARAMETER PATIENT MONITORS"
          },
          {
            "code" : "Z1203020280",
            "display" : "MULTI-PARAMETER MONITORS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1203020282",
            "display" : "MULTI-PARAMETER MONITORS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1203020285",
            "display" : "MULTI-PARAMETER MONITORS - CONSUMABLES"
          },
          {
            "code" : "Z1203020292",
            "display" : "MULTI-PARAMETER MONITORS - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1203020299",
            "display" : "MULTI–PARAMETER MONITORS - OTHER"
          }]
        },
        {
          "code" : "Z12030203",
          "display" : "BLOOD PRESSURE MONITORING INSTRUMENTS",
          "concept" : [{
            "code" : "Z1203020301",
            "display" : "INVASIVE BLOOD PRESSURE MONITORING INSTRUMENTS"
          },
          {
            "code" : "Z1203020302",
            "display" : "NON–INVASIVE BLOOD PRESSURE MONITORING INSTRUMENTS"
          }]
        },
        {
          "code" : "Z12030204",
          "display" : "GASEOUS EXCHANGE MONITORING INSTRUMENTS",
          "concept" : [{
            "code" : "Z1203020401",
            "display" : "CARBON DIOXIDE ANALYSERS"
          },
          {
            "code" : "Z1203020402",
            "display" : "CARBON MONOXIDE ANALYSERS"
          },
          {
            "code" : "Z1203020403",
            "display" : "OXYGEN ANALYSERS"
          },
          {
            "code" : "Z1203020404",
            "display" : "METABOLISM EQUIPMENT"
          },
          {
            "code" : "Z1203020405",
            "display" : "TRANSCUTANEOUS PO2/PCO2 MONITORS"
          },
          {
            "code" : "Z1203020406",
            "display" : "CEREBRAL OXIMETERS"
          },
          {
            "code" : "Z1203020407",
            "display" : "SUBCUTANEOUS OXIMETERS"
          },
          {
            "code" : "Z1203020408",
            "display" : "PULSE OXIMETERS"
          },
          {
            "code" : "Z1203020480",
            "display" : "GASEOUS EXCHANGE MONITORING INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1203020482",
            "display" : "GASEOUS EXCHANGE MONITORING INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1203020485",
            "display" : "GASEOUS EXCHANGE MONITORING INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1203020492",
            "display" : "GASEOUS EXCHANGE MONITORING INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1203020499",
            "display" : "GASEOUS EXCHANGE MONITORING INSTRUMENTS – OTHER"
          }]
        },
        {
          "code" : "Z12030205",
          "display" : "NON–INVASIVE BLOOD PRESSURE GAUGES",
          "concept" : [{
            "code" : "Z1203020501",
            "display" : "NON–INVASIVE OSCILLOMETRIC BLOOD PRESSURE GAUGES"
          },
          {
            "code" : "Z1203020599",
            "display" : "NON-INVASIVE BLOOD PRESSURE GAUGES - OTHER"
          }]
        },
        {
          "code" : "Z12030280",
          "display" : "VITAL SIGNS MONITORING INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12030282",
          "display" : "VITAL SIGNS MONITORING INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12030285",
          "display" : "VITAL SIGNS MONITORING INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12030292",
          "display" : "VITAL SIGNS MONITORING INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12030299",
          "display" : "VITAL SIGNS MONITORING INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120303",
        "display" : "INFUSION INSTRUMENTS",
        "concept" : [{
          "code" : "Z12030301",
          "display" : "INFUSION PUMPS"
        },
        {
          "code" : "Z12030302",
          "display" : "SYRINGE PUMPS"
        },
        {
          "code" : "Z12030303",
          "display" : "ENTERAL FEEDING PUMPS"
        },
        {
          "code" : "Z12030304",
          "display" : "INFUSION REGULATORS"
        },
        {
          "code" : "Z12030305",
          "display" : "INFUSION HEATERS"
        },
        {
          "code" : "Z12030306",
          "display" : "INFUSION AND SYRINGE PUMP CONTROL SYSTEMS"
        },
        {
          "code" : "Z12030380",
          "display" : "INFUSION INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12030382",
          "display" : "INFUSION INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12030385",
          "display" : "INFUSION INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12030392",
          "display" : "INFUSION INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12030399",
          "display" : "INFUSION INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120304",
        "display" : "CARDIAC COMPRESSORS"
      },
      {
        "code" : "Z120305",
        "display" : "DEFIBRILLATORS",
        "concept" : [{
          "code" : "Z12030501",
          "display" : "SEMI-AUTOMATIC DEFIBRILLATORS"
        },
        {
          "code" : "Z12030502",
          "display" : "MANUAL DEFIBRILLATORS"
        },
        {
          "code" : "Z12030503",
          "display" : "AUTOMATIC DEFIBRILLATORS"
        },
        {
          "code" : "Z12030580",
          "display" : "DEFIBRILLATORS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12030582",
          "display" : "DEFIBRILLATORS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12030585",
          "display" : "DEFIBRILLATORS - CONSUMABLES"
        },
        {
          "code" : "Z12030592",
          "display" : "DEFIBRILLATORS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12030599",
          "display" : "DEFIBRILLATORS - OTHER"
        }]
      },
      {
        "code" : "Z120306",
        "display" : "VITAL SIGNS TELEMETRY INSTRUMENTS (ECG, NIPB, EtCO2, SpO2, RESPIRATION,...)",
        "concept" : [{
          "code" : "Z12030601",
          "display" : "COMPLETE VITAL SIGNS TELEMETRY SYSTEMS"
        },
        {
          "code" : "Z12030602",
          "display" : "VITAL SIGNS TELEMETRY RECEIVERS"
        },
        {
          "code" : "Z12030603",
          "display" : "VITAL SIGNS TELEMETRY TRANSMITTER"
        },
        {
          "code" : "Z12030680",
          "display" : "VITAL SIGNS TELEMETRY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12030682",
          "display" : "VITAL SIGNS TELEMETRY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12030685",
          "display" : "VITAL SIGNS TELEMETRY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12030692",
          "display" : "VITAL SIGNS TELEMETRY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120308",
        "display" : "HYPERBARIC CHAMBERS"
      },
      {
        "code" : "Z120309",
        "display" : "MEDICAL/MEDICINAL GAS PIPELINE SYSTEMS AND RELATED ACCESSORIES"
      },
      {
        "code" : "Z120390",
        "display" : "VARIOUS INSTRUMENTS TO SUPPORT AND MONITOR VITAL SIGNS",
        "concept" : [{
          "code" : "Z12039001",
          "display" : "INTRACRANIAL PRESSURE MEASURING SYSTEMS"
        },
        {
          "code" : "Z12039002",
          "display" : "INTRA COMPARTMENTAL PRESSURE MONITOR SYSTEMS"
        },
        {
          "code" : "Z12039080",
          "display" : "VVARIOUS INSTRUMENTS TO SUPPORT AND MONITOR VITAL SIGNS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12039082",
          "display" : "VARIOUS INSTRUMENTS TO SUPPORT AND MONITOR VITAL SIGNS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12039085",
          "display" : "VARIOUS INSTRUMENTS TO SUPPORT AND MONITOR VITAL SIGNS - CONSUMABLES"
        },
        {
          "code" : "Z12039092",
          "display" : "VARIOUS INSTRUMENTS TO SUPPORT AND MONITOR VITAL SIGNS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12039099",
          "display" : "VARIOUS INSTRUMENTS TO SUPPORT AND MONITOR VITAL SIGNS – OTHER"
        }]
      }]
    },
    {
      "code" : "Z1204",
      "display" : "GENERAL MEDICINE INSTRUMENTS",
      "concept" : [{
        "code" : "Z120401",
        "display" : "GENERAL MEDICINE DIAGNOSIS AND MONITORING INSTRUMENTS",
        "concept" : [{
          "code" : "Z12040101",
          "display" : "ALGESIMETERS"
        },
        {
          "code" : "Z12040102",
          "display" : "EQUIPMENT FOR ANALYSIS OF THE PHYSIOLOGICAL PARAMETERS OF THE SKIN"
        },
        {
          "code" : "Z12040103",
          "display" : "HEPATIC FUNCTIONALITY EQUIPMENT"
        },
        {
          "code" : "Z12040104",
          "display" : "EQUIPMENT FOR DIAGNOSIS OF THE BIOELECTRIC FUNCTIONAL STATE"
        },
        {
          "code" : "Z12040105",
          "display" : "PERCEPTION THRESHOLD EQUIPMENT"
        },
        {
          "code" : "Z12040106",
          "display" : "ELECTROCELLULAR TOMOGRAPHY EQUIPMENT"
        },
        {
          "code" : "Z12040107",
          "display" : "CAPILLARISCOPES"
        },
        {
          "code" : "Z12040108",
          "display" : "DERMATOSCOPES"
        },
        {
          "code" : "Z12040109",
          "display" : "DERMOHYGROMETERS"
        },
        {
          "code" : "Z12040110",
          "display" : "ELECTROGUSTOMETERS"
        },
        {
          "code" : "Z12040111",
          "display" : "BLOOD FLOW METERS"
        },
        {
          "code" : "Z12040112",
          "display" : "ONCOLOGY TISSUE INTERFEROMETERS"
        },
        {
          "code" : "Z12040113",
          "display" : "REGIONAL PLETHYSMOGRAPHS"
        },
        {
          "code" : "Z12040114",
          "display" : "SYSTEMS FOR THE STUDY OF AUTONOMIC NEUROPATHIES"
        },
        {
          "code" : "Z12040115",
          "display" : "BLOOD SUGAR MONITORING SYSTEMS",
          "concept" : [{
            "code" : "Z1204011501",
            "display" : "NON INVASIVE BLOOD SUGAR MONITORING SYSTEMS"
          },
          {
            "code" : "Z1204011502",
            "display" : "INVASIVE BLOOD SUGAR MONITORING SYSTEMS"
          },
          {
            "code" : "Z1204011585",
            "display" : "INVASIVE BLOOD SUGAR MONITORING SYSTEMS, SINGLE–USE SENSORS"
          },
          {
            "code" : "Z1204011599",
            "display" : "BLOOD SUGAR MONITORING SYSTEMS - OTHER"
          }]
        },
        {
          "code" : "Z12040116",
          "display" : "SPECTROPHOTOMETERS FOR EARLY DETECTION OF MELANOMA"
        },
        {
          "code" : "Z12040117",
          "display" : "METABOLIC AND PHYSICAL ACTIVITY HOLTER SYSTEMS"
        },
        {
          "code" : "Z12040118",
          "display" : "VIDEO DERMATOSCOPES"
        },
        {
          "code" : "Z12040180",
          "display" : "GENERAL MEDICINE DIAGNOSIS AND MONITORING INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12040182",
          "display" : "GENERAL MEDICINE DIAGNOSIS AND MONITORING INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12040185",
          "display" : "GENERAL MEDICINE DIAGNOSIS AND MONITORING INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12040192",
          "display" : "GENERAL MEDICINE DIAGNOSIS AND MONITORING INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12040199",
          "display" : "GENERAL MEDICINE DIAGNOSIS AND MONITORING INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120402",
        "display" : "GENERAL MEDICINE THERAPEUTIC TREATMENT INSTRUMENTS",
        "concept" : [{
          "code" : "Z12040201",
          "display" : "PHOTOEPILATION EQUIPMENT"
        },
        {
          "code" : "Z12040202",
          "display" : "PHOTOTHERAPY EQUIPMENT"
        },
        {
          "code" : "Z12040203",
          "display" : "DERMAL REGENERATION EQUIPMENT"
        },
        {
          "code" : "Z12040205",
          "display" : "VACUUM MEDICATION EQUIPMENT"
        },
        {
          "code" : "Z12040206",
          "display" : "MESOTHERAPY EQUIPMENT"
        },
        {
          "code" : "Z12040207",
          "display" : "OZONE THERAPY EQUIPMENT"
        },
        {
          "code" : "Z12040208",
          "display" : "BODY THERMOREGULATION EQUIPMENT"
        },
        {
          "code" : "Z12040210",
          "display" : "ULTRASONIC NEBULISERS"
        },
        {
          "code" : "Z12040211",
          "display" : "ARTIFICIAL PANCREAS"
        },
        {
          "code" : "Z12040213",
          "display" : "PATIENT WASHING SYSTEMS"
        },
        {
          "code" : "Z12040214",
          "display" : "LIPOSUCTION SYSTEMS"
        },
        {
          "code" : "Z12040215",
          "display" : "MULTI-DISTRICT ONCOLOGICAL HYPERTHERMIA INSTRUMENTS",
          "concept" : [{
            "code" : "Z1204021501",
            "display" : "MULTI-DISTRICT ONCOLOGICAL HYPERTHERMIA EQUIPMENT"
          },
          {
            "code" : "Z1204021580",
            "display" : "MULTI-DISTRICT ONCOLOGICAL HYPERTHERMIA INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1204021582",
            "display" : "MULTI-DISTRICT ONCOLOGICAL HYPERTHERMIA INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1204021585",
            "display" : "MULTI-DISTRICT ONCOLOGICAL HYPERTHERMIA INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1204021592",
            "display" : "MULTI-DISTRICT ONCOLOGICAL HYPERTHERMIA INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "Z12040216",
          "display" : "PORTABLE MICROINFUSION INSTRUMENTS",
          "concept" : [{
            "code" : "Z1204021601",
            "display" : "PORTABLE INSULIN INFUSION INSTRUMENTS",
            "concept" : [{
              "code" : "Z120402160101",
              "display" : "PORTABLE INSULIN MICROINFUSORS"
            },
            {
              "code" : "Z120402160102",
              "display" : "PORTABLE INSULIN MICROINFUSORS WITH HANDHELD GLUCOSE METER"
            },
            {
              "code" : "Z120402160103",
              "display" : "PORTABLE INSULIN MICROINFUSORS CONNECTABLE TO CONTINUOUS GLUCOSE MONITORING SYSTEMS"
            }]
          },
          {
            "code" : "Z1204021602",
            "display" : "PORTABLE PAIN THERAPY INSTRUMENTS"
          },
          {
            "code" : "Z1204021603",
            "display" : "PORTABLE DOBUTAMINE INFUSION INSTRUMENTS"
          },
          {
            "code" : "Z1204021680",
            "display" : "PORTABLE MICROINFUSION INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1204021685",
            "display" : "PORTABLE MICROINFUSION INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1204021699",
            "display" : "PORTABLE MICROINFUSION INSTRUMENTS - OTHER"
          }]
        },
        {
          "code" : "Z12040218",
          "display" : "ENDERMOLOGY TREATMENTS"
        },
        {
          "code" : "Z12040219",
          "display" : "REGIONAL PERFUSION UNITS"
        },
        {
          "code" : "Z12040280",
          "display" : "GENERAL MEDICINE THERAPEUTIC TREATMENT INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12040282",
          "display" : "GENERAL MEDICINE THERAPEUTIC TREATMENT INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12040285",
          "display" : "GENERAL MEDICINE THERAPEUTIC TREATMENT INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12040292",
          "display" : "GENERAL MEDICINE THERAPEUTIC TREATMENT INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12040299",
          "display" : "GENERAL MEDICINE THERAPEUTIC TREATMENT INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120499",
        "display" : "GENERAL MEDICINE INSTRUMENTS - OTHER"
      }]
    },
    {
      "code" : "Z1205",
      "display" : "CARDIOLOGY AND CARDIOSURGERY INSTRUMENTS",
      "concept" : [{
        "code" : "Z120501",
        "display" : "STRESS ANALYSIS INSTRUMENTS",
        "concept" : [{
          "code" : "Z12050101",
          "display" : "STRESS ANALYSIS SYSTEMS"
        },
        {
          "code" : "Z12050180",
          "display" : "STRESS ANALYSIS INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12050182",
          "display" : "STRESS ANALYSIS INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12050185",
          "display" : "STRESS ANALYSIS INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12050192",
          "display" : "STRESS ANALYSIS INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120502",
        "display" : "EXTRA-CORPOREAL CIRCULATION INSTRUMENTS",
        "concept" : [{
          "code" : "Z12050201",
          "display" : "EXTRA-CORPOREAL CIRCULATION SYSTEMS"
        },
        {
          "code" : "Z12050280",
          "display" : "EXTRA-CORPOREAL CIRCULATION INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12050282",
          "display" : "EXTRA-CORPOREAL CIRCULATION INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12050285",
          "display" : "EXTRA-CORPOREAL CIRCULATION INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12050292",
          "display" : "EXTRA-CORPOREAL CIRCULATION INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120503",
        "display" : "ELECTROCARDIOGRAPHS",
        "concept" : [{
          "code" : "Z12050301",
          "display" : "GENERAL PURPOSE ELECTROCARDIOGRAPHS"
        },
        {
          "code" : "Z12050302",
          "display" : "ADVANCED DIAGNOSIS ELECTROCARDIOGRAPHS"
        },
        {
          "code" : "Z12050303",
          "display" : "CARDIOPHONES"
        },
        {
          "code" : "Z12050380",
          "display" : "ELECTROCARDIOGRAPHS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12050382",
          "display" : "ELECTROCARDIOGRAPHS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12050385",
          "display" : "ELECTROCARDIOGRAPHS - CONSUMABLES"
        },
        {
          "code" : "Z12050392",
          "display" : "ELECTROCARDIOGRAPHS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120504",
        "display" : "HOLTER SYSTEM INSTRUMENTS FOR CARDIOVASCULAR PARAMETERS",
        "concept" : [{
          "code" : "Z12050401",
          "display" : "CARDIOVASCULAR HOLTER ANALYSERS"
        },
        {
          "code" : "Z12050402",
          "display" : "MULTI–PARAMETER CARDIOVASCULAR HOLTER RECORDERS (ECG, NIPB, ETC.)"
        },
        {
          "code" : "Z12050403",
          "display" : "ECG HOLTER RECORDERS"
        },
        {
          "code" : "Z12050404",
          "display" : "BLOOD PRESSURE HOLTER RECORDERS"
        },
        {
          "code" : "Z12050480",
          "display" : "HOLTER SYSTEM INSTRUMENTS FOR CARDIOVASCULAR PARAMETERS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12050482",
          "display" : "HOLTER SYSTEM INSTRUMENTS FOR CARDIOVASCULAR PARAMETERS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12050485",
          "display" : "HOLTER SYSTEM INSTRUMENTS FOR CARDIOVASCULAR PARAMETERS - CONSUMABLES"
        },
        {
          "code" : "Z12050492",
          "display" : "HOLTER SYSTEM INSTRUMENTS FOR CARDIOVASCULAR PARAMETERS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12050499",
          "display" : "HOLTER SYSTEM INSTRUMENTS FOR CARDIOVASCULAR PARAMETERS – OTHER"
        }]
      },
      {
        "code" : "Z120505",
        "display" : "CARDIAC OUTPUT MEASUREMENT INSTRUMENTS",
        "concept" : [{
          "code" : "Z12050501",
          "display" : "CARDIAC OUTPUT MEASUREMENT METERS"
        },
        {
          "code" : "Z12050580",
          "display" : "CARDIAC OUTPUT MEASUREMENT INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12050582",
          "display" : "CARDIAC OUTPUT MEASUREMENT INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12050585",
          "display" : "CARDIAC OUTPUT MEASUREMENT INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12050592",
          "display" : "CARDIAC OUTPUT MEASUREMENT INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120506",
        "display" : "NON–IMPLANTABLE CARDIAC STIMULATORS",
        "concept" : [{
          "code" : "Z12050601",
          "display" : "TRANSOESOPHAGEAL CARDIAC STIMULATORS"
        },
        {
          "code" : "Z12050602",
          "display" : "INVASIVE CARDIAC STIMULATORS"
        },
        {
          "code" : "Z12050603",
          "display" : "TRANSTHORACIC CARDIAC STIMULATORS"
        },
        {
          "code" : "Z12050680",
          "display" : "NON-IMPLANTABLE CARDIAC STIMULATORS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12050682",
          "display" : "NON-IMPLANTABLE CARDIAC STIMULATORS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12050685",
          "display" : "NON-IMPLANTABLE CARDIAC STIMULATORS - CONSUMABLES"
        },
        {
          "code" : "Z12050692",
          "display" : "NON-IMPLANTABLE CARDIAC STIMULATORS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12050699",
          "display" : "NON–IMPLANTABLE CARDIAC STIMULATORS – OTHER"
        }]
      },
      {
        "code" : "Z120507",
        "display" : "CARDIOGRAPHY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12050701",
          "display" : "COMPLETE CARDIOGRAPHY SYSTEMS"
        },
        {
          "code" : "Z12050702",
          "display" : "POLYGRAPHY SYSTEMS FOR HAEMODYNAMIC STUDIES"
        },
        {
          "code" : "Z12050703",
          "display" : "POLYGRAPHY SYSTEMS FOR ELECTROPHYSIOLOGICAL STUDIES"
        },
        {
          "code" : "Z12050780",
          "display" : "CARDIOGRAPHY INSTRUMENTS - HARDWARE ACCESSORIES",
          "concept" : [{
            "code" : "Z1205078001",
            "display" : "CARDIAC ELECTROPHYSIOLOGY STIMULATORS"
          },
          {
            "code" : "Z1205078099",
            "display" : "INSTRUMENTS FOR CARDIOLOGICAL POLYGRAPHY - HARDWARE ACCESSORIES - OTHER"
          }]
        },
        {
          "code" : "Z12050782",
          "display" : "INSTRUMENTS FOR CARDIOLOGICAL POLYGRAPHY - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12050785",
          "display" : "INSTRUMENTS FOR CARDIOLOGICAL POLYGRAPHY - CONSUMABLES"
        },
        {
          "code" : "Z12050792",
          "display" : "INSTRUMENTS FOR CARDIOLOGICAL POLYGRAPHY - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120508",
        "display" : "CARDIAC TELEMETRY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12050801",
          "display" : "COMPLETE CARDIAC TELEMETRY SYSTEMS"
        },
        {
          "code" : "Z12050802",
          "display" : "ELECTROCARDIOGRAPH TELEMETRY SYSTEM RECEIVERS"
        },
        {
          "code" : "Z12050803",
          "display" : "ELECTROCARDIOGRAPH TELEMETRY SYSTEM TRANSMITTERS"
        },
        {
          "code" : "Z12050804",
          "display" : "ERGOSPIROMETRIC TELEMETRY TRANSMITTERS"
        },
        {
          "code" : "Z12050880",
          "display" : "CARDIAC TELEMETRY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12050882",
          "display" : "CARDIAC TELEMETRY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12050885",
          "display" : "CARDIAC TELEMETRY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12050892",
          "display" : "CARDIAC TELEMETRY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12050899",
          "display" : "CARDIAC TELEMETRY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120590",
        "display" : "VARIOUS INSTRUMENTS FOR CARDIOLOGY AND CARDIAC SURGERY",
        "concept" : [{
          "code" : "Z12059001",
          "display" : "PACING SENSING ANALYSERS"
        },
        {
          "code" : "Z12059002",
          "display" : "CARDIAC MAPPING EQUIPMENT"
        },
        {
          "code" : "Z12059003",
          "display" : "CLOT ASPIRATORS"
        },
        {
          "code" : "Z12059004",
          "display" : "AORTIC PUMPS"
        },
        {
          "code" : "Z12059005",
          "display" : "BLOOD FLOW VELOCIMETERS"
        },
        {
          "code" : "Z12059006",
          "display" : "FIBRILLATORS"
        },
        {
          "code" : "Z12059007",
          "display" : "INTRA-CARDIAC OXIMETERS"
        },
        {
          "code" : "Z12059008",
          "display" : "LASER FLUXIMETRY SYSTEMS"
        },
        {
          "code" : "Z12059009",
          "display" : "ECG DATA MANAGEMENT SYSTEMS"
        },
        {
          "code" : "Z12059010",
          "display" : "STERNOTOMES"
        },
        {
          "code" : "Z12059011",
          "display" : "CARDIAC ABLATION EQUIPMENT"
        },
        {
          "code" : "Z12059012",
          "display" : "PHONOCARDIOGRAPHS"
        },
        {
          "code" : "Z12059013",
          "display" : "MAGNETOCARDIOGRAPHS"
        },
        {
          "code" : "Z12059080",
          "display" : "VARIOUS INSTRUMENTS FOR CARDIOLOGY AND CARDIAC SURGERY - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12059082",
          "display" : "VARIOUS INSTRUMENTS FOR CARDIOLOGY AND CARDIAC SURGERY - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12059085",
          "display" : "VARIOUS INSTRUMENTS FOR CARDIOLOGY AND CARDIAC SURGERY - CONSUMABLES"
        },
        {
          "code" : "Z12059092",
          "display" : "VARIOUS INSTRUMENTS FOR CARDIOLOGY AND CARDIAC SURGERY - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12059099",
          "display" : "VARIOUS INSTRUMENTS FOR CARDIOLOGY AND CARDIAC SURGERY -OTHER"
        }]
      }]
    },
    {
      "code" : "Z1206",
      "display" : "PHYSIOTHERAPY AND REHABILITATION INSTRUMENTS",
      "concept" : [{
        "code" : "Z120601",
        "display" : "ELECTROTHERAPY EQUIPMENT (INCLUDED TENS)"
      },
      {
        "code" : "Z120602",
        "display" : "PHYSIOTHERAPY EQUIPMENT"
      },
      {
        "code" : "Z120603",
        "display" : "PASSIVE REHABILITATIVE GYMNASTICS EQUIPMENT"
      },
      {
        "code" : "Z120604",
        "display" : "IONTOPHORESIS EQUIPMENT"
      },
      {
        "code" : "Z120605",
        "display" : "EQUIPMENT FOR ELECTROMYOGRAPHIC ANALYSIS"
      },
      {
        "code" : "Z120606",
        "display" : "MAGNETOTHERAPY EQUIPMENT"
      },
      {
        "code" : "Z120607",
        "display" : "PNEUMATIC COMPRESSION EQUIPMENT"
      },
      {
        "code" : "Z120608",
        "display" : "MICROWAVE THERAPY EQUIPMENT"
      },
      {
        "code" : "Z120609",
        "display" : "SHORTWAVE THERAPY EQUIPMENT"
      },
      {
        "code" : "Z120610",
        "display" : "ULTRASOUND THERAPY EQUIPMENT"
      },
      {
        "code" : "Z120611",
        "display" : "VACUUM THERAPY EQUIPMENT"
      },
      {
        "code" : "Z120612",
        "display" : "ENDORAL ELECTRIC MASSAGE EQUIPMENT"
      },
      {
        "code" : "Z120613",
        "display" : "REHABILITATIVE THERAPY FURNACES"
      },
      {
        "code" : "Z120614",
        "display" : "INFRARED ULTRAVIOLET RAY LAMPS"
      },
      {
        "code" : "Z120615",
        "display" : "THERAPEUTIC LASERS"
      },
      {
        "code" : "Z120616",
        "display" : "ELECTROMECHANICAL SYSTEMS FOR PHYSICAL THERAPY"
      },
      {
        "code" : "Z120617",
        "display" : "MOVEMENT ANALYSIS INTEGRATED SYSTEMS"
      },
      {
        "code" : "Z120618",
        "display" : "HYDROGYMNASTICS AND HYDROTHERAPY SYSTEMS"
      },
      {
        "code" : "Z120619",
        "display" : "PARAFFIN THERAPY SYSTEMS"
      },
      {
        "code" : "Z120620",
        "display" : "VERTEBRAL COLUMN ELECTROANALGESIC STIMULATORS"
      },
      {
        "code" : "Z120621",
        "display" : "FACIAL STIMULATORS"
      },
      {
        "code" : "Z120622",
        "display" : "MUSCLE STIMULATORS"
      },
      {
        "code" : "Z120623",
        "display" : "ACUPUNCTURE STIMULATORS"
      },
      {
        "code" : "Z120624",
        "display" : "BIOFEEDBACK INSTRUMENTS",
        "concept" : [{
          "code" : "Z12062401",
          "display" : "ELECTROMYOGRAPHIC BIOFEEDBACK SYSTEMS"
        },
        {
          "code" : "Z12062402",
          "display" : "POSITIONAL BIOFEEDBACK SYSTEMS"
        },
        {
          "code" : "Z12062403",
          "display" : "TEMPERATURE BIOFEEDBACK SYSTEMS"
        },
        {
          "code" : "Z12062404",
          "display" : "ELECTRODERMAL SIGNAL BIOFEEDBACK SYSTEMS"
        },
        {
          "code" : "Z12062480",
          "display" : "BIOFEEDBACK INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12062482",
          "display" : "BIOFEEDBACK INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12062485",
          "display" : "BIOFEEDBACK INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12062492",
          "display" : "BIOFEEDBACK INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12062499",
          "display" : "BIOFEEDBACK INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120625",
        "display" : "KINEMATIC MOTION CAPTURE ANALYSIS SYSTEMS",
        "concept" : [{
          "code" : "Z12062501",
          "display" : "KINEMATIC GONIOMETRIC MOTION CAPTURE ANALYSIS SYSTEMS"
        },
        {
          "code" : "Z12062502",
          "display" : "KINEMATIC INERTIAL MOTION CAPTURE ANALYSIS SYSTEMS"
        },
        {
          "code" : "Z12062503",
          "display" : "KINEMATIC OPTOELECTRONIC MOTION CAPTURE ANALYSIS SYSTEMS USING PASSIVE MARKERS"
        },
        {
          "code" : "Z12062504",
          "display" : "KINEMATIC OPTOELECTRONIC MOTION CAPTURE ANALYSIS SYSTEMS USING ACTIVE MARKERS"
        },
        {
          "code" : "Z12062505",
          "display" : "KINEMATIC ULTRASOUND MOTION CAPTURE ANALYSIS SYSTEMS"
        },
        {
          "code" : "Z12062506",
          "display" : "KINEMATIC ELECTROMAGNETIC FIELD MOTION CAPTURE ANALYSIS SYSTEMS"
        },
        {
          "code" : "Z12062580",
          "display" : "KINEMATIC MOTION CAPTURE ANALYSIS SYSTEMS - HARDWARE"
        },
        {
          "code" : "Z12062582",
          "display" : "KINEMATIC MOTION CAPTURE ANALYSIS SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12062585",
          "display" : "KINEMATIC MOTION CAPTURE ANALYSIS SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z12062592",
          "display" : "KINEMATIC MOTION CAPTURE ANALYSIS SYSTEMS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12062599",
          "display" : "KINEMATIC MOTION CAPTURE ANALYSIS SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "Z120626",
        "display" : "DYNAMOMETRIC SYSTEMS FOR MOVEMENT ANALYSIS",
        "concept" : [{
          "code" : "Z12062601",
          "display" : "DYNAMOMETRIC PLATFORMS"
        },
        {
          "code" : "Z12062602",
          "display" : "SENSOR-BASED INSOLES"
        },
        {
          "code" : "Z12062603",
          "display" : "SENSOR-BASED PLATFORMS"
        },
        {
          "code" : "Z12062680",
          "display" : "DYNAMOMETRIC SYSTEMS FOR MOVEMENT ANALYSIS - HARDWARE"
        },
        {
          "code" : "Z12062682",
          "display" : "DYNAMOMETRIC SYSTEMS FOR MOVEMENT ANALYSIS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12062685",
          "display" : "DYNAMOMETRIC SYSTEMS FOR MOVEMENT ANALYSIS - CONSUMABLES"
        },
        {
          "code" : "Z12062692",
          "display" : "DYNAMOMETRIC SYSTEMS FOR MOVEMENT ANALYSIS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12062699",
          "display" : "DYNAMOMETRIC SYSTEMS FOR MOVEMENT ANALYSIS – OTHER"
        }]
      },
      {
        "code" : "Z120627",
        "display" : "FUNCTIONAL ELECTRICAL STIMULATION SYSTEMS",
        "concept" : [{
          "code" : "Z12062701",
          "display" : "PERINEAL STIMULATORS"
        },
        {
          "code" : "Z12062702",
          "display" : "HOISTING AND WALKING STIMULATORS"
        },
        {
          "code" : "Z12062703",
          "display" : "CYCLING STIMULATORS"
        },
        {
          "code" : "Z12062704",
          "display" : "PREHENSION STIMULATORS"
        },
        {
          "code" : "Z12062705",
          "display" : "MYOELECTRIC CONTROL STIMULATORS"
        },
        {
          "code" : "Z12062780",
          "display" : "FUNCTIONAL ELECTRICAL STIMULATION SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12062782",
          "display" : "FUNCTIONAL ELECTRICAL STIMULATION SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12062785",
          "display" : "FUNCTIONAL ELECTRICAL STIMULATION SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z12062792",
          "display" : "FUNCTIONAL ELECTRICAL STIMULATION SYSTEMS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12062799",
          "display" : "FUNCTIONAL ELECTRICAL STIMULATION SYSTEMS - OTHER"
        }]
      },
      {
        "code" : "Z120628",
        "display" : "NEUROMUSCULAR STIMULATION EQUIPMENT",
        "concept" : [{
          "code" : "Z12062801",
          "display" : "MUSCLE REINFORCEMENT STIMULATORS FOR INNERVATED MUSCLES"
        },
        {
          "code" : "Z12062802",
          "display" : "STIMULATORS FOR SCOLIOSIS TREATMENT"
        },
        {
          "code" : "Z12062880",
          "display" : "NEUROMUSCULAR STIMULATION EQUIPMENT - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12062882",
          "display" : "NEUROMUSCULAR STIMULATION EQUIPMENT - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12062885",
          "display" : "NEUROMUSCULAR STIMULATION EQUIPMENT - CONSUMABLES"
        },
        {
          "code" : "Z12062892",
          "display" : "NEUROMUSCULAR STIMULATION EQUIPMENT - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12062899",
          "display" : "NEUROMUSCULAR STIMULATION EQUIPMENT - OTHER"
        }]
      },
      {
        "code" : "Z120690",
        "display" : "VARIOUS PHYSIOTHERAPY AND REHABILITATION INSTRUMENTS",
        "concept" : [{
          "code" : "Z12069001",
          "display" : "ELECTRIC HOISTS AND WALKERS"
        },
        {
          "code" : "Z12069002",
          "display" : "ASSISTED LOCOMOTION SYSTEMS"
        },
        {
          "code" : "Z12069003",
          "display" : "CRYOTHERAPY CHAMBERS"
        },
        {
          "code" : "Z12069080",
          "display" : "VARIOUS PHYSIOTHERAPY AND REHABILITATION INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12069082",
          "display" : "VARIOUS PHYSIOTHERAPY AND REHABILITATION INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12069085",
          "display" : "VARIOUS PHYSIOTHERAPY AND REHABILITATION INSTRUMENTS - SPECIFIC MATERIALS"
        },
        {
          "code" : "Z12069092",
          "display" : "VARIOUS PHYSIOTHERAPY AND REHABILITATION INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12069099",
          "display" : "VARIOUS PHYSIOTHERAPY AND REHABILITATION INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1207",
      "display" : "GASTROENTEROLOGICAL INSTRUMENTS",
      "concept" : [{
        "code" : "Z120701",
        "display" : "GASTROENTEROLOGICAL MANOMETRY EQUIPMENT"
      },
      {
        "code" : "Z120702",
        "display" : "GASTROESOPHAGEAL PH HOLTER RECORDERS"
      },
      {
        "code" : "Z120703",
        "display" : "OESOPHAGEAL FUNCTIONALITY ANALYSIS EQUIPMENT"
      },
      {
        "code" : "Z120704",
        "display" : "GASTRIC PH MONITOR"
      },
      {
        "code" : "Z120706",
        "display" : "EQUIPMENT FOR RADIOFREQUENCY TREATMENT OF THE CARDIAS"
      },
      {
        "code" : "Z120707",
        "display" : "LACTOSE INTOLERANCE EQUIPMENT"
      },
      {
        "code" : "Z120780",
        "display" : "GASTROENTEROLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
      },
      {
        "code" : "Z120782",
        "display" : "GASTROENTEROLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
      },
      {
        "code" : "Z120785",
        "display" : "GASTROENTEROLOGY INSTRUMENTS - CONSUMABLES"
      },
      {
        "code" : "Z120792",
        "display" : "GASTROENTEROLOGY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
      },
      {
        "code" : "Z120799",
        "display" : "GASTROENTEROLOGY INSTRUMENTS -OTHER"
      }]
    },
    {
      "code" : "Z1208",
      "display" : "OBSTETRICS AND GYNAECOLOGY INSTRUMENTS",
      "concept" : [{
        "code" : "Z120801",
        "display" : "PRENATAL DIAGNOSTIC INSTRUMENTS",
        "concept" : [{
          "code" : "Z12080101",
          "display" : "FOETAL MONITORS"
        },
        {
          "code" : "Z12080102",
          "display" : "FOETAL PH MONITORS"
        },
        {
          "code" : "Z12080103",
          "display" : "FOETAL HEARTBEAT DETECTORS"
        },
        {
          "code" : "Z12080104",
          "display" : "CARDIOTOCOGRAPHIC TELEMETRY INSTRUMENTS",
          "concept" : [{
            "code" : "Z1208010401",
            "display" : "COMPLETE CARDIOTOCOGRAPHIC TELEMETRY SYSTEMS"
          },
          {
            "code" : "Z1208010402",
            "display" : "RECEIVING UNITS FOR CARDIOTOCOGRAPHIC TELEMETRY"
          },
          {
            "code" : "Z1208010403",
            "display" : "TRANSMITTING UNITS FOR CARDIOTOCOGRAPHIC TELEMETRY"
          },
          {
            "code" : "Z1208010480",
            "display" : "CARDIOTOCOGRAPHIC TELEMETRY INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1208010482",
            "display" : "CARDIOTOCOGRAPHIC TELEMETRY INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1208010485",
            "display" : "CARDIOTOCOGRAPHIC TELEMETRY INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1208010492",
            "display" : "CARDIOTOCOGRAPHIC TELEMETRY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1208010499",
            "display" : "CARDIOTOCOGRAPHIC TELEMETRY INSTRUMENTS - OTHER"
          }]
        },
        {
          "code" : "Z12080105",
          "display" : "FOETAL ACOUSTIC STIMULATORS"
        },
        {
          "code" : "Z12080180",
          "display" : "PRENATAL DIAGNOSTIC INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12080182",
          "display" : "PRENATAL DIAGNOSTIC INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12080185",
          "display" : "PRENATAL DIAGNOSTIC INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12080192",
          "display" : "PRENATAL DIAGNOSTIC INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12080199",
          "display" : "PRENATAL DIAGNOSTIC INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120802",
        "display" : "GYNAECOLOGY AND FERTILITY TREATMENT INSTRUMENTS",
        "concept" : [{
          "code" : "Z12080201",
          "display" : "ENDOMETRIAL ABLATION EQUIPMENT"
        },
        {
          "code" : "Z12080202",
          "display" : "OOCYTE ASPIRATION EQUIPMENT"
        },
        {
          "code" : "Z12080203",
          "display" : "HYSTEROSUCTION SURGICAL ASPIRATORS"
        },
        {
          "code" : "Z12080204",
          "display" : "MORCELLATORS"
        },
        {
          "code" : "Z12080205",
          "display" : "OOCYTE LASER DRILLS"
        },
        {
          "code" : "Z12080280",
          "display" : "GYNAECOLOGY AND FERTILITY TREATMENT INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12080282",
          "display" : "GYNAECOLOGY AND FERTILITY TREATMENT INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12080285",
          "display" : "GYNAECOLOGY AND FERTILITY TREATMENT INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12080292",
          "display" : "GYNAECOLOGY AND FERTILITY TREATMENT INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12080299",
          "display" : "GYNAECOLOGY AND FERTILITY TREATMENT INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120803",
        "display" : "CHILDBIRTH SUPPORT AND MATERNAL ASSISTANCE INSTRUMENTS",
        "concept" : [{
          "code" : "Z12080301",
          "display" : "OBSTETRIC VACUUM EXTRACTORS"
        },
        {
          "code" : "Z12080303",
          "display" : "BREAST PUMPS"
        },
        {
          "code" : "Z12080304",
          "display" : "ULTRASONIC BLADDER VOLUME SCANNERS"
        },
        {
          "code" : "Z12080305",
          "display" : "BIRTHING BATHS"
        },
        {
          "code" : "Z12080380",
          "display" : "VARIOUS CHILDBIRTH SUPPORT AND MATERNAL ASSISTANCE INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12080382",
          "display" : "VARIOUS CHILDBIRTH SUPPORT AND MATERNAL ASSISTANCE INSTRUMENTS -SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12080385",
          "display" : "VARIOUS CHILDBIRTH SUPPORT AND MATERNAL ASSISTANCE INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12080392",
          "display" : "VARIOUS CHILDBIRTH SUPPORT AND MATERNAL ASSISTANCE INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12080399",
          "display" : "VARIOUS CHILDBIRTH SUPPORT AND MATERNAL ASSISTANCE INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120804",
        "display" : "NEONATOLOGY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12080401",
          "display" : "PAEDIATRIC PHOTOTHERAPY EQUIPMENT"
        },
        {
          "code" : "Z12080402",
          "display" : "NEONATAL SCALES"
        },
        {
          "code" : "Z12080403",
          "display" : "NEONATAL INCUBATORS",
          "concept" : [{
            "code" : "Z1208040301",
            "display" : "FIXED NEONATAL INCUBATORS"
          },
          {
            "code" : "Z1208040302",
            "display" : "MOBILE NEONATAL INCUBATORS"
          },
          {
            "code" : "Z1208040380",
            "display" : "NEONATAL INCUBATORS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1208040382",
            "display" : "NEONATAL INCUBATORS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1208040385",
            "display" : "NEONATAL INCUBATORS - CONSUMABLES"
          },
          {
            "code" : "Z1208040392",
            "display" : "NEONATAL INCUBATORS - MEDICAL DEVICE SOFTWARE"
          }]
        },
        {
          "code" : "Z12080404",
          "display" : "PAEDIATRIC INFRARED LAMPS"
        },
        {
          "code" : "Z12080405",
          "display" : "NEONATAL RESUSCITATION BEDS"
        },
        {
          "code" : "Z12080406",
          "display" : "APNOEA MONITORS"
        },
        {
          "code" : "Z12080407",
          "display" : "NEONATAL RADIANT WARMERS"
        },
        {
          "code" : "Z12080408",
          "display" : "SWEAT TEST STIMULATORS"
        },
        {
          "code" : "Z12080409",
          "display" : "INFRARED CEREBRAL TOPOGRAPHS"
        },
        {
          "code" : "Z12080410",
          "display" : "TRANSCUTANEOUS BILIRUBINOMETERS"
        },
        {
          "code" : "Z12080480",
          "display" : "NEONATOLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12080482",
          "display" : "NEONATOLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12080485",
          "display" : "NEONATOLOGY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12080492",
          "display" : "NEONATOLOGY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12080499",
          "display" : "NEONATOLOGY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z120899",
        "display" : "GYNAECOLOGY AND MATERNAL-INFANTS INSTRUMENTS - OTHER"
      }]
    },
    {
      "code" : "Z1209",
      "display" : "NEPHROLOGY AND HAEMODIALYSIS INSTRUMENTS",
      "concept" : [{
        "code" : "Z120901",
        "display" : "PERITONEAL DIALYSIS INSTRUMENTS",
        "concept" : [{
          "code" : "Z12090101",
          "display" : "PERITONEAL DIALYSIS EQUIPMENT"
        },
        {
          "code" : "Z12090180",
          "display" : "PERITONEAL DIALYSIS INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12090182",
          "display" : "PERITONEAL DIALYSIS INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12090185",
          "display" : "PERITONEAL DIALYSIS INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12090192",
          "display" : "PERITONEAL DIALYSIS INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120902",
        "display" : "HAEMODIALYSIS INSTRUMENTS",
        "concept" : [{
          "code" : "Z12090201",
          "display" : "HAEMODIALYSIS EQUIPMENT"
        },
        {
          "code" : "Z12090280",
          "display" : "HAEMODIALYSIS INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12090282",
          "display" : "HAEMODIALYSIS INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12090285",
          "display" : "HAEMODIALYSIS INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12090292",
          "display" : "HAEMODIALYSIS INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120903",
        "display" : "HAEMOFILTRATION INSTRUMENTS",
        "concept" : [{
          "code" : "Z12090301",
          "display" : "HAEMOFILTRATION EQUIPMENT"
        },
        {
          "code" : "Z12090380",
          "display" : "HAEMOFILTRATION INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12090382",
          "display" : "HAEMOFILTRATION INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12090385",
          "display" : "HAEMOFILTRATION INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12090392",
          "display" : "HAEMOFILTRATION INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z120990",
        "display" : "VARIOUS NEPHROLOGY AND HAEMODIALYSIS INSTRUMENTS",
        "concept" : [{
          "code" : "Z12099001",
          "display" : "BODY IMPEDANCE ANALYSERS"
        },
        {
          "code" : "Z12099002",
          "display" : "MONITORING CENTRES FOR DIALYSIS TREATMENT"
        },
        {
          "code" : "Z12099003",
          "display" : "HOSPITAL BEDS OR ARMCHAIR SCALES FOR DIALYSIS"
        },
        {
          "code" : "Z12099004",
          "display" : "HEPARIN PUMPS"
        },
        {
          "code" : "Z12099005",
          "display" : "BLOOD PUMPS"
        },
        {
          "code" : "Z12099006",
          "display" : "LIQUID DIALYSIS PREPARATIONS"
        },
        {
          "code" : "Z12099007",
          "display" : "DIALYSIS WATER TREATMENT SYSTEMS"
        },
        {
          "code" : "Z12099080",
          "display" : "VARIOUS NEPHROLOGY AND HAEMODIALYSIS INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12099082",
          "display" : "VARIOUS NEPHROLOGY AND HAEMODIALYSIS INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12099085",
          "display" : "VARIOUS NEPHROLOGY AND HAEMODIALYSIS INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12099092",
          "display" : "VARIOUS NEPHROLOGY AND HAEMODIALYSIS INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12099099",
          "display" : "VARIOUS NEPHROLOGY AND HAEMODIALYSIS INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1210",
      "display" : "NEUROLOGY AND NEUROSURGERY INSTRUMENTS",
      "concept" : [{
        "code" : "Z121001",
        "display" : "RADIOFREQUENCY NERVOUS TISSUE ABLATION INSTRUMENTS"
      },
      {
        "code" : "Z121002",
        "display" : "NERVOUS SYSTEM MONITORING SYSTEMS"
      },
      {
        "code" : "Z121003",
        "display" : "ELECTROENCEPHALOGRAPHY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12100301",
          "display" : "EEG SPECTRAL ANALYSERS"
        },
        {
          "code" : "Z12100302",
          "display" : "ELECTROENCEPHALOGRAPHS"
        },
        {
          "code" : "Z12100303",
          "display" : "SYSTEMS FOR ANALYSING AND MANAGING EEG TRACES"
        },
        {
          "code" : "Z12100380",
          "display" : "ELECTROENCEPHALOGRAPHY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12100382",
          "display" : "ELECTROENCEPHALOGRAPHY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12100385",
          "display" : "ELECTROENCEPHALOGRAPHY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12100392",
          "display" : "ELECTROENCEPHALOGRAPHY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121004",
        "display" : "ELECTROMYOGRAPHY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12100401",
          "display" : "ELECTROMYOGRAPHS"
        },
        {
          "code" : "Z12100480",
          "display" : "ELECTROMYOGRAPHY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12100482",
          "display" : "ELECTROMYOGRAPHY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12100485",
          "display" : "ELECTROMYOGRAPHY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12100492",
          "display" : "ELECTROMYOGRAPHY INSTRUMENTS -MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121005",
        "display" : "POLYSOMNOGRAPHY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12100501",
          "display" : "POLYSOMNOGRAPHS"
        },
        {
          "code" : "Z12100580",
          "display" : "POLYSOMNOGRAPHY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12100582",
          "display" : "POLYSOMNOGRAPHY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12100585",
          "display" : "POLYSOMNOGRAPHY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12100592",
          "display" : "POLYSOMNOGRAPHY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121006",
        "display" : "STEREOTACTIC NEUROSURGERY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12100601",
          "display" : "STEREOTACTIC NEUROSURGERY SYSTEMS"
        },
        {
          "code" : "Z12100680",
          "display" : "STEREOTACTIC NEUROSURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12100682",
          "display" : "STEREOTACTIC NEUROSURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12100685",
          "display" : "STEREOTACTIC NEUROSURGERY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12100692",
          "display" : "STEREOTACTIC NEUROSURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121007",
        "display" : "ELECTROMYOGRAPHIC (EMG) TELEMETRY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12100701",
          "display" : "EMG TELEMETRY SYSTEMS"
        },
        {
          "code" : "Z12100702",
          "display" : "EMG TELEMETRIC TRANSMITTERS"
        },
        {
          "code" : "Z12100703",
          "display" : "EMG TELEMETRY RECEIVERS"
        },
        {
          "code" : "Z12100780",
          "display" : "EMG TELEMETRY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12100782",
          "display" : "EMG TELEMETRY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12100785",
          "display" : "EMG TELEMETRY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12100792",
          "display" : "EMG TELEMETRY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121008",
        "display" : "ELECTROENCEPHALOGRAPHIC (EEG) TELEMETRY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12100801",
          "display" : "EEG TELEMETRY SYSTEMS"
        },
        {
          "code" : "Z12100802",
          "display" : "EEG TELEMETRY TRANSMITTERS"
        },
        {
          "code" : "Z12100803",
          "display" : "EEG TELEMETRY RECEIVERS"
        },
        {
          "code" : "Z12100880",
          "display" : "EEG TELEMETRY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12100882",
          "display" : "EEG TELEMETRY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12100885",
          "display" : "EEG TELEMETRY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12100892",
          "display" : "EEG TELEMETRY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121009",
        "display" : "INSTRUMENTS FOR MOTORISED NEUROSURGERY SYSTEMS",
        "concept" : [{
          "code" : "Z12100901",
          "display" : "MOTORISED NEUROSURGERY SYSTEMS"
        },
        {
          "code" : "Z12100902",
          "display" : "DRILLS FOR NEUROSURGERY"
        },
        {
          "code" : "Z12100980",
          "display" : "INSTRUMENTS FOR MOTORISED NEUROSURGERY SYSTEMS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12100982",
          "display" : "INSTRUMENTS FOR MOTORISED NEUROSURGERY SYSTEMS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12100985",
          "display" : "INSTRUMENTS FOR MOTORISED NEUROSURGERY SYSTEMS - CONSUMABLES"
        },
        {
          "code" : "Z12100992",
          "display" : "INSTRUMENTS FOR MOTORISED NEUROSURGERY SYSTEMS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121010",
        "display" : "ELECTROENCEPHALOGRAPHIC (EEG) HOLTER SYSTEMS INSTRUMENTS",
        "concept" : [{
          "code" : "Z12101001",
          "display" : "EEG HOLTER SYSTEMS"
        },
        {
          "code" : "Z12101002",
          "display" : "EEG HOLTER READERS"
        },
        {
          "code" : "Z12101003",
          "display" : "EEG HOLTER RECORDERS"
        },
        {
          "code" : "Z12101080",
          "display" : "EEG HOLTER SYSTEMS INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12101082",
          "display" : "EEG HOLTER SYSTEMS INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12101085",
          "display" : "EEG HOLTER SYSTEMS INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12101092",
          "display" : "EEG HOLTER SYSTEMS INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121011",
        "display" : "PERIPHERAL OR CENTRAL NEURO STIMULATION AND ASSESSMENT INSTRUMENTS",
        "concept" : [{
          "code" : "Z12101101",
          "display" : "SOMATOSENSORY EVOKED POTENTIAL ANALYSERS"
        },
        {
          "code" : "Z12101102",
          "display" : "ELECTRODE POSITIONING SYSTEMS FOR BRAIN STIMULATION"
        },
        {
          "code" : "Z12101103",
          "display" : "SOMATOSENSORY EVOKED POTENTIAL INTEGRATED SYSTEMS"
        },
        {
          "code" : "Z12101104",
          "display" : "CEREBRAL MAPPING SYSTEMS"
        },
        {
          "code" : "Z12101105",
          "display" : "MAGNETIC STIMULATORS"
        },
        {
          "code" : "Z12101106",
          "display" : "NEUROLOGICAL STIMULATORS"
        },
        {
          "code" : "Z12101180",
          "display" : "PERIPHERAL OR CENTRAL NEURO STIMULATION AND ASSESSMENT INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12101182",
          "display" : "PERIPHERAL OR CENTRAL NEURO STIMULATION AND ASSESSMENT INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12101185",
          "display" : "PERIPHERAL OR CENTRAL NEURO STIMULATION AND ASSESSMENT INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12101192",
          "display" : "PERIPHERAL OR CENTRAL NEURO STIMULATION AND ASSESSMENT INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12101199",
          "display" : "PERIPHERAL OR CENTRAL NEURO STIMULATION AND ASSESSMENT INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z121012",
        "display" : "MAGNETOENCEPHALOGRAPHY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12101201",
          "display" : "MAGNETOENCEPHALOGRAPHY SYSTEMS"
        },
        {
          "code" : "Z12101280",
          "display" : "MAGNETOENCEPHALOGRAPHY INSTRUMENTS – HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12101282",
          "display" : "MAGNETOENCEPHALOGRAPHY INSTRUMENTS – SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12101285",
          "display" : "MAGNETOENCEPHALOGRAPHY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12101292",
          "display" : "MAGNETOENCEPHALOGRAPHY INSTRUMENTS – MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121090",
        "display" : "VARIOUS NEUROLOGY AND NEUROSURGERY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12109001",
          "display" : "DETACHABLE COIL EQUIPMENT FOR BRAIN ANEURYSMS"
        },
        {
          "code" : "Z12109002",
          "display" : "ELECTROCONVULSIVE THERAPY (ECT) EQUIPMENT"
        },
        {
          "code" : "Z12109003",
          "display" : "CEREBROSPINAL FLUID PRESSURE MONITORING SYSTEMS"
        },
        {
          "code" : "Z12109004",
          "display" : "VIBRATION THRESHOLD METERS (VIBROMETER)"
        },
        {
          "code" : "Z12109005",
          "display" : "REACTION TIME/REFLEX METERS"
        },
        {
          "code" : "Z12109006",
          "display" : "BRAIN TISSUE MONITORING SYSTEMS"
        },
        {
          "code" : "Z12109007",
          "display" : "PSYCHOMETRIC TESTING SYSTEMS"
        },
        {
          "code" : "Z12109080",
          "display" : "VARIOUS NEUROLOGY AND NEUROSURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12109082",
          "display" : "VARIOUS NEUROLOGY AND NEUROSURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12109085",
          "display" : "VARIOUS NEUROLOGY AND NEUROSURGERY INSTRUMENTS - SPECIFIC MATERIALS"
        },
        {
          "code" : "Z12109092",
          "display" : "VARIOUS NEUROLOGY AND NEUROSURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12109099",
          "display" : "VARIOUS NEUROLOGY AND NEUROSURGERY INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1211",
      "display" : "DENTAL STOMATOLOGY INSTRUMENTS",
      "concept" : [{
        "code" : "Z121101",
        "display" : "INSTRUMENTS FOR DENTAL TREATMENT UNITS",
        "concept" : [{
          "code" : "Z12110101",
          "display" : "DENTAL TREATMENT UNITS"
        },
        {
          "code" : "Z12110102",
          "display" : "DENTAL DRILLS"
        },
        {
          "code" : "Z12110180",
          "display" : "INSTRUMENTS FOR DENTAL TREATMENT UNITS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12110182",
          "display" : "INSTRUMENTS FOR DENTAL TREATMENT UNITS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12110185",
          "display" : "INSTRUMENTS FOR DENTAL TREATMENT UNITS - CONSUMABLES"
        },
        {
          "code" : "Z12110192",
          "display" : "INSTRUMENTS FOR DENTAL TREATMENT UNITS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12110199",
          "display" : "INSTRUMENTS FOR DENTAL TREATMENT UNITS - OTHER"
        }]
      },
      {
        "code" : "Z121190",
        "display" : "VARIOUS DENTAL STOMATOLOGY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12119001",
          "display" : "TARTAR ABLATORS"
        },
        {
          "code" : "Z12119002",
          "display" : "AMALGAMATORS"
        },
        {
          "code" : "Z12119003",
          "display" : "COLD LIGHT DENTAL EQUIPMENT"
        },
        {
          "code" : "Z12119004",
          "display" : "EQUIPMENT FOR DIAGNOSIS OF PERIODONTAL DISEASES"
        },
        {
          "code" : "Z12119005",
          "display" : "PULP VITALITY ANALYSERS"
        },
        {
          "code" : "Z12119006",
          "display" : "DENTAL CLEANING/WASHING HANDPIECE EQUIPMENTS"
        },
        {
          "code" : "Z12119007",
          "display" : "DENTAL PROPHYLAXIS EQUIPMENT"
        },
        {
          "code" : "Z12119008",
          "display" : "ENDODONTIC COMPACTORS"
        },
        {
          "code" : "Z12119009",
          "display" : "APEX LOCATORS"
        },
        {
          "code" : "Z12119080",
          "display" : "VARIOUS DENTAL STOMATOLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12119082",
          "display" : "VARIOUS DENTAL STOMATOLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12119085",
          "display" : "VARIOUS DENTAL STOMATOLOGY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12119092",
          "display" : "VARIOUS DENTAL STOMATOLOGY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12119099",
          "display" : "VARIOUS DENTAL STOMATOLOGY INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1212",
      "display" : "OPHTHALMOLOGY INSTRUMENTS",
      "concept" : [{
        "code" : "Z121201",
        "display" : "OPHTALMOLOGY ASSESSMENTS AND DIAGNOSIS INSTRUMENTS",
        "concept" : [{
          "code" : "Z12120101",
          "display" : "LASER POLARIMETRY EQUIPMENT"
        },
        {
          "code" : "Z12120102",
          "display" : "COMPUTERISED OPTICAL BIOMETERS"
        },
        {
          "code" : "Z12120103",
          "display" : "ELECTRORETINOGRAPHS"
        },
        {
          "code" : "Z12120104",
          "display" : "EXOPHTHALMOMETERS"
        },
        {
          "code" : "Z12120105",
          "display" : "FLUOROANGIOGRAPHS"
        },
        {
          "code" : "Z12120106",
          "display" : "FLUOROPHOTOMETERS"
        },
        {
          "code" : "Z12120107",
          "display" : "PHOTOCHERATOSCOPES"
        },
        {
          "code" : "Z12120108",
          "display" : "SLIT LAMPS"
        },
        {
          "code" : "Z12120109",
          "display" : "RETINOSCOPY LAMPS"
        },
        {
          "code" : "Z12120110",
          "display" : "CORNEAL CONFOCAL MICROSCOPES"
        },
        {
          "code" : "Z12120111",
          "display" : "EYE MOVEMENT MONITORS"
        },
        {
          "code" : "Z12120112",
          "display" : "GLASSES FOR NYSTAGMUS"
        },
        {
          "code" : "Z12120113",
          "display" : "OPHTHALMOMETERS"
        },
        {
          "code" : "Z12120114",
          "display" : "OPHTHALMOSCOPES"
        },
        {
          "code" : "Z12120115",
          "display" : "OPTOMETERS"
        },
        {
          "code" : "Z12120116",
          "display" : "PACHYMETERS"
        },
        {
          "code" : "Z12120117",
          "display" : "INTRA-OCULAR PRESSURE REGULATORS"
        },
        {
          "code" : "Z12120118",
          "display" : "RETINOSCOPES"
        },
        {
          "code" : "Z12120119",
          "display" : "OPHTHALMOLOGICAL TREATMENT UNITS"
        },
        {
          "code" : "Z12120120",
          "display" : "INSTRUMENTS FOR THE ASSESSMENT OF VISUAL FUNCTIONALITY",
          "concept" : [{
            "code" : "Z1212012001",
            "display" : "VISUAL FUNCTIONAL ASSESSMENT EQUIPMENT"
          },
          {
            "code" : "Z1212012002",
            "display" : "ADAPTOMETERS"
          },
          {
            "code" : "Z1212012003",
            "display" : "PERIPHERAL VISION ANALYSERS"
          },
          {
            "code" : "Z1212012004",
            "display" : "HESS SCREENS"
          },
          {
            "code" : "Z1212012005",
            "display" : "ANOMALOSCOPES"
          },
          {
            "code" : "Z1212012080",
            "display" : "INSTRUMENTS FOR THE ASSESSMENT OF VISUAL FUNCTIONALITY - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1212012082",
            "display" : "INSTRUMENTS FOR THE ASSESSMENT OF VISUAL FUNCTIONALITY - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1212012085",
            "display" : "INSTRUMENTS FOR THE ASSESSMENT OF VISUAL FUNCTIONALITY - CONSUMABLES"
          },
          {
            "code" : "Z1212012092",
            "display" : "INSTRUMENTS FOR THE ASSESSMENT OF VISUAL FUNCTIONALITY - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1212012099",
            "display" : "INSTRUMENTS FOR THE ASSESSMENT OF VISUAL FUNCTIONALITY - OTHER"
          }]
        },
        {
          "code" : "Z12120121",
          "display" : "OPTICAL CONSISTENCY TOMOGRAPHS"
        },
        {
          "code" : "Z12120122",
          "display" : "TONOMETERS"
        },
        {
          "code" : "Z12120123",
          "display" : "COMPUTERISED CORNEAL TOPOGRAPHS"
        },
        {
          "code" : "Z12120124",
          "display" : "VIDEO/ELECTRONYSTAGMOGRAPHS"
        },
        {
          "code" : "Z12120125",
          "display" : "PUPILLOMETERS"
        },
        {
          "code" : "Z12120180",
          "display" : "OPHTALMOLOGY ASSESSMENTS AND DIAGNOSIS INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12120182",
          "display" : "OPHTALMOLOGY ASSESSMENTS AND DIAGNOSIS INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12120185",
          "display" : "OPHTALMOLOGY ASSESSMENTS AND DIAGNOSIS INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12120192",
          "display" : "OPHTALMOLOGY ASSESSMENTS AND DIAGNOSIS INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12120199",
          "display" : "OPHTALMOLOGY ASSESSMENTS AND DIAGNOSIS INSTRUMENTS – OTHER"
        }]
      },
      {
        "code" : "Z121202",
        "display" : "THERAPEUTIC AND SURGICAL OPHTHOLMOLOGICAL TREATMENTS INSTRUMENTS",
        "concept" : [{
          "code" : "Z12120201",
          "display" : "CROSS–EYE CONVERGENCE TRAINERS"
        },
        {
          "code" : "Z12120202",
          "display" : "LASER PHOTOCOAGULATORS"
        },
        {
          "code" : "Z12120203",
          "display" : "CORNEAL MILLER"
        },
        {
          "code" : "Z12120204",
          "display" : "SYNOPTISCOPES"
        },
        {
          "code" : "Z12120205",
          "display" : "INSTRUMENTS FOR MICROKERATOME SURGERY",
          "concept" : [{
            "code" : "Z1212020501",
            "display" : "MICROKERATOME LASERS"
          },
          {
            "code" : "Z1212020502",
            "display" : "MICROBLADE MICROKERATOMES"
          },
          {
            "code" : "Z1212020580",
            "display" : "MICROKERATOMY INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1212020582",
            "display" : "MICROKERATOMY INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1212020585",
            "display" : "MICROKERATOMY INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1212020592",
            "display" : "MICROKERATOMY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1212020599",
            "display" : "MICROKERATOMY INSTRUMENTS - OTHER"
          }]
        },
        {
          "code" : "Z12120206",
          "display" : "OPHTHALMIC ELECTROSURGERY INSTRUMENTS",
          "concept" : [{
            "code" : "Z1212020601",
            "display" : "OPHTHALMIC ELECTROSURGERY EQUIPMENT"
          },
          {
            "code" : "Z1212020602",
            "display" : "OPHTHALMIC MICRODIATHERMY COAGULATORS"
          },
          {
            "code" : "Z1212020680",
            "display" : "OPHTHALMIC ELECTROSURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1212020682",
            "display" : "OPHTHALMIC ELECTROSURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1212020685",
            "display" : "OPHTHALMIC ELECTROSURGERY INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1212020692",
            "display" : "OPHTHALMIC ELECTROSURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1212020699",
            "display" : "OPHTHALMIC ELECTROSURGERY INSTRUMENTS – OTHER"
          }]
        },
        {
          "code" : "Z12120207",
          "display" : "PHACO-VITRECTOMY INSTRUMENTS",
          "concept" : [{
            "code" : "Z1212020701",
            "display" : "PHACO-EMULSIFIERS"
          },
          {
            "code" : "Z1212020702",
            "display" : "PHACO-VITRECTOMY SYSTEMS"
          },
          {
            "code" : "Z1212020703",
            "display" : "VITRECTOMES"
          },
          {
            "code" : "Z1212020780",
            "display" : "PHACO-VITRECTOMY INSTRUMENTS - HARDWARE ACCESSORIES"
          },
          {
            "code" : "Z1212020782",
            "display" : "PHACO-VITRECTOMY INSTRUMENTS - SOFTWARE ACCESSORIES"
          },
          {
            "code" : "Z1212020785",
            "display" : "PHACO-VITRECTOMY INSTRUMENTS - CONSUMABLES"
          },
          {
            "code" : "Z1212020792",
            "display" : "PHACO-VITRECTOMY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
          },
          {
            "code" : "Z1212020799",
            "display" : "PHACO-VITRECTOMY INSTRUMENTS - OTHER"
          }]
        },
        {
          "code" : "Z12120208",
          "display" : "CORNEAL DRILLS"
        },
        {
          "code" : "Z12120280",
          "display" : "THERAPEUTIC AND SURGICAL OPHTHOLMOLOGICAL TREATMENTS INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12120282",
          "display" : "THERAPEUTIC AND SURGICAL OPHTHOLMOLOGICAL TREATMENTS INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12120285",
          "display" : "THERAPEUTIC AND SURGICAL OPHTHOLMOLOGICAL TREATMENTS INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12120292",
          "display" : "THERAPEUTIC AND SURGICAL OPHTHOLMOLOGICAL TREATMENTS INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12120299",
          "display" : "THERAPEUTIC AND SURGICAL OPHTHOLMOLOGICAL TREATMENTS INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z121290",
        "display" : "VARIOUS OPHTALMOLOGY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12129001",
          "display" : "OPHTHALMOLOGICAL INSTRUMENT STANDS"
        },
        {
          "code" : "Z12129080",
          "display" : "VARIOUS OPHTALMOLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12129082",
          "display" : "VARIOUS OPHTALMOLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12129085",
          "display" : "VARIOUS OPHTALMOLOGY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12129092",
          "display" : "VARIOUS OPHTALMOLOGY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12129099",
          "display" : "VARIOUS OPHTALMOLOGY INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1213",
      "display" : "ORTHOPAEDIC INSTRUMENTS",
      "concept" : [{
        "code" : "Z121301",
        "display" : "PERCUTANEOUS DISCECTOMY EQUIPMENT"
      },
      {
        "code" : "Z121302",
        "display" : "ORTHOPAEDIC TRACTION INSTRUMENTS",
        "concept" : [{
          "code" : "Z12130201",
          "display" : "TRACTION BEDS"
        },
        {
          "code" : "Z12130202",
          "display" : "TRACTION SYSTEMS"
        },
        {
          "code" : "Z12130280",
          "display" : "ORTHOPAEDIC TRACTION INSTRUMENTS – HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12130282",
          "display" : "ORTHOPAEDIC TRACTION INSTRUMENTS – SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12130285",
          "display" : "ORTHOPAEDIC TRACTION INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12130292",
          "display" : "ORTHOPAEDIC TRACTION INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121303",
        "display" : "BONE GROWTH STIMULATION INSTRUMENTS",
        "concept" : [{
          "code" : "Z12130301",
          "display" : "BONE GROWTH STIMULATORS"
        },
        {
          "code" : "Z12130380",
          "display" : "BONE GROWTH STIMULATION INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12130382",
          "display" : "BONE GROWTH STIMULATION INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12130385",
          "display" : "BONE GROWTH STIMULATION INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12130392",
          "display" : "BONE GROWTH STIMULATION INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121304",
        "display" : "STEREOTACTIC ORTHOPAEDIC SURGERY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12130401",
          "display" : "STEREOTACTIC ORTHOPAEDIC SURGERY SYSTEMS"
        },
        {
          "code" : "Z12130480",
          "display" : "STEREOTACTIC ORTHOPAEDIC SURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12130482",
          "display" : "STEREOTACTIC ORTHOPAEDIC SURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12130485",
          "display" : "STEREOTACTIC ORTHOPAEDIC SURGERY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12130492",
          "display" : "STEREOTACTIC ORTHOPAEDIC SURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121305",
        "display" : "MOTORISED ORTHOPAEDIC SURGERY SYSTEM INSTRUMENTS",
        "concept" : [{
          "code" : "Z12130501",
          "display" : "MOTORISED ORTHOPAEDIC SURGERY SYSTEMS"
        },
        {
          "code" : "Z12130502",
          "display" : "ORTHOPAEDIC SURGICAL SAWS"
        },
        {
          "code" : "Z12130503",
          "display" : "ORTHOPAEDIC SURGICAL DRILLS"
        },
        {
          "code" : "Z12130580",
          "display" : "MOTORISED ORTHOPAEDIC SURGERY SYSTEM INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12130582",
          "display" : "MOTORISED ORTHOPAEDIC SURGERY SYSTEM INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12130585",
          "display" : "MOTORISED ORTHOPAEDIC SURGERY SYSTEM INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12130592",
          "display" : "MOTORISED ORTHOPAEDIC SURGERY SYSTEM INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12130599",
          "display" : "MOTORISED ORTHOPAEDIC SURGERY SYSTEM INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z121390",
        "display" : "VARIOUS ORTHOPAEDIC AND TRAUMATOLOGY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12139001",
          "display" : "SHOCK WAVE THERAPY EQUIPMENT"
        },
        {
          "code" : "Z12139002",
          "display" : "PROSTHETIC CEMENT REMOVAL EQUIPMENT"
        },
        {
          "code" : "Z12139003",
          "display" : "PODOSCOPE SYSTEMS"
        },
        {
          "code" : "Z12139004",
          "display" : "PODOLOGICAL TREATMENT UNITS"
        },
        {
          "code" : "Z12139005",
          "display" : "PLASTER CAST SAWS"
        },
        {
          "code" : "Z12139006",
          "display" : "PNEUMATIC TOURNIQUETS"
        },
        {
          "code" : "Z12139080",
          "display" : "VARIOUS ORTHOPAEDIC AND TRAUMATOLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12139082",
          "display" : "VARIOUS ORTHOPAEDIC AND TRAUMATOLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12139085",
          "display" : "VARIOUS ORTHOPAEDIC AND TRAUMATOLOGY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12139092",
          "display" : "VARIOUS ORTHOPAEDIC AND TRAUMATOLOGY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12139099",
          "display" : "VARIOUS ORTHOPAEDIC AND TRAUMATOLOGY INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1214",
      "display" : "ENT INSTRUMENTS",
      "concept" : [{
        "code" : "Z121401",
        "display" : "AUDIOMETERS"
      },
      {
        "code" : "Z121402",
        "display" : "ENT TREATMENT UNITS"
      },
      {
        "code" : "Z121403",
        "display" : "EVOKED POTENTIAL AUDIOMETRY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12140301",
          "display" : "EVOKED POTENTIAL AUDIOMETRY INTEGRATED SYSTEMS"
        },
        {
          "code" : "Z12140302",
          "display" : "EVOKED POTENTIAL AUDIOMETRY EQUIPMENTS"
        },
        {
          "code" : "Z12140380",
          "display" : "EVOKED POTENTIAL AUDIOMETRY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12140382",
          "display" : "EVOKED POTENTIAL AUDIOMETRY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12140385",
          "display" : "EVOKED POTENTIAL AUDIOMETRY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12140392",
          "display" : "EVOKED POTENTIAL AUDIOMETRY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121404",
        "display" : "VESTIBULAR SYSTEM ANALYSIS INSTRUMENTS",
        "concept" : [{
          "code" : "Z12140401",
          "display" : "VESTIBULAR ASSESSMENT SYSTEMS"
        },
        {
          "code" : "Z12140402",
          "display" : "VESTIBULAR ASSESSMENTSTABILOMETRIC PLATFORMS"
        },
        {
          "code" : "Z12140403",
          "display" : "ROTATING PENDULAR CHAIRS"
        },
        {
          "code" : "Z12140404",
          "display" : "POSTUROGRAPHY SYSTEMS"
        },
        {
          "code" : "Z12140480",
          "display" : "VESTIBULAR SYSTEM ANALYSIS INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12140482",
          "display" : "VESTIBULAR SYSTEM ANALYSIS INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12140485",
          "display" : "VESTIBULAR SYSTEM ANALYSIS INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12140492",
          "display" : "VESTIBULAR SYSTEM ANALYSIS INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121405",
        "display" : "STEREOTACTIC ENT SURGERY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12140501",
          "display" : "STEREOTACTIC ENT SURGERY SYSTEMS"
        },
        {
          "code" : "Z12140580",
          "display" : "STEREOTACTIC ENT SURGERY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12140582",
          "display" : "STEREOTACTIC ENT SURGERY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12140585",
          "display" : "STEREOTACTIC ENT SURGERY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12140592",
          "display" : "STEREOTACTIC ENT SURGERY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121490",
        "display" : "VARIOUS ENT INSTRUMENTS",
        "concept" : [{
          "code" : "Z12149001",
          "display" : "OTOACOUSTIC EMISSIONS EQUIPMENT"
        },
        {
          "code" : "Z12149002",
          "display" : "AUDIOMETRIC CHAMBERS"
        },
        {
          "code" : "Z12149003",
          "display" : "OLFACTOMETERS"
        },
        {
          "code" : "Z12149004",
          "display" : "OTO-CALORIC STIMULATORS"
        },
        {
          "code" : "Z12149005",
          "display" : "IMPEDANCE METERS FOR THE AUDITORY SYSTEM"
        },
        {
          "code" : "Z12149006",
          "display" : "DIRECT OUTPATIENT OTOSCOPES"
        },
        {
          "code" : "Z12149007",
          "display" : "OTOLOGICAL DRILLS"
        },
        {
          "code" : "Z12149008",
          "display" : "RHINOANEMOMETERS"
        },
        {
          "code" : "Z12149009",
          "display" : "RHINOMETERS"
        },
        {
          "code" : "Z12149010",
          "display" : "VOICE DISPLAYS"
        },
        {
          "code" : "Z12149011",
          "display" : "ELECTRIC PHARYNGEAL STIMULATORS"
        },
        {
          "code" : "Z12149080",
          "display" : "VARIOUS ENT INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12149082",
          "display" : "VARIOUS ENT INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12149085",
          "display" : "VARIOUS ENT INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12149092",
          "display" : "VARIOUS ENT INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12149099",
          "display" : "VARIOUS ENT INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1215",
      "display" : "PNEUMONOLOGY AND RESPIRATORY PHYSIOPATHOLOGY INSTRUMENTS",
      "concept" : [{
        "code" : "Z121501",
        "display" : "SPIROMETRY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12150101",
          "display" : "CLINICAL/DIAGNOSTIC SPIROMETERS"
        },
        {
          "code" : "Z12150102",
          "display" : "PEAK FLOW SPIROMETERS"
        },
        {
          "code" : "Z12150180",
          "display" : "SPIROMETRY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12150182",
          "display" : "SPIROMETRY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12150185",
          "display" : "SPIROMETRY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12150192",
          "display" : "SPIROMETRY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12150199",
          "display" : "SPIROMETRY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z121502",
        "display" : "SPIROMETRIC TELEMETRY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12150201",
          "display" : "COMPLETE SPIROMETRIC TELEMETRY SYSTEMS"
        },
        {
          "code" : "Z12150202",
          "display" : "SPIROMETRIC TELEMETRY RECEIVERS"
        },
        {
          "code" : "Z12150203",
          "display" : "SPIROMETRIC TELEMETRY TRANSMITTERS"
        },
        {
          "code" : "Z12150280",
          "display" : "SPIROMETRIC TELEMETRY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12150282",
          "display" : "SPIROMETRIC TELEMETRY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12150285",
          "display" : "SPIROMETRIC TELEMETRY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12150292",
          "display" : "SPIROMETRIC TELEMETRY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121590",
        "display" : "VAROUS PNEUMOLOGY AND RESPIRATORY PHYSIOPATHOLOGY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12159001",
          "display" : "NITROGEN ANALYSERS"
        },
        {
          "code" : "Z12159002",
          "display" : "AEROSOL EQUIPMENT"
        },
        {
          "code" : "Z12159003",
          "display" : "DIFFUSION ANALYSIS EQUIPMENT"
        },
        {
          "code" : "Z12159004",
          "display" : "OXYGEN CONCENTRATORS"
        },
        {
          "code" : "Z12159005",
          "display" : "BRONCHOSTIMULATION DOSIMETERS"
        },
        {
          "code" : "Z12159006",
          "display" : "EXPIRATED GAS ANALYSERS"
        },
        {
          "code" : "Z12159007",
          "display" : "BODY PLETHYSMOGRAPHS"
        },
        {
          "code" : "Z12159008",
          "display" : "PNEUMOTACHOGRAPHS"
        },
        {
          "code" : "Z12159009",
          "display" : "EQUIPMENT FOR REMOVAL OF SECRETIONS"
        },
        {
          "code" : "Z12159010",
          "display" : "RHINOMANOMETERS"
        },
        {
          "code" : "Z12159011",
          "display" : "PNEUMOLOGICAL NAVIGATION SYSTEM"
        },
        {
          "code" : "Z12159080",
          "display" : "VAROUS PNEUMOLOGY AND RESPIRATORY PHYSIOPATHOLOGY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12159082",
          "display" : "VAROUS PNEUMOLOGY AND RESPIRATORY PHYSIOPATHOLOGY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12159085",
          "display" : "VAROUS PNEUMOLOGY AND RESPIRATORY PHYSIOPATHOLOGY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12159092",
          "display" : "VAROUS PNEUMOLOGY AND RESPIRATORY PHYSIOPATHOLOGY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12159099",
          "display" : "VAROUS PNEUMOLOGY AND RESPIRATORY PHYSIOPATHOLOGY INSTRUMENTS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1216",
      "display" : "UROLOGY INSTRUMENTS",
      "concept" : [{
        "code" : "Z121601",
        "display" : "EXTRACORPOREAL LITHOTRIPSY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12160101",
          "display" : "EXTRACORPOREAL LITHOTRIPTERS"
        },
        {
          "code" : "Z12160180",
          "display" : "EXTRACORPOREAL LITHOTRIPSY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12160182",
          "display" : "EXTRACORPOREAL LITHOTRIPSY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12160185",
          "display" : "EXTRACORPOREAL LITHOTRIPSY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12160192",
          "display" : "EXTRACORPOREAL LITHOTRIPSY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121602",
        "display" : "HOLTER SYSTEM INSTRUMENTS FOR URODYNAMIC PARAMETERS",
        "concept" : [{
          "code" : "Z12160201",
          "display" : "URODYNAMIC HOLTER ANALYSERS"
        },
        {
          "code" : "Z12160202",
          "display" : "URODYNAMIC HOLTER RECORDERS"
        },
        {
          "code" : "Z12160280",
          "display" : "HOLTER SYSTEM INSTRUMENTS FOR URODYNAMIC PARAMETERS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12160282",
          "display" : "HOLTER SYSTEM INSTRUMENTS FOR URODYNAMIC PARAMETERS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12160285",
          "display" : "HOLTER SYSTEM INSTRUMENTS FOR URODYNAMIC PARAMETERS - CONSUMABLES"
        },
        {
          "code" : "Z12160292",
          "display" : "HOLTER SYSTEM INSTRUMENTS FOR URODYNAMIC PARAMETERS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121603",
        "display" : "PROSTATE THERMOTHERAPY INSTRUMENTS",
        "concept" : [{
          "code" : "Z12160301",
          "display" : "EQUIPMENT FOR MICROWAVE PROSTATE THERMOTHERAPY"
        },
        {
          "code" : "Z12160302",
          "display" : "EQUIPMENT FOR LIQUID PROSTATE THERMOTHERAPY"
        },
        {
          "code" : "Z12160303",
          "display" : "EQUIPMENT FOR ULTRASONIC ONCOLOGY THERAPY"
        },
        {
          "code" : "Z12160380",
          "display" : "PROSTATE THERMOTHERAPY INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12160382",
          "display" : "PROSTATE THERMOTHERAPY INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12160385",
          "display" : "PROSTATE THERMOTHERAPY INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12160392",
          "display" : "PROSTATE THERMOTHERAPY INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12160399",
          "display" : "PROSTATE THERMOTHERAPY INSTRUMENTS - OTHER"
        }]
      },
      {
        "code" : "Z121604",
        "display" : "URODYNAMICS INSTRUMENTS",
        "concept" : [{
          "code" : "Z12160401",
          "display" : "URODYNAMICS SYSTEMS"
        },
        {
          "code" : "Z12160480",
          "display" : "URODYNAMICS INSTRUMENTS - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12160482",
          "display" : "URODYNAMICS INSTRUMENTS - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12160485",
          "display" : "URODYNAMICS INSTRUMENTS - CONSUMABLES"
        },
        {
          "code" : "Z12160492",
          "display" : "URODYNAMICS INSTRUMENTS - MEDICAL DEVICE SOFTWARE"
        }]
      },
      {
        "code" : "Z121605",
        "display" : "UROFLOWMETERS"
      },
      {
        "code" : "Z121690",
        "display" : "VARIOUS INSTRUMENTS FOR UROLOGY",
        "concept" : [{
          "code" : "Z12169001",
          "display" : "PENILE TUMESCENCE MEASURING EQUIPMENT"
        },
        {
          "code" : "Z12169002",
          "display" : "UROLOGICAL STIMULATORS"
        },
        {
          "code" : "Z12169003",
          "display" : "EJACULATION STIMULATORS"
        },
        {
          "code" : "Z12169004",
          "display" : "ERECTILE DYSFUNCTION STIMULATORS"
        },
        {
          "code" : "Z12169080",
          "display" : "VARIOUS INSTRUMENTS FOR UROLOGY - HARDWARE ACCESSORIES"
        },
        {
          "code" : "Z12169082",
          "display" : "VARIOUS INSTRUMENTS FOR UROLOGY - SOFTWARE ACCESSORIES"
        },
        {
          "code" : "Z12169085",
          "display" : "VARIOUS INSTRUMENTS FOR UROLOGY - CONSUMABLES"
        },
        {
          "code" : "Z12169092",
          "display" : "VARIOUS INSTRUMENTS FOR UROLOGY - MEDICAL DEVICE SOFTWARE"
        },
        {
          "code" : "Z12169099",
          "display" : "VARIOUS INSTRUMENTS FOR UROLOGY - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1217",
      "display" : "BLOOD TRANSFUSION INSTRUMENTS",
      "concept" : [{
        "code" : "Z121701",
        "display" : "BLOOD BANKS REFRIGERATORS"
      },
      {
        "code" : "Z121702",
        "display" : "PLASMA FREEZERS"
      },
      {
        "code" : "Z121703",
        "display" : "PLASMA THAWERS"
      },
      {
        "code" : "Z121704",
        "display" : "APHERESIS EQUIPMENT",
        "concept" : [{
          "code" : "Z12170401",
          "display" : "BLOOD DONATION APHERESIS EQUIPMENT"
        },
        {
          "code" : "Z12170402",
          "display" : "THERAPEUTIC APHERESIS EQUIPMENT"
        }]
      },
      {
        "code" : "Z121780",
        "display" : "BLOOD TRANSFUSION INSTRUMENTS - HARDWARE ACCESSORIES"
      },
      {
        "code" : "Z121799",
        "display" : "BLOOD TRANSFUSION INSTRUMENTS - OTHER"
      }]
    },
    {
      "code" : "Z1290",
      "display" : "VARIOUS INSTRUMENTS FOR FUNCTIONAL EXPLORATION AND THERAPEUTIC INTERVENTIONS",
      "concept" : [{
        "code" : "Z129003",
        "display" : "CYCLES FOR PHYSIOTHERAPY AND/OR DIAGNOSTIC USES"
      },
      {
        "code" : "Z129004",
        "display" : "LIGHT SOURCES"
      },
      {
        "code" : "Z129005",
        "display" : "GENERIC PHOTOSTIMULATORS"
      },
      {
        "code" : "Z129006",
        "display" : "TREADMILLS FOR PHYSIOTHERAPY AND/OR DIAGNOSTIC USES"
      },
      {
        "code" : "Z129007",
        "display" : "HANGING UNITS FOR THE OPERATING ROOM AND INTENSIVE CARE"
      },
      {
        "code" : "Z129009",
        "display" : "EQUIPMENT FOR ANALYSING POTENTIAL"
      },
      {
        "code" : "Z129010",
        "display" : "MULTI-DISCIPLINARY HOLTER SYSTEMS"
      },
      {
        "code" : "Z129011",
        "display" : "MULTI-DISCIPLINARY TELEMETRY SYSTEMS"
      },
      {
        "code" : "Z129012",
        "display" : "MULTI-FUNCTIONAL POLYGRAPHIC SYSTEMS"
      },
      {
        "code" : "Z129013",
        "display" : "GENERAL AUDITORY AND/OR VISUAL STIMULATORS"
      },
      {
        "code" : "Z129017",
        "display" : "BED HEAD UNITS"
      },
      {
        "code" : "Z129080",
        "display" : "VARIOUS INSTRUMENTS FOR FUNCTIONAL EXPLORATION AND THERAPEUTIC INTERVENTIONS - HARDWARE ACCESSORIES"
      },
      {
        "code" : "Z129082",
        "display" : "VARIOUS INSTRUMENTS FOR FUNCTIONAL EXPLORATION AND THERAPEUTIC INTERVENTIONS - SOFTWARE ACCESSORIES"
      },
      {
        "code" : "Z129085",
        "display" : "VARIOUS INSTRUMENTS FOR FUNCTIONAL EXPLORATION AND THERAPEUTIC INTERVENTIONS - SPECIFIC MATERIALS"
      },
      {
        "code" : "Z129092",
        "display" : "VARIOUS INSTRUMENTS FOR FUNCTIONAL EXPLORATION AND THERAPEUTIC INTERVENTIONS - MEDICAL DEVICE SOFTWARE"
      },
      {
        "code" : "Z129099",
        "display" : "VARIOUS INSTRUMENTS FOR FUNCTIONAL EXPLORATION AND THERAPEUTIC INTERVENTIONS - OTHER"
      }]
    }]
  },
  {
    "code" : "Z13",
    "display" : "NON-SPECIFIC CONSUMABLES FOR DIAGNOSTIC INSTRUMENTS",
    "concept" : [{
      "code" : "Z1301",
      "display" : "X-RAY FILMS",
      "concept" : [{
        "code" : "Z130101",
        "display" : "GENERAL PURPOSE X-RAY FILMS"
      },
      {
        "code" : "Z130102",
        "display" : "THORACIC X-RAY FILMS"
      },
      {
        "code" : "Z130103",
        "display" : "MAMMOGRAPHIC X-RAY FILMS"
      },
      {
        "code" : "Z130104",
        "display" : "ENDORAL DENTAL X-RAY FILMS"
      },
      {
        "code" : "Z130105",
        "display" : "EXTRA–ORAL DENTAL X-RAY FILMS"
      },
      {
        "code" : "Z130106",
        "display" : "DRY THERMAL PRINTER X-RAY FILMS"
      },
      {
        "code" : "Z130107",
        "display" : "FILMS FOR REPRODUCTION FROM LASER TECHNOLOGIES"
      },
      {
        "code" : "Z130190",
        "display" : "FILMS FOR VARIOUS USES",
        "concept" : [{
          "code" : "Z13019001",
          "display" : "FILMS FOR THE REPRODUCTION OF RADIOGRAMS (DUPLICATING)"
        },
        {
          "code" : "Z13019002",
          "display" : "RADIOTHERAPY VERIFICATION AND LOCALIZATION FILMS"
        },
        {
          "code" : "Z13019099",
          "display" : "X-RAY FILMS - OTHER"
        }]
      }]
    },
    {
      "code" : "Z1302",
      "display" : "DIAGNOSTIC REGISTRATION PAPERS"
    },
    {
      "code" : "Z1399",
      "display" : "NON-SPECIFIC CONSUMABLES FOR DIAGNOSTIC INSTRUMENTS - OTHER"
    }]
  }]
}

```
