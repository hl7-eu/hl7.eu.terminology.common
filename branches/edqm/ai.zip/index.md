# Home page - EU Common Terminologies v0.4.0

* [**Table of Contents**](toc.md)
* **Home page**

## Home page

| | |
| :--- | :--- |
| *Official URL*:http://hl7europe.org/fhir/terminology/common/ImplementationGuide/hl7.eu.terminology.common | *Version*:0.4.0 |
| Draft as of 2026-10-24 | *Computable Name*:EUCommon |

This is the HL7 Europe Common Terminology Package.

